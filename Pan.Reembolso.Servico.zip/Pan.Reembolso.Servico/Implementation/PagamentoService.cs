﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Servico.Results;
using System.Data;
using System.IO;
using System.Globalization;

namespace Pan.Reembolso.Servico.Implementation
{
    public class PagamentoService : IPagamentoService
    {
        private IPagamentoRepository _pagamentoRepository;
        private IContratoRepository _contratoRepository;
        private IReembolsoService _reembolsoService;
        private IReembolsoRepository _reembolsoRepository;
        private IFavorecidoService _objFavorecidoService;
        
        public PagamentoService(
            IPagamentoRepository pagamentoRepository,
            IReembolsoRepository reembolsoRepository,
            IContratoRepository contratoRepository,
            IFavorecidoService favorecidoService,
            IReembolsoService reembolsoService)
        {
            _pagamentoRepository = pagamentoRepository;
            _contratoRepository = contratoRepository;
            _reembolsoRepository = reembolsoRepository;
            _reembolsoService = reembolsoService;
            _objFavorecidoService = favorecidoService;
        }



        public void AprovarPagamento(List<long> ids, string status, string mensagemErro)
        {

            if (status == ReembolsoTypes.StatusReembolsoType.PagamentoLiberado.ToString())
            {

                var reembolsos = new List<Entidades.Reembolso>();
                foreach (var id in ids)
                {
                    reembolsos.Add(_reembolsoRepository.ObterReembolso(id));
                }

                var pagamento = new Entidades.Pagamento()
                {
                    valorPagamento = reembolsos.Sum(x => x.valorReembolso),
                    listaReembolsos = reembolsos
                };

                PersistirPagamento(pagamento);
            }

            _reembolsoService.AlterarStatusReembolso(ids, status, mensagemErro, "APROVAR REEMBOLSO");

        }

        public void PersistirPagamento(Pagamento pagamento)
        {
            pagamento.favorecido = _objFavorecidoService.ObterFavorecido(pagamento.listaReembolsos[0].contrato.cliente.numeroCpfCnpj);

            _pagamentoRepository.PersistirPagamento(pagamento);
        }

        public async Task<PagamentoResult> ObterRetiradaInterna(string cpfCnpj, string produto)
        {
            var result = new PagamentoResult();
            try
            {
                var retiradaInterna = await _pagamentoRepository.ConsultarRetiradaInterna(cpfCnpj, produto);
                result.Success = true;
                result.Retiradas = retiradaInterna;
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.MessageError = ex.Message;
                throw ex;
            }
        }

        public async Task<Result> EfetuarRetiradaInterna(List<long> ids, string cpfCnpj, decimal valor, bool retiradaTotal, string justificativa, string usuario)
        {
            var result = new PagamentoResult();

            try
            {
                // 1 - Obter os Reembolsos para Retirada
                var reembolsos = _reembolsoRepository.ObterListaReembolso(ids).OrderByDescending(s => s.dtInclusao);

                // 2 - Criar pagamento para a retirada

                var idsRetirar = new List<long>();

                decimal novoValorReembolso = 0;
                Entidades.Reembolso reembolsoOrigem = null;
                var saldoARetirar = valor;


                foreach(var reembolso in reembolsos)
                {
                    if (saldoARetirar <= 0)
                        continue;

                    idsRetirar.Add(reembolso.numeroReembolso);

                    if (saldoARetirar > reembolso.valorReembolso)
                    {
                        saldoARetirar -= reembolso.valorReembolso;
                    }
                    else
                    {
                        novoValorReembolso = reembolso.valorReembolso - saldoARetirar;
                        reembolsoOrigem = reembolso;
                    }
                }

                _reembolsoService.AlterarStatusReembolso(idsRetirar
                    , StatusReembolsoType.Reembolsado.ToString()
                    , justificativa
                    , "RETIRADA USO INTERNO");

                // Gerar Pagamento
                //PersistirPagamento(idsRetirar, valor, cpfCnpj);

                // Gerar Novo Reembolso
                //GerarReembolsoPorSaldo(reembolsoOrigem, novoValorReembolso);

                result.Success = true;
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.MessageError = ex.Message;
                throw ex;
            }
        }

        public async Task<Result> RetirarLoteUsoInterno(string file)
        {
            var result = new Result();

            try
            {
                string loteRetirada = string.Empty;
                var retiradas = await ObterDadosArquivo(@file);

                using (var reader = new StreamReader(@file))
                {
                    loteRetirada = await _pagamentoRepository.PersistirIntegracaoBulk(retiradas);
                }

                result.Success = true;
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }

        private void GerarReembolsoSaldoRemanescente(Entidades.Reembolso reembolsoOrigem, decimal novoValorReembolso, string usuario)
        {
            throw new NotImplementedException();
        }

        public Object ConsultarPagamentosPorStatus(DateTime? dtInicial, DateTime? dtFinal, string statusReembolso)
        {
            StatusReembolsoType statusEnum = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), statusReembolso);

            return _reembolsoRepository.ConsultarPagamentosPorStatus(dtInicial, dtFinal, statusEnum);
        }

        private async Task<DataTable> ObterDadosArquivo(string file)
        {
            var retiradas = _pagamentoRepository.ObterIntegracaoRetiradaDataTable();

            DataRow retirada;

            var idLoteRetirada = Guid.NewGuid();

            using (var reader = new StreamReader(@file))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    CultureInfo[] cultures = { new CultureInfo("en-US") };

                    retirada = retiradas.NewRow();

                    //retirada["ID_INTEGRACAO"] = 
                    retirada["NO_CPF_CNPJ"] = values[0];
                    retirada["CD_PRODUTO"] = values[1];
                    retirada["VL_RETIRADA"] = Convert.ToDecimal(values[2], cultures[0]);
                    retirada["ID_PAGAMENTO"] = null;
                    retirada["CD_LOTE_INTEGRACAO"] = idLoteRetirada;
                    retirada["CD_STATUS_INTEGRACAO"] = StatusIntegracaoType.Pendente.ToString();
                    retirada["DS_MENSAGEM_ERRO"] = null;
                    retirada["CD_USUARIO_INCLUSAO"] = "usuarioIntegracao";
                    //retirada["DT_INCLUSAO"] = DateTime.Now

                    retiradas.Rows.Add(retirada);
                }
            }

            return retiradas;
        }
    }
}
