﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Entidades.DatabaseEntities;

namespace Pan.Reembolso.Servico.Implementation
{
    public class PagamentoService : IPagamentoService
    {
        private IReembolsoService _objReembolsoService;
        private IHistoricoReembolsoService _objHistoricoReembolsoService;
        private IPagamentoRepository _objPagamentoRepository;
        private IReembolsoRepository _objReembolsoRepository;
        private IContratoRepository _objContratoRepository;

        public PagamentoService(IReembolsoService reembolsoService, 
            IHistoricoReembolsoService historicoReembolsoService, 
            IPagamentoRepository pagamentoRepository,
            IReembolsoRepository reembolsoRepository,
            IContratoRepository contratoRepository)

        {
            _objReembolsoService = reembolsoService;
            _objHistoricoReembolsoService = historicoReembolsoService;
            _objPagamentoRepository = pagamentoRepository;
            _objReembolsoRepository = reembolsoRepository;
            _objContratoRepository = contratoRepository;
        }

        public void PersistirPagamento(long[] idsReembolsos, string cpfOuCnpj)
        {
            var valor = _objReembolsoRepository.ObterValorTotalDeReembolsos(idsReembolsos);

            if (valor == 0)
            {
                throw new Exception("Erro: Não pode ser gerado pagamento de valor igual a 0");
            }
            //Verifica se já existe pagamento aberto para dado cpf
            PagamentoDatabase pagamentoDB = _objPagamentoRepository.ObterPagamentoAbertoPorCPF(cpfOuCnpj);

            var idPagamento = -1;

            //Persiste pagamento
            if (pagamentoDB != null)
            {
                idPagamento = _objPagamentoRepository.AtualizarPagamento(pagamentoDB, valor);
            }
            else
            {
                Contrato contrato = _objContratoRepository.ObterContratoPorIdReembolso(idsReembolsos.First());
                idPagamento = _objPagamentoRepository.IncluirPagamento(valor,contrato.numeroContrato);
            }

            //Adiciona pagamento na tabela intermediaria entre pagamento e reembolso
            _objPagamentoRepository.IncluirPagamentoReembolsosDB(idPagamento, idsReembolsos);

            //Gera Reembolso Historico
            List<HistoricoReembolso> lista = new List<HistoricoReembolso>();
            foreach (var reembolso in _objReembolsoRepository.ObterListaReembolso( idsReembolsos.ToList()))
            {

                lista.Add(_objHistoricoReembolsoService.GerarHistoricoReembolso(reembolso,StatusReembolsoType.EmTransito, "PAGAMENTO EFETUADO"));
            }
            //Altera Status dos Reembolsos que compoem o novo pagamento
            _objReembolsoService.AlterarStatusReembolso(idsReembolsos.ToList(), ReembolsoTypes.StatusReembolsoType.EmTransito.ToString(),"");
            
            //Persiste Reembolso Historico
            foreach (var historico in lista)
            {
                _objHistoricoReembolsoService.PersistirHistoricoReembolso(historico);
            }
            

  

        }


    }
}
