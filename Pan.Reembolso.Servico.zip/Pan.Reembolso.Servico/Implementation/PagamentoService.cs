﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Helper.Interface;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class PagamentoService : IPagamentoService
    {
        private IPagamentoRepository _pagamentoRepository;
        private IContratoRepository _contratoRepository;
        private IReembolsoService _reembolsoService;
        private IReembolsoRepository _reembolsoRepository;
        private IFavorecidoService _favorecidoService;
        private IReembolsoStatusHelper _reembolsoStatusHelper;
        private IProcessoRegistroRepository _processoRegistroRepository;
        private IMensagemRepository _mensagemRepository;
        private IMotivoBloqueioRepository _motivoBloqueioRepository;

        private IIdentity _user;

        public PagamentoService(
            IPagamentoRepository pagamentoRepository,
            IReembolsoRepository reembolsoRepository,
            IContratoRepository contratoRepository,
            IFavorecidoService favorecidoService,
            IReembolsoService reembolsoService,
            IReembolsoStatusHelper reembolsoStatusHelper,
            IProcessoRegistroRepository processoRegistroRepository,
            IMensagemRepository mensagemRepository,
            IMotivoBloqueioRepository motivoBloqueioRepository)
        {
            _pagamentoRepository = pagamentoRepository;
            _contratoRepository = contratoRepository;
            _reembolsoRepository = reembolsoRepository;
            _reembolsoService = reembolsoService;
            _favorecidoService = favorecidoService;
            _reembolsoStatusHelper = reembolsoStatusHelper;
            _processoRegistroRepository = processoRegistroRepository;
            _mensagemRepository = mensagemRepository;
            _motivoBloqueioRepository = motivoBloqueioRepository;
        }



        public void AprovarPagamento(List<long> ids, string status, string mensagemErro, string userId)
        {
            try
            {
                MotivoBloqueio motivoBloqueio = null;
                StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), status);

                if (statusReembolso == ReembolsoTypes.StatusReembolsoType.PagamentoLiberado)
                {
                    var reembolsos = new List<Entidades.Reembolso>();

                    foreach (var id in ids)
                    {
                        reembolsos.Add(_reembolsoRepository.ObterReembolso(id));
                    }

                    var pagamento = new Entidades.Pagamento()
                    {
                        valorPagamento = reembolsos.Sum(x => x.valorReembolso),
                        listaReembolsos = reembolsos
                    };

                    PersistirPagamento(pagamento);
                }
                else
                {
                    motivoBloqueio  = _motivoBloqueioRepository.ObterMotivoBloqueio(MotivoBloqueioType.AprovacaoPagamentoRejeitada);
                }

                
                  
                _reembolsoStatusHelper.AlterarStatusReembolso(ids, statusReembolso, mensagemErro, "APROVACAO REEMBOLSO", motivoBloqueio, userId);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public void PersistirPagamento(Pagamento pagamento)
        {
            pagamento.favorecido = _favorecidoService.ObterFavorecido(pagamento.listaReembolsos[0].contrato.cliente.numeroCpfCnpj);

            _pagamentoRepository.PersistirPagamento(pagamento);
        }

        public async Task<PagamentoResult<object>> ObterRetiradaInternaPorContrato(string cpfCnpj, string produto)
        {
            var result = new PagamentoResult<object>();
            try
            {
                var retiradaInterna = await _pagamentoRepository.ConsultarRetiradaInternaPorContrato(cpfCnpj, produto);
                result.Success = true;
                result.Retiradas = retiradaInterna;
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.MessageError = ex.Message;
                throw ex;
            }
        }

        public async Task<PagamentoResult<RetiradaUsoInterno>> ObterRetiradaInterna(string cpfCnpj, string produto)
        {
            var result = new PagamentoResult<RetiradaUsoInterno>();
            try
            {
                var retiradaInterna = await _pagamentoRepository.ConsultarRetiradaInterna(cpfCnpj, produto);
                result.Success = true;
                result.Retiradas = retiradaInterna;
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.MessageError = ex.Message;
                throw ex;
            }
        }

        public async Task<RetiradaUsoInternoResult> EfetuarRetiradaInterna(List<long> ids, string cpfCnpj, decimal valor, bool retiradaTotal, int processoRegistro, string justificativa, string userId)
        {
            var result = new RetiradaUsoInternoResult();

            try
            {
                var reembolsosRetirar = new List<Entidades.Reembolso>();

                var procRegistro = _processoRegistroRepository.ObterProcessoRegistroPorCodigoFluxo(processoRegistro, "SAIDA");

                var statusAceitaveis = new List<string>()
                {
                    StatusReembolsoType.Registrado.ToString(),
                    StatusReembolsoType.Bloqueado.ToString()
                };

                // 1 - Obter os Reembolsos para Retirada
                var reembolsos = _reembolsoRepository.ObterListaReembolso(ids).Where(f => statusAceitaveis.Contains( f.statusReembolso)  ).ToList();

                if (reembolsos.Count == 0)
                {
                    result.Success = false;
                    result.MessageError = "Não existem reembolsos para serem efetivados";
                    return result;
                }
                    

                // 2 - Criar pagamento para a retirada
                decimal novoValorReembolso = 0;
                Entidades.Reembolso reembolsoOrigem = null;
                var saldoARetirar = valor;

                foreach(var reembolso in reembolsos)
                {
                    if (saldoARetirar <= 0)
                        continue;

                    //idsRetirar.Add(reembolso.numeroReembolso);
                    reembolsosRetirar.Add(reembolso);

                    if (saldoARetirar > reembolso.valorReembolso)
                    {
                        saldoARetirar -= reembolso.valorReembolso;
                    }
                    else
                    {
                        novoValorReembolso = reembolso.valorReembolso - saldoARetirar;
                        reembolsoOrigem = reembolso;
                        saldoARetirar = 0;
                    }
                }

                _reembolsoStatusHelper.AlterarStatusReembolso(reembolsosRetirar.Select(x => x.idReembolso).ToList()
                    , StatusReembolsoType.RetiradaUsoInterno
                    , procRegistro.processoRegistro
                    , "RETIRADA USO INTERNO"
                    , null
                    , userId
                    , procRegistro.codigoProcessoRegistro
                    , userId);



                foreach (var reembolso in reembolsosRetirar)
                {
                    var reembolsoResult = new IdReembolsoResult
                    {
                        idReembolso = reembolso.numeroReembolso,
                        valorReembolso = reembolso.valorReembolso,
                        statusReembolso = StatusReembolsoType.RetiradaUsoInterno.ToString()
                    };

                    result.Reembolsos.Add(reembolsoResult);
                }

                // Gerar Pagamento
                var pagamento = await GerarPagamentoUsoInterno(reembolsosRetirar.Select(x => x.idReembolso).ToList(), valor);
                
                // Gerar Novo Reembolso
                if (novoValorReembolso > 0)
                {
                    var novoReembolso = await GerarReembolsoSaldoRemanescente(reembolsoOrigem, novoValorReembolso, processoRegistro, userId);

                    var reembolsoResult = new IdReembolsoResult
                    {
                        idReembolso = novoReembolso.numeroReembolso,
                        valorReembolso = novoReembolso.valorReembolso,
                        statusReembolso = novoReembolso.statusReembolso
                    };

                    result.Reembolsos.Add(reembolsoResult);

                    _reembolsoService.ProcessarReembolsoAsync(new List<Entidades.Reembolso>() { novoReembolso }); 
                }

                result.Success = true;

                result.PagamentoEfetuado = pagamento;

                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                result.MessageError = ex.Message;
                throw ex;
            }
        }

        public async Task<Pagamento> GerarPagamentoUsoInterno(List<long> idsReembolsos, decimal valor)
        {
            var reembolsos = new List<Entidades.Reembolso>();
            foreach (var id in idsReembolsos)
            {
                reembolsos.Add(_reembolsoRepository.ObterReembolso(id));
            }

            var pagamento = new Entidades.Pagamento()
            {
                valorPagamento = valor,
                listaReembolsos = reembolsos,
                statusPagamento = StatusPagamentoType.Efetivado.ToString(),
                tipoPagamento = PagamentoType.UsoInterno.ToString()
            };

            _pagamentoRepository.IncluirPagamento(pagamento);

            return pagamento;
        }

        public async Task<LoteRetiradaResult> RetirarLoteUsoInterno(string file)
        {
            var result = new LoteRetiradaResult();

            try
            {
                int idLoteRetirada = _pagamentoRepository.GerarNovoLoteIntegracao();

                var retiradas = await ObterDadosArquivo(@file, idLoteRetirada);

                using (var reader = new StreamReader(@file))
                {
                    await _pagamentoRepository.PersistirIntegracaoBulk(retiradas);
                }

                result.idLoteIntegracao = idLoteRetirada;
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }
        public void AtualizarIntegracaoRetiradaUsoInternoLote(IntegracaoRetiradaUsoInterno integracaoRetiradaUsoInterno)
        {
            _pagamentoRepository.AtualizarIntegracaoRetiradaUsoInternoLote(integracaoRetiradaUsoInterno);
        }
        public List<Entidades.IntegracaoRetiradaUsoInterno> ConsultarRetiradasPendentesLote()
        {
            return _pagamentoRepository.ConsultarRetiradasPendentesLote();
        }
        private async Task<Entidades.Reembolso> GerarReembolsoSaldoRemanescente(Entidades.Reembolso reembolsoOrigem
            , decimal novoValorReembolso
            , int processoRegistro
            , string usuario)
        {

            var reembolso = new Entidades.Reembolso();

            reembolso.dtInclusao = DateTime.Now;

            reembolso.valorReembolso = novoValorReembolso;

            reembolso.usuarioInclusao = usuario;

            reembolso.statusReembolso = StatusReembolsoType.Registrado.ToString();

            reembolso.contrato = reembolsoOrigem.contrato;

            reembolso.mesCompetencia = reembolsoOrigem.mesCompetencia;

            reembolso.anoCompetencia = reembolsoOrigem.anoCompetencia;

            reembolso.processoRegistro = _processoRegistroRepository.ObterProcessoRegistroPorCodigoFluxo(Convert.ToInt16(ReembolsoConstantes.PROCESSO_REGISTRO_SALDO_RETIRADA_USO_INTERNO), "ENTRADA");

            reembolso.sigla = reembolsoOrigem.sigla;

            reembolso.departamento = reembolsoOrigem.departamento;

            reembolso.dataSolicitacao = reembolsoOrigem.dataSolicitacao;

            reembolso.lote = reembolsoOrigem.lote;

            reembolso.motivoBloqueio = null;

            _reembolsoService.PersistirReembolso(reembolso, usuario);

            return reembolso;
        }

        public Aprovacao ConsultarPagamentosPorStatus(DateTime? dtInicial, DateTime? dtFinal, string statusReembolso)
        {
            StatusReembolsoType statusEnum = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), statusReembolso);

            return _reembolsoRepository.ConsultarPagamentosARealizarPorStatus(dtInicial, dtFinal, statusEnum);
        }

        private async Task<DataTable> ObterDadosArquivo(string file, int idLote)
        {
            var retiradas = _pagamentoRepository.ObterIntegracaoRetiradaDataTable();

            DataRow retirada;

            using (var reader = new StreamReader(@file))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    CultureInfo[] cultures = { new CultureInfo("en-US") };

                    retirada = retiradas.NewRow();

                    retirada["NO_CPF_CNPJ"] = values[0];
                    retirada["CD_PRODUTO"] = values[1];
                    retirada["VL_RETIRADA"] = Convert.ToDecimal(values[2], cultures[0]);
                    retirada["ID_PAGAMENTO"] = DBNull.Value;
                    retirada["CD_PROCESSO_REGISTRO"] = values[3];
                    retirada["CD_LOTE_INTEGRACAO"] = idLote;
                    retirada["CD_STATUS_INTEGRACAO"] = StatusIntegracaoType.Pendente.ToString();
                    retirada["DS_MENSAGEM_ERRO"] = DBNull.Value;
                    retirada["CD_USUARIO_INCLUSAO"] = "usuarioIntegracao";
                    retirada["DT_INCLUSAO"] = DateTime.Now;

                    retiradas.Rows.Add(retirada);
                }
            }

            return retiradas;
        }

        public IList<Object> ObterHistoricoPorIdReembolso(long idReembolso)
        {
            return _mensagemRepository.ObterHistoricoPorIdReembolso(idReembolso);
        }

        public async Task<IntegracaoRetiradaResult> ObterLoteRetiradaInterna(int idLote, DateTime? dataIni, DateTime? dataFim, StatusIntegracaoType status)
        {
            var result = new IntegracaoRetiradaResult();
            try
            {
                var retiradaInterna = await _pagamentoRepository.ConsultarLoteRetiradaInterna(idLote, dataIni, dataFim, status);
                result.Success = true;
                result.Retiradas = retiradaInterna;
                return result;
            }
            catch (Exception ex)
            {
                result.Success = false;
                result.MessageError = ex.Message;
                throw ex;
            }
        }
    }
}
