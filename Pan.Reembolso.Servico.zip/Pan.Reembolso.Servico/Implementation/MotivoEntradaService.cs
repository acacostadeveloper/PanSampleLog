﻿using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class MotivoEntradaService : IMotivoEntradaService
    {

        private readonly IMotivoEntradaRepository _objMotivoEntradaRepository;


        public MotivoEntradaService( IMotivoEntradaRepository MotivoEntradaRepository )
        {
            _objMotivoEntradaRepository = MotivoEntradaRepository;
        }

        public List<Entidades.MotivoEntrada> ObterMotivosEntrada()
        {
            return _objMotivoEntradaRepository.ObterMotivosEntrada();
        }
    }
}
