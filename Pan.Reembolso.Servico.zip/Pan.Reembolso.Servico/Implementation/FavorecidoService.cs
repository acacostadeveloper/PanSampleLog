﻿using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class FavorecidoService : IFavorecidoService
    {
        //private readonly IContaCreditoRepository _contaCreditoRepository;
        private readonly ITransferenciaDireitoRepository _objTransferenciaDireitoRepository;
        private readonly IClienteRepository _objClienteRepository;
        private readonly IContaCreditoRepository _objContaCreditoRepository;

        public FavorecidoService
            (
            //IContaCreditoRepository contaCreditoRepository
            ITransferenciaDireitoRepository transferenciaDireitoRepository,
            IClienteRepository clienteRepository,
            IContaCreditoRepository contaCreditoRepository
            )
        {
            //_contaCreditoRepository = contaCreditoRepository;
            _objClienteRepository = clienteRepository;
            _objTransferenciaDireitoRepository = transferenciaDireitoRepository;
            _objContaCreditoRepository = contaCreditoRepository;
        }

        public Entidades.Favorecido ObterFavorecido(string cpfCnpjCliente)
        {
            var result = new Entidades.Favorecido();

            var transf = _objTransferenciaDireitoRepository.ObterTransferenciaDireitoAtivoPorCpfCliente(cpfCnpjCliente);

            if (transf != null && transf.Ativa())
            {
                result.numeroCpfCnpj = transf.numeroCpfCnpj;
                result.nome = transf.nome;
                result.sequenciaCpfCnpj = transf.sequenciaCpfCnpj;
                result.tipoPesssoa = transf.tipoPesssoa;
                result.contaCredito = transf.contaCredito;
            }
            else
            {
                var cliente = _objClienteRepository.ObterCliente(cpfCnpjCliente);
                result.numeroCpfCnpj = cliente.numeroCpfCnpj;
                result.nome = cliente.nomeCliente;
                result.sequenciaCpfCnpj = 0;
                result.tipoPesssoa = cliente.GetTipoDePessoa();
                result.contaCredito = cliente.contaCredito;
            }

            return result;
        }
    }
}
