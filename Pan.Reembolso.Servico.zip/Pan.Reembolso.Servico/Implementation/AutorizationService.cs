﻿using Pan.Reembolso.Infra.Autentication.Interface;
using Pan.Reembolso.Infra.Security.Helper;
using Pan.Reembolso.Infra.Security.Interface;
using Pan.Reembolso.Servico.Interface;
using System.Linq;
using System.Security.Principal;
using Pan.Reembolso.Infra.Autentication.Entidades;

namespace Pan.Reembolso.Servico.Implementation
{

    public class AutorizationService : IAutorizationService
    {
        private readonly IAutorization _autorization;
        private readonly IAutenticationUserRepository _autenticationUserRepository;

        public AutorizationService(IAutorization autorization, IAutenticationUserRepository autenticationUserRepository)
        {
            _autorization = autorization;
            _autenticationUserRepository = autenticationUserRepository;
        }

        public UserAuthorization Authorize(string token)
        {
            var userName = _autorization.ValidateToken(token);

            //var user = GetUser(userName);

            //return user;

            return null;
        }

        public string GetToken(string userName, string password)
        {
            return _autorization.GetToken(userName, password);
        }

        public UserAuthorization GetUser(string userName)
        {
            var principal = new GenericPrincipal(new GenericIdentity(userName), null);

            string userId = principal.Identity.Name;

            var user = GetLoggedUser(principal);

            var roles = user.roles.Select(n => n.roleId).ToList();

            var result = _autenticationUserRepository.AutenticationUser(user.nome, roles);

            result.userId = userName; 

            return result;
        }

        private UserAuthorization GetLoggedUser(GenericPrincipal principal)
        {
            var user = new UserAuthorization();

            AuthorizeHelper auth;

            var username = principal.Identity.Name;

            var userAD = new AuthorizeHelper().AuthorizeUser(username);

            user.nome = (string)userAD.Properties["name"][0].ToString();

            user.userId = username;

            int propertyCount = userAD.Properties["memberOf"].Count;

            string dn;
            int equalsIndex, commaIndex;

            for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
            {
                dn = (string)userAD.Properties["memberOf"][propertyCounter];

                equalsIndex = dn.IndexOf("=", 1);
                commaIndex = dn.IndexOf(",", 1);

                if (-1 == equalsIndex)
                {
                    break;
                }

                string role = dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1);

                user.roles.Add(new RoleUser { roleId = role });
            }

            return user;
        }

    }
}
