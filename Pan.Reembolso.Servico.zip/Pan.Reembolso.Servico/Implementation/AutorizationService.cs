﻿using Pan.Reembolso.Infra.Security.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Implementation
{

    public class AutorizationService : IAutorizationService
    {
        private readonly IAutorization _autorization;

        public AutorizationService(IAutorization autorization)
        {
            _autorization = autorization;
        }

        public void Authorize()
        {
            _autorization.Authorize();
        }

        public string GetToken(string userName, string password)
        {
            return _autorization.GetToken(userName, password);
        }
    }
}
