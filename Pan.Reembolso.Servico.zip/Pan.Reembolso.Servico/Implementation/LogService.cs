﻿using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Servico.Interface;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Implementation
{
    public class LogService : ILogService
    {
        private readonly ILogRepository _logRepository;

        public LogService(ILogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public async Task LogAsync(Entidades.Log log)
        {
            await _logRepository.PersistirLog(log);
        }
    }
}
