﻿using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Servico.Implementation
{
    public class LogService : ILogService
    {
        private readonly ILogRepository _logRepository;

        public LogService(ILogRepository logRepository)
        {
            _logRepository = logRepository;
        }

        public void Log(Entidades.Log log)
        {
            _logRepository.PersistirLog(log);
        }
    }
}
