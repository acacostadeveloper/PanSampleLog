﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Servico.Implementation
{
    public class TransferenciaDireitoService : ITransferenciaDireitoService
    {
        
        //private IHistoricoReembolsoService _objHistoricoReembolsoService;
        //private IPagamentoRepository _objPagamentoRepository;
        //private IContratoRepository _objContratoRepository;
        private ITransferenciaDireitoRepository _transferenciaDireitoRepository;
        private IContaCreditoRepository _contaCreditoRepository;

        public TransferenciaDireitoService( ITransferenciaDireitoRepository transferenciaDireitoRepository,
        IContaCreditoRepository contaCreditoRepository)
        {
            _transferenciaDireitoRepository = transferenciaDireitoRepository;
            _contaCreditoRepository = contaCreditoRepository;
        }

        

        public Result PersistirTransferenciaDireito(ContaCredito conta,string numeroCpfCnpjCliente,string numeroCpfCnpjTerceiro,string nomeTerceiro,DateTime dtInicioVigencia, DateTime? dtFimVigencia,string usuarioInclusao, string documento)
        {
            var result = new Result();

            try
            {
                var terceiro = new Cliente()
                {
                    nomeCliente = nomeTerceiro,
                    numeroCpfCnpj = numeroCpfCnpjTerceiro,
                };
                terceiro.tipoPessoa = terceiro.GetTipoDePessoa();

                //TODO verificar se a conta existe antes de incluir

                var idConta = _contaCreditoRepository.IncluirConta(conta).idConta;

                _transferenciaDireitoRepository.PersistirTransferenciaDireito(idConta, numeroCpfCnpjCliente, terceiro, dtInicioVigencia, dtFimVigencia, usuarioInclusao, documento);

                result.Success = true;
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
                throw ex;
            }

            return result;
        }


        public List<TransferenciaDireito> ConsultarTransferenciasCliente(string numeroCpfCnpjCliente)
        {
            try
            {
                var lista = _transferenciaDireitoRepository.ObterTransferenciaDireitoPorCpfCliente(numeroCpfCnpjCliente);

                return lista.ToList();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
