﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ReembolsoService : IReembolsoService
    {
        private IReembolsoRepository _objReembolsoRep;
        private ICartaoLobApp _objCartaoLob;
        private ICdcLobApp _objCdcLob;
        private IConsignadoLobApp _objConsignadoLob;
        private IConsorcioLobApp _objConsorcioLob;
        private IHistoricoReembolsoService _historicoReembolsoService;
        private IClienteService _objClienteService;


        public ReembolsoService(IReembolsoRepository objReembolsoRep,
                                ICartaoLobApp objCartaoLob,
                                ICdcLobApp objCdcLob,
                                IConsignadoLobApp objConsignadoLob,
                                IConsorcioLobApp objConsorcioLob,
                                IHistoricoReembolsoService historicoReembolsoService,
                                IClienteService objClienteService)
        {
            _objReembolsoRep = objReembolsoRep;
            _objCartaoLob = objCartaoLob;
            _objCdcLob = objCdcLob;
            _objConsignadoLob = objConsignadoLob;
            _objConsorcioLob = objConsorcioLob;
            _historicoReembolsoService = historicoReembolsoService;
            _objClienteService = objClienteService;
        }

        public Entidades.Reembolso ObterReembolso(long id) 
        {
            try
            {
                var retorno = _objReembolsoRep.ObterReembolso(id);
                    retorno.PermiteEstorno();
                return retorno;
            }
            catch (Exception ex)
            {
                throw ex; 
            }       
        }

        public Entidades.Reembolso ObterReembolsoByIdContrato(string codigoContrato)
        {
            // TODO - ObterReembolsoByIdContrato
            return new Entidades.Reembolso();
        }

        public IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter)
        {
            try
            {
                var lista = _objReembolsoRep.ConsultarInformacoesReembolso(filter);

                return lista;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        
        //public Entidades.Reembolso ObterDetalhesReembolso(int idReembolso)
        //{
        //    try
        //    {
        //        var reembolso = _objReembolsoRep.ObterReembolso(idReembolso);//ObterDetalhes(idReembolso);

        //            reembolso.PermiteEstorno();

        //        return reembolso;
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
        //}

        public IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso)
        {
            return _historicoReembolsoService.ObterHistoricoReembolsoPorIdReembolso(idReembolso);
        }

        public IList<Entidades.Reembolso> IncluirReembolso(IEnumerable<Entidades.Reembolso> values)
        {
            Guid lote = Guid.NewGuid();
            int idLote = 0;

            foreach (Entidades.Reembolso unit in values)
            {
                unit.lote.idLote = idLote;
                unit.lote.lote = lote.ToString();

                IncluirReembolso(unit);

                idLote = unit.lote.idLote;
            }

            var resultList = values.ToList();

            var registrados = values.Where(s => s.statusReembolso == StatusReembolsoType.Registrado.ToString());

            Task.Factory.StartNew(() => { ProcessarReembolsoAsync(registrados); });

            return resultList;
        }

        public void AlterarStatusReembolso(List<long> ids, string status, string mensagemErro)
        {
            var aprovador = "usuario Pagamento";

            try
            {
                foreach (long id in ids)
                {
                    var reembolso = _objReembolsoRep.ObterReembolso(id);

                    StatusReembolsoType statusReembolso = DefinirStatusReembolso(reembolso, status, mensagemErro, aprovador);

                    PersistirStatusReembolso(reembolso, statusReembolso);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private StatusReembolsoType DefinirStatusReembolso(Entidades.Reembolso reembolso, string status, string mensagemErro, string aprovador)
        {
            StatusReembolsoType statusEnum = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), status);

            return statusEnum;
        }

        public void ExcluirReembolso(List<long> idsAExtornar)
        {
            var historicosReembolso = new List<HistoricoReembolso>();

            try
            {
                foreach (long idReembolso in idsAExtornar)
                {
                    var reembolso = _objReembolsoRep.ObterReembolso(idReembolso);
                    reembolso.PermiteEstorno();
                    reembolso.mensagemErro = "Estornado Via Interface Web";
                    historicosReembolso.Add(_historicoReembolsoService.GerarHistoricoReembolso(reembolso, StatusReembolsoType.Cancelado, "ESTORNO REEMBOLSO"));
                }

                _objReembolsoRep.ExcluirReembolso(idsAExtornar);

                foreach(var historicoReembolso in historicosReembolso)
                {
                    _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Object ConsultarPagamentosARealizar(DateTime? dtInicial, DateTime? dtFinal)
        {
            return _objReembolsoRep.ConsultarPagamentosARealizar(dtInicial, dtFinal);
        }

        public Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null)
        {
            return _objReembolsoRep.ConsultarHistoricoPagamentos(dtInicial);
        }

        private void IncluirReembolso(Entidades.Reembolso unit)
        {
            try
            {
                var statusAnterior = unit.statusReembolso;

                if (VerificaNovoReembolso(unit))
                {
                    VerificaContratoNaoIntegrado(unit);

                    if (unit.contrato == null)
                    {
                        // TODO - verificar diferenciação entre contrato inexistente e cliente inexistente
                        unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Rejeitado.ToString();
                        unit.mensagemErro = ReembolsoConstantes.CONTRATO_INEXISTENTE;
                    }

                    if (unit.contrato.cliente == null)
                    {
                        unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Rejeitado.ToString();
                        unit.mensagemErro = ReembolsoConstantes.CLIENTE_INEXISTENTE;
                    }

                    if (unit.statusReembolso == ReembolsoTypes.StatusReembolsoType.Registrado.ToString())
                    {
                        PersistirReembolso(unit);
                    }
                }
            }
            catch (Exception ex)
            {
                unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Cancelado.ToString();
                unit.mensagemErro = ex.Message;
            }
        }

        private void PersistirReembolso(Entidades.Reembolso reembolso)
        {
           
            var oldStatatus = reembolso.statusReembolso;

            StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), oldStatatus);

            HistoricoReembolso historicoReembolso = new HistoricoReembolso();

            _objReembolsoRep.PersistirReembolso(reembolso, reembolso.lote.lote);

            historicoReembolso = _historicoReembolsoService.GerarHistoricoReembolso(reembolso, statusReembolso, "NAO INTEGRADO", "user");

            historicoReembolso.reembolso = reembolso.numeroReembolso;

            _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
        }

        private void PersistirStatusReembolso(Entidades.Reembolso reembolso, StatusReembolsoType novoStatus)
        {
            var oldStatatus = reembolso.statusReembolso;

            StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), reembolso.statusReembolso);

            var historicoReembolso = _historicoReembolsoService.GerarHistoricoReembolso(reembolso, novoStatus, "NAO INTEGRADO","user");

            _objReembolsoRep.AtualizarStatusReembolso(reembolso.numeroReembolso, novoStatus, reembolso.mensagemErro, reembolso.usuarioAlteracao, reembolso.usuarioAprovacao);

            _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
        }

        private void AtualizarContratoLobApp(Entidades.Contrato contrato)
        {
            switch (contrato.produto.codigoProduto)
            {
                case "0001": // CONSIGNADO
                    _objConsignadoLob.ObterContrato(contrato);
                    break;
                case "CDC": // VEICULOS 
                    _objCdcLob.ObterContrato(contrato);
                    break;
                case "CARTAO": // CARTAO
                    _objCartaoLob.ObterContrato(contrato);
                    break;
                case "CONSORCIO": // CONSORCIO 
                    _objConsorcioLob.ObterContrato(contrato);
                    break;
            }
        }

        private void VerificaContratoNaoIntegrado(Entidades.Reembolso unit)
        {
            if (unit.sigla.codigoSigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO &&
                unit.contrato.statusContrato != ReembolsoTypes.StatusContratoType.NaoIntegrado)
            {
                GerarContratoNaoIntegrado(unit.contrato);
            }

            AtualizarContratoLobApp(unit.contrato);
        }

        private void GerarContratoNaoIntegrado(Entidades.Contrato contrato)
        {
            contrato.statusContrato = ReembolsoTypes.StatusContratoType.NaoIntegrado;

            contrato.numeroContrato = contrato.cliente.numeroCpfCnpj;
        }

        private void ProcessarReembolsoAsync(IEnumerable<Entidades.Reembolso> values)
        {
            foreach (Entidades.Reembolso value in values) 
            {
                var statusAnterior = value.statusReembolso;

                ReembolsoHelper.ValidarReembolso(value);

                if (value.statusReembolso != ReembolsoTypes.StatusReembolsoType.Registrado.ToString())
                {
                    var evento = value.mensagemErro == ReembolsoConstantes.REGISTRO_OBITO ? "CONSULTA CONTRATO" : "CONSULTA CLIENTE";

                    value.statusReembolso = statusAnterior;

                    var historicoReembolso = _historicoReembolsoService.GerarHistoricoReembolso(value, StatusReembolsoType.Bloqueado, evento);

                    _objReembolsoRep.AtualizarStatusReembolso(value.numeroReembolso, StatusReembolsoType.Bloqueado, value.mensagemErro, value.usuarioInclusao, "");

                    _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
                }
                else
                {
                    IntegrarReembolso(value);
                }
            }
        }

        private void IntegrarReembolso(Entidades.Reembolso value)
        {
            // todo: Integrar Tesouraria para envio de TED caso a forma de liquidação seja esta 
        }

        private bool VerificaNovoReembolso(Entidades.Reembolso unit)
        {
            IEnumerable<Entidades.Reembolso> integracaoDuplicidade;

            integracaoDuplicidade = _objReembolsoRep.ObterReembolsoPorContrato(unit.contrato.numeroContrato, unit.valorReembolso, unit.mesCompetencia);

            var result = integracaoDuplicidade.FirstOrDefault();

            if (result != null)
            {
                unit.numeroReembolso = result.numeroReembolso;
                unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Rejeitado.ToString();
                unit.mensagemErro = "Contrato ja Integrado: " + result.numeroReembolso + " Lote : " + result.lote.idLote;
            }

            return ReembolsoHelper.NovoReembolso(unit);
        }

        public List<Object> ConsultarClientesParaManutencaoDadosBancarios()
        {
            return _objClienteService.ConsultarClientesParaManutencaoDadosBancarios();
        }
    }
}
