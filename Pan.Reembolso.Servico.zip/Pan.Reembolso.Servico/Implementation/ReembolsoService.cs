﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ReembolsoService : IReembolsoService
    {
        private IReembolsoRepository _objReembolsoRep;
        private ICartaoLobApp _objCartaoLob;
        private ICdcLobApp _objCdcLob;
        private IConsignadoLobApp _objConsignadoLob;
        private IConsorcioLobApp _objConsorcioLob;

        public ReembolsoService(IReembolsoRepository objReembolsoRep,
                                ICartaoLobApp objCartaoLob,
                                ICdcLobApp objCdcLob,
                                IConsignadoLobApp objConsignadoLob,
                                IConsorcioLobApp objConsorcioLob)

        {
            _objReembolsoRep = objReembolsoRep;
            _objCartaoLob = objCartaoLob;
            _objCdcLob = objCdcLob;
            _objConsignadoLob = objConsignadoLob;
            _objConsorcioLob = objConsorcioLob;
        }

        public Entidades.Reembolso ObterReembolso(int id) 
        {
            try
            {
                return _objReembolsoRep.ObterReembolso(id);
            }
            catch (Exception ex)
            {
                throw ex; 
            }       
        }

        public Entidades.Reembolso ObterReembolso(string codigoContrato) 
        {
            return new Entidades.Reembolso();
        }

        public Entidades.Reembolso ObterReembolsoIntegracao(Entidades.Integracao integracao)
        {
            var result = new Entidades.Reembolso();


            return new Entidades.Reembolso();
        }

        private void AtualizarContratoLobApp(Entidades.Contrato contrato)
        {
            switch (contrato.produto.codigoProduto)
            {
                case "0001": // CONSIGNADO
                    _objConsignadoLob.ObterContrato(contrato);
                    break;
                case "CDC": // VEICULOS 
                    _objCdcLob.ObterContrato(contrato);
                    break;
                case "CARTAO": // CARTAO
                    _objCartaoLob.ObterContrato(contrato);
                    break;
                case "CONSORCIO": // CONSORCIO 
                    _objConsorcioLob.ObterContrato(contrato);
                    break;
            }
        }

        public IList<Entidades.Reembolso> IncluirReembolso(IEnumerable<Entidades.Reembolso> values)
        {
            Guid idLote = Guid.NewGuid();

            foreach (Entidades.Reembolso unit in values)
            {
                VerificaContrato(unit);

                if (unit.contrato == null)
                    unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.RejeitadoContratoInexistente.ToString();

                if (unit.contrato.cliente == null)
                    unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.RejeitadoClienteInexistente.ToString();

                // TODO - Verificar Regra
                if (unit.contrato != null || unit.contrato.cliente != null)
                {
                    unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Solicitado.ToString();
                    _objReembolsoRep.PersistirReembolso(unit, idLote.ToString());
                }
            }
			
            var resultList = values.ToList();

            Task.Factory.StartNew(() => { ProcessarReembolsoAsync(values); });

            return resultList;
        }
		
        private void VerificaContrato(Entidades.Reembolso unit)
        {
            if (unit.sigla.codigoSigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO &&
                unit.contrato.statusContrato != ReembolsoTypes.StatusContratoType.NaoIntegrado)
            {
                GerarContratoNaoIntegrado(unit.contrato);
            }

            AtualizarContratoLobApp(unit.contrato);
        }

        private void GerarContratoNaoIntegrado(Entidades.Contrato contrato)
        {
            contrato.statusContrato = ReembolsoTypes.StatusContratoType.NaoIntegrado;

            contrato.numeroContrato = contrato.cliente.numeroCpfCnpj;
        }

        private void ProcessarReembolsoAsync(IEnumerable<Entidades.Reembolso> values)
        {
            foreach (Entidades.Reembolso value in values) 
            {
                var helper = new ReembolsoHelper();
                if (helper.ValidarReembolso(value))
                    IntegrarReembolso(value);
            }
        }

        private void IntegrarReembolso(Entidades.Reembolso value)
        {
            // todo: Integrar Tesouraria para envio de TED caso a forma de liquidação seja esta 

        }

        public void EditarReembolso(Entidades.Reembolso values) 
        { 
            // Not implemented 
        }

        public void ExcluirReembolso(int id) 
        {
            // Not implemented 
        }
        
        public async Task ProcessarIntegracaoReembolso()
        {

        }

    }
}
