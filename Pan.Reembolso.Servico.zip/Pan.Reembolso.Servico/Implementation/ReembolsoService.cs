﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ReembolsoService : IReembolsoService
    {
        private IReembolsoRepository _reembolsoRep;
        private ICartaoLobApp _cartaoLob;
        private ICdcLobApp _cdcLob;
        private IConsignadoLobApp _consignadoLob;
        private IConsorcioLobApp _consorcioLob;
        private IHistoricoReembolsoService _historicoReembolsoService;
        private IContaCreditoService _contaCreditoService;

        public ReembolsoService(IReembolsoRepository objReembolsoRep,
                                ICartaoLobApp objCartaoLob,
                                ICdcLobApp objCdcLob,
                                IConsignadoLobApp objConsignadoLob,
                                IConsorcioLobApp objConsorcioLob,
                                IContaCreditoService objContaCreditoService,
                                IHistoricoReembolsoService objHistoricoReembolsoService)
        {
            _reembolsoRep = objReembolsoRep;
            _cartaoLob = objCartaoLob;
            _cdcLob = objCdcLob;
            _consignadoLob = objConsignadoLob;
            _consorcioLob = objConsorcioLob;
            _historicoReembolsoService = objHistoricoReembolsoService;
            _contaCreditoService = objContaCreditoService;
        }

        public Entidades.Reembolso ObterReembolso(long id) 
        {
            try
            {
                var retorno = _reembolsoRep.ObterReembolso(id);
                    retorno.PermiteEstorno();
                return retorno;
            }
            catch (Exception ex)
            {
                throw ex; 
            }       
        }

        public List<Entidades.Reembolso> ObterReembolsoList()
        {
            try
            {
                var retorno = _reembolsoRep.ObterReembolsoList(0);

                foreach (var item in retorno)
                {
                    item.PermiteEstorno();
                }
                
                return retorno;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.Reembolso ObterReembolsoByIdContrato(string codigoContrato)
        {
            // TODO - ObterReembolsoByIdContrato
            return new Entidades.Reembolso();
        }

        public IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter)
        {
            try
            {
                var lista = _reembolsoRep.ConsultarInformacoesReembolso(filter);

                return lista;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        
        public IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso)
        {
            return _historicoReembolsoService.ObterHistoricoReembolsoPorIdReembolso(idReembolso);
        }

        public IList<Entidades.Reembolso> IncluirReembolso(IEnumerable<Entidades.Reembolso> values)
        {
            Guid lote = Guid.NewGuid();
            int idLote = 0;

            foreach (Entidades.Reembolso unit in values)
            {
                unit.lote.idLote = idLote;
                unit.lote.lote = lote.ToString();

                var loteResut = IntegrarLoteReembolso(unit);

                idLote = (loteResut > 0) ? loteResut : idLote;
            }

            var resultList = values.ToList();

            var registrados = values.Where(s => s.statusReembolso == StatusReembolsoType.Registrado.ToString());

            Task.Factory.StartNew(() => { ProcessarReembolsoAsync(registrados); });

            return resultList;
        }

        private int IntegrarLoteReembolso(Entidades.Reembolso unit)
        {
            IncluirReembolso(unit);

            return  unit.lote.idLote;
        }

        public void AlterarStatusReembolso(List<long> ids, string status, string mensagemErro, string evento)
        {
            var aprovador = "usuario Pagamento";

            try
            {
                foreach (long id in ids)
                {
                    var reembolso = _reembolsoRep.ObterReembolso(id);

                    StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), status);

                    PersistirStatusReembolso(reembolso, statusReembolso, evento);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ExcluirReembolso(List<long> idsAExtornar)
        {
            var historicosReembolso = new List<HistoricoReembolso>();

            try
            {
                foreach (long idReembolso in idsAExtornar)
                {
                    var reembolso = _reembolsoRep.ObterReembolso(idReembolso);
                    reembolso.PermiteEstorno();
                    reembolso.mensagemErro = "Estornado Via Interface Web";
                    historicosReembolso.Add(_historicoReembolsoService.GerarHistoricoReembolsoProcessoRegistro(reembolso, StatusReembolsoType.Cancelado));
                }

                _reembolsoRep.ExcluirReembolso(idsAExtornar);

                foreach(var historicoReembolso in historicosReembolso)
                {
                    _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null)
        {
            return _reembolsoRep.ConsultarHistoricoPagamentos(dtInicial);
        }

        public async Task<Result> AtualizarReembolsosPorDadosBancarios(string cpfCnpjcliente, StatusReembolsoType status, string messageError)
        {
            var result = new Result();

            await Task.Run(() =>
            {
                try
                {
                    var statusReembolso = new string[] { StatusReembolsoType.Registrado.ToString(), StatusReembolsoType.Bloqueado.ToString() };

                    var filter = new ReembolsoFilter { cpfCliente = cpfCnpjcliente, statusReembolso = statusReembolso };

                    var ids = _reembolsoRep.ObterIdsReembolsoPorFiltro(filter).ToList();

                    AlterarStatusReembolso(ids, status.ToString(), messageError, "MANUTENCAO DADOS BANCARIOS");
                
                }
                catch (Exception ex)
                {
                    result.MessageError = ex.Message;
                }
            });

            return result;
            
        }

        private void IncluirReembolso(Entidades.Reembolso unit)
        {
            try
            {
                CheckReembolsoRejeitado(unit);
            }
            catch (Exception ex)
            {
                unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Cancelado.ToString();
                unit.mensagemErro = ex.Message;
            }
        }

        private void CheckReembolsoRejeitado(Entidades.Reembolso unit)
        {
            var statusAnterior = unit.statusReembolso;

            if (VerificaNovoReembolso(unit))
            {
                VerificaContratoNaoIntegrado(unit);

                unit.dtInclusao = DateTime.Now;

                if (unit.contrato == null)
                {
                    // TODO - verificar diferenciação entre contrato inexistente e cliente inexistente
                    unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Rejeitado.ToString();
                    unit.mensagemErro = ReembolsoConstantes.CONTRATO_INEXISTENTE;
                }

                if (unit.contrato.cliente == null)
                {
                    unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Rejeitado.ToString();
                    unit.mensagemErro = ReembolsoConstantes.CLIENTE_INEXISTENTE;
                }

                if (unit.statusReembolso == null)
                {
                    unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Registrado.ToString();
                }

                if (unit.statusReembolso == ReembolsoTypes.StatusReembolsoType.Registrado.ToString())
                {
                    PersistirReembolso(unit);
                }
            }
        }

        private void PersistirReembolso(Entidades.Reembolso reembolso)
        {
            var oldStatatus = reembolso.statusReembolso;

            StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), oldStatatus);

            HistoricoReembolso historicoReembolso = new HistoricoReembolso();

            _reembolsoRep.PersistirReembolso(reembolso, reembolso.lote.lote);

            historicoReembolso = _historicoReembolsoService.GerarHistoricoReembolsoProcessoRegistro(reembolso, statusReembolso, "NAO INTEGRADO", "user");

            historicoReembolso.reembolso = reembolso.numeroReembolso;

            _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
        }

        private void PersistirStatusReembolso(Entidades.Reembolso reembolso, StatusReembolsoType novoStatus, string codigoEvento)
        {

            var oldStatatus = reembolso.statusReembolso;

            StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), reembolso.statusReembolso);

            var historicoReembolso = _historicoReembolsoService.GerarHistoricoReembolso(reembolso, novoStatus, codigoEvento);

            _reembolsoRep.AtualizarStatusReembolso(reembolso.numeroReembolso, novoStatus, reembolso.mensagemErro, reembolso.usuarioAlteracao, reembolso.usuarioAprovacao);

            _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);

        }

        private void AtualizarContratoLobApp(Entidades.Contrato contrato)
        {
            switch (contrato.produto.codigoProduto)
            {
                case "0001": // CONSIGNADO
                    _consignadoLob.ObterContrato(contrato);
                    break;
                case "CDC": // VEICULOS 
                    _cdcLob.ObterContrato(contrato);
                    break;
                case "CARTAO": // CARTAO
                    _cartaoLob.ObterContrato(contrato);
                    break;
                case "CONSORCIO": // CONSORCIO 
                    _consorcioLob.ObterContrato(contrato);
                    break;
            }
        }

        private void VerificaContratoNaoIntegrado(Entidades.Reembolso unit)
        {
            if (unit.sigla.codigoSigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO &&
                unit.contrato.statusContrato != ReembolsoTypes.StatusContratoType.NaoIntegrado)
            {
                GerarContratoNaoIntegrado(unit.contrato);
            }

            AtualizarContratoLobApp(unit.contrato);
        }

        private void GerarContratoNaoIntegrado(Entidades.Contrato contrato)
        {
            contrato.statusContrato = ReembolsoTypes.StatusContratoType.NaoIntegrado;

            contrato.numeroContrato = contrato.cliente.numeroCpfCnpj;
        }

        private void ProcessarReembolsoAsync(IEnumerable<Entidades.Reembolso> values)
        {
            foreach (Entidades.Reembolso value in values) 
            {
                var statusAnterior = value.statusReembolso;

                ReembolsoHelper.ValidarReembolso(value);

                if (value.statusReembolso != ReembolsoTypes.StatusReembolsoType.Registrado.ToString())
                {
                    var evento = value.mensagemErro == ReembolsoConstantes.REGISTRO_OBITO ? "CONSULTA CONTRATO" : "CONSULTA CLIENTE";

                    value.statusReembolso = statusAnterior;

                    PersistirStatusReembolso(value, StatusReembolsoType.Bloqueado, evento);

                    continue;
                }

                var contaCreditoResult = _contaCreditoService.VerificarContaCredito(value.contrato.cliente.contaCredito).Result;

                if (!contaCreditoResult.Success)
                {
                    var evento = "MANUTENCAO DADOS BANCARIOS";

                    value.mensagemErro = contaCreditoResult.MessageError;

                    value.statusReembolso = statusAnterior;

                    PersistirStatusReembolso(value, StatusReembolsoType.Bloqueado, evento);

                    continue;
                }

                IntegrarReembolso(value);
            }
        }

        private void IntegrarReembolso(Entidades.Reembolso value)
        {
            // todo: Integrar Tesouraria para envio de TED caso a forma de liquidação seja esta 
        }

        private bool VerificaNovoReembolso(Entidades.Reembolso unit)
        {
            IEnumerable<Entidades.Reembolso> integracaoDuplicidade;

            integracaoDuplicidade = _reembolsoRep.ObterReembolsoPorContrato(unit.contrato.numeroContrato, unit.valorReembolso, unit.mesCompetencia);

            var result = integracaoDuplicidade.FirstOrDefault();

            if (result != null)
            {
                unit.numeroReembolso = result.numeroReembolso;
                unit.statusReembolso = ReembolsoTypes.StatusReembolsoType.Rejeitado.ToString();
                unit.mensagemErro = "Contrato ja Integrado: " + result.numeroReembolso + " Lote : " + result.lote.idLote;
            }

            return ReembolsoHelper.NovoReembolso(unit);
        }

        public async Task<ContaCreditoResult> ManterDadorBancarios(Entidades.ContaCredito contaCredito, int idCliente, string cpfCnpjcliente = "")
        {
            var contaCreditoResult = new ContaCreditoResult();

            var result = await _contaCreditoService.VerificarContaCredito(contaCredito);

            if (!result.Success) return result;

            result = await _contaCreditoService.ManterDadosBancarios(contaCredito, idCliente);

            var statusReembolsoResult = result.Success ? StatusReembolsoType.Registrado : StatusReembolsoType.Bloqueado;

            var statusReembolso = new string[] { StatusReembolsoType.Registrado.ToString(), StatusReembolsoType.Bloqueado.ToString() };

            var filter = new ReembolsoFilter { cpfCliente = cpfCnpjcliente, statusReembolso = statusReembolso };

            var ids = _reembolsoRep.ObterIdsReembolsoPorFiltro(filter).ToList();

            this.AlterarStatusReembolso(ids, statusReembolsoResult.ToString(), result.MessageError, "");

            return contaCreditoResult;
        }
    }
}
