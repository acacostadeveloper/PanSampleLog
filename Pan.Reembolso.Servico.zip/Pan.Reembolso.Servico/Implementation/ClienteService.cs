﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ClienteService : IClienteService
    {
        private readonly IReembolsoService _reembolsoService;
        private readonly IContaCreditoService _contaCreditoService;
        private readonly ITransferenciaDireitoService _transferenciaDireitoService;

        private readonly IContaCreditoRepository _contaCreditoRepository;
        private readonly IClienteRepository _objClienteRepository;
        private readonly ITransferenciaDireitoRepository _transferenciaDireitoRepository;
        private readonly IMotivoBloqueioRepository _motivoBloqueioRepository;

        public ClienteService(IClienteRepository clienteRepository,
            IContaCreditoService contaCreditoService,
            IContaCreditoRepository contaCreditoRepository,
            IReembolsoService reembolsoService,
            ITransferenciaDireitoRepository transferenciaDireitoRepository,
            ITransferenciaDireitoService transferenciaDireitoService,
            IMotivoBloqueioRepository motivoBloqueioRepository)
        {
            _reembolsoService = reembolsoService;
            _contaCreditoService = contaCreditoService;
            _contaCreditoRepository = contaCreditoRepository;
            _objClienteRepository = clienteRepository;
            _transferenciaDireitoService = transferenciaDireitoService;
            _transferenciaDireitoRepository = transferenciaDireitoRepository;
            _motivoBloqueioRepository = motivoBloqueioRepository;
        }

        public async Task<List<Cliente>> ConsultarClientes(Repositorio.Filters.ReembolsoFilter filter)
        {
            var result = new List<Cliente>();

            result = await _objClienteRepository.ConsultarClientesPorFiltro(filter);

            return result;
        }

        public async Task<List<Object>> ConsultarClientesParaManutencaoDadosBancarios(string numeroCpfCnpj, string nomeCliente)
        {
            var result = new List<Object>();

            result = await _objClienteRepository.ConsultarClientesParaManutencaoDadosBancariosFlat(numeroCpfCnpj, nomeCliente);

            return result;
        }

        public async Task<ClienteResult> PersistirCliente(Entidades.Cliente cliente)
        {

            var result = new ClienteResult();

            try
            {
                result.idCliente = _objClienteRepository.PersistirCliente(cliente);
                result.Success = true;
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }

        public async Task<ContaCreditoResult> ManterDadosBancarios(ContaCredito contaCredito, int idCliente, string userId, string cpfCnpjcliente = "")
        {

            var result = new ContaCreditoResult();

            try
            {
                if (idCliente == 0)
                {
                    idCliente = _objClienteRepository.ObterIdCliente(cpfCnpjcliente);
                }

                result = await _contaCreditoService.VerificarContaCredito(contaCredito);

                if (!result.Success) return result;

                var statusReembolsoResult = result.Success ? StatusReembolsoType.Registrado : StatusReembolsoType.Bloqueado;

                result = await _contaCreditoService.ManterDadosBancarios(contaCredito, idCliente);

                var motivoBloqueio = _motivoBloqueioRepository.ObterMotivoBloqueio(ReembolsoTypes.MotivoBloqueioType.DadosBancariosAusente);

                await _reembolsoService.AtualizarReembolsosPorDadosBancarios(cpfCnpjcliente, statusReembolsoResult, motivoBloqueio.descricaoMotivoBloqueio, motivoBloqueio, userId);
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }

        public void IncluirTransferenciaDireito(TransferenciaDireito transferencia)
        {
            _transferenciaDireitoService.PersistirTransferenciaDireito(transferencia.contaCredito, transferencia.cliente.numeroCpfCnpj, transferencia.numeroCpfCnpj, transferencia.nome, transferencia.dtInicioVigencia, transferencia.dtFimVigencia, transferencia.usuarioInclusao, transferencia.documento);
        }

        public async Task<IEnumerable<TransferenciaDireito>> ConsultarTransferenciasCliente(string numeroCpfCnpjCliente)
        {
            var result = new List<TransferenciaDireito>();

            result = _transferenciaDireitoService.ConsultarTransferenciasCliente(numeroCpfCnpjCliente);

            return result;
        }

        public TransferenciaDireito ObterTransferenciaDireitoAtivoPorId(long idTransferenciaDireito)
        {
            try
            {
                return _transferenciaDireitoService.ObterTransferenciaDireitoAtivoPorId(idTransferenciaDireito);
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
