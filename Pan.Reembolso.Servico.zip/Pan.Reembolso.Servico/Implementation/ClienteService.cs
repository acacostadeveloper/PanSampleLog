﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;
using Pan.Reembolso.Agente.Implementation;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ClienteService : IClienteService
    {
        //private IReembolsoService _reembolsoService;
        private IClienteRepository _objClienteRepository;
        private readonly IContaCreditoRepository _contaCreditoRepository;


        public ClienteService(IClienteRepository clienteRepository, IContaCreditoRepository contaCreditoRepository)
        {
            //_reembolsoService = reembolsoService;
            _objClienteRepository = clienteRepository;
            _contaCreditoRepository = contaCreditoRepository;
        }

        public List<Object> ConsultarClientesParaManutencaoDadosBancarios()
        {
            return _objClienteRepository.ConsultarClientesParaManutencaoDadosBancarios();
        }

        public async Task ManterDadosBancarios(ContaCredito contaCredito, int idCliente)
        {
            var statusReembolso = StatusReembolsoType.Undefined;
            var mensagemErro = string.Empty;

            try
            {
                _contaCreditoRepository.PersistirContaCredito(contaCredito, idCliente);

                // TODO - Verificar se a conta consta em blackList / Dados Invalidos
                var contas = new List<ContaCredito> { contaCredito };

                new ConsignadoLobApp().VerificarContaFraudada(contas);
                var contaCreditoOk = contas.FirstOrDefault(s => s.fraude == "0");

                if (contaCreditoOk != null)
                {
                    statusReembolso = StatusReembolsoType.Registrado;
                }
                else
                {
                    statusReembolso = StatusReembolsoType.Bloqueado;
                }

                //var ids = _reembolsoService.ConsultarInformacoesReembolso
                //_reembolsoService.AlterarStatusReembolso();

            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
    }
}
