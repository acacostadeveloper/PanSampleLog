﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Servico.Extensions;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ClienteService : IClienteService
    {
        private IClienteRepository _objClienteRepository;


        public ClienteService(IClienteRepository clienteRepository)

        {
            _objClienteRepository = clienteRepository;
        }

        public List<Object> ConsultarClientesParaManutencaoDadosBancarios()
        {
            return _objClienteRepository.ConsultarClientesParaManutencaoDadosBancarios();
        }
    }
}
