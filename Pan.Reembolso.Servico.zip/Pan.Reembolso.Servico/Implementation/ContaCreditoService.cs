﻿using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ContaCreditoService : IContaCreditoService
    {
        private readonly IContaCreditoRepository _contaCreditoRepository;
        private readonly IContaRejeicaoRepository _contaRejeicaoRepository;

        public ContaCreditoService(IContaCreditoRepository contaCreditoRepository, IContaRejeicaoRepository contaRejeicaoRepository)
        {
            _contaCreditoRepository = contaCreditoRepository;
            _contaRejeicaoRepository = contaRejeicaoRepository;
        }

        public async Task<ContaCreditoResult> ManterDadosBancarios(ContaCredito contaCredito, int idCliente)
        {
            var result = new ContaCreditoResult();

            try
            {
                _contaCreditoRepository.PersistirContaCredito(contaCredito, idCliente);

                result.Success = true;
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }


        public async Task<ContaCreditoResult> VerificarContaCredito(ContaCredito contaCredito)
        {
            try
            {
                ContaCreditoResult result = await CheckBlackListReembolso(contaCredito);

                if (result.Success)
                {
                    result = await CheckBlackListRestritivos(contaCredito);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async Task<ContaCreditoResult> CheckBlackListRestritivos(ContaCredito contaCredito)
        {
            var result = new ContaCreditoResult();

            var blackListAccounts = RestritivosLobApp.CheckBlackList(contaCredito);

            if (blackListAccounts.Contains(contaCredito))
            {
                AdicionarContaCreditoBlackList(contaCredito, ErroContaCreditoType.Fraude);

                result.MessageError = "Conta consta na blackList tesouraria";
            }
            else
            {
                result.Success = true;
            }

            return result;
        }

        private async Task<ContaCreditoResult> CheckBlackListReembolso(ContaCredito contaCredito)
        {
            var result = new ContaCreditoResult();

            try
            {
                var blackListreembolsos = ObterBlackListReembolso();
                var contaRejetada = ConstaBlackList(blackListreembolsos, contaCredito);

                if (contaRejetada != null)
                {
                    result.MessageError = string.Format("Conta consta na blackList Reembolso {0}",contaRejetada.erro);
                }
                else
                {
                    result.Success = true;
                }
            }
            catch (Exception ex)
            {
                result.MessageError = ex.Message;
            }
            return result;
        }

        private void AdicionarContaCreditoBlackList(ContaCredito contaCredito, ErroContaCreditoType erroContaCredito)
        {
            _contaRejeicaoRepository.PersistirContaRejeicao(contaCredito, erroContaCredito);
        }

        private List<ContaRejeicao> ObterBlackListReembolso()
        {
            return _contaRejeicaoRepository.ObterBlackListReembolso().ToList();
        }

        public ContaRejeicao ConstaBlackList(List<ContaRejeicao> blackList, ContaCredito contaCredito)
        {
            return blackList.Where(s => s.numeroAgencia == contaCredito.numeroAgencia && s.digitoAgencia == contaCredito.digitoAgencia &&
                                        s.numeroConta == contaCredito.numeroConta && s.digitoConta == contaCredito.digitoConta &&
                                        s.numeroBanco == contaCredito.numeroBanco && s.tipoConta == contaCredito.tipoConta).FirstOrDefault();
        }
    }
}
