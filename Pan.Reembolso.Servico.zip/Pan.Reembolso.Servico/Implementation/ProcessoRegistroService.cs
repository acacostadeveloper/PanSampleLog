﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;

namespace Pan.Reembolso.Servico.Implementation
{
    public class ProcessoRegistroService : IProcessoRegistroService
    {
        private IProcessoRegistroRepository _objProcessoRegistroRep;

        public ProcessoRegistroService(IProcessoRegistroRepository objProcessoRegistroRep)
        {
            _objProcessoRegistroRep = objProcessoRegistroRep;
        }

        public IEnumerable<object> ObterProcessoRegistroList()
        {
            try
            {
                return _objProcessoRegistroRep.ObterProcessoRegistro("");
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public IEnumerable<ProcessoRegistro> ObterProcessoRegistros(string fluxo)
        {
            try
            {
                return _objProcessoRegistroRep.ObterProcessoRegistro(fluxo);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
