﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;

namespace Pan.Reembolso.Servico.Implementation
{
    public class SiglaService : ISiglaService
    {
        private ISiglaRepository _objSiglaRep;
        public SiglaService(ISiglaRepository objSiglaRep)
        {
            _objSiglaRep = objSiglaRep;
        }

        public IEnumerable<Sigla> ObterSiglas()
        {
            try
            {
                return _objSiglaRep.ObterSiglas();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
