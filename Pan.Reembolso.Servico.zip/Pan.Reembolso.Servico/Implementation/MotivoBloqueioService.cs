﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Servico.Implementation
{
    public class MotivoBloqueioService : IMotivoBloqueioService
    {
        private readonly IMotivoBloqueioRepository _motivoBloqueioRepository;

        public MotivoBloqueioService(IMotivoBloqueioRepository motivoBloqueioRepository)
        {
            _motivoBloqueioRepository = motivoBloqueioRepository;
        }

        public IEnumerable<MotivoBloqueio> ObterMotivosBloqueio()
        {
            try
            {
                return _motivoBloqueioRepository.ObterMotivoBloqueio();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
