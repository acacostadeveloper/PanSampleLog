﻿using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System.IO;
using System.Threading.Tasks;
using System.Web.Configuration;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Pan.Reembolso.Servico.Implementation
{
    public class UploadService : IUploadService
    {
        private IIntegracaoService _integracaoService;
        private IPagamentoService _pagamentoService;


        public UploadService(IIntegracaoService integracaoService, IReembolsoService reembolsoService, IPagamentoService pagamentoService)
        {
            _integracaoService = integracaoService;
            _pagamentoService = pagamentoService;
        }

        public async Task<int> ProcessarArquivo(string fileName, byte[] streamArquivo)
        {
            try
            {
                var filePath = WebConfigurationManager.AppSettings["UploadPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, streamArquivo);

                var idLoteIntegracao = await _integracaoService.PersistirIntegracao(file);
                //var idLoteIntegracao = "65003444-ab1d-4eff-b9c5-9aeae9aadc0f";

                Task.Factory.StartNew(() =>
                {
                    var sucesso = IniciarProcessoIntegracao(file, idLoteIntegracao);

                    if (sucesso)
                        File.Delete(file);
                });

                return idLoteIntegracao;
            }
            catch (System.Exception ex)
            {
                // TODO Implementar Log
                throw ex;
            }
        }

        private bool IniciarProcessoIntegracao(string file, int idLoteIntegracao)
        {
            bool result;

            _integracaoService.ProcessarIntegracaoPendentePorLote(idLoteIntegracao);

            // TDDO - Verificar Retorno 
            result = true;

            return result;
        }


        public async Task<Result> PersistirArquivoLoteRetiradaInterna(string fileName, byte[] streamArquivo)
        {
            var result = new LoteRetiradaResult();
            try
            {
                var filePath = WebConfigurationManager.AppSettings["UploadPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, streamArquivo);

                await Task.Factory.StartNew(() =>
                 {
                     result = _pagamentoService.RetirarLoteUsoInterno(file).Result;
                     if (result.Success)
                         File.Delete(file);
                 });

                /**/
                Task.Factory.StartNew(() =>
                {
                    var sucesso = IniciarRetiradasEmLote();
                });
                /**/
            }
            catch (System.Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }
        private async Task<bool> IniciarRetiradasEmLote()
        {
            bool result;

            var pendentes = _pagamentoService.ConsultarRetiradasPendentesLote();

            for (int i = 0; i < pendentes.Count; i++)
            {
                try
                {
                    var retiradaIntegracao = pendentes[i];

                    var resultConsult = await _pagamentoService.ObterRetiradaInterna(retiradaIntegracao.numeroCpfCnpj, retiradaIntegracao.codigoProduto);

                    if (resultConsult.Retiradas.Count == 0)
                    {
                        retiradaIntegracao.codigoStatusIntegracao = ReembolsoTypes.StatusIntegracaoType.Erro.ToString();
                        retiradaIntegracao.mensagemErro = ReembolsoConstantes.RETIRADA_SEM_REEMBOLSO;
                        resultConsult.Success = false;
                    }

                    if (resultConsult.Success)
                    {
                        foreach (var item in resultConsult.Retiradas)
                        {
                            decimal valorARetirar = 0;
                            bool retiradaTotal;

                            if (retiradaIntegracao.valorRetirada > item.valor)
                            {
                                retiradaTotal = true;
                                valorARetirar = item.valor;
                            }
                            else
                            {
                                valorARetirar = retiradaIntegracao.valorRetirada;
                                retiradaTotal = false;
                            }

                            var resultPagamento = await _pagamentoService.EfetuarRetiradaInterna(item.ids, item.cpfcnpj, valorARetirar, retiradaTotal, retiradaIntegracao.codigoProcessoRegistro, ReembolsoConstantes.MOTIVO_RETIRADA_LOTE, retiradaIntegracao.usuarioInclusao);

                            retiradaIntegracao.Pagamento = resultPagamento.PagamentoEfetuado;
                            retiradaIntegracao.codigoStatusIntegracao = ReembolsoTypes.StatusIntegracaoType.Integrado.ToString();
                        }
                    }
                }
                catch (System.Exception ex)
                {
                    pendentes[i].mensagemErro = ex.Message;
                    pendentes[i].codigoStatusIntegracao = ReembolsoTypes.StatusIntegracaoType.Erro.ToString();
                }
            }

            foreach (var item in pendentes)
            {
                _pagamentoService.AtualizarIntegracaoRetiradaUsoInternoLote(item);
            }

            result = true;

            return result;
        }
    }
}
