﻿using Pan.Reembolso.Servico.Interface;
using System.IO;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Pan.Reembolso.Servico.Implementation
{
    public class UploadService : IUploadService
    {
        private IIntegracaoService _integracaoService;

        public UploadService(IIntegracaoService integracaoService, IReembolsoService reembolsoService)
        {
            _integracaoService = integracaoService;
        }

        public async Task<string> ProcessarArquivo(string fileName, byte[] streamArquivo)
        {
            try
            {
                var filePath = WebConfigurationManager.AppSettings["UploadPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, streamArquivo);

                var idLoteIntegracao = await _integracaoService.PersistirIntegracao(file);
                //var idLoteIntegracao = "f1762875-087c-4db5-af76-2d0470f2379c";

                Task.Factory.StartNew(() =>
                {
                    var sucesso = InicarProcessoIntegracao(file, idLoteIntegracao);

                    if (sucesso)
                        File.Delete(file);
                });

                return idLoteIntegracao.ToString();
            }
            catch (System.Exception ex)
            {
                // TODO Implementar Log
                throw ex;
            }
        }

        private bool InicarProcessoIntegracao(string file, string idLoteIntegracao)
        {
            bool result;

            _integracaoService.ProcessarIntegracaoPendentePorLote(idLoteIntegracao);

            // TDDO - Verificar Retorno 
            result = true;

            return result;
        }
    }
}
