﻿using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;
using System.IO;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Pan.Reembolso.Servico.Implementation
{
    public class UploadService : IUploadService
    {
        private IIntegracaoService _integracaoService;
        private IPagamentoService _pagamentoService;


        public UploadService(IIntegracaoService integracaoService, IReembolsoService reembolsoService, IPagamentoService pagamentoService)
        {
            _integracaoService = integracaoService;
            _pagamentoService = pagamentoService;
        }

        public async Task<string> ProcessarArquivo(string fileName, byte[] streamArquivo)
        {
            try
            {
                var filePath = WebConfigurationManager.AppSettings["UploadPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, streamArquivo);

                var idLoteIntegracao = await _integracaoService.PersistirIntegracao(file);
                //var idLoteIntegracao = "64921248-0c6a-4877-8519-e686d96cd4d4";

                Task.Factory.StartNew(() =>
                {
                    var sucesso = InicarProcessoIntegracao(file, idLoteIntegracao);

                    if (sucesso)
                        File.Delete(file);
                });

                return idLoteIntegracao.ToString();
            }
            catch (System.Exception ex)
            {
                // TODO Implementar Log
                throw ex;
            }
        }

        private bool InicarProcessoIntegracao(string file, string idLoteIntegracao)
        {
            bool result;

            _integracaoService.ProcessarIntegracaoPendentePorLote(idLoteIntegracao);

            // TDDO - Verificar Retorno 
            result = true;

            return result;
        }


        public async Task<Result> PersistorArquivoLoteRetiradaInterna(string fileName, byte[] streamArquivo)
        {
            var result = new Result();
            try
            {
                var filePath = WebConfigurationManager.AppSettings["UploadPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, streamArquivo);

                Task.Factory.StartNew(() =>
                {
                    result = _pagamentoService.RetirarLoteUsoInterno(file).Result;

                    if (result.Success)
                        File.Delete(file);
                });
            }
            catch (System.Exception ex)
            {
                result.MessageError = ex.Message;
            }

            return result;
        }
    }
}
