﻿using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Helper;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class UploadService : IUploadService
    {
        private IIntegracaoRepository _integracaoRepository;
        private IReembolsoService _reembolsoService;

        public UploadService(IIntegracaoRepository integracaoRepository, IReembolsoService reembolsoService)
        {
            _integracaoRepository = integracaoRepository;
            _reembolsoService = reembolsoService;
        }

        public async Task ProcessarArquivo(string fileName, byte[] streamArquivo)
        {
            var filePath = WebConfigurationManager.AppSettings["UploadPath"];

            var file = filePath + @fileName;

            File.WriteAllBytes(file, streamArquivo);

            await ProcessarArquivo(file).ConfigureAwait(false);
        }

        private async Task ProcessarArquivo(string file)
        {
            var integracoesReader = await ObterDadosArquivo(file);

            var bulkResult = await _integracaoRepository.PersistirIntegracaoBulk(integracoesReader);

            if (bulkResult)
            {
                File.Delete(file);

                // TODO - _integracaoService.ProcessarIntegracao();
            }
        }

        private async Task<IDataReader> ObterDadosArquivo(string file)
        {
            var integracoes = new List<IntegracaoTable>();

            using (var reader = new StreamReader(@file))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    var integracao = new IntegracaoTable
                    {

                        ID_REEMBOLSO = null,
                        ID_LOTE = null,
                        CD_STATUS_INTEGRACAO = StatusIntegracao.Pendente.ToString(),
                        DS_MENSAGEM_ERRO = null,
                        DT_INTEGRACAO = null,
                        NM_CLIENTE = values[0],
                        NO_CONTRATO = values[1],
                        VL_REEMBOLSO = Convert.ToDecimal(values[2]),
                        NM_CONVENIO = values[3],
                        CD_MATRICULA = values[4],
                        NO_CPF_CNPJ = values[5],
                        NO_MES_COMPETENCIA = Convert.ToInt16(values[6]),
                        NO_ANO_COMPETENCIA = Convert.ToInt16(values[7]),
                        CD_SIGLA = values[8],
                        CD_PROCESSO_ENTRADA = values[9],
                        CD_PRODUTO = values[10],
                        CD_USUARIO_INCLUSAO = "integracao",
                    };

                    integracoes.Add(integracao);
                }
            }

            return new DataReaderHelper<IntegracaoTable>(integracoes);
        }
    }

    public class IntegracaoTable
    {
        public string ID_REEMBOLSO { get; set; }
        public string ID_LOTE { get; set; }
        public string CD_STATUS_INTEGRACAO { get; set; }
        public string DS_MENSAGEM_ERRO { get; set; }
        public DateTime? DT_INTEGRACAO { get; set; }
        public string NM_CLIENTE { get; set; }
        public string NO_CONTRATO { get; set; }
        public decimal VL_REEMBOLSO { get; set; }
        public string NM_CONVENIO { get; set; }
        public string CD_MATRICULA { get; set; }
        public string NO_CPF_CNPJ { get; set; }
        public int NO_MES_COMPETENCIA { get; set; }
        public int NO_ANO_COMPETENCIA { get; set; }
        public string CD_SIGLA { get; set; }
        public string CD_PROCESSO_ENTRADA { get; set; }
        public string CD_PRODUTO { get; set; }
        public string CD_USUARIO_INCLUSAO { get; set; }
    }
}
