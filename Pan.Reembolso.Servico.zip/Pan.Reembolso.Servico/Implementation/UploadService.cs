﻿using Pan.Reembolso.Servico.Interface;
using System.IO;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace Pan.Reembolso.Servico.Implementation
{
    public class UploadService : IUploadService
    {
        private IIntegracaoService _integracaoService;

        public UploadService(IIntegracaoService integracaoService, IReembolsoService reembolsoService)
        {
            _integracaoService = integracaoService;
        }

        public async Task ProcessarArquivo(string fileName, byte[] streamArquivo)
        {
            try
            {
                var filePath = WebConfigurationManager.AppSettings["UploadPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, streamArquivo);

                Task.Factory.StartNew(() =>
                {
                    var sucesso = InicarProcessoIntegracao(file);

                    if (sucesso)
                        File.Delete(file);
                });
            }
            catch (System.Exception ex)
            {
                // TODO Implementar Log
                throw ex;
            }

        }

        private bool InicarProcessoIntegracao(string file)
        {
            bool result;

            _integracaoService.PersistirIntegracao(file);

            _integracaoService.ProcessarIntegracaoPendente();

            result = true;

            return result;
        }
    }
}
