﻿using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class UploadService : IUploadService
    {
        public UploadService()
        {

        }

        public async Task ProcessarArquivo(string fileName, byte[] streamArquivo)
        {
            var filePath = WebConfigurationManager.AppSettings["UploadPath"];

            var file = filePath + "\\" + fileName;

            File.WriteAllBytes(file, streamArquivo);

            var integracoes = await ProcessData(file);


            //await BulkInsert(file);
        }

        private async Task<List<Entidades.Integracao>> ProcessData(string file)
        {
            var integracoes = new List<Entidades.Integracao>();

            using (var reader = new StreamReader(@file))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    var integracao = new Entidades.Integracao
                    {
                        idCliente = values[0],
                        idContrato = values[1],
                        valorReembolso = Convert.ToDecimal(values[2]),
                        convenio = values[3],
                        matricula = values[4],
                        cpfCnpj = values[5],
                        mesCompetencia = values[6],
                        sigla = values[7],
                        idProcesso = values[8],
                        idProduto = values[9],
                        status = StatusIntegracao.Pendente.ToString(),
                        codigoUsuarioInclusao = "integracao",
                        dataEnvio = DateTime.Now
                    };

                    integracoes.Add(integracao);
                }
            }

            return integracoes;
        }

        private async Task BulkInsert(List<Entidades.Integracao> integracoes)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings["PanBulkIntegracao"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = "dbo.BulkCopyDemoMatchingColumns";

                    try
                    {
                        bulkCopy.WriteToServer(integracoes);
                        bulkCopy.WriteToServer(  .WriteToServer(integracoes);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }

            }

            }
    }
}
