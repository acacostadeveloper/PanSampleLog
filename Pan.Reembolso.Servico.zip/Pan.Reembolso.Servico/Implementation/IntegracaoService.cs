﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class IntegracaoService
    {
        IIntegracaoRepository _integracaoRepository;
        IReembolsoService _reembolsoService;

        public IntegracaoService(IIntegracaoRepository integracaoRepository, IReembolsoService reembolsoService)
        {
            _integracaoRepository = integracaoRepository;
            _reembolsoService = reembolsoService;
        }

        private static Entidades.Reembolso ObterReembolsoIntegracao(Entidades.Integracao pendente)
        {
            // TODO - Implementar
            return new Entidades.Reembolso();
        }


        private async Task ProcessarIntegracao()
        {

            // TODO - Iniciar processo de Integracao
            var pendentes = _integracaoRepository.ObterIntegracaoPorStatus(StatusIntegracao.Pendente);

            var reembolsos = new List<Entidades.Reembolso>();

            // Montar Entidade Reembolso
            foreach (var integracaoPendente in pendentes)
            {

                // TODO - Verificar se o registro de integracao ja existe integrado
                if (ObterRegistroIntegracao(integracaoPendente)) continue;

                // 2 - Criticar por linha
                // ****** Verificar Fluent Validation

                // Verificar Resultado
                var reembolso = ObterReembolsoIntegracao(integracaoPendente);

                reembolso.dataSolicitacao = DateTime.Now;

                reembolso.valorReembolso = integracaoPendente.valorReembolso;

                reembolso.processoRegistro = new Entidades.ProcessoRegistro { processoRegistro = integracaoPendente.processoEntrada };

                reembolso.sigla = new Entidades.Sigla { codigoSigla = integracaoPendente.sigla };

                reembolsos.Add(reembolso);
            }

            // 3 - Enviar Para Interacao
            var reembolsosResult = _reembolsoService.IncluirReembolso(reembolsos);

            foreach (var reembolso in reembolsosResult)
            {
                var integracao = pendentes.Where(p => p.idIntegracao == reembolso.integracao);

            }
        }

        private bool ObterRegistroIntegracao(Integracao integracao)
        {
            IEnumerable<Integracao> IntegracaoDuplicidade;

            if (integracao.sigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO)
            {
                IntegracaoDuplicidade = _integracaoRepository.ObterIntegracaoPorCpfCnPj(integracao.cpfCnpj, integracao.valorReembolso, integracao.mesCompetencia);
            }
            else
            {
                IntegracaoDuplicidade = _integracaoRepository.ObterIntegracaoPorContrato(integracao.contrato, integracao.valorReembolso, integracao.mesCompetencia);
            }

            var result = IntegracaoDuplicidade.Any();

            if (result)
            {
                RecusarDuplicado(integracao);
            }

            return false;
        }

        public void RecusarDuplicado(Integracao integracao)
        {
            integracao.status = StatusIntegracao.Erro.ToString();
            integracao.mensagemErro = ReembolsoConstantes.INTEGRACAO_DUPLICADA;

            _integracaoRepository.PersistirIntegracao(integracao);
        }
    }

}
