﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class IntegracaoService : IIntegracaoService
    {
        IIntegracaoRepository _integracaoRepository;
        IReembolsoService _reembolsoService;
        IEventoRepository _eventoRepository;
        IProcessoRegistroRepository _processoRegistroRepository;

        public IntegracaoService(IIntegracaoRepository integracaoRepository, IReembolsoService reembolsoService, IProcessoRegistroRepository processoRegistroRepository, IEventoRepository eventoRepository)
        {
            _integracaoRepository = integracaoRepository;
            _reembolsoService = reembolsoService;
            _processoRegistroRepository = processoRegistroRepository;
            _eventoRepository = eventoRepository;
        }

        public async Task<string> PersistirIntegracao(string file)
        {
            string loteIntegracao = string.Empty;
            var dataTable = await ObterDadosArquivo(@file);

            using (var reader = new StreamReader(@file))
            {
                loteIntegracao = await _integracaoRepository.PersistirIntegracaoBulk(dataTable);
            }

            return loteIntegracao;
        }

        public async Task ProcessarIntegracaoPendentePorLote(string loteIntegracao)
        {
            try
            {
                var pendentes = _integracaoRepository.ObterIntegracaoPorStatus(StatusIntegracaoType.Pendente, loteIntegracao).ToList();

                var reembolsos = new List<Entidades.Reembolso>();

                reembolsos = SetIntegracaoReembolso(pendentes);

                var reembolsosResult = _reembolsoService.IncluirReembolso(reembolsos);

                SetListIntegracaoResult(pendentes, reembolsosResult);
            }
            catch (Exception ex)
            {
                // TODO tratasmente de Erro. AUDIT.
                // throw ex;
            }
        }

        private void SetListIntegracaoResult(List<Integracao> pendentes, IList<Entidades.Reembolso> reembolsosResult)
        {
            foreach (var reembolso in reembolsosResult)
            {
                var integracao = pendentes.Where(p => p.idIntegracao == reembolso.integracao).FirstOrDefault();

                SetIntegracaoResult(reembolso, integracao);
            }
        }

        private void SetIntegracaoResult(Entidades.Reembolso reembolso, Integracao integracao)
        {
            if (integracao != null)
            {
                integracao.mensagemErro = reembolso.mensagemErro;

                if (reembolso.statusReembolso == StatusReembolsoType.Registrado.ToString())
                {
                    integracao.status = StatusIntegracaoType.Integrado.ToString();
                    integracao.dataIntegracao = DateTime.Now;
                    integracao.idLote = reembolso.lote.idLote.ToString();
                    integracao.idReembolso = reembolso.numeroReembolso;
                }
                else
                {
                    integracao.status = StatusIntegracaoType.Erro.ToString();
                }

                if (integracao != null)
                {
                    _integracaoRepository.AtualizarIntegracao(integracao);
                }
            }
        }

        private List<Entidades.Reembolso> SetIntegracaoReembolso(List<Integracao> pendentes)
        {
            var reembolsos = new List<Entidades.Reembolso>();

            foreach (var integracaoPendente in pendentes)
            {
                if (ObterRegistroIntegracaoDuplicidade(integracaoPendente))
                {
                    continue;
                }

                var reembolso = ObterReembolsoIntegracao(integracaoPendente);

                reembolsos.Add(reembolso);
            }

            return reembolsos;
        }

        private Entidades.Reembolso ObterReembolsoIntegracao(Entidades.Integracao integracao)
        {
            var reembolso = new Entidades.Reembolso();

            reembolso.integracao = integracao.idIntegracao;

            reembolso.dtInclusao = DateTime.Now;

            reembolso.valorReembolso = integracao.valorReembolso;

            reembolso.usuarioInclusao = integracao.usuarioInclusao;

            reembolso.statusReembolso = StatusReembolsoType.Registrado.ToString();

            reembolso.contrato.numeroContrato = integracao.sigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO ? integracao.cpfCnpj : integracao.contrato;

            reembolso.contrato.produto.codigoProduto = integracao.produto;

            reembolso.contrato.cliente.numeroCpfCnpj = integracao.cpfCnpj;

            reembolso.mesCompetencia = integracao.mesCompetencia;

            reembolso.anoCompetencia = integracao.anoCompetencia;

            reembolso.contrato.cliente.nomeCliente = integracao.cliente;

            reembolso.contrato.convenio = integracao.convenio;

            reembolso.contrato.cliente.tipoPessoa =  Helper.IntegracaoHelper.GetTipoDePessoa(integracao.cpfCnpj);

            reembolso.contrato.coligada.codigoColigada = ReembolsoConstantes.COLIGADA;

            reembolso.departamento.codigoDepartamento = ReembolsoConstantes.DEPARTAMENTO;

            reembolso.processoRegistro = _processoRegistroRepository.ObterProcessoRegistroPorCodigoFluxo (Convert.ToInt16(integracao.processoEntrada), "ENTRADA");

            reembolso.sigla = new Entidades.Sigla { codigoSigla = integracao.sigla };

            reembolso.dtInclusao = integracao.dataInclusao;

            return reembolso;
        }

        private bool ObterRegistroIntegracaoDuplicidade(Integracao integracao)
        {
            IEnumerable<Integracao> IntegracaoDuplicidade;

            if (integracao.sigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO)
            {
                IntegracaoDuplicidade = _integracaoRepository.ObterIntegracaoPorCpfCnPj(integracao.cpfCnpj, integracao.valorReembolso, integracao.mesCompetencia);
            }
            else
            {
                IntegracaoDuplicidade = _integracaoRepository.ObterIntegracaoPorContrato(integracao.contrato, integracao.valorReembolso, integracao.mesCompetencia);
            }

            var result = IntegracaoDuplicidade.Any(s => s.status == StatusIntegracaoType.Integrado.ToString());

            if (result)
            {
                RecusarDuplicado(integracao);
            }

            return result;
        }

        private void RecusarDuplicado(Integracao integracao)
        {
            integracao.status = StatusIntegracaoType.Cancelado.ToString();
            integracao.mensagemErro = ReembolsoConstantes.INTEGRACAO_DUPLICADA;

            _integracaoRepository.AtualizarIntegracao(integracao);
        }

        private async Task<DataTable> ObterDadosArquivo(string file)
        {
            var integracoes = _integracaoRepository.ObterIntegracaoDataTable();

            DataRow integracao;

            var idLoteIntegracao = Guid.NewGuid();

            using (var reader = new StreamReader(@file))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');
                    CultureInfo[] cultures = { new CultureInfo("en-US") };

                    integracao = integracoes.NewRow();

                    integracao["CD_LOTE_INTEGRACAO"] = idLoteIntegracao;
                    integracao["CD_STATUS_INTEGRACAO"] = StatusIntegracaoType.Pendente.ToString();
                    integracao["DS_MENSAGEM_ERRO"] = "";
                    integracao["NM_CLIENTE"] = values[0];
                    integracao["NO_CONTRATO"] = values[1];
                    integracao["VL_REEMBOLSO"] = Convert.ToDecimal(values[2], cultures[0]);
                    integracao["NM_CONVENIO"] = values[3];
                    integracao["CD_MATRICULA"] = values[4];
                    integracao["NO_CPF_CNPJ"] = values[5];
                    integracao["NO_MES_COMPETENCIA"] = Convert.ToInt16(values[6]);
                    integracao["NO_ANO_COMPETENCIA"] = Convert.ToInt16(values[7]);
                    integracao["CD_SIGLA"] = values[8];
                    integracao["CD_PROCESSO_ENTRADA"] = values[9];
                    integracao["CD_PRODUTO"] = values[10];
                    // TODO - Incluir usuario Upload
                    integracao["CD_USUARIO_INCLUSAO"] = "integracao";
                    integracao["DT_INCLUSAO"] = DateTime.Now;

                    integracoes.Rows.Add(integracao);
                }
            }

            return integracoes;
        }
    }
}
