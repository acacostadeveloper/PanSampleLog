﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class IntegracaoService : IIntegracaoService
    {
        IIntegracaoRepository _integracaoRepository;
        IReembolsoService _reembolsoService;

        public IntegracaoService(IIntegracaoRepository integracaoRepository, IReembolsoService reembolsoService)
        {
            _integracaoRepository = integracaoRepository;
            _reembolsoService = reembolsoService;
        }

        public async Task PersistirIntegracao(string file)
        {
            var dataTable = await ObterDadosArquivo(@file);

            using (var reader = new StreamReader(@file))
            {
                var bulkResult = await _integracaoRepository.PersistirIntegracaoBulk(dataTable);
            }
        }

        public async Task ProcessarIntegracaoPendente()
        {
            try
            {
                // TODO - Iniciar processo de Integracao
                var pendentes = _integracaoRepository.ObterIntegracaoPorStatus(StatusIntegracaoType.Pendente).ToList();

                var reembolsos = new List<Entidades.Reembolso>();

                // Montar Entidade Reembolso
                foreach (var integracaoPendente in pendentes)
                {
                    if (ObterRegistroIntegracao(integracaoPendente)) continue;

                    // 2 - Criticar por linha
                    // ****** Verificar Fluent Validation

                    // Verificar Resultado
                    var reembolso = ObterReembolsoIntegracao(integracaoPendente);

                    reembolsos.Add(reembolso);
                }

                // 3 - Enviar Para Interacao
                var reembolsosResult = _reembolsoService.IncluirReembolso(reembolsos);

                foreach (var reembolso in reembolsosResult)
                {
                    var integracao = pendentes.Where(p => p.idIntegracao == reembolso.integracao).FirstOrDefault();

                    if (integracao != null)
                    {
                        integracao.status = StatusIntegracaoType.Integrado.ToString();
                        integracao.idLote = reembolso.idLote;
                        integracao.idReembolso = reembolso.numeroReembolso;

                        _integracaoRepository.PersistirIntegracao(integracao);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private static Entidades.Reembolso ObterReembolsoIntegracao(Entidades.Integracao integracao)
        {
            var reembolso = new Entidades.Reembolso();

            reembolso.integracao = integracao.idIntegracao;

            reembolso.dataSolicitacao = DateTime.Now;

            reembolso.valorReembolso = integracao.valorReembolso;

            reembolso.usuario.codigoUsuario = integracao.usuarioInclusao;

            reembolso.contrato.numeroContrato = integracao.contrato;

            reembolso.contrato.produto.codigoProduto = integracao.produto;

            reembolso.contrato.cliente.numeroCpfCnpj = integracao.cpfCnpj;

            reembolso.contrato.cliente.nomeCliente = integracao.cliente;

            // TODO - Validar Tipo Pessoa
            reembolso.contrato.cliente.tipoPessoa = "F";

            // TODO - Verificar Coligade
            reembolso.contrato.coligada.codigoColigada = "001";

            // TODO - Verificar Departamento
            reembolso.departamento.codigoDepartamento = "0000020";

            reembolso.processoRegistro = new Entidades.ProcessoRegistro { processoRegistro = integracao.processoEntrada };

            reembolso.sigla = new Entidades.Sigla { codigoSigla = integracao.sigla };

            return reembolso;
        }

        private bool ObterRegistroIntegracao(Integracao integracao)
        {
            IEnumerable<Integracao> IntegracaoDuplicidade;

            if (integracao.sigla == ReembolsoConstantes.CONTRATO_NAO_INTEGRADO)
            {
                IntegracaoDuplicidade = _integracaoRepository.ObterIntegracaoPorCpfCnPj(integracao.cpfCnpj, integracao.valorReembolso, integracao.mesCompetencia);
            }
            else
            {
                IntegracaoDuplicidade = _integracaoRepository.ObterIntegracaoPorContrato(integracao.contrato, integracao.valorReembolso, integracao.mesCompetencia);
            }

            var result = IntegracaoDuplicidade.Any(s => s.status == StatusIntegracaoType.Integrado.ToString());

            if (result)
            {
                RecusarDuplicado(integracao);
            }

            return false;
        }

        private void RecusarDuplicado(Integracao integracao)
        {
            integracao.status = StatusIntegracaoType.Cancelado.ToString();
            integracao.mensagemErro = ReembolsoConstantes.INTEGRACAO_DUPLICADA;

            _integracaoRepository.PersistirIntegracao(integracao);
        }

        private async Task<DataTable> ObterDadosArquivo(string file)
        {
            var integracoes = _integracaoRepository.ObterIntegracaoDataTable();

            DataRow integracao;

            using (var reader = new StreamReader(@file))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(';');

                    integracao = integracoes.NewRow();

                    integracao["ID_LOTE"] = null;
                    integracao["CD_STATUS_INTEGRACAO"] = StatusIntegracaoType.Pendente.ToString();
                    integracao["NM_CLIENTE"] = values[0];
                    integracao["NO_CONTRATO"] = values[1];
                    integracao["VL_REEMBOLSO"] = Convert.ToDecimal(values[2]);
                    integracao["NM_CONVENIO"] = values[3];
                    integracao["CD_MATRICULA"] = values[4];
                    integracao["NO_CPF_CNPJ"] = values[5];
                    integracao["NO_MES_COMPETENCIA"] = Convert.ToInt16(values[6]);
                    integracao["NO_ANO_COMPETENCIA"] = Convert.ToInt16(values[7]);
                    integracao["CD_SIGLA"] = values[8];
                    integracao["CD_PROCESSO_ENTRADA"] = values[9];
                    integracao["CD_PRODUTO"] = values[10];
                    integracao["CD_USUARIO_INCLUSAO"] = "integracao";
                    integracao["DT_INCLUSAO"] = DateTime.Now;

                    integracoes.Rows.Add(integracao);
                }
            }

            return integracoes;
        }
    }
}
