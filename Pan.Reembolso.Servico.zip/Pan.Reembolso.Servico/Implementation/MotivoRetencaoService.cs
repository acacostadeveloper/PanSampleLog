﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Servico.Implementation
{
    public class MotivoRetencaoService : IMotivoRetencaoService
    {
        private IMotivoRetencaoRepository _objMotivoRetencaoRep;
        public MotivoRetencaoService(IMotivoRetencaoRepository objMotivoRetencaoRep)
        {
            _objMotivoRetencaoRep = objMotivoRetencaoRep;
        }
        public IEnumerable<MotivoRetencao> ObterMotivosRetencao()
        {
            try
            {
                return _objMotivoRetencaoRep.ObterMotivosRetencao();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
