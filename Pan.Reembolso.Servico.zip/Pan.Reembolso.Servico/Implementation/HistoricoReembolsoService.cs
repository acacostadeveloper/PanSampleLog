﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class HistoricoReembolsoService : IHistoricoReembolsoService
    {
        private IHistoricoReembolsoRepository _historicoReembolsoRepository;
        private IEventoRepository _eventoRepository;

        public HistoricoReembolsoService(IHistoricoReembolsoRepository historicoReembolsoRepository, IEventoRepository eventoRepository)
        {
            _historicoReembolsoRepository = historicoReembolsoRepository;
            _eventoRepository = eventoRepository;
        }

        public HistoricoReembolso GerarHistoricoReembolsoProcessoRegistro(Entidades.Reembolso reembolso
            , StatusReembolsoType statusFinal
            , string statusContabil = "NAO INTEGRADO"
            , string usuario = "")
        {

            Evento evento= new Evento();

            evento = (statusFinal == StatusReembolsoType.Registrado || statusFinal == StatusReembolsoType.Bloqueado) ?
                _eventoRepository.ObterEventoPorProcessoRegistroInclusao(reembolso.processoRegistro.codigoProcessoRegistro)
                :
                _eventoRepository.ObterEventoPorProcessoRegistroEstorno(reembolso.processoRegistro.codigoProcessoRegistro);


            var historicoReembolso = new HistoricoReembolso
            {
                evento = evento,
                dataEvento = DateTime.Now,
                reembolso = reembolso.numeroReembolso,
                statusIni = reembolso.statusReembolso,
                statusFim = statusFinal.ToString(),
                usuarioInclusao = usuario,
                statusContabil = statusContabil,
                mensagemErro = reembolso.mensagemErro
            };

            historicoReembolso.evento = evento;

            return historicoReembolso;
        }


        public HistoricoReembolso GerarHistoricoReembolso(Entidades.Reembolso reembolso
            , StatusReembolsoType statusFinal
            , string codigoEvento
            , string statusContabil = "NAO INTEGRADO"
            , string usuario = "")
        {

            Evento evento = new Evento();

            evento = _eventoRepository.ObterEvento(codigoEvento);

            var historicoReembolso = new HistoricoReembolso
            {
                evento = evento,
                dataEvento = DateTime.Now,
                reembolso = reembolso.numeroReembolso,
                statusIni = reembolso.statusReembolso,
                statusFim = statusFinal.ToString(),
                usuarioInclusao = usuario,
                statusContabil = statusContabil,
                mensagemErro = reembolso.mensagemErro
            };

            historicoReembolso.evento = evento;

            return historicoReembolso;
        }


        public void GerarHistoricoReembolso(Entidades.Reembolso unit, StatusReembolsoType statusReembolso, string evento)
        {
            // TODO  - Gerar Historico
            //var historicoReembolso = GerarHistoricoReembolso(unit, statusReembolso, evento);

            //_historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
        }


        public void PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso)
        {
            _historicoReembolsoRepository.PersistirHistoricoReembolso(historicoReembolso);
        }

        public IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(long idReembolso)
        {
            return _historicoReembolsoRepository.ObterHistoricoReembolsoPorIdReembolso(idReembolso);
        }
    }
}
