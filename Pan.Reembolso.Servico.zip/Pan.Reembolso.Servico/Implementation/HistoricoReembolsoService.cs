﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    public class HistoricoReembolsoService : IHistoricoReembolsoService
    {
        private IHistoricoReembolsoRepository _historicoReembolsoRepository;
        private IEventoRepository _eventoRepository;
        private IMotivoBloqueioRepository _motivoBloqueioRepository;

        public HistoricoReembolsoService(IHistoricoReembolsoRepository historicoReembolsoRepository, 
            IEventoRepository eventoRepository,
            IMotivoBloqueioRepository motivoBloqueioRepository)
        {
            _historicoReembolsoRepository = historicoReembolsoRepository;
            _eventoRepository = eventoRepository;
            _motivoBloqueioRepository = motivoBloqueioRepository;
        }

        public HistoricoReembolso GerarHistoricoReembolsoProcessoRegistro(Entidades.Reembolso reembolso
            , StatusReembolsoType statusFinal
            , string statusContabil = "NAO INTEGRADO"
            , string usuario = "")
        {

            Evento evento= new Evento();

            evento = (statusFinal == StatusReembolsoType.Registrado || statusFinal == StatusReembolsoType.Bloqueado) ?

                _eventoRepository.ObterEventoPorProcessoRegistroInclusao(reembolso.processoRegistro.codigoProcessoRegistro)
                :
                _eventoRepository.ObterEventoPorProcessoRegistroEstorno(reembolso.processoRegistro.codigoProcessoRegistro);

            
            var historicoReembolso = new HistoricoReembolso
            {
                evento = evento,
                dataEvento = DateTime.Now,
                reembolso = reembolso.numeroReembolso,
                statusIni = reembolso.statusReembolso,
                statusFim = statusFinal.ToString(),
                statusUsuario = reembolso.statusUsuario,
                usuarioInclusao = usuario,
                statusContabil = statusContabil,
                mensagemErro = reembolso.mensagemErro,
                motivoBloqueio = reembolso.motivoBloqueio
            };

            historicoReembolso.evento = evento;

            return historicoReembolso;
        }


        public HistoricoReembolso GerarHistoricoReembolso(Entidades.Reembolso reembolso
            , StatusReembolsoType statusFinal
            , StatusReembolsoUserType statusUsuario
            , string codigoEvento
            , string statusContabil = "NAO INTEGRADO"
            , string usuario = ""
            , int processoRegistro = 0)
        {

            Evento evento = new Evento();

            evento = _eventoRepository.ObterEvento(codigoEvento);

            var historicoReembolso = new HistoricoReembolso
            {
                evento = evento,
                dataEvento = DateTime.Now,
                reembolso = reembolso.numeroReembolso,
                statusIni = reembolso.statusReembolso,
                statusFim = statusFinal.ToString(),
                statusUsuario = statusUsuario.ToString(),
                usuarioInclusao = usuario,
                statusContabil = statusContabil,
                mensagemErro = reembolso.mensagemErro,
                ProcessoRegistro = processoRegistro,
                motivoBloqueio = reembolso.motivoBloqueio
            };

            historicoReembolso.evento = evento;

            return historicoReembolso;
        }

        public void PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso)
        {
            _historicoReembolsoRepository.PersistirHistoricoReembolso(historicoReembolso);
        }

        public IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(long idReembolso)
        {
            return _historicoReembolsoRepository.ObterHistoricoReembolsoPorIdReembolso(idReembolso);
        }
    }
}
