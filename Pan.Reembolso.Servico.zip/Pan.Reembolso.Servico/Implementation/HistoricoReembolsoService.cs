﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Interface;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Implementation
{
    public class HistoricoReembolsoService : IHistoricoReembolsoService
    {
        private IHistoricoReembolsoRepository _historicoReembolsoRepository;
        private IEventoRepository _eventoRepository;

        public HistoricoReembolsoService(IHistoricoReembolsoRepository historicoReembolsoRepository, IEventoRepository eventoRepository)
        {
            _historicoReembolsoRepository = historicoReembolsoRepository;
            _eventoRepository = eventoRepository;
        }

        public HistoricoReembolso GerarHistoricoReembolso(Entidades.Reembolso reembolso, string statusFinal, string operacao, string statusContabil = "NAO INTEGRADO")
        {
            var evento = _eventoRepository.ObterEventoObterEventoPorOperacao(operacao);

            var historicoReembolso = new HistoricoReembolso
            {
                evento = evento,
                dataEvento = DateTime.Now,
                reembolso = reembolso.numeroReembolso,
                statusIni = reembolso.statusReembolso,
                statusFim = statusFinal,
                usuarioInclusao = reembolso.usuario.codigoUsuario,
                statusContabil = statusContabil
            };

            historicoReembolso.evento = evento;

            return historicoReembolso;
        }

        public void PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso)
        {
            _historicoReembolsoRepository.PersistirHistoricoReembolso(historicoReembolso);
        }


        public IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(int idReembolso)
        {
            return _historicoReembolsoRepository.ObterHistoricoReembolsoPorIdReembolso(idReembolso);
        }
    }
}
