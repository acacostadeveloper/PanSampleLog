﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;


namespace Pan.Reembolso.Servico.Implementation
{
    public class ProdutoService : IProdutoService
    {
        private IProdutoRepository _objProdutoRep;
        public ProdutoService(IProdutoRepository objProdutoRep)
        {
            _objProdutoRep = objProdutoRep;
        }

        public IEnumerable<Produto> ObterProdutos()
        {
            try
            {
                return _objProdutoRep.ObterProdutos();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
