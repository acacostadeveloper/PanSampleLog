﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Implementation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Helper.Implementation
{
    public class ValidationHelper
    {
        public List<Produto> produtos { get; private set; }
        public List<Sigla> siglas { get; private set; }
        public List<ProcessoRegistro> processoRegistros { get; private set; }
        public List<MotivoBloqueio> motivosBloqueios { get; private set; }

        public ValidationHelper()
        {
            produtos = new ProdutoRepository().ObterProdutos().ToList();
            siglas = new SiglaRepository().ObterSiglas().ToList();
            processoRegistros = new ProcessoRegistroRepository().ObterProcessoRegistro("").ToList();
            motivosBloqueios = new MotivoBloqueioRepository().ObterMotivoBloqueio().ToList();
        }
    }
}
