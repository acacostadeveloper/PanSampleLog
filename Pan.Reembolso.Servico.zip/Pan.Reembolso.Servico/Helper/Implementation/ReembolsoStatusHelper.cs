﻿using System;
using System.Collections.Generic;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Servico.Helper.Interface;
using Pan.Reembolso.Servico.Interface;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Helper.Implementation
{
    public class ReembolsoStatusHelper : IReembolsoStatusHelper
    {
        private readonly IHistoricoReembolsoService _historicoReembolsoService;
        private readonly IReembolsoRepository _reembolsoRepository;

        public ReembolsoStatusHelper(IHistoricoReembolsoService historicoReembolsoService, IReembolsoRepository reembolsoRepository)
        {
            _reembolsoRepository = reembolsoRepository;
            _historicoReembolsoService = historicoReembolsoService;
        }

        public static bool ValidarContaExistente(Entidades.Cliente cliente) 
        {
            return cliente.contaCredito.numeroConta != null;
        }

        public static bool VerificarObito(Entidades.Contrato value)
        {
            return !value.cliente.obito; 
        }

        public void AlterarStatusReembolso(List<long> ids, StatusReembolsoType novoStatus, string mensagemErro,  string evento, string aprovador = "usuario Pagamento", int processoRegistro = 0)
        {
            try
            {
                foreach (long id in ids)
                {
                    var reembolso = _reembolsoRepository.ObterReembolso(id);

                    reembolso.mensagemErro = mensagemErro;

                    PersistirStatusReembolso(reembolso, novoStatus, evento, processoRegistro);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void PersistirStatusReembolso(Entidades.Reembolso reembolso, StatusReembolsoType novoStatus, string codigoEvento, int processoRegistro = 0)
        {
            var oldStatatus = reembolso.statusReembolso;

            StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), reembolso.statusReembolso);

            var historicoReembolso = _historicoReembolsoService.GerarHistoricoReembolso(reembolso, novoStatus, codigoEvento, "NAO INTEGRADO", "", processoRegistro);

            _reembolsoRepository.AtualizarStatusReembolso(reembolso.numeroReembolso, novoStatus, reembolso.mensagemErro, reembolso.usuarioAlteracao, reembolso.usuarioAprovacao);

            _historicoReembolsoService.PersistirHistoricoReembolso(historicoReembolso);
        }
    }
}
