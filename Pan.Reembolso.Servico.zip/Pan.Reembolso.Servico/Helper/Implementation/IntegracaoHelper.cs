﻿using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Servico.Helper.Implementation
{
    internal class IntegracaoHelper
    {
      
        public static string GetTipoDePessoa(string cpfCNPJ)
        {
            //CPF: 122.556.847-85
            //CNPJ: 15.163.396/0001-65

            var validate = cpfCNPJ.Replace(".", "").Replace("-","");

            return (validate.Length == 11) ? "F" : (validate.Length == 14) ? "J" : string.Empty;
        }
    }
}
