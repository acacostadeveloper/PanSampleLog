﻿using System;
using System.Collections.Generic;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Servico.Helper;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Helper.Implementation
{
    internal static class ReembolsoHelper
    {
        private static Dictionary<StatusReembolsoType, List<string>> statusEvento = new Dictionary<StatusReembolsoType, List<string>>();

        internal static void ValidarReembolso(Entidades.Reembolso value)
        {
            string evento = string.Empty;

            if (!ReembolsoStatusHelper.ValidarContaExistente(value.contrato.cliente))
            {
                var motivoBloqueio = new MotivoBloqueioRepository().ObterMotivoBloqueio(ReembolsoTypes.MotivoBloqueioType.DadosBancariosAusente);

                value.statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado.ToString();
                value.mensagemErro = motivoBloqueio.descricaoMotivoBloqueio;
                value.motivoBloqueio = motivoBloqueio;
            }

            if (!ReembolsoStatusHelper.VerificarObito(value.contrato))
            {
                var motivoBloqueio = new MotivoBloqueioRepository().ObterMotivoBloqueio(ReembolsoTypes.MotivoBloqueioType.RegistroObito);
                value.statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado.ToString();
                value.mensagemErro = motivoBloqueio.descricaoMotivoBloqueio;
                value.motivoBloqueio = motivoBloqueio;
            }
        }

        public static bool NovoReembolso(Entidades.Reembolso unit)
        {
            return (unit.numeroReembolso == 0) || unit.statusReembolso != ReembolsoTypes.StatusReembolsoType.Registrado.ToString();
        }
    }
}
