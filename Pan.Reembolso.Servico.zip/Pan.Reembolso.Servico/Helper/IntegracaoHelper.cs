﻿using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Servico.Helper
{
    internal class IntegracaoHelper
    {
      
        public static string GetTipoDePessoa(string cpfCNPJ)
        {
            //CPF: 122.556.847-85
            //CNPJ: 15.163.396/0001-65
            if (cpfCNPJ.Contains("."))
            {
                if (cpfCNPJ.Length == 14)
                {
                    return "F";
                }
                else if (cpfCNPJ.Length == 18)
                {
                    return "J";
                }
            }
            else
            {
                if (cpfCNPJ.Length == 11)
                {
                    return "F";
                }
                else if (cpfCNPJ.Length == 14)
                {
                    return "J";
                }
            }
            return string.Empty;
        }



    }
}
