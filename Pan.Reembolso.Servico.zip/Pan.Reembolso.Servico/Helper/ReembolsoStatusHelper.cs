﻿using System;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Helper
{
    internal static class ReembolsoStatusHelper
    {

        public static bool ValidarContaFraudada(Cliente cliente)
        {
            return cliente.contaCredito != null;
        }

        public static bool ValidarContaExistente(Entidades.Cliente value) 
        {
            return (value.contaCredito.fraude == "0");
        }

        public static bool VerificarObito(Entidades.Contrato value)
        {
            return !value.cliente.obito; 
        }
    }
}
