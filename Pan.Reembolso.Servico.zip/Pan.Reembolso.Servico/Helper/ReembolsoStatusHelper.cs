﻿using System;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Helper
{
    internal static class ReembolsoStatusHelper
    {

        public static bool ValidarContaExistente(Entidades.Cliente cliente) 
        {
            return cliente.contaCredito != null;
        }

        public static bool VerificarObito(Entidades.Contrato value)
        {
            return !value.cliente.obito; 
        }
    }
}
