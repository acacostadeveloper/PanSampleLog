﻿using System.Collections.Generic;
using Pan.Reembolso.Entidades;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Helper.Interface
{
    public interface IReembolsoStatusHelper
    {
        void AlterarStatusReembolso(List<long> ids, StatusReembolsoType status, string mensagemErro, string evento, string aprovador = "usuario Pagamento", int processoRegistro = 0);
        void PersistirStatusReembolso(Entidades.Reembolso reembolso, StatusReembolsoType novoStatus, string codigoEvento, int processoRegistro = 0);
    }
}