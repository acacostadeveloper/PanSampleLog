﻿using System.Collections.Generic;
using Pan.Reembolso.Entidades;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Helper.Interface
{
    public interface IReembolsoStatusHelper
    {
        void AlterarStatusReembolso(List<long> ids, StatusReembolsoType novoStatus, string mensagemErro, string evento, MotivoBloqueio motivoBloqueio, string aprovador, int processoRegistro = 0, string userId = "");
        void PersistirStatusReembolso(Entidades.Reembolso reembolso, StatusReembolsoType novoStatus, string codigoEvento, int processoRegistro = 0, string userId = "");
    }
}