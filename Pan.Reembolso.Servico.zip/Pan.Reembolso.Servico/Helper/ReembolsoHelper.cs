﻿using System;
using System.Collections.Generic;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Servico.Helper;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Implementation
{
    internal static class ReembolsoHelper
    {
        private static Dictionary<StatusReembolsoType, List<string>> statusEvento = new Dictionary<StatusReembolsoType, List<string>>();

        private static void InitEventos()
        {
            statusEvento.Add(StatusReembolsoType.Cancelado, new List<string>() { "ESTORNO REEMBOLSO" });
            statusEvento.Add(StatusReembolsoType.Registrado, new List<string>() { "INCLUSAO REEMBOLSO", "MANUTECAO DADOS BANCARIOS", "DESBLOQUEIO OBITO" });
            statusEvento.Add(StatusReembolsoType.Bloqueado, new List<string>() { "BLOQUEIO OBITO", "DADOS BANCARIOS AUSENTES", "PAGAMENTO RECUSADO", "PAGAMENTO DEVOLVIDO", "CONTA FRAUDADA" });
            statusEvento.Add(StatusReembolsoType.PagamentoLiberado, new List<string>() { "ENVIO DE PAGAMENTO" });
            statusEvento.Add(StatusReembolsoType.Reembolsado, new List<string>() { "PAGAMENTO EFETIVADO" });
            statusEvento.Add(StatusReembolsoType.Rejeitado, new List<string>() { "CONTRATO INEXISTENTE", "CLIENTE INEXISTENTE"});
        }

        internal static void ValidarReembolso(Entidades.Reembolso value)
        {
            string evento = string.Empty;

            if (!ReembolsoStatusHelper.ValidarContaExistente(value.contrato.cliente))
            {
                value.statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado.ToString();
                value.mensagemErro = ReembolsoConstantes.DADOS_BANCARIOS_AUSENTES;
            }

            if (!ReembolsoStatusHelper.ValidarContaFraudada(value.contrato.cliente))
            {
                value.statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado.ToString();
                value.mensagemErro = ReembolsoConstantes.CONTA_FRAUDADA;
            }

            if (!ReembolsoStatusHelper.VerificarObito(value.contrato))
            {
                value.statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado.ToString();
                value.mensagemErro = ReembolsoConstantes.REGISTRO_OBITO;
            }
        }

        public static bool NovoReembolso(Entidades.Reembolso unit)
        {
            return (unit.numeroReembolso == 0) || unit.statusReembolso != ReembolsoTypes.StatusReembolsoType.Registrado.ToString();
        }
    }
}
