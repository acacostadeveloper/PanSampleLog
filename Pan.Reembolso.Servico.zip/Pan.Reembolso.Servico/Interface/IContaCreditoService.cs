﻿using System.Threading.Tasks;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IContaCreditoService
    {
        Task<ContaCreditoResult> ManterDadosBancarios(ContaCredito contaCredito, int idCliente);
        Task<ContaCreditoResult> VerificarContaCredito(ContaCredito contaCredito);
    }
}