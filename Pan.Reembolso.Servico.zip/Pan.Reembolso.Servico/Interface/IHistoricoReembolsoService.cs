﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IHistoricoReembolsoService
    {
        HistoricoReembolso GerarHistoricoReembolso(Entidades.Reembolso reembolso, string statusFinal, string operacao, string statusContabil = "NAO INTEGRADO");
        void PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso);
        IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(int idReembolso);
    }
}