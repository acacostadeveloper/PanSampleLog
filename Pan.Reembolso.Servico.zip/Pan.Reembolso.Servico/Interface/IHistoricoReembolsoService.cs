﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IHistoricoReembolsoService
    {
        HistoricoReembolso GerarHistoricoReembolso(Entidades.Reembolso reembolso, StatusReembolsoType statusFinal, string statusContabil = "NAO INTEGRADO", string usuario = "");
        void PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso);
        IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(long idReembolso);
    }
}