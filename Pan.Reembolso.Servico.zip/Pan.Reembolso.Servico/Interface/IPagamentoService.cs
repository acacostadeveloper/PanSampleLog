﻿using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pan.Reembolso.Servico.Interface
{
    public interface IPagamentoService
    {
        void AprovarPagamento(List<long> ids, string status, string mensagemErro, string user);
        void PersistirPagamento(Entidades.Pagamento pagamento);
        Task<PagamentoResult<object>> ObterRetiradaInternaPorContrato(string cpfCnpj, string produto);
        Task<PagamentoResult<Entidades.RetiradaUsoInterno>> ObterRetiradaInterna(string cpfCnpj, string produto);
        Task<RetiradaUsoInternoResult> EfetuarRetiradaInterna(List<long> ids, string cpfCnpj, decimal valor, bool retiradaTotal, int processoRegistro, string justificativa, string usuario);
        Entidades.Aprovacao ConsultarPagamentosPorStatus(DateTime? dtInicial, DateTime? dtFinal, string statusReembolso);
        Task<LoteRetiradaResult> RetirarLoteUsoInterno(string file);
        List<Entidades.IntegracaoRetiradaUsoInterno> ConsultarRetiradasPendentesLote();
        void AtualizarIntegracaoRetiradaUsoInternoLote(Entidades.IntegracaoRetiradaUsoInterno integracaoRetiradaUsoInterno);
        IList<Object> ObterHistoricoPorIdReembolso(long idReembolso);
        Task<IntegracaoRetiradaResult> ObterLoteRetiradaInterna(int idLote, DateTime? dataIni, DateTime? dataFim, ReembolsoTypes.StatusIntegracaoType status);
    }
}
