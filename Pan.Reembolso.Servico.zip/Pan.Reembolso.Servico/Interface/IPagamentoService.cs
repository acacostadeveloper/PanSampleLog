﻿using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pan.Reembolso.Servico.Interface
{
    public interface IPagamentoService
    {
        void AprovarPagamento(List<long> ids, string status, string mensagemErro);
        void PersistirPagamento(Entidades.Pagamento pagamento);
        Task<PagamentoResult> ObterRetiradaInterna(string cpfCnpj, string produto);
        Task<Result> EfetuarRetiradaInterna(List<long> ids, string cpfCnpj, decimal valor, bool retiradaTotal, string justificativa, string usuario);
        Object ConsultarPagamentosPorStatus(DateTime? dtInicial, DateTime? dtFinal, string statusReembolso);
        Task<Result> RetirarLoteUsoInterno(string file);
    }
}
