﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IUploadService
    {
        Task<int> ProcessarArquivo(string fileName, byte[] streamArquivo);
        Task<Result> PersistirArquivoLoteRetiradaInterna(string fileName, byte[] streamArquivo);
    }
}