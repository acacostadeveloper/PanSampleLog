﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IUploadService
    {
        Task ProcessarArquivo(string fileName, byte[] streamArquivo);
    }
}