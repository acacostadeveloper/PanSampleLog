﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pan.Reembolso.Servico.Interface
{
    public interface IClienteService
    {
        Task<List<Cliente>> ConsultarClientes(Repositorio.Filters.ReembolsoFilter filter);
        Task<ClienteResult> PersistirCliente(Entidades.Cliente cliente);
        Task<List<Object>> ConsultarClientesParaManutencaoDadosBancarios(string numeroCpfCnpj, string nomeCliente);
        Task<ContaCreditoResult> ManterDadosBancarios(Entidades.ContaCredito contaCredito, int idCliente, string userId, string cpfCnpjcliente = "");
        void IncluirTransferenciaDireito(Entidades.TransferenciaDireito transferencia);
        Task<IEnumerable<Entidades.TransferenciaDireito>> ConsultarTransferenciasCliente(string numeroCpfCnpjCliente);
        TransferenciaDireito ObterTransferenciaDireitoAtivoPorId(long idTransferenciaDireito);
    }
}
