﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pan.Reembolso.Servico.Interface
{
    public interface IClienteService
    {
        Task<List<Entidades.Cliente>> ConsultarClientes(string numeroCpfCnpj, string nomeCliente);
        Task<ClienteResult> PersistirCliente(Entidades.Cliente cliente);
        Task<List<Object>> ConsultarClientesParaManutencaoDadosBancarios(string numeroCpfCnpj, string nomeCliente);
        Task<ContaCreditoResult> ManterDadorBancarios(Entidades.ContaCredito contaCredito, int idCliente, string cpfCnpjcliente = "");
        void IncluirTransferenciaDireito(Entidades.TransferenciaDireito transferencia);
        Task<IEnumerable<Entidades.TransferenciaDireito>> ConsultarTransferenciasCliente(string numeroCpfCnpjCliente);
        TransferenciaDireito ObterTransferenciaDireitoAtivoPorId(long idTransferenciaDireito);
    }
}
