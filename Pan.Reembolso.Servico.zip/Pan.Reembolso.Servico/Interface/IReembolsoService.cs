﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IReembolsoService
    {
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(long id);
        Pan.Reembolso.Entidades.Reembolso ObterReembolsoByIdContrato(string codigoContrato);
        IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        //Entidades.Reembolso ObterDetalhesReembolso(int idReembolso);
        IList<Pan.Reembolso.Entidades.Reembolso> IncluirReembolso(IEnumerable<Pan.Reembolso.Entidades.Reembolso> values);
        void ExcluirReembolso(List<long> idsEstornar);
        IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso);
        void AlterarStatusReembolso(List<long> ids, string status, string mensagemErro);
        Object ConsultarPagamentosARealizar(DateTime? dtInicial, DateTime? dtFinal);
        Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        List<Object> ConsultarClientesParaManutencaoDadosBancarios();
    }
}
