﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IReembolsoService
    {
        Entidades.Reembolso ObterReembolso(long id);
        IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        IncluirReembolsoResult IncluirReembolso(IEnumerable<Entidades.Reembolso> values, string userId);
        void ExcluirReembolso(List<long> idsEstornar);
        IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso);
        //Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        Task<Result> AtualizarReembolsosPorDadosBancarios(string cpfCnpjcliente, ReembolsoTypes.StatusReembolsoType status, string messageError, MotivoBloqueio motivoBloqueio, string userId);
        List<Entidades.Reembolso> ObterReembolsoList();
        ReembolsoResult ObterReembolsoPorCpfCnpj(string cpfCnpj);
        void ProcessarReembolsoAsync(IEnumerable<Entidades.Reembolso> values);
        void PersistirReembolso(Entidades.Reembolso reembolso, string userId);
    }
}
