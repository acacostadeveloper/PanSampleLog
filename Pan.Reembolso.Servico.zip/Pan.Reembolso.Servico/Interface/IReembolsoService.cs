﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IReembolsoService
    {
        Entidades.Reembolso ObterReembolso(long id);
        IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        IList<Entidades.Reembolso> IncluirReembolso(IEnumerable<Pan.Reembolso.Entidades.Reembolso> values);
        void ExcluirReembolso(List<long> idsEstornar);
        IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso);
        Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        Task<Result> AtualizarReembolsosPorDadosBancarios(string cpfCnpjcliente, ReembolsoTypes.StatusReembolsoType status, string messageError);
        List<Entidades.Reembolso> ObterReembolsoList();
        void PersistirReembolso(Entidades.Reembolso reembolso);
    }
}
