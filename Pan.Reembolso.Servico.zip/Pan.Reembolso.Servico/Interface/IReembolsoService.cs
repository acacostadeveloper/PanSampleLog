﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Results;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IReembolsoService
    {
        Entidades.Reembolso ObterReembolso(long id);
        Entidades.Reembolso ObterReembolsoByIdContrato(string codigoContrato);
        IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        IList<Entidades.Reembolso> IncluirReembolso(IEnumerable<Pan.Reembolso.Entidades.Reembolso> values);
        void ExcluirReembolso(List<long> idsEstornar);
        IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso);
        void AlterarStatusReembolso(List<long> ids, string status, string mensagemErro, string evento);
        Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        Task<Result> AtualizarReembolsosPorDadosBancarios(string cpfCnpjcliente, ReembolsoTypes.StatusReembolsoType status, string messageError);
        List<Entidades.Reembolso> ObterReembolsoList();
    }
}
