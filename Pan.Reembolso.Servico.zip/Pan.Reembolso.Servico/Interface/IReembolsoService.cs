﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IReembolsoService
    {
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(int id);
        Pan.Reembolso.Entidades.Reembolso ObterReembolsoByIdContrato(string codigoContrato);
        IEnumerable<Entidades.Reembolso> ObterReembolsos(ReembolsoFilter filter);
        IList<Pan.Reembolso.Entidades.Reembolso> IncluirReembolso(IEnumerable<Pan.Reembolso.Entidades.Reembolso> values);
        void ExcluirReembolso(List<int> idsAEstornar);
        IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(int idReembolso);
    }
}
