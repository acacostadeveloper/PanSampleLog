﻿using System;
using System.Collections.Generic;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Servico.Interface
{
    public interface ITransferenciaDireitoService
    {
        Result PersistirTransferenciaDireito(ContaCredito conta, string numeroCpfCnpjCliente, string numeroCpfCnpjTerceiro, string nomeTerceiro, DateTime dtInicioVigencia, DateTime? dtFimVigencia, string usuarioInclusao, string documento);
        List<TransferenciaDireito> ConsultarTransferenciasCliente(string numeroCpfCnpjCliente);
        TransferenciaDireito ObterTransferenciaDireitoAtivoPorId(long idTransferenciaDireito);
    }
}