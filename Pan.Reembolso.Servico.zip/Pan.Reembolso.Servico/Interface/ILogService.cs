﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Interface
{
    public interface ILogService
    {
        Task LogAsync(Entidades.Log log);
    }
}
