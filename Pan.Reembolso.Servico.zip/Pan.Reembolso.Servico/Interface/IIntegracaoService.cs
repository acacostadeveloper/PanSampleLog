﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IIntegracaoService
    {
        Task<int> PersistirIntegracao(string file, string userId);
        Task ProcessarIntegracaoPendentePorLote(int loteIntegracao, string userId);
        IEnumerable<Object> ConsultarReembolsoIntegracao(IntegracaoFilter filter);
    }
}
