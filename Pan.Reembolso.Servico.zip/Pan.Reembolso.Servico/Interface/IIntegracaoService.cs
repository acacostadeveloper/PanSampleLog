﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IIntegracaoService
    {
        Task<int> PersistirIntegracao(string file);
        Task ProcessarIntegracaoPendentePorLote(int loteIntegracao);
        List<Integracao> ConsultarReembolsoIntegracaoPorLoteIntegracao(int idLoteIntegracao);
    }
}
