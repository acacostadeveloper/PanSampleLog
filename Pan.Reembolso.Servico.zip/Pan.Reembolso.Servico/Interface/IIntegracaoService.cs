﻿using System.Threading.Tasks;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IIntegracaoService
    {
        Task PersistirIntegracao(string file);
        Task ProcessarIntegracaoPendente();
    }
}