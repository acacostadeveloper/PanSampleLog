﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Pan.Reembolso.Servico.Interface
{
    public interface IProcessoRegistroService
    {
        IEnumerable<object> ObterProcessoRegistroList();
        IEnumerable<Entidades.ProcessoRegistro> ObterProcessoRegistros();
    }
}
