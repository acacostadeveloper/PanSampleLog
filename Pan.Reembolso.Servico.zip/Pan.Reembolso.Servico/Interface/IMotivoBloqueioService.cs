﻿using System.Collections.Generic;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IMotivoBloqueioService
    {
        IEnumerable<MotivoBloqueio> ObterMotivosBloqueio();
    }
}