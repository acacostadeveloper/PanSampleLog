﻿using FluentValidation;
using Pan.Reembolso.Servico.Helper.Implementation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Validations
{
    public class IncluirReembolsoValidation : AbstractValidator<Entidades.Reembolso>
    {
        private ValidationHelper _validationHelper;

        public IncluirReembolsoValidation()
        {
            _validationHelper = new ValidationHelper();

            RuleFor(x => x.contrato.numeroContrato).NotEmpty().WithMessage("Contrato Obrigatorio");
            RuleFor(x => x.contrato).NotNull().WithMessage("Contrato Obrigatorio");

            RuleFor(x => x.contrato).NotNull().WithMessage("Contrato Obrigatorio");

            RuleFor(x => x.usuarioInclusao).NotNull().WithMessage("Usuario Inclusão Obrigatorio");
            RuleFor(x => x.usuarioInclusao).NotEmpty().WithMessage("Usuario Inclusão Obrigatorio");

            RuleFor(x => x.usuarioInclusao).NotNull().WithMessage("Usuario Inclusão Obrigatorio");
            RuleFor(x => x.usuarioInclusao).NotEmpty().WithMessage("Usuario Inclusão Obrigatorio");

            RuleFor(x => x.valorReembolso).NotNull().WithMessage("Valor reembolso Obrigatorio");
            RuleFor(x => x.valorReembolso).GreaterThan(0).WithMessage("Valor reembolso inválido");

            RuleFor(x => x.anoCompetencia).NotNull().WithMessage("Ano Competencia Obrigatorio");
            RuleFor(x => x.anoCompetencia).LessThanOrEqualTo(DateTime.Now.Year).WithMessage("Ano Competencia inválido");

            RuleFor(x => x.mesCompetencia).NotNull().WithMessage("Mes Competencia Obrigatorio");

            RuleFor(x => x.processoRegistro).NotNull().WithMessage("Processo Registro Obrigatorio");
            RuleFor(x => x.processoRegistro.codigoProcessoRegistro).NotNull().WithMessage("Codigo Processo Registro Obrigatorio");

            RuleFor(x => x.sigla).NotNull().WithMessage("Sigla Obrigatoria");
            RuleFor(x => x.sigla).Must(SiglaValidate).WithMessage("Sigla inválida.");

            RuleFor(x => x.contrato.convenio).NotNull().WithMessage("Convênio Obrigatorio");
            RuleFor(x => x.contrato.convenio).NotEmpty().WithMessage("Convênio Obrigatorio");

            RuleFor(x => x.departamento).NotNull().WithMessage("Departamento Obrigatorio");
            RuleFor(x => x.departamento).NotEmpty().WithMessage("Departamento Obrigatorio");

            RuleFor(x => x.contrato.cliente.numeroCpfCnpj).NotNull().WithMessage("Cpf/Cnpj Obrigatorio");
            RuleFor(x => x.contrato.cliente.numeroCpfCnpj).NotEmpty().WithMessage("Cpf/Cnpj Obrigatorio");

            RuleFor(x => x.contrato.cliente.matricula).NotNull().WithMessage("Matricula Obrigatorio");
            RuleFor(x => x.contrato.cliente.matricula).NotEmpty().WithMessage("Matricula Obrigatorio");

            // DOMINIOS

            RuleFor(x => x.contrato.produto).Must(ProdutoValidate).WithMessage("Produto inválido.");
            RuleFor(x => x.processoRegistro).Must(ProcessoValidate).WithMessage("Processo Registro inválido.");
        }

        private bool SiglaValidate(Entidades.Sigla sigla)
        {
            return _validationHelper.siglas.Select(x => x.codigoSigla).Contains(sigla.codigoSigla);
        }

        private bool ProdutoValidate(Entidades.Produto produto)
        {
            return _validationHelper.produtos.Select(x => x.codigoProduto).Contains(produto.codigoProduto);
        }

        private bool ProcessoValidate(Entidades.ProcessoRegistro processoRegistro)
        {
            return _validationHelper.processoRegistros.Select(x => x.codigoProcessoRegistro).Contains(processoRegistro.codigoProcessoRegistro);
        }
    }
}
