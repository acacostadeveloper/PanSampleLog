﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Extensions
{
    public static class Extensions
    {
        public static void PermiteEstorno(this Entidades.Reembolso reembolso)
        {
            reembolso.permiteEstorno = (reembolso.statusReembolso.ToLower() == "registrado"|| reembolso.statusReembolso.ToLower() == "bloqueado");
        }
    }
}
