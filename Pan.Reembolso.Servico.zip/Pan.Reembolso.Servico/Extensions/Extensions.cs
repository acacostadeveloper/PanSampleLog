﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Extensions
{
    public static class Extensions
    {
        public static void PermiteEstorno(this Entidades.Reembolso reembolso)
        {
            reembolso.permiteEstorno = (reembolso.statusReembolso == StatusReembolsoType.Registrado.ToString()
                || reembolso.statusReembolso == StatusReembolsoType.Bloqueado.ToString());
        }
    }
}
