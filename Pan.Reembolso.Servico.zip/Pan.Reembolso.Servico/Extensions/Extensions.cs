﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Servico.Extensions
{
    public static class Extensions
    {
        public static void PermiteEstorno(this Entidades.Reembolso reembolso)
        {
            reembolso.permiteEstorno = (reembolso.statusReembolso == StatusReembolsoType.Registrado.ToString()
                || reembolso.statusReembolso == StatusReembolsoType.Bloqueado.ToString());
        }

        public static string GetTipoDePessoa(this Entidades.Cliente cliente)
        {
            //CPF: 122.556.847-85
            //CNPJ: 15.163.396/0001-65

            var validate = cliente.numeroCpfCnpj.Replace(".", "").Replace("-", "");

            return (validate.Length == 11) ? "F" : (validate.Length == 14) ? "J" : string.Empty;
        }

        public static bool Ativa(this Entidades.TransferenciaDireito transferenciaDireito)
        {
            return (transferenciaDireito.indicadorAtivo == "1" && (DateTime.Now >= transferenciaDireito.dtInicioVigencia && DateTime.Now <= transferenciaDireito.dtFimVigencia));
        }

        public static bool Ativa(this Entidades.DatabaseEntities.TransferenciaDireitoDatabase transferenciaDireito)
        {
            return (transferenciaDireito.indicadorAtivo == "1" && (DateTime.Now >= transferenciaDireito.dtInicioVigencia && DateTime.Now <= transferenciaDireito.dtFimVigencia));
        }

        public static bool ConstaBlackList(this List<ContaRejeicao> blackList, ContaCredito contaCredito)
        {
            return blackList.Exists(s => s.digitoAgencia == contaCredito.digitoAgencia &&
                                        s.digitoConta == contaCredito.digitoConta &&
                                        s.numeroAgencia == contaCredito.numeroAgencia &&
                                        s.numeroBanco == contaCredito.numeroBanco &&
                                        s.numeroConta == contaCredito.numeroConta &&
                                        s.tipoConta == contaCredito.tipoConta);
        }
    }
}
