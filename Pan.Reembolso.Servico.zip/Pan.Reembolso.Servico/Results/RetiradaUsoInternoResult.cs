﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Results
{
    public class RetiradaUsoInternoResult : Result
    {
        public RetiradaUsoInternoResult()
        {
            Reembolsos = new List<IdReembolsoResult>();
        }
        public Entidades.Pagamento PagamentoEfetuado { get; set; }
        public List<IdReembolsoResult> Reembolsos { get; set; }
        
    }
    

    public class IdReembolsoResult
    {
        public long idReembolso { get; set; }
        public decimal valorReembolso { get; set; }
        public string statusReembolso { get; set; }
    }
}
