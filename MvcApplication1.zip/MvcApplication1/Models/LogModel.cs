﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting.Messaging;
using System.Web.Http;

namespace Pan.Reembolso.Api.Models
{
    public class  LogModel : Entidades.Log
    { 
        public string TotalTime
        {
            get
            {
                if (ResponseTimestamp == null || RequestTimestamp == null) return null;
                var time = ResponseTimestamp.Value.Subtract(RequestTimestamp.Value);
                return $"{time.TotalHours:00}:{time.TotalMinutes:00}:{time.TotalSeconds:00}.{time.TotalMilliseconds / 10:000}";
            }
            set => throw new NotImplementedException();
        }

        public HttpError HttpError { get; set; }

    }
}