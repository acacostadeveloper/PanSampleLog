﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using SimpleInjector;
using SimpleInjector.Integration.WebApi;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Implementation;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Api.Handlers;
using Pan.Reembolso.Infra.Security.Interface;
using Pan.Reembolso.Infra.Security.Implementation;

namespace Pan.Reembolso.Api
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();

            WebApiConfig.Register(GlobalConfiguration.Configuration);

            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            LoadInjectionContainer();

            //GlobalConfiguration.Configuration.MessageHandlers.Add(DependencyResolver.Current.GetService<LogHandler>());

            //GlobalConfiguration.Configuration.MessageHandlers.Add(DependencyResolver.Current.GetService<AuthHandler>());

            GlobalConfiguration.Configuration.EnsureInitialized(); 
        }

        private void LoadInjectionContainer()
        {
            var container = new Container();
            //---------------------------------------------------------------------------------
            
            container.Register<IReembolsoService, ReembolsoService>();
            container.Register<IUploadService, UploadService>();
            container.Register<IReembolsoRepository, ReembolsoRepository>();
            container.Register<IClienteRepository, ClienteRepository>();
            container.Register<IContratoRepository, ContratoRepository>();
            container.Register<IDepartamentoRepository, DepartamentoRepository>();
            container.Register<IIntegracaoRepository, IntegracaoRepository>();

            container.Register<ICartaoLobApp, CartaoLobApp>();
            container.Register<ICdcLobApp, CdcLobApp>();
            container.Register<IConsignadoLobApp, ConsignadoLobApp>();
            container.Register<IConsorcioLobApp, ConsorcioLobApp>();
            container.Register<ILogService, LogService>();
            container.Register<ILogRepository, LogRepository>();

            container.Register<IAutorizationService, AutorizationService>();
            container.Register<IAutorization, Autorization>();

            //---------------------------------------------------------------------------------
            container.Verify();
            DependencyResolver.SetResolver(new SimpleInjectorDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new SimpleInjectorDependencyResolver(container);   
        }

    }
}