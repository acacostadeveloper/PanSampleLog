﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/reembolso")]
    public class ReembolsoController : ApiController
    {
        private IReembolsoService reembolsoService;

        private IReembolsoService GetReembolsoService()
        {
            return reembolsoService;
        }

        private void SetReembolsoService(IReembolsoService value)
        {
            reembolsoService = value;
        }

        public ReembolsoController(IReembolsoService ReembolsoService) => SetReembolsoService(ReembolsoService);

        [Route("{id}")]
        [HttpGet]
        public Entidades.Reembolso GetById(int id)
        {
            try
            {
                return GetReembolsoService().ObterReembolso(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }            
        }

        [Route("status/{status}")]
        [HttpGet]
        public IEnumerable<Entidades.Reembolso> GetByStatus(int status)
        {
            try
            {
                return new List<Entidades.Reembolso>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Route("contrato/{codigoContrato}")]
        [HttpGet]
        public Entidades.Reembolso GetByContrato(string codigoContrato)
        {
            try
            {
                return GetReembolsoService().ObterReembolso(codigoContrato);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Route("")]
        [HttpPost]
        public IEnumerable<Entidades.Reembolso> Post([FromBody]IEnumerable<Entidades.Reembolso> value)
        {
            try 
            {
                var result = GetReembolsoService().IncluirReembolso(value);
                return result;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        [Route("{id}")]
        [HttpPut]
        public void Put(int id, [FromBody]Entidades.Reembolso value)
        {
            try
            {
                GetReembolsoService().EditarReembolso(value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [Route("{id}")]
        [HttpDelete]
        public void Delete(int id)
        {
            try
            {
                GetReembolsoService().ExcluirReembolso(id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}