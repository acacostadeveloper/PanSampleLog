﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/reembolso")]
    public class ReembolsoController : ApiController
    {
        private IReembolsoService reembolsoService;

        private IReembolsoService GetReembolsoService()
        {
            return reembolsoService;
        }

        private void SetReembolsoService(IReembolsoService value)
        {
            reembolsoService = value;
        }

        public ReembolsoController(IReembolsoService ReembolsoService) => SetReembolsoService(ReembolsoService);

        [Route("{id}")]
        [HttpGet]
        public HttpResponseMessage GetById(int id)
        {
            try
            {
                var reembolso = GetReembolsoService().ObterReembolso(id);

                return VerificaReembolso(reembolso);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }            
        }

        [Route("status/{status}")]
        [HttpGet]
        public HttpResponseMessage GetByStatus(int status)
        {
            try
            {
                // TODO - Implementar/Chamar busca por status
                var reembolsos = new List<Entidades.Reembolso>();

                if (reembolsos.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, reembolsos);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, reembolsos);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("contrato/{codigoContrato}")]
        [HttpGet]
        public HttpResponseMessage GetByContrato(string codigoContrato)
        {
            try
            {
                var reembolso = GetReembolsoService().ObterReembolso(codigoContrato);

                return VerificaReembolso(reembolso);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("")]
        [HttpPost]
        public HttpResponseMessage Post([FromBody]IEnumerable<Entidades.Reembolso> value)
        {
            try 
            {
                var result = GetReembolsoService().IncluirReembolso(value);

                return Request.CreateResponse(HttpStatusCode.Created, result);
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("{id}")]
        [HttpPut]
        public HttpResponseMessage Put(int id, [FromBody]Entidades.Reembolso value)
        {
            try
            {
                GetReembolsoService().EditarReembolso(value);
                return Request.CreateResponse(HttpStatusCode.OK);

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("{id}")]
        [HttpDelete]
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                GetReembolsoService().ExcluirReembolso(id);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        private HttpResponseMessage VerificaReembolso(Entidades.Reembolso reembolso)
        {
            if (reembolso.idLote != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, reembolso);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NoContent, reembolso);
            }
        }
    }
}