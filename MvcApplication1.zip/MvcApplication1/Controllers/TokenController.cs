﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{

    [RoutePrefix("api/token")]
    public class TokenController : ApiController
    {

        private IAutorizationService autorizationService;

        private IAutorizationService GetAutorizationService()
        {
            return autorizationService;
        }

        private void AutorizationService(IAutorizationService value)
        {
            autorizationService = value;
        }

        public TokenController(IAutorizationService autorizationService) => AutorizationService(autorizationService);


        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetToken(string clientId = "", string clientSecret = "")
        {
            try
            {

                if (string.IsNullOrWhiteSpace(clientId))
                {
                    throw new ArgumentException("message", nameof(clientId));
                }

                if (string.IsNullOrWhiteSpace(clientSecret))
                {
                    throw new ArgumentException("message", nameof(clientSecret));
                }


                var userName = clientId.Replace(' ', '+');
                var passWord = clientSecret.Replace(' ', '+');

                var result = GetAutorizationService().GetToken(userName, passWord);

                return Request.CreateResponse(HttpStatusCode.Created, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}