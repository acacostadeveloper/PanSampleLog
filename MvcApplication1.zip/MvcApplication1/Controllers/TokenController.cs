﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{

    [RoutePrefix("api/token")]
    public class TokenController : ApiController
    {

        private IAutorizationService autorizationService;

        private IAutorizationService GetAutorizationService()
        {
            return autorizationService;
        }

        private void AutorizationService(IAutorizationService value)
        {
            autorizationService = value;
        }

        public TokenController(IAutorizationService autorizationService) => AutorizationService(autorizationService);


        [Route("{userName}")]
        [HttpGet]
        public HttpResponseMessage GetToken(string userName)
        {
            try
            {
                var pass = "";

                var result = GetAutorizationService().GetToken(userName, pass);

                return Request.CreateResponse(HttpStatusCode.Created, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}