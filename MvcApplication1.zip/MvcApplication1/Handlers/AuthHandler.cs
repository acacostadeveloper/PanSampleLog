﻿using Pan.Reembolso.Infra.Security.Helper;
using Pan.Reembolso.Infra.Security.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Handlers
{
    public class AuthHandler
    {
        private IAutorization _autorization;

        public AuthHandler(IAutorization autorization)
        {
            _autorization = autorization;
        }

        public void Authorize()
        {
            _autorization.Authorize(); 
        }
    }
}