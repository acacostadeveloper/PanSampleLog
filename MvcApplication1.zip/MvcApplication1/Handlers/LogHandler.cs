﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using Newtonsoft.Json;
using Pan.Reembolso.Api.Models;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Handlers
{
    public class LogHandler : DelegatingHandler
    {
        private ILogService logService;

        private ILogService GetLogService()
        {
            return logService;
        }

        private void SetLogService(ILogService value)
        {
            logService = value;
        }

        public LogHandler(ILogService logService) => SetLogService(logService);

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {

            var logModel = CreateLog(request);
            if (request.Content != null)
            {
                await request.Content.ReadAsStringAsync()
                    .ContinueWith(task =>
                    {
                        logModel.RequestContentBody = JsonConvert.DeserializeObject(task.Result);
                    }, cancellationToken);
            }

            return await base.SendAsync(request, cancellationToken)
                .ContinueWith(task =>
                {
                    var response = task.Result;

                    logModel.ResponseStatusCode = (int)response.StatusCode;
                    if (logModel.ResponseStatusCode >= 500)
                    {
                        logModel.HttpError = response.Content.ReadAsAsync<HttpError>(cancellationToken).Result;
                    }
                    logModel.ResponseTimestamp = DateTime.Now;

                    if (response.Content != null)
                    {
                        logModel.LogId = request.GetCorrelationId();
                        logModel.ResponseContentBody = JsonConvert.DeserializeObject(response.Content.ReadAsStringAsync().Result);
                        logModel.ResponseHeaders = GetHeaders(response.Content.Headers);
                    }

                    var log = Mapper(logModel);

                    GetLogService().Log(log);

                    return response;

                }, cancellationToken);

        }

        private Log Mapper(LogModel logModel)
        {
            return new Log
            {
                Application = logModel.Application,
                CorrelationId = logModel.LogId,
                Machine = logModel.Machine,
                IpAddress = logModel.RequestIpAddress,
                RequestUri = logModel.RequestUri,
                StatusCode = logModel.ResponseStatusCode,
                RequestTimestamp = logModel.RequestTimestamp,
                ResponseTimestamp = logModel.ResponseTimestamp,
                TotalTime = (int)(logModel.ResponseTimestamp.Value - logModel.RequestTimestamp.Value).TotalSeconds,
                JsonLog = JsonConvert.SerializeObject(logModel, Formatting.Indented),
                MessageError = logModel.HttpError?.ExceptionMessage
            };
        }

        private LogModel CreateLog(HttpRequestMessage request)
        {
            var context = ((HttpContextBase)request.Properties["MS_HttpContext"]);

            return new LogModel
            {
                Application = ReembolsoConstantes.ID_APLICATION,
                User = context.User.Identity.Name,
                Machine = Environment.MachineName,
                RequestIpAddress = context.Request.UserHostAddress,
                RequestMethod = request.Method.Method,
                RequestHeaders = GetHeaders(request.Headers),
                RequestTimestamp = DateTime.Now,
                RequestUri = request.RequestUri.ToString()
            };
        }

        private static IDictionary<string, string> GetHeaders(HttpHeaders headers)
        {
            var retorno = new Dictionary<string, string>();

            foreach (var item in headers.ToList())
            {
                if (item.Value == null) continue;
                var header = item.Value.Aggregate(string.Empty, (current, value) => current + (value + " "));

                header = header.TrimEnd(" ".ToCharArray());
                retorno.Add(item.Key, header);
            }
            return retorno;
        }
    }
}