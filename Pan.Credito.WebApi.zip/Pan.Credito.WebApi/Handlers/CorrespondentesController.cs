﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Authenticate;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class CorrespondentesController : ApiController
    {
        private readonly ICorrespondenteServices _correspondenteServices;

        public CorrespondentesController(ICorrespondenteServices correspondenteServices)
        {
            _correspondenteServices = correspondenteServices;
        }
        
        [HttpGet]
        [Route("~/correspondentes/obterCorrespondentes/{cep}")]
        public HttpResponseMessage ObterCorrespondentes(string cep)
        {
            if (cep == null) return Request.CreateResponse(HttpStatusCode.BadRequest);
            try
            {
                var correspondentes = _correspondenteServices.ObterCorrespondente(cep);
                return correspondentes == null ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.OK, correspondentes);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
      
        protected override void Dispose(bool disposing)
        {
            _correspondenteServices.Dispose();
            base.Dispose(disposing);
        }
    }
}
