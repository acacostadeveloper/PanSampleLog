﻿using System;
using System.Web;
using System.Web.Http;
using Pan.Credito.WebApi.Handlers;

namespace Pan.Credito.WebApi
{
    public class WebApiApplication : HttpApplication
    {
        protected void Application_Start()
        {
            Environment.SetEnvironmentVariable("ENV", "PROD");
            Environment.SetEnvironmentVariable("CYBER", "ON");
            GlobalConfiguration.Configure(WebApiConfig.Register);
            SimpleInjectorWebApiInitializer.Initialize();
            GlobalConfiguration.Configuration.MessageHandlers.Add(new LogHandler());
        }
    }
}