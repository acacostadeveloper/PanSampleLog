﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Authenticate;
using Pan.Credito.WebApi.Filters;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class BoletosController : ApiController
    {
        private readonly IBoletoServices _boletoServices;

        public BoletosController(IBoletoServices boletoServices)
        {
            _boletoServices = boletoServices;
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/boletos/segundaViaParcela")]
        public HttpResponseMessage SegundaViaParcela([FromBody] SegundaViaParcela segundaViaParcela)
        {
            try
            {
                switch (segundaViaParcela.Origem)
                {
                    case Origens.Funcao:
                        {
                            var boletos = _boletoServices.GerarPDFBinarioParcelaFuncao(segundaViaParcela.NumeroContrato, segundaViaParcela.Proximos);
                            return boletos == null ? Request.CreateResponse(HttpStatusCode.BadRequest) : Request.CreateResponse(HttpStatusCode.OK, Convert.ToBase64String(boletos));
                        }
                    case Origens.PanSolution:
                        {
                            throw new NotImplementedException();
                        }
                }
                ModelState.AddModelError("ModelState", "Origem Inválida");
                return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/boletos/segundaViaAcordo")]
        public HttpResponseMessage SegundaViaAcordo([FromBody] SegundaViaAcordo segundaViaAcordo)
        {
            try
            {
                switch (segundaViaAcordo.Origem)
                {
                    case Origens.Funcao:
                        {
                            var boletos = _boletoServices.GerarPDFBinarioAcordoFuncao(segundaViaAcordo.NumeroAcordo, segundaViaAcordo.NumeroContrato);
                            return boletos == null ? Request.CreateResponse(HttpStatusCode.BadRequest) : Request.CreateResponse(HttpStatusCode.OK, Convert.ToBase64String(boletos));
                        }
                    case Origens.PanSolution:
                        {
                            throw new NotImplementedException();
                        }
                }
                ModelState.AddModelError("ModelState", "Origem Inválida");
                return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        protected override void Dispose(bool disposing)
        {
            _boletoServices.Dispose();
            base.Dispose(disposing);
        }
    }
    #region HelpClasses
    public class SegundaViaParcela
    {
        [Required]
        public string NumeroContrato { get; set; }
        [Required]
        public DateTime DataVencimento { get; set; }
        [Required]
        public int Proximos { get; set; }
        [Required]
        public Origens Origem { get; set; }
    }
    public class SegundaViaAcordo
    {
        [Required]
        public string NumeroContrato { get; set; }
        [Required]
        public string NumeroAcordo { get; set; }
        [Required]
        public DateTime DataVencimento { get; set; }
        [Required]
        public Origens Origem { get; set; }
    }
    #endregion


}
