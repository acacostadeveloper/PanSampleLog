﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Common;
using Pan.Credito.Domain.Entidades.Helpers;
using Pan.Credito.Domain.Repository;
using Pan.Credito.WebApi.Authenticate;

namespace Pan.Credito.WebApi.Controllers
{
    public class SecurityController : ApiController
    {
        private readonly ISmsDispatcher _smsDispatcher;
        private readonly IEmailDispatcher _emailDispatcher;
        private readonly IVerificationCodeRepository _verificationCode;

        public SecurityController(ISmsDispatcher smsDispatcher, IVerificationCodeRepository verificationCode, IEmailDispatcher emailDispatcher)
        {
            _smsDispatcher = smsDispatcher;
            _verificationCode = verificationCode;
            _emailDispatcher = emailDispatcher;
        }

        [HttpPost]
        [Route("~/security/sms/verificationCode")]
        [CustomAuthorize]
        public HttpResponseMessage GenerateCodeSms([FromBody] GenerateCodeSms generateCode)
        {
            try
            {
                var token = new TokenWorkFlow
                {
                    Documento = generateCode.Documento,
                    Data = DateTime.Now,
                    DDD = generateCode.DDD,
                    Celular = generateCode.Celular,
                    Channel="sms",
                    Code = GenerateSecurityCode()
                };

                var insert = _verificationCode.InsertToken(token);
                if (!(insert > 0)) return Request.CreateResponse(HttpStatusCode.BadRequest);
                _smsDispatcher.EnviarSmsCode(token.DDD, token.Celular, token.Code, token.Documento);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [Route("~/security/email/verificationCode")]
        [CustomAuthorize]
        public HttpResponseMessage GenerateCodeEmail([FromBody] GenerateCodeEmail generateCode)
        {
            try
            {
                var token = new TokenWorkFlow
                {
                    Documento = generateCode.Documento,
                    Data = DateTime.Now,
                    Channel = "email",
                    Email = generateCode.Email,
                    Code = GenerateSecurityCode()
                };

                var insert = _verificationCode.InsertToken(token);
                if (!(insert > 0)) return Request.CreateResponse(HttpStatusCode.BadRequest);
                _emailDispatcher.SendTokenEmail(token.Email, token.Code);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }



        [HttpGet]
        [Route("~/security/verificationCode/{code}/cliente/{documento}")]
        [CustomAuthorize]
        public HttpResponseMessage VerificationCode(string code, string documento)
        {
            try
            {
                return
                    Request.CreateResponse(_verificationCode.CheckToken(code, documento)
                        ? HttpStatusCode.OK
                        : HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        protected override void Dispose(bool disposing)
        {
            _smsDispatcher.Dispose();
            _verificationCode.Dispose();
            base.Dispose(disposing);
        }

        private string GenerateSecurityCode()
        {
            const string CHARS = "0123456789";
            var random = new Random();
            return new String(Enumerable.Repeat(CHARS, 5).Select(s => CHARS[random.Next(CHARS.Length)]).ToArray());
        }
    }

    public class GenerateCodeSms
    {
        [Required]
        public int DDD { get; set; }

        [Required]
        public int Celular { get; set; }

        [Required]
        public string Documento { get; set; }
    }

    public class GenerateCodeEmail
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Documento { get; set; }
    }
}