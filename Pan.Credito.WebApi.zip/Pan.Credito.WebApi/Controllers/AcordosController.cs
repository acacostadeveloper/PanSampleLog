﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Authenticate;
using Pan.Credito.WebApi.Filters;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class AcordosController : ApiController
    {
       private readonly IAcordoServices _acordoServices;
       
        public AcordosController(IAcordoServices acordoServices)
        {
            _acordoServices = acordoServices;
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/acordos/registrarAcordo")]
        public HttpResponseMessage RegistrarAcordo([FromBody]RegistraAcordo registraAcordo)
         {
            try
            {
                switch (registraAcordo.Origem)
                {
                    case Origens.Funcao:
                        {
                            var acordo = _acordoServices.EfetuarAcordoFuncao(new SolicitaAcordo
                             {
                                 Contrato = registraAcordo.Contrato,
                                 DataPagamento = registraAcordo.DataPagamento,
                                 Desconto = registraAcordo.Desconto,
                                 DatasVencimento = registraAcordo.DataVencParcelas,
                                 WithPDF = registraAcordo.WithPDF
                             });
                            if (acordo == null)
                            {
                                ModelState.AddModelError("Mensagem", "erro ao obter acordos função wsgv.obteracordos");
                                return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
                            }
                        return Request.CreateResponse(HttpStatusCode.OK, acordo);
                        }
                    case Origens.PanSolution:
                        {
                            return Request.CreateResponse(HttpStatusCode.NotImplemented);
                        }
                }
                ModelState.AddModelError("ERRO", "ORIGEM INVALIDA");
                return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/acordos/simularAcordoQuitar")]
        public HttpResponseMessage SimularAcordoQuitar([FromBody]SolicitaAcordo solicitaAcordo)
        {
            try
            {
                var acordo = _acordoServices.SimularAcordoQuitar(solicitaAcordo);
                if (!string.IsNullOrEmpty(acordo.LinhaDigitavel)) throw new Exception("[ERRO FUNCAO ACORDO SEM LINHA DIGITAVEL]");
                return Request.CreateResponse(HttpStatusCode.OK, acordo);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/acordos/renegocie/simularAcordoRenegocie")]
        public HttpResponseMessage SimularAcordoRenegocie([FromBody]AcordoRenegocie acordoRenegocie)
        {
            try
            {
                var acordo = _acordoServices.SimularAcordoRenegocie(acordoRenegocie);
                if (acordo.Parcelas.Count == 0) throw new Exception("[ERRO WSCDC CONSULTARSALDOPARCELAS RETORNO NULO]");
                return Request.CreateResponse(HttpStatusCode.OK, acordo);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/acordos/renegocie/registrarAcordo")]
        public HttpResponseMessage RegistrarAcordoRenegocie([FromBody]AcordoRenegocie registraAcordo)
        {
            try
            {
                var acordo = _acordoServices.EfetuarAcordoRenegocie(registraAcordo);
                if (acordo == null)
                {
                    ModelState.AddModelError("Mensagem", "erro ao obter acordos função wsgv.obteracordos");
                    return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
                }
                if (!registraAcordo.WithPDF)
                {
                    acordo.PDF = null;
                }
                return Request.CreateResponse(HttpStatusCode.OK, acordo);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        [HttpPost]
        [ValidateModel]
        [Route("~/acordos/cancelarAcordo")]
        public HttpResponseMessage CancelarAcordo([FromBody]CancelaAcordo cancelaAcordo)
        {
            try
            {
                var retorno = _acordoServices.CancelarAcordo(cancelaAcordo.Origem,cancelaAcordo.NumeroAcordo, cancelaAcordo.Contrato);
                return Request.CreateResponse(HttpStatusCode.OK, retorno);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
        [HttpPost]
        [ValidateModel]
        [Route("~/acordos/obterAcordos")]
        public HttpResponseMessage ObterAcordos([FromBody]ObterAcordo obterAcordo)
        {
            try
            {
                switch (obterAcordo.Origem)
                {
                    case Origens.Funcao:
                        var acordosFuncao = _acordoServices.ObterAcordosFuncao(obterAcordo.Contrato);
                        return acordosFuncao.Count == 0 ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.OK, acordosFuncao);
                    case Origens.PanSolution:
                        return Request.CreateResponse(HttpStatusCode.NotImplemented);
                        //var acordosPansolution = _acordoServices.ObterAcordosPansolution(Convert.ToInt64(obterAcordo.NumeroAcordo));
                        //return acordosPansolution.Count == 0 ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.OK, acordosPansolution);
                }
                return Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        protected override void Dispose(bool disposing)
        {
            _acordoServices.Dispose();
            base.Dispose(disposing);
        }
    }

    #region HELP CLASS

    public class ObterAcordo
    {
        [Required]
        public Origens Origem { get; set; }
        [Required]
        public string Contrato { get; set; }
        [Required]
        public string NumeroAcordo { get; set; }
    }

    public class CancelaAcordo
    {
        [Required]
        public Origens Origem { get; set; }
        [Required]
        public string Contrato { get; set; }
        [Required]
        public string NumeroAcordo { get; set; }
    }
    public class RegistraAcordo
    {
        [Required]
        public Origens Origem { get; set; }
        [Required]
        public string Contrato { get; set; }
        [Required]
        public DateTime DataPagamento { get; set; }
        [Required]
        public bool Desconto { get; set; }
        [Required]
        public List<DateTime> DataVencParcelas { get; set; }

        public bool WithPDF { get; set; }

        public RegistraAcordo()
        {
            Desconto = false;
            DataVencParcelas = new List<DateTime>();
        }
    }

    
    #endregion
}
