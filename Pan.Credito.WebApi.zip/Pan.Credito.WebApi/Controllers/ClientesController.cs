﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Authenticate;
using Pan.Credito.WebApi.Filters;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class ClientesController : ApiController
    {
        private readonly IClienteServices _clienteServiceService;
        
        public ClientesController(IClienteServices clienteServices)
        {
            _clienteServiceService = clienteServices;
        }

        [HttpGet]
        [Route("~/clientes/obterCliente/{documento}")]
        public HttpResponseMessage ObterCliente(string documento)
        {
            if (documento == null) return Request.CreateResponse(HttpStatusCode.BadRequest);
            try
            {
                var cliente = _clienteServiceService.ObterCliente(documento);
                return cliente == null ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.OK, cliente);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/clientes/updateCliente")]
        public HttpResponseMessage GravarCliente([FromBody]Cliente cliente)
        {
            try
            {
                var retorno = _clienteServiceService.GravarCliente(cliente);
                if (retorno == string.Empty) return Request.CreateResponse(HttpStatusCode.Accepted, cliente);
                ModelState.AddModelError("Mensagem", retorno);
                return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
      
        protected override void Dispose(bool disposing)
        {
            _clienteServiceService.Dispose();
            base.Dispose(disposing);
        }
    }




}
