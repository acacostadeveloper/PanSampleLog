﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using Pan.Credito.Domain.Common;
using Pan.Credito.WebApi.Authenticate;
using Pan.Credito.WebApi.Filters;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class HelpersController : ApiController
    {
        private readonly IEmailDispatcher _emailDispatcher;
        private readonly ISmsDispatcher _smsDispatcher;

        public HelpersController(ISmsDispatcher smsDispatcher, IEmailDispatcher emailDispatcher)
        {
            _smsDispatcher = smsDispatcher;
            _emailDispatcher = emailDispatcher;
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/helpers/enviarSms")]
        public HttpResponseMessage EnviarSms([FromBody] EnviaSms enviaSms)
        {
            try
            {
                var retorno = _smsDispatcher.EnviarSms(enviaSms.DDD, enviaSms.Celular, enviaSms.LinhaDigitavel,
                    enviaSms.Documento, enviaSms.DataVenc, enviaSms.ValorBoleto);
                return retorno
                    ? Request.CreateResponse(HttpStatusCode.OK, "Sms enviado com sucesso !")
                    : Request.CreateResponse(HttpStatusCode.BadRequest);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        [HttpPost]
        [ValidateModel]
        [Route("~/helpers/enviarEmail")]
        public HttpResponseMessage EnviarEmail([FromBody] EnviaEmail enviaEmail)
        {
            try
            {
                var bytes = Convert.FromBase64String(enviaEmail.Anexo);
                _emailDispatcher.EnviarEmail(enviaEmail.Email, ref bytes);
                return Request.CreateResponse(HttpStatusCode.OK, "Email enviado com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpGet]
        [Route("~/admin/log/{env}")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public HttpResponseMessage HabilitaLog(string env)
        {
            try
            {
                switch (env.ToUpper())
                {
                    case "HML":
                        Environment.SetEnvironmentVariable("ENV", "HML");
                        break;
                    case "PROD":
                        Environment.SetEnvironmentVariable("ENV", "PROD");
                        break;
                }

                return Request.CreateResponse(HttpStatusCode.OK,
                    string.Format("LOG ATIVO EM MODO {0}", Environment.GetEnvironmentVariable("ENV")));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpGet]
        [Route("~/admin/cyber/{env}")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public HttpResponseMessage CyberOff(string env)
        {
            try
            {
                var ambiente = Environment.GetEnvironmentVariable("CYBER");
                Environment.SetEnvironmentVariable("CYBER", ambiente == "ON" ? "OFF" : "ON");
                return Request.CreateResponse(HttpStatusCode.OK, string.Format("VARIAVEL DE AMBIENTE CYBER {0}", Environment.GetEnvironmentVariable("CYBER")));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        protected override void Dispose(bool disposing)
        {
            _smsDispatcher.Dispose();
            base.Dispose(disposing);
        }
    }

    #region HelpClasses

    public class EnviaSms
    {
        [Required] public int DDD { get; set; }

        [Required] public int Celular { get; set; }

        [Required] public string LinhaDigitavel { get; set; }

        [Required] public string Documento { get; set; }

        [Required] public DateTime DataVenc { get; set; }

        [Required] public decimal ValorBoleto { get; set; }
    }

    public class EnviaEmail
    {
        [EmailAddress] [Required] public string Email { get; set; }

        [Required] public string Anexo { get; set; }
    }

    #endregion
}