﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Authenticate;
using Swashbuckle.Swagger.Annotations;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class OperacoesController : ApiController
    {
        private readonly IOperacaoServices _operacoesServices;
        
        public OperacoesController(IOperacaoServices operacoesServices)
        {
            _operacoesServices = operacoesServices;
        }

        [HttpGet]
        [Route("~/operacoes/obterOperacao/{contrato}")]
        public HttpResponseMessage ObterOperacao(string contrato)
        {
            try
            {
                if (contrato == null) return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
                var operacao = _operacoesServices.ObterOperacao(contrato);
                return operacao == null ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.OK, operacao);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpGet]
        [Route("~/operacoes/obterOperacoes/{documento}")]
        [SwaggerResponse(HttpStatusCode.OK, Type = typeof(List<OperacaoCredito>))]
        public HttpResponseMessage ObterOperacoes(string documento)
        {
            try
            {
                if (documento == null) return Request.CreateResponse(HttpStatusCode.BadRequest, ModelState);
               
                var operacoes = _operacoesServices.ObterOperacoes(documento);
                return operacoes.Count == 0 ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.OK, operacoes);
            }
            catch (Exception ex)
            { 
               
                ModelState.AddModelError(string.Format("Erro RequestId==>{0}", Request.GetCorrelationId()), ex.InnerException.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
        
        protected override void Dispose(bool disposing)
        {
            _operacoesServices.Dispose();
            base.Dispose(disposing);
        }

    }
    
}
