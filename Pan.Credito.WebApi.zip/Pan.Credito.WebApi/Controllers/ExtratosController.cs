﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Authenticate;
using Pan.Credito.WebApi.Filters;

namespace Pan.Credito.WebApi.Controllers
{
    [CustomAuthorize]
    public class ExtratosController : ApiController
    {
        private readonly IExtratoServices _extratoServices;

        public ExtratosController(IExtratoServices extratoServices)
        {
            _extratoServices = extratoServices;
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/pagamentos")]
        public HttpResponseMessage ObterPagamentos([FromBody]ExtratoRequest extratoRequest)
        {
            try
            {
                var retorno = _extratoServices.ObterExtratoDePagamentos(extratoRequest.Ano, extratoRequest.Documento,extratoRequest.Email, extratoRequest.EnviarEmail);
                if (string.IsNullOrEmpty(retorno) && !extratoRequest.EnviarEmail)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent);
                }
                return !string.IsNullOrEmpty(retorno) && !extratoRequest.EnviarEmail? Request.CreateResponse(HttpStatusCode.OK, retorno): Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return ex.Message == "SEM CONTEUDO" ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
      
        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/tarifas")]
        public HttpResponseMessage ObterTarifas([FromBody]ExtratoRequest extratoRequest)
        {
            try
            {
                var retorno = _extratoServices.ObterExtratoTarifas(extratoRequest.Ano, extratoRequest.Documento, extratoRequest.Email, extratoRequest.EnviarEmail);
                if (string.IsNullOrEmpty(retorno) && !extratoRequest.EnviarEmail)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, "Não foram encontrados registros");
                }
                return !string.IsNullOrEmpty(retorno) && !extratoRequest.EnviarEmail ? Request.CreateResponse(HttpStatusCode.OK, retorno) : Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return ex.Message == "SEM CONTEUDO" ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.InternalServerError,ModelState);
            }

        }
     
        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/informeDeRendimentos")]
        public HttpResponseMessage ObterInformeDeRendimento([FromBody]ExtratoRequest extratoRequest)
        {
            try
            {
                var retorno = _extratoServices.ObterInformeDeRedimentos(extratoRequest.Ano, extratoRequest.Documento, extratoRequest.Email, extratoRequest.EnviarEmail);
                if (string.IsNullOrEmpty(retorno) && !extratoRequest.EnviarEmail)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, "Não foram encontrados registros");
                }
                return !string.IsNullOrEmpty(retorno) && !extratoRequest.EnviarEmail ? Request.CreateResponse(HttpStatusCode.OK,retorno): Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return ex.Message == "SEM CONTEUDO" ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
      
        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/declaracaoContratoQuitado")]
        public HttpResponseMessage DeclaracaoContratoQuitado([FromBody] DeclaracaoRequest declaracaoRequest)
        {
            try
            {

                var retorno = _extratoServices.DeclaracaoContratoQuitado(declaracaoRequest.Contrato, declaracaoRequest.Email, declaracaoRequest.EnviarEmail);
                if (string.IsNullOrEmpty(retorno) && !declaracaoRequest.EnviarEmail)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent);
                }
                return !string.IsNullOrEmpty(retorno) && !declaracaoRequest.EnviarEmail ? Request.CreateResponse(HttpStatusCode.OK, retorno): Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return ex.Message == "SEM CONTEUDO" ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
     
        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/obterCartaResumo")]
        public HttpResponseMessage ObterCartaResumo([FromBody] CartaResumoRequest cartaResumo)
        {
            try
            {
                var retorno = _extratoServices.ObterCartaResumo(cartaResumo.Documento,cartaResumo.Contrato, cartaResumo.Email,cartaResumo.EnviarEmail);
                if (string.IsNullOrEmpty(retorno) && !cartaResumo.EnviarEmail)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent);
                }
                return !string.IsNullOrEmpty(retorno) && !cartaResumo.EnviarEmail ? Request.CreateResponse(HttpStatusCode.OK,retorno): Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return ex.Message == "SEM CONTEUDO" ? Request.CreateResponse(HttpStatusCode.NoContent) : Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/GuiaTransferenciaDivida")]
        public HttpResponseMessage GuiaTransfDivida([FromBody] GuiaTransfDivida guiaTransfDivida)
        {
            try
            {
                var arquivos = _extratoServices.GuiaTransferenciaDivida(guiaTransfDivida.Email, guiaTransfDivida.EnviarEmail);
                return arquivos.Count > 0 && !guiaTransfDivida.EnviarEmail ? Request.CreateResponse(HttpStatusCode.OK, arquivos) : Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/extratos/GuiaSubstituicaoDeGarantia")]
        public HttpResponseMessage GuiaSubstituicaoDeGarantia([FromBody] GuiaSubGarantia guiaSubGarantia)
        {
            try
            {
                var arquivos = _extratoServices.GuiaSubstituicaoDeGarantia(guiaSubGarantia.Email, guiaSubGarantia.EnviarEmail);
                return arquivos.Count > 0 && !guiaSubGarantia.EnviarEmail ? Request.CreateResponse(HttpStatusCode.OK, arquivos) : Request.CreateResponse(HttpStatusCode.OK, "Enviado por email com sucesso !");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        protected override void Dispose(bool disposing)
        {
            _extratoServices.Dispose();
            base.Dispose(disposing);
        }
    }

    #region HELP_CLASSES
    public class GuiaTransfDivida
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public bool EnviarEmail { get; set; }
    }
    public class GuiaSubGarantia
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public bool EnviarEmail { get; set; }
    }
    public class CartaResumoRequest
    {
        [Required]
        public string Documento { get; set; }
        [Required]
        public string Contrato { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public bool EnviarEmail { get; set; }
    }
   
    public class DeclaracaoRequest
    {
        [Required]
        public string Contrato { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public bool EnviarEmail { get; set; }
    }
    
    public class ExtratoRequest
    {
        [Required]
        public string Documento { get; set; }
        [Required]
        public int Ano { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public bool EnviarEmail { get; set; }
    }
    #endregion
}
