﻿using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Pan.Credito.WebApi.Controllers
{
    public class HealthController : ApiController
    {
        [HttpGet]
        [Route("~/health/life")]
        public HttpResponseMessage Get()
        {
            return Request.CreateResponse(HttpStatusCode.OK);
        }
    }
}
