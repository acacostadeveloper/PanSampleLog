﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Pan.Credito.Domain.Entidades.Protocolo;
using Pan.Credito.Domain.Services;
using Pan.Credito.WebApi.Filters;

namespace Pan.Credito.WebApi.Controllers
{
    public class ProtocolosController : ApiController
    {
        private readonly IProtocoloServices _protocoloServices;

        public ProtocolosController(IProtocoloServices protocoloServices)
        {
            _protocoloServices = protocoloServices;
        }

        [HttpPost]
        [ValidateModel]
        [Route("~/protocolos/protocoloSpa")]
        public HttpResponseMessage ProtocoloSpa([FromBody] ProtocoloModel protocoloModel )
        {
            try
            {
                var protocolo = _protocoloServices.AbrirProtocolo(protocoloModel);
                return Request.CreateResponse(HttpStatusCode.OK, protocolo);
            }
            catch (Exception ex)
            {
                var message = string.Format("FALHA AO INTEGRAR PROTOCOLO NO SPA {0}",ex.Message);
                ModelState.AddModelError("ERRO", message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        protected override void Dispose(bool disposing)
        {
            _protocoloServices.Dispose();
            base.Dispose(disposing);
        }
    }
}
