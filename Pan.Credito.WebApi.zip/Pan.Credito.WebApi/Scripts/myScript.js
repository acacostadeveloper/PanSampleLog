﻿$(document).ready(function () {

    $("#logo__title").text("BANCO PAN");

});