using System.Web.Http;
using Pan.Credito.Application.Services;
using Pan.Credito.CrossCutting;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Common;
using Pan.Credito.Domain.Repository;
using Pan.Credito.Domain.Services;
using Pan.Credito.Infrastructure.Adapters;
using Pan.Credito.Infrastructure.Repositories;
using SimpleInjector;
using SimpleInjector.Integration.WebApi;

namespace Pan.Credito.WebApi
{
    public static class SimpleInjectorWebApiInitializer
    {
        public static void Initialize()
        {
            var container = new Container();
            container.Options.DefaultScopedLifestyle = new WebApiRequestLifestyle();

            InitializeContainer(container);

            container.RegisterWebApiControllers(GlobalConfiguration.Configuration);

            container.Verify();

            GlobalConfiguration.Configuration.DependencyResolver = new SimpleInjectorWebApiDependencyResolver(container);
        }

        private static void InitializeContainer(Container container)
        {
            #region Application
            container.Register<IAcordoServices, AcordoServices>(Lifestyle.Scoped);
            container.Register<IBoletoServices, BoletoServices>(Lifestyle.Scoped);
            container.Register<IClienteServices, ClienteServices>(Lifestyle.Scoped);
            container.Register<ICorrespondenteServices, CorrespondenteServices>(Lifestyle.Scoped);
            container.Register<IOperacaoServices, OperacaoServices>(Lifestyle.Scoped);
            container.Register<IExtratoServices, ExtratoServices>(Lifestyle.Scoped);
            container.Register<IProtocoloServices, ProtocoloServices>(Lifestyle.Scoped);
            #endregion

            #region Infra
            container.Register<ICucAdapter, CucAdapter>(Lifestyle.Scoped);
            container.Register<ICyberAdapter, CyberAdapter>(Lifestyle.Scoped);
            container.Register<IFuncaoAdapter, FuncaoAdapter>(Lifestyle.Scoped);
            container.Register<IRcpRepository, RcpRepository>(Lifestyle.Scoped);
            container.Register<IExtratosAdapter, ExtratosAdapter>(Lifestyle.Scoped);
            container.Register<IRenegocieRepository, RenegocieRepository>(Lifestyle.Scoped);
            container.Register<ICobrancaAdapter, CobrancaAdapter>(Lifestyle.Scoped);
            container.Register<IVerificationCodeRepository, VerificationCodeRepository>(Lifestyle.Scoped);
            container.Register<IPansolutionAdapter, PansolutionAdapter>(Lifestyle.Scoped);
            #endregion

            #region CrossCutting
            container.Register<IEmailDispatcher, EmailDispatcher>(Lifestyle.Scoped);
            container.Register<ISmsDispatcher, SmsDispatcher>(Lifestyle.Scoped);
            #endregion

        }
    }
}