using System;
using System.Configuration;
using System.Web.Http;
using WebActivatorEx;
using Pan.Credito.WebApi;
using Swashbuckle.Application;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace Pan.Credito.WebApi
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            var baseUrl = @"http://localhost:48456";
            var thisAssembly = typeof(SwaggerConfig).Assembly;
            if (ConfigurationManager.AppSettings["ENV"] == "HML")
            {
                baseUrl  = @"http://veiculoshml-api.bancopan.com.br";
            }
            if (ConfigurationManager.AppSettings["ENV"] == "PROD")
            {
                baseUrl = @"https://veiculos-api.bancopan.com.br";
            }

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                    {

                        c.RootUrl(req => baseUrl);
                        c.Schemes(new[] { "http", "https" });
                        c.SingleApiVersion("v1", "BARRAMENTO URA E CHAT BANCO PAN");
                        c.ApiKey("Token")
                            .Description("Token de Indentifica��o")
                            .Name("Authorization")
                            .In("header");
                       
                    })
                .EnableSwaggerUi(c =>
                    {
                        c.EnableApiKeySupport("Authorization", "header");
                        c.InjectStylesheet(thisAssembly, "Pan.Credito.WebApi.Content.myStyle.css");
                        c.InjectJavaScript(thisAssembly, "Pan.Credito.WebApi.Scripts.myScript.js");
                        c.SetValidatorUrl(baseUrl);
                        // Use the "InjectJavaScript" option to invoke one or more custom JavaScripts after the swagger-ui
                        // has loaded. The file must be included in your project as an "Embedded Resource", and then the resource's
                        // "Logical Name" is passed to the method as shown above.
                        //
                        //c.InjectJavaScript(thisAssembly, "Swashbuckle.Dummy.SwaggerExtensions.testScript1.js");

                        // Specify which HTTP operations will have the 'Try it out!' option. An empty paramter list disables
                        // it for all operations.
                        //
                        //c.SupportedSubmitMethods("GET", "HEAD");

                    });
        }
    }
}
