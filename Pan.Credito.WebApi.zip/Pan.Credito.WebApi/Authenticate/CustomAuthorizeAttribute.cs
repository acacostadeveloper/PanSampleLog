﻿using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Pan.Credito.WebApi.Authenticate
{
    public class CustomAuthorizeAttribute : AuthorizeAttribute
    {
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            var token = ConfigurationManager.AppSettings["TOKEN_AUTHORIZE"];
            
            IEnumerable<string> authorization;
            actionContext.Request.Headers.TryGetValues("Authorization", out authorization);
            
            if (authorization != null)
            {
                if (actionContext.Request.RequestUri.AbsoluteUri.Contains("admin"))
                {
                    if (authorization.FirstOrDefault() == "veiculos-api") return;
                }

                if (authorization.FirstOrDefault() == token) return;
            }   
           
            HandleUnauthorizedRequest(actionContext);
        }
        protected override void HandleUnauthorizedRequest(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            var Error = new Dictionary<string, string> { { "Error", "TOKEN INVALIDO OU NULO" } };
            actionContext.Response = actionContext.Request.CreateResponse(HttpStatusCode.Unauthorized, Error);
        }
    }
}