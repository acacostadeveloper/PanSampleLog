﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Pan.Reembolso.Api
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            string origem = WebConfigurationManager.AppSettings["corsOrigem"];

            config.EnableCors();

            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
            

            var cors = new EnableCorsAttribute(origem, "*", "*") { SupportsCredentials = true };
            config.EnableCors(cors);

            config.EnableSystemDiagnosticsTracing();
        }
    }
}
