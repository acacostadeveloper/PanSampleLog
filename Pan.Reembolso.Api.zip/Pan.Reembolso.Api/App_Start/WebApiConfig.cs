﻿using Pan.Reembolso.Api.Handlers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;

namespace Pan.Reembolso.Api
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {



            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );

            //config.Routes.MapHttpRoute(
            //    name: "reembolso",
            //    routeTemplate: "api/reembolso/cpf/{cpfcnpj}",
            //    constraints: null,
            //    defaults: new { cpfcnpj = RouteParameter.Optional },
            //    handler: new AuthHandler()  // per-route message handler
            //);

            //config.MessageHandlers.Add(new AuthHandler());

            config.EnableSystemDiagnosticsTracing();
        }
    }
}
