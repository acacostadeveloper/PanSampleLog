﻿using Pan.Reembolso.Infra.Security.Helper;
using Pan.Reembolso.Infra.Security.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web;

namespace Pan.Reembolso.Api.Handlers
{
    public class AuthHandler : DelegatingHandler
    {
        private IAutorization _autorization;

        public AuthHandler(IAutorization autorization)
        {
            _autorization = autorization;
        }


        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {

            request.Headers.TryGetValues("Authorization",  out IEnumerable<string> token);

            //GetHeaders(request.Headers).TryGetValue("Authorization", out string token);

            if (!string.IsNullOrWhiteSpace(token.ToString()))
            {
                _autorization.Authorize(token.ToArray()[0]);
            }

            return await base.SendAsync(request, cancellationToken)
                .ContinueWith(task =>
                {
                    var response = task.Result;

                    if (token == null && response.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        var host = request.RequestUri.DnsSafeHost;
                        //response.Headers.Add("WWW - Authenticate", string.Format("Basic realm=\"{0}\"", host));
                    }

                    return response;

                }, cancellationToken);
        }

        private static IDictionary<string, string> GetHeaders(HttpHeaders headers)
        {
            var retorno = new Dictionary<string, string>();

            foreach (var item in headers.ToList())
            {
                if (item.Value == null) continue;
                var header = item.Value.Aggregate(string.Empty, (current, value) => current + (value + " "));

                header = header.TrimEnd(" ".ToCharArray());
                retorno.Add(item.Key, header);
            }
            return retorno;
        }
    }
}