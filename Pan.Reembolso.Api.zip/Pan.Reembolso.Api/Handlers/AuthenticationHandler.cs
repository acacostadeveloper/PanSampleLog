﻿
using Newtonsoft.Json;
using Pan.Reembolso.Infra.Autentication;
using Pan.Reembolso.Infra.Autentication.Entidades;
using Pan.Reembolso.Infra.Security.Helper;
using Pan.Reembolso.Infra.Security.Interface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Security.Principal;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Routing;

public class AuthenticationHandler : DelegatingHandler
{
    private IAutorization _autorization;

    public AuthenticationHandler(IAutorization autorization)
    {
        _autorization = autorization;
    }

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        UserAuthorization userApp = null;

        if (permittedSkipAuthorization(HttpContext.Current.Request.FilePath))
        {
            return base.SendAsync(request, cancellationToken);
        }

        GenericPrincipal principal;

        if (IsValid(request, out userApp))
        {
            if (userApp != null)
            {
                principal = new GenericPrincipal(new GenericIdentity(userApp.userId), null);

                Thread.CurrentPrincipal = principal;

                if (HttpContext.Current != null)
                    HttpContext.Current.User = principal;
            }

            return base.SendAsync(request, cancellationToken);
        }
        else
        {
            return Task.Factory.StartNew(() =>
            {
                var r = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                r.Headers.Add("WWW-Authenticate", "Basic realm=\"AppTeste\"");
                return r;
            });
        }
    }

    private bool IsValid(HttpRequestMessage request, out UserAuthorization user)
    {
        bool result = false;

        var header = request.Headers.Authorization;

        if (header != null)
        {
            if (HttpContext.Current != null && HttpContext.Current.User != null && HttpContext.Current.User.Identity.Name != null)
            {
                var userName = HttpContext.Current.User.Identity.Name.Split('\\')[1];

                return AuthorizeUserName(userName, out user);
            }
        }
        else
        {
            request.Headers.TryGetValues("Authorization", out IEnumerable<string> token);

            if (token != null)
            {
                result = _autorization.ValidateToken(token.ToArray()[0]);
                
            }
        }

        user = null;
        return result;
    }

    private bool AuthorizeUserName(string userName, out UserAuthorization user)
    {
        var auth = new AuthorizeHelper();

        var principal = new GenericPrincipal(new GenericIdentity(userName), null);

        string userId = principal.Identity.Name;

        user = GetLoggedUser(principal);

        return auth.CheckInRoleAutentication(userId);       // : principal.Identity.IsAuthenticated;
    }

    private static IDictionary<string, string> GetHeaders(HttpHeaders headers)
    {
        var retorno = new Dictionary<string, string>();

        foreach (var item in headers.ToList())
        {
            if (item.Value == null) continue;
            var header = item.Value.Aggregate(string.Empty, (current, value) => current + (value + " "));

            header = header.TrimEnd(" ".ToCharArray());
            retorno.Add(item.Key, header);
        }
        return retorno;
    }

    private static UserAuthorization GetLoggedUser(GenericPrincipal principal)
    {
        var user = new UserAuthorization();

        AuthorizeHelper auth;

        var username = principal.Identity.Name;

        var userAD = new AuthorizeHelper().AuthorizeUser(username);

        user.nome = (string)userAD.Properties["name"][0].ToString();

        user.userId = username;

        int propertyCount = userAD.Properties["memberOf"].Count;

        String dn;
        int equalsIndex, commaIndex;

        for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
        {
            dn = (String)userAD.Properties["memberOf"][propertyCounter];

            equalsIndex = dn.IndexOf("=", 1);
            commaIndex = dn.IndexOf(",", 1);
            if (-1 == equalsIndex)
            {
                break;
            }

            string role = dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1);

            user.roles.Add(new RoleUser { roleId = role });
        }

        return user;
    }

    //private void CheckSkipAuthorization()
    //{
    //    if (HttpContext.Current.Request.HttpMethod == "OPTIONS")
    //    {
    //        HttpContext.Current.Response.AddHeader("Cache-Control", "no-cache");
    //        HttpContext.Current.Response.AddHeader("Access-Control-Allow-Methods", "POST,GET,OPTIONS");
    //        HttpContext.Current.Response.AddHeader("Access-Control-Allow-Headers", "Content-Type, Access-Control-Allow-Headers, Access-Control-Allow-Methods, Authorization, X-Requested-With, Access-Control-Allow-Origin, Access-Control-Expose-Headers, Skip-Authorization, X-SessionId");
    //        HttpContext.Current.Response.AddHeader("Access-Control-Expose-Headers", "Content-Type, Authorization");
    //        HttpContext.Current.Response.AddHeader("Access-Control-Max-Age", "1728000");
    //        HttpContext.Current.Response.AddHeader("X-Frame-Options", "DENY");
    //        HttpContext.Current.Response.End();
    //    }
    //    else
    //    {
    //        if (HttpContext.Current.Request.Headers["Skip-Authorization"] == "true")
    //        {
    //            if (!permittedSkipAuthorization(HttpContext.Current.Request.FilePath))
    //            {
    //                Exception ex = new Exception("Acesso Negado: Esta requisição não pode utilizar Skip Authorization!");

    //                //Log.salvar(ex);
    //                //string desc_erro = ex.Message;
    //                //GenericError desc = new GenericError(desc_erro);

    //                HttpContext.Current.Response.Clear();
    //                HttpContext.Current.Response.ContentType = "application/json";
    //                HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
    //                HttpContext.Current.Response.StatusDescription = desc_erro;
    //                HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
    //                HttpContext.Current.Response.End();
    //            }
    //        }
    //        else
    //        {
    //            CustomToken objToken = new CustomToken();
    //            String _keyCrypto = String.Empty;

    //            // Obtém o token do Header da requisição
    //            var token = HttpContext.Current.Request.Headers["Authorization"];

    //            // Se possui token...
    //            if (token != null)
    //            {
    //                // Obtem a chave de criptografia
    //                _keyCrypto = System.Configuration.ConfigurationManager.AppSettings.Get("keyCrypto");

    //                // Prepara o token para decodificação
    //                token = token.Replace("Bearer ", "");

    //                try
    //                {
    //                    // Decodifica o token transformado-o em objeto
    //                    objToken = JsonWebToken.DecodeToObject<CustomToken>(token, _keyCrypto, true);

    //                    // Pega o User Agent da requisição
    //                    objToken.UserAgent = HttpContext.Current.Request.Headers["User-Agent"];

    //                    // Pega o Session ID da requisição
    //                    objToken.SessionId = Convert.ToInt32(HttpContext.Current.Request.Headers["X-SessionId"]);

    //                    // Pega o Client Address da requisição
    //                    objToken.ClientAddress = HttpContext.Current.Request.UserHostAddress;

    //                    // Valida usuário
    //                    ValidaToken _ValidaToken = new ValidaToken();
    //                    _ValidaToken.validateToken(objToken);

    //                }
    //                catch (ArgumentException ex)
    //                {
    //                    //Log.salvar(ex);
    //                    //string desc_erro = "Acesso Negado: Token inválido.";
    //                    //GenericError desc = new GenericError(desc_erro);

    //                    HttpContext.Current.Response.Clear();
    //                    HttpContext.Current.Response.ContentType = "application/json";
    //                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
    //                    HttpContext.Current.Response.StatusDescription = desc_erro;
    //                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
    //                    HttpContext.Current.Response.End();
    //                }
    //                catch (SignatureVerificationException ex)
    //                {
    //                    //Log.salvar(ex);
    //                    //string desc_erro = "Acesso Negado: Problema na assinatura do Token.";
    //                    //GenericError desc = new GenericError(desc_erro);

    //                    HttpContext.Current.Response.Clear();
    //                    HttpContext.Current.Response.ContentType = "application/json";
    //                    HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
    //                    HttpContext.Current.Response.StatusDescription = desc_erro;
    //                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
    //                    HttpContext.Current.Response.End();

    //                }
    //                catch (FaultException<ServiceFault> fault)
    //                {
    //                    Exception ex = new Exception(fault.Detail.Message);
    //                    //Log.salvar(ex);

    //                    int statusCode = HttpStatusCode.BadRequest.GetHashCode();

    //                    if (fault.Detail.Data["StatusCode"] != null)
    //                    {
    //                        statusCode = (int)fault.Detail.Data["StatusCode"];
    //                    }

    //                    string desc_erro = fault.Detail.Message;
    //                    //GenericError desc = new GenericError(desc_erro);

    //                    HttpContext.Current.Response.Clear();
    //                    HttpContext.Current.Response.ContentType = "application/json";
    //                    HttpContext.Current.Response.StatusCode = statusCode;
    //                    HttpContext.Current.Response.StatusDescription = desc_erro;
    //                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
    //                    HttpContext.Current.Response.End();
    //                }
    //                catch (Exception ex)
    //                {
    //                    //Log.salvar(ex);
    //                    //string desc_erro = ex.Message;
    //                    //GenericError desc = new GenericError(desc_erro);

    //                    HttpContext.Current.Response.Clear();
    //                    HttpContext.Current.Response.ContentType = "application/json";
    //                    HttpContext.Current.Response.StatusCode = HttpStatusCode.BadRequest.GetHashCode();
    //                    HttpContext.Current.Response.StatusDescription = desc_erro;
    //                    HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
    //                    HttpContext.Current.Response.End();
    //                }
    //            }
    //            else
    //            {
    //                Exception ex = new Exception("Acesso Negado: Não foi encontrado o token desta requisição!");

    //                //Log.salvar(ex);
    //                //string desc_erro = ex.Message;
    //                //GenericError desc = new GenericError(desc_erro);

    //                HttpContext.Current.Response.Clear();
    //                HttpContext.Current.Response.ContentType = "application/json";
    //                HttpContext.Current.Response.StatusCode = HttpStatusCode.Unauthorized.GetHashCode();
    //                HttpContext.Current.Response.StatusDescription = desc_erro;
    //                HttpContext.Current.Response.Output.Write(JsonConvert.SerializeObject(desc));
    //                HttpContext.Current.Response.End();
    //            }
    //        }
    //    }
    //}

    private bool permittedSkipAuthorization(string url)
    {
        List<string> requisicoesAbertas = new List<string>();

        requisicoesAbertas.Add("/");
        requisicoesAbertas.Add("/api/token");

        if (String.IsNullOrEmpty(requisicoesAbertas.Find(x => x == url)))
            return false;
        else
            return true;
    }
}