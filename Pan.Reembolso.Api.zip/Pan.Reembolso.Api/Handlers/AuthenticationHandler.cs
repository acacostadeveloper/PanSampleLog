﻿
using Pan.Reembolso.Infra.Security.Helper;
using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Routing;

public class AuthenticationHandler : DelegatingHandler
{
    protected override Task<HttpResponseMessage> SendAsync(
        HttpRequestMessage request, CancellationToken cancellationToken)
    {
        string username = null;

        GenericPrincipal principal;

        if (IsValid(request, out username))
        {
            principal = new GenericPrincipal(new GenericIdentity(username), null);
            Thread.CurrentPrincipal = principal;

            if (HttpContext.Current != null)
                HttpContext.Current.User = principal;

            return base.SendAsync(request, cancellationToken);
        }
        else
        {
            return Task.Factory.StartNew(() =>
            {
                var r = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                r.Headers.Add("WWW-Authenticate", "Basic realm=\"AppTeste\"");
                return r;
            });
        }
    }


    private static bool IsValid(HttpRequestMessage request, out string username)
    {
        username = null;

        var header = request.Headers.Authorization;

        var auth = new AuthorizeHelper();

        if (header != null)
        {
            if (HttpContext.Current != null && HttpContext.Current.User != null && HttpContext.Current.User.Identity.Name != null)
            {
                string userName = HttpContext.Current.User.Identity.Name;

                var principal = new GenericPrincipal(new GenericIdentity(userName), null);

                foreach(Claim claim in ((System.Security.Claims.ClaimsPrincipal)HttpContext.Current.User).Claims)
                {
                    Debug.Write($"claim.Type : {claim.Type} - claim.Value : {claim.Value}");
                }
               


                string userId = principal.Identity.Name;
            }

            WindowsIdentity identity = HttpContext.Current.Request.LogonUserIdentity;

            return auth.AuthorizeUser(identity.Name);
        }

        return false;
    }
}