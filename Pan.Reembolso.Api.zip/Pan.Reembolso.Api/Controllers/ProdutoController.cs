﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;


namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/produto")]
    public class ProdutoController : ApiController
    {
        private IProdutoService produtoService;

        private void SetProdutoService(IProdutoService value)
        {
            produtoService = value;
        }
        public ProdutoController(IProdutoService produtoService)
        {
            SetProdutoService(produtoService);
        }

        [Route("obter")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                var produtos = produtoService.ObterProdutos();

                if (produtos.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, produtos);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, produtos);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}