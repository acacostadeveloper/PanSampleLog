﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/motivoEntrada")]
    public class MotivoEntradaController : ApiController
    {

        private IMotivoEntradaService motivoEntradaService;

        private void SetMotivoEntradaService(IMotivoEntradaService value)
        {
            motivoEntradaService = value;
        }
        public MotivoEntradaController(IMotivoEntradaService motivoEntradaService)
        {
            SetMotivoEntradaService(motivoEntradaService);
        }

        [Route("obter")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                var motivoEntrada = motivoEntradaService.ObterMotivosEntrada();

                if (motivoEntrada.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, motivoEntrada);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, motivoEntrada);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}