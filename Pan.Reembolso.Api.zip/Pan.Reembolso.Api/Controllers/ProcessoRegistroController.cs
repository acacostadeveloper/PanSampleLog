﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/processoRegistro")]
    public class processoRegistroController : ApiController
    {

        private IProcessoRegistroService processoRegistroService;

        private void SetprocessoRegistroService(IProcessoRegistroService value)
        {
            processoRegistroService = value;
        }
        public processoRegistroController(IProcessoRegistroService processoRegistroService)
        {
            SetprocessoRegistroService(processoRegistroService);
        }


        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetList()
        {
            try
            {
                var processoRegistros = processoRegistroService.ObterProcessoRegistroList();

                if (processoRegistros.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, processoRegistros);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, processoRegistros);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("obter")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                var processoRegistros = processoRegistroService.ObterProcessoRegistros();

                if (processoRegistros.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, processoRegistros);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, processoRegistros);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}