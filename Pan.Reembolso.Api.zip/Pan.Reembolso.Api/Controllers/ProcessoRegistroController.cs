﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/processoRegistro")]
    [EnableCors(origins: "http://PANFASD3096:35101", headers: "*", methods: "*")]
    public class processoRegistroController : ApiController
    {

        private IProcessoRegistroService processoRegistroService;

        private void SetprocessoRegistroService(IProcessoRegistroService value)
        {
            processoRegistroService = value;
        }
        public processoRegistroController(IProcessoRegistroService processoRegistroService)
        {
            SetprocessoRegistroService(processoRegistroService);
        }


        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetList()
        {
            try
            {
                var processoRegistros = processoRegistroService.ObterProcessoRegistroList();

                if (processoRegistros.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, processoRegistros);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, processoRegistros);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("{fluxo}")]
        [HttpGet]
        public HttpResponseMessage Get(string fluxo)
        {
            try
            {
                var processoRegistros = processoRegistroService.ObterProcessoRegistros(fluxo.ToUpper());

                if (processoRegistros.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, processoRegistros);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, processoRegistros);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}