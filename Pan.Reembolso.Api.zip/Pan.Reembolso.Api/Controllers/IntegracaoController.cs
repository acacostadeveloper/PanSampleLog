﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/integracao")]
    public class IntegracaoController : ApiController
    {
        private IIntegracaoService integracaoService;

        private void SetIntegracaoService(IIntegracaoService value)
        {
            integracaoService = value;
        }
        public IntegracaoController(IIntegracaoService integracaoService)
        {
            SetIntegracaoService(integracaoService);
        }

        [Route("list")]
        [HttpGet]
        public HttpResponseMessage GetByIdLote([FromUri]ObterIntegracaoRequest request)
        {
            try
            {
                var filter = Mapper.Map<ObterIntegracaoRequest, IntegracaoFilter>(request);

                var integracao = integracaoService.ConsultarReembolsoIntegracao(filter);

                return Request.CreateResponse(HttpStatusCode.OK, integracao); 
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}