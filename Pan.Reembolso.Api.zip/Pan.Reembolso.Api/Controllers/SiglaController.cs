﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/sigla")]
    public class SiglaController : ApiController
    {

        private ISiglaService siglaService;

        private void SetSiglaService(ISiglaService value)
        {
            siglaService = value;
        }
        public SiglaController(ISiglaService siglaService)
        {
            SetSiglaService(siglaService);
        }

        [Route("obter")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                var siglas = siglaService.ObterSiglas();

                if (siglas.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, siglas);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, siglas);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}