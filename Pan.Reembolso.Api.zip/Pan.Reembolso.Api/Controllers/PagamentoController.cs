﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Transactions;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Api.Controllers
{

    [RoutePrefix("api/pagamento")]
    public class PagamentoController : ApiController
    {
        private readonly IUploadService _uploadService;
        private readonly IPagamentoService _pagamentoService;
        private IIdentity _user = null;

        public PagamentoController(IPagamentoService pagamentoService, IUploadService uploadService)
        {
            _uploadService = uploadService;
            _pagamentoService = pagamentoService;
            _user = HttpContext.Current.User.Identity;
        }
        private IPagamentoService GetPagamentoService()
        {
            return _pagamentoService;
        }

        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetPagamentosARealizar([FromUri]ObterPagamentosRequest request)
        {
            try
            {
                Aprovacao result = GetPagamentoService().ConsultarPagamentosPorStatus(request.dtInicial, request.dtFinal, request.StatusReembolso);

                if (result != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("")]
        [HttpPost]
        public HttpResponseMessage Post([FromBody]AtualizarReembolsosRequest value)
        {
            try
            {
                _pagamentoService.AprovarPagamento(value.ids, value.status, value.mensagemErro, _user.Name);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        [Route("lote")]
        [HttpGet]
        public async Task<HttpResponseMessage> Get([FromUri]ObterLoteRetiradaRequest request)
        {
            var result = new IntegracaoRetiradaResult();

            try
            {
                result = await _pagamentoService.ObterLoteRetiradaInterna(request.idLote, request.dataIni, request.dataFim, request.status);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("retirada")]
        [HttpGet]
        public async Task<HttpResponseMessage> Get([FromUri]ObterRetiradaRequest request)
        {
            if (request == null)
            {
                request = new ObterRetiradaRequest();

                request.cpfCnpj = "";
                request.codigoProduto = "";

            }

            var result = new PagamentoResult<object>();

            try
            {
                result = await _pagamentoService.ObterRetiradaInternaPorContrato(request.cpfCnpj, request.codigoProduto);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("upload")]
        [HttpPost]
        public async Task<HttpResponseMessage> UploadFile(UploadFileRequest request)
        {
            try
            {
                var bytes = Convert.FromBase64String(request.arrayBytesDocumento);


                List<byte> fileBytes = new List<byte>();
                if (bytes.Length == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, "Arquivo Inválido");
                }

                var fileName = request.nomeDocumento;

                foreach (var stream in bytes)
                {
                    fileBytes.Add(stream);
                }
                var filePath = WebConfigurationManager.AppSettings["FileServerPath"];

                var file = filePath + @fileName;

                var retorno = await _uploadService.PersistirArquivoLoteRetiradaInterna(fileName, fileBytes.ToArray());

                return Request.CreateResponse(HttpStatusCode.OK, retorno);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("retirada")]
        [HttpPost]
        
        public async Task<HttpResponseMessage> Post([FromBody]EfetuarRetiradaRequest request)
        {
            var result = new RetiradaUsoInternoResult();

            try
            {

                foreach (var retirada in request.items)
                {
                    result = await _pagamentoService.EfetuarRetiradaInterna(retirada.ids, request.cpfCnpj, retirada.valorSolicitado, retirada.retitiradaTotal, request.codigoProcesso, request.justificativa, request.usuario);
                }

                return Request.CreateResponse(HttpStatusCode.OK, result);

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("historico/{idReembolso}")]
        [HttpGet]
        public HttpResponseMessage GetHistoricoPagamento(long idReembolso)
        {
            try
            {

                var user = HttpContext.Current.User.Identity;

                var result = GetPagamentoService().ObterHistoricoPorIdReembolso(idReembolso);

                if (result != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("exportar")]
        [HttpGet]
        public HttpResponseMessage Export([FromUri]ObterPagamentosRequest request)
        {
            try
            {

                Aprovacao result = GetPagamentoService().ConsultarPagamentosPorStatus(request.dtInicial, request.dtFinal, request.StatusReembolso);


                


                HttpResponseMessage httpResponseMessage = new HttpResponseMessage();

                var dataBytes = System.Text.Encoding.ASCII.GetBytes(WriteCSV(result.pagamentos)); ;
                var dataStream = new MemoryStream(dataBytes);
                httpResponseMessage.Content = new StreamContent(dataStream);
                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                httpResponseMessage.Content.Headers.ContentDisposition.FileName = "pagamento_" + request.dtInicial.Value.ToString("yyyyMMdd")+ "_"+ request.dtFinal.Value.ToString("yyyyMMdd") + ".csv";
                httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("text/csv");


                return httpResponseMessage;
            }

            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        private String WriteCSV<T>(IEnumerable<T> items)
        {

            Type itemType = typeof(T);
            var sb = new System.Text.StringBuilder();
            var props = itemType.GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance)
                            .OrderBy(p => p.Name);

            sb.AppendLine(string.Join(";", props.Where(n => n.Name != "ids").Select(p => p.Name)));

            foreach (var item in items)
            {
                sb.AppendLine(string.Join(";", props.Where(n => n.Name != "ids").Select(p => p.GetValue(item, null))));
            }

            return sb.ToString();

        }
    }
}