﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Api.Controllers
{

    [RoutePrefix("api/pagamento")]
    [System.Web.Http.Cors.EnableCors(origins: "http://10.99.5.43:3510", headers: "*", methods: "*")]

    public class PagamentoController : ApiController
    {

        private readonly IPagamentoService _pagamentoService;

        public PagamentoController(IPagamentoService pagamentoService)
        {
            _pagamentoService = pagamentoService;
        }
        private IPagamentoService GetPagamentoService()
        {
            return _pagamentoService;
        }

        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetPagamentosARealizar([FromUri]ObterPagamentosRequest request)
        {
            try
            {
                object result = GetPagamentoService().ConsultarPagamentosPorStatus(request.dtInicial, request.dtFinal, request.StatusReembolso);

                if (result != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("")]
        [HttpPost]
        public HttpResponseMessage Post([FromBody]AtualizarReembolsosRequest value)
        {
            try
            {
                _pagamentoService.AprovarPagamento(value.ids, value.status, value.mensagemErro);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("retirada")]
        [HttpGet]
        public async Task<HttpResponseMessage> Get([FromUri]ObterRetiradaRequest request)
        {
            if (request==null)
            {
                request = new ObterRetiradaRequest();

                request.cpfCnpj = "";
                request.produto = "";

            }

            var result = new PagamentoResult();

            try
            {
                result = await _pagamentoService.ObterRetiradaInterna(request.cpfCnpj, request.produto);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("retirada")]
        [HttpPost]
        public async Task<HttpResponseMessage> Post(EfetuarRetiradaRequest request)
        {
            var result = new Result();

            try
            {
                result = await _pagamentoService.EfetuarRetiradaInterna(request.Ids, request.CpfCnpj, request.Valor, request.Retitiradatotal, request.Justificativa, request.Usuario);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}