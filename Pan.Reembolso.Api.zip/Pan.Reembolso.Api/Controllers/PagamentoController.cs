﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Results;

namespace Pan.Reembolso.Api.Controllers
{

    [RoutePrefix("api/pagamento")]
    [EnableCors(origins: "http://PANFASD3096:35101", headers: "*", methods: "*")]

    public class PagamentoController : ApiController
    {
        private readonly IUploadService _uploadService;
        private readonly IPagamentoService _pagamentoService;

        public PagamentoController(IPagamentoService pagamentoService, IUploadService uploadService)
        {
            _uploadService = uploadService;
            _pagamentoService = pagamentoService;
        }
        private IPagamentoService GetPagamentoService()
        {
            return _pagamentoService;
        }

        [Route("")]
        [HttpGet]
        public HttpResponseMessage GetPagamentosARealizar([FromUri]ObterPagamentosRequest request)
        {
            try
            {
                object result = GetPagamentoService().ConsultarPagamentosPorStatus(request.dtInicial, request.dtFinal, request.StatusReembolso);

                if (result != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("")]
        [HttpPost]
        public HttpResponseMessage Post([FromBody]AtualizarReembolsosRequest value)
        {
            try
            {
                _pagamentoService.AprovarPagamento(value.ids, value.status, value.mensagemErro);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("retirada")]
        [HttpGet]
        public async Task<HttpResponseMessage> Get([FromUri]ObterRetiradaRequest request)
        {
            if (request==null)
            {
                request = new ObterRetiradaRequest();

                request.cpfCnpj = "";
                request.codigoProduto = "";

            }

            var result = new PagamentoResult();

            try
            {
                result = await _pagamentoService.ObterRetiradaInterna(request.cpfCnpj, request.codigoProduto);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("upload")]
        [HttpPost]
        public async Task<HttpResponseMessage> UploadFile()
        {
            byte[] fileBytes = new byte[0];

            if (!Request.Content.IsMimeMultipartContent())
            {
                return Request.CreateResponse(HttpStatusCode.UnsupportedMediaType);
            }

            try
            {
                var filesReadToProvider = await Request.Content.ReadAsMultipartAsync();

                var fileName = filesReadToProvider.Contents[0].Headers.ContentDisposition.FileName.Replace("\"", "");

                foreach (var stream in filesReadToProvider.Contents)
                {
                    fileBytes = await stream.ReadAsByteArrayAsync();
                }

                var str = System.Text.Encoding.Default.GetString(fileBytes);

                var retorno = await _uploadService.PersistirArquivoLoteRetiradaInterna(fileName, fileBytes);

                return Request.CreateResponse(HttpStatusCode.OK, retorno);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("retirada")]
        [HttpPost]
        public async Task<HttpResponseMessage> Post([FromBody]EfetuarRetiradaRequest request)
        {
            var result = new RetiradaUsoInternoResult();

            try
            {
                result = await _pagamentoService.EfetuarRetiradaInterna(request.ids, request.cpfCnpj, request.valor, request.retitiradatotal, request.codigoProcesso, request.justificativa, request.usuario);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("historico/{idReembolso}")]
        [HttpGet]
        public HttpResponseMessage GetHistoricoPagamento(long idReembolso)
        {
            try
            {
                var result = GetPagamentoService().ObterHistoricoPorIdReembolso(idReembolso);

                if (result != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}