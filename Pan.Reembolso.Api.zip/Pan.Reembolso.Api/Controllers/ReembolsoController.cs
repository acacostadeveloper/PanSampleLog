﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/reembolso")]
    public class ReembolsoController : ApiController
    {
        private readonly IUploadService _uploadService;

        private IReembolsoService reembolsoService;

        private IReembolsoService GetReembolsoService()
        {
            return reembolsoService;
        }

        private void SetReembolsoService(IReembolsoService value)
        {
            reembolsoService = value;
        }

        public ReembolsoController(IReembolsoService reembolsoService, IUploadService uploadService)
        {
            SetReembolsoService(reembolsoService);

            _uploadService = uploadService;
        }

        [Route("{id}")]
        [HttpGet]
        public HttpResponseMessage GetById(int id)
        {
            try
            {
                var reembolso = GetReembolsoService().ObterReembolso(id);

                return VerificaReembolso(reembolso);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }            
        }

        [Route("status/{status}")]
        [HttpGet]
        public HttpResponseMessage GetByStatus(int status)
        {
            try
            {
                // TODO - Implementar/Chamar busca por status
                var reembolsos = new List<Entidades.Reembolso>();

                if (reembolsos.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, reembolsos);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, reembolsos);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        //[Route("statusLote/{idLoteIntegracao}")]
        //[HttpGet]
        //public HttpResponseMessage GetByIdLoteIntegracao(string idLoteIntegracao)
        //{
        //    try
        //    {
        //        // TODO Implemntar _integracaoService.ObterStatusIntegracaoPorIdLote(idLoteIntegracao);
        //    }
        //    catch (Exception ex)
        //    {
        //        ModelState.AddModelError("Exception", ex.Message);
        //        return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
        //    }
        //}

        [Route("contrato/{codigoContrato}")]
        [HttpGet]
        public HttpResponseMessage GetByContrato(string codigoContrato)
        {
            try
            {
                var reembolso = GetReembolsoService().ObterReembolsoByIdContrato(codigoContrato);

                return VerificaReembolso(reembolso);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("obter")]
        [HttpGet]
        public HttpResponseMessage GetReembolsos([FromUri]ObterReembolsosRequest request)
        {
            try
            {
                var filter = Mapper.Map<ObterReembolsosRequest, ReembolsoFilter>(request);
                var reembolsos = GetReembolsoService().ObterReembolsos(filter);

                if (reembolsos.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, reembolsos);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, reembolsos);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("historicoReemb/{codigoReemb}")]
        [HttpGet]
        public HttpResponseMessage GetHistoricoByReembolso(int codigoReemb)
        {
            try
            {
                //var reembolso = GetReembolsoService().ObterReembolso(idReembolso);
                IEnumerable<Entidades.HistoricoReembolso> historicosReembolso = GetReembolsoService().ObterHistoricosReembolso(codigoReemb);


                if (historicosReembolso.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, historicosReembolso);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, historicosReembolso);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        [Route("")]
        [HttpPost]
        public HttpResponseMessage Post([FromBody]IEnumerable<Entidades.Reembolso> value)
        {
            try 
            {
               var result = GetReembolsoService().IncluirReembolso(value);

                return Request.CreateResponse(HttpStatusCode.Created, result);
            }
            catch(Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

   

        [Route("delete")]
        [HttpDelete]
        public HttpResponseMessage Delete([FromBody]List<int> idsEstornar)
        {
            try
            {
                GetReembolsoService().ExcluirReembolso(idsEstornar);
                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("upload")]
        [HttpPost]
        public async Task<HttpResponseMessage> UploadFile()
        {
            byte[] fileBytes = new byte[0];

            if (!Request.Content.IsMimeMultipartContent())
            {
                return Request.CreateResponse(HttpStatusCode.UnsupportedMediaType);
            }

            try
            {
                var filesReadToProvider = await Request.Content.ReadAsMultipartAsync();

                var fileName = filesReadToProvider.Contents[0].Headers.ContentDisposition.FileName.Replace("\"","");

                foreach (var stream in filesReadToProvider.Contents)
                {
                    fileBytes = await stream.ReadAsByteArrayAsync();
                }

                var idLoteIntegracao = await _uploadService.ProcessarArquivo(fileName, fileBytes);

                return Request.CreateResponse(HttpStatusCode.OK, idLoteIntegracao);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        private HttpResponseMessage VerificaReembolso(Entidades.Reembolso reembolso)
        {
            if (reembolso.lote.lote != null)
            {
                return Request.CreateResponse(HttpStatusCode.OK, reembolso);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NoContent, reembolso);
            }
        }

    }


}