﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Principal;
using System.Threading.Tasks;
using System.Transactions;
using System.Web;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Autentication.Interface;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/reembolso")]
    public class ReembolsoController : ApiController
    {
        private readonly IUploadService _uploadService;
        private readonly IAutenticationUserRepository _autenticationUserRepository;
        private IIdentity _user;

        private IReembolsoService reembolsoService;

        private IReembolsoService GetReembolsoService()
        {
            return reembolsoService;
        }

        private void SetReembolsoService(IReembolsoService value)
        {
            reembolsoService = value;
        }

        public ReembolsoController(IReembolsoService reembolsoService, IUploadService uploadService, IAutenticationUserRepository autenticationUserRepository)
        {
            SetReembolsoService(reembolsoService);

            _autenticationUserRepository = autenticationUserRepository;

            _uploadService = uploadService;

            _user = HttpContext.Current.User.Identity;
        }

        [Route("{id}")]
        [HttpGet]
        public HttpResponseMessage GetById(long id)
        {
            try
            {
                var reembolso = GetReembolsoService().ObterReembolso(id);
                return CheckResult(reembolso);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("cpf/{cpfcnpj}")]
        [HttpGet]
        public HttpResponseMessage GetByCpfCnpj(string cpfCnpj)
        {
            try
            {
                var result = GetReembolsoService().ObterReembolsoPorCpfCnpj(cpfCnpj);

                var item = result.Reembolsos.FirstOrDefault();

                if (item == null)
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("lista")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                var reembolsos = GetReembolsoService().ObterReembolsoList();
                return Request.CreateResponse(HttpStatusCode.OK, reembolsos);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("status/{status}")]
        [HttpGet]
        public HttpResponseMessage GetByStatus(int status)
        {
            try
            {
                // TODO - Implementar/Chamar busca por status
                var reembolsos = new List<Entidades.Reembolso>();

                if (reembolsos.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, reembolsos);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, reembolsos);
                }
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }


        [Route("detalhe/{idReembolso}")]
        [HttpGet]
        public HttpResponseMessage GetDetalhesReembolso(long idReembolso)
        {
            try
            {
                var detalhe = GetReembolsoService().ObterReembolso(idReembolso);

                if (detalhe != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, detalhe);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, detalhe);
                }
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("list")]
        [HttpGet]
        public HttpResponseMessage ConsultarInformacoesReembolso([FromUri]ObterReembolsosRequest request)
        {
            try
            {
                var filter = Mapper.Map<ObterReembolsosRequest, ReembolsoFilter>(request);
                var reembolsos = GetReembolsoService().ConsultarInformacoesReembolso(filter);

                if (reembolsos.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, reembolsos);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, reembolsos);
                }
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("historicoReemb/{codigoReemb}")]
        [HttpGet]
        public HttpResponseMessage GetHistoricoByReembolso(int codigoReemb)
        {
            try
            {
                IEnumerable<Entidades.HistoricoReembolso> historicosReembolso = GetReembolsoService().ObterHistoricosReembolso(codigoReemb);

                if (historicosReembolso.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, historicosReembolso);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, historicosReembolso);
                }

            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("")]
        [HttpPost]
        public HttpResponseMessage Post([FromBody]IEnumerable<Entidades.Reembolso> value)
        {
            try
            {
                var result = GetReembolsoService().IncluirReembolso(value, _user.Name);

                if (result.Success)
                {
                    return Request.CreateResponse(HttpStatusCode.Created, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.Accepted, result);
                }
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("list")]
        [HttpDelete]
        public HttpResponseMessage Delete([FromBody]List<long> idsEstornar)
        {
            try
            {
                GetReembolsoService().ExcluirReembolso(idsEstornar);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("{idReembolso}")]
        [HttpDelete]
        public HttpResponseMessage Delete(long idReembolso)
        {
            try
            {
                var param = new List<long>();

                param.Add(idReembolso);

                GetReembolsoService().ExcluirReembolso(param);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("upload")]
        [HttpPost]
        public async Task<HttpResponseMessage> UploadFile(UploadFileRequest request)
        {
            try
            {
                var bytes = Convert.FromBase64String(request.arrayBytesDocumento);


                List<byte> fileBytes = new List<byte>();
                if (bytes.Length == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, "Arquivo Inválido");
                }

                var fileName = request.nomeDocumento;

                foreach (var stream in bytes)
                {
                    fileBytes.Add(stream);
                }
                var filePath = WebConfigurationManager.AppSettings["FileServerPath"];

                var file = filePath + @fileName;

                var idLoteIntegracao = await _uploadService.ProcessarArquivo(fileName, fileBytes.ToArray(), _user.Name);

                return Request.CreateResponse(HttpStatusCode.OK, idLoteIntegracao);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        private HttpResponseMessage CheckResult(Entidades.Reembolso reembolso)
        {
            if (reembolso == null)
            {
                return Request.CreateResponse(HttpStatusCode.NoContent, reembolso);
            }
            else if (reembolso.lote == null)
            {
                return Request.CreateResponse(HttpStatusCode.NoContent, reembolso);
            }
            else if (reembolso.lote.idLote != 0)
            {
                return Request.CreateResponse(HttpStatusCode.OK, reembolso);
            }
            else
            {
                return Request.CreateResponse(HttpStatusCode.NoContent, reembolso);
            }
        }

    }


}