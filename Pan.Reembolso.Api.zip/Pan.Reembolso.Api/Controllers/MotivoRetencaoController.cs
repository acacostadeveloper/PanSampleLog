﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;
namespace Pan.Reembolso.Api.Controllers
{
    [RoutePrefix("api/MotivoRetencao")]
    public class MotivoRetencaoController : ApiController
    {
        private IMotivoRetencaoService motivoRetencaoService;

        private void SetMotivoRetencao(IMotivoRetencaoService value)
        {
            motivoRetencaoService = value;
        }
        public MotivoRetencaoController(IMotivoRetencaoService motivoRetencaoService)
        {
            SetMotivoRetencao(motivoRetencaoService);
        }

        [Route("")]
        [HttpGet]
        public HttpResponseMessage Get()
        {
            try
            {
                var motivosRetencao = motivoRetencaoService.ObterMotivosRetencao();

                if (motivosRetencao.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, motivosRetencao);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, motivosRetencao);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }
    }
}