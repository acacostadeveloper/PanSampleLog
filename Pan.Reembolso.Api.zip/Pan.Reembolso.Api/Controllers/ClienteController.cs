﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Http;
using System.Web.Http.Cors;
using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using Pan.Reembolso.Servico.Interface;

namespace Pan.Reembolso.Api.Controllers
{

    [RoutePrefix("api/cliente")]
    [EnableCors(origins: "http://10.99.5.43:3510", headers: "*", methods: "*")]
    public class ClienteController : ApiController
    {
        private IClienteService _clienteService;

        private IClienteService GetClienteService()
        {
            return _clienteService;
        }

        private void SetClienteService(IClienteService value)
        {
            _clienteService = value;
        }


        public ClienteController(IClienteService clienteService)
        {
            SetClienteService(clienteService);
        }

        [Route("")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetList(string numeroCpfCnpj, string nomeCliente)
        {
            try
            {
                var clientes = await _clienteService.ConsultarClientes(numeroCpfCnpj, nomeCliente);

                if (clientes.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, clientes);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, clientes);
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("")]
        [HttpPost]
        public async Task<HttpResponseMessage> Post(Entidades.Cliente cliente)
        {
            try
            {
                object result = await GetClienteService().PersistirCliente(cliente);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("conta")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetClientesParaManutencaoDadosBancarios(string numeroCpfCnpj, string nomeCliente)
        {
            try
            {
                var result = await GetClienteService().ConsultarClientesParaManutencaoDadosBancarios(numeroCpfCnpj, nomeCliente);

                if (result != null)
                {
                    return Request.CreateResponse(HttpStatusCode.OK, result);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, result);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("conta")]
        [HttpPost]
        public async Task<HttpResponseMessage> ManterDadosBancarios(ManterContaCreditoRequest request)
        {
            try
            {
                var contaCredito = Mapper.Map<ManterContaCreditoRequest, ContaCredito>(request);

                object result = await GetClienteService().ManterDadorBancarios(contaCredito, request.idCliente, request.numeroCpfCnpj);

                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("transferencia")]
        [HttpPost]
        public async Task<HttpResponseMessage> TransferenciaPOST(TransferenciaDireitoRequest request)
        {
            try
            {
                var bytes = Convert.FromBase64String(request.arrayBytesDocumento);


                List<byte> fileBytes = new List<byte>();
                if (bytes.Length == 0)
                {
                    return Request.CreateResponse(HttpStatusCode.ExpectationFailed, "Documento de comprovação ausente");
                }

                var fileName = request.nomeDocumento;

                foreach (var stream in bytes)
                {
                    fileBytes.Add(stream);
                }
                var filePath = WebConfigurationManager.AppSettings["FileServerPath"];

                var file = filePath + @fileName;

                File.WriteAllBytes(file, fileBytes.ToArray());

                var transferenciaDireito = new TransferenciaDireito()
                {
                    cliente = new Cliente() { numeroCpfCnpj = request.numeroCpfCnpjCliente },
                    sequenciaCpfCnpj = 0,
                    documento = file,
                    dtInicioVigencia = request.dtInicioVigencia,
                    dtFimVigencia = request.dtFimVigencia,
                    indicadorAtivo = request.indicadorAtivo,
                    nome = request.nomeTerceiro,
                    numeroCpfCnpj = request.numeroCpfCnpjTerceiro,
                    usuarioInclusao = request.usuarioInclusao,
                    contaCredito = new ContaCredito
                    {
                        tipoConta = request.contaCreditoTerceiro.tipoConta,
                        numeroBanco = request.contaCreditoTerceiro.numeroBanco,
                        numeroAgencia = request.contaCreditoTerceiro.numeroAgencia,
                        digitoAgencia = request.contaCreditoTerceiro.digitoAgencia,
                        numeroConta = request.contaCreditoTerceiro.numeroConta,
                        digitoConta = request.contaCreditoTerceiro.digitoConta
                    }

                };

                GetClienteService().IncluirTransferenciaDireito(transferenciaDireito);

                return Request.CreateResponse(HttpStatusCode.OK);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("transferencia")]
        [HttpGet]
        public async Task<HttpResponseMessage> GetTransferenciasCliente(string numeroCpfCnpj)
        {
            try
            {
                IEnumerable<Entidades.TransferenciaDireito> transferenciaDireito = await GetClienteService().ConsultarTransferenciasCliente(numeroCpfCnpj);

                if (transferenciaDireito.Any())
                {
                    return Request.CreateResponse(HttpStatusCode.OK, transferenciaDireito);
                }
                else
                {
                    return Request.CreateResponse(HttpStatusCode.NoContent, transferenciaDireito);
                }

            }
            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

        [Route("transferencia/documento")]
        [HttpGet]
        public HttpResponseMessage GetFileTransferencia(string pathDocumento)
        {
            try
            {
                HttpResponseMessage httpResponseMessage = new HttpResponseMessage();

                var dataBytes = File.ReadAllBytes(pathDocumento);
                var dataStream = new MemoryStream(dataBytes);
                httpResponseMessage.Content = new StreamContent(dataStream);

                httpResponseMessage.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment");
                httpResponseMessage.Content.Headers.ContentDisposition.FileName = Path.GetFileName(pathDocumento);
                httpResponseMessage.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");


                return httpResponseMessage;
            }

            catch (Exception ex)
            {
                ModelState.AddModelError("Exception", ex.Message);
                return Request.CreateResponse(HttpStatusCode.InternalServerError, ModelState);
            }
        }

    }
}