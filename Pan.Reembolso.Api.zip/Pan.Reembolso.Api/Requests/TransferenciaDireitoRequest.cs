﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class TransferenciaDireitoRequest
    {
        public string numeroCpfCnpjCliente { get; set; }
        public string numeroCpfCnpjTerceiro { get; set; }
        public int sequenciaCpfCnpjterceiro { get; set; }
        public string nomeTerceiro { get; set; }
        public ContaCredito contaCreditoTerceiro { get; set; }
        public DateTime dtInicioVigencia { get; set; }
        public DateTime? dtFimVigencia { get; set; }
        public string indicadorAtivo { get; set; }
        public string usuarioInclusao { get; set; }
        public string nomeDocumento { get; set; }
        public string arrayBytesDocumento { get; set; }
    }


}

