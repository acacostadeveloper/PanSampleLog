﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class ObterRetiradaRequest
    {
        public string cpfCnpj { get; set; } = "";
        public string codigoProduto { get; set; } = "";
    }
}