﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class EfetuarRetiradaRequest
    {
        public string cpfCnpj { get; set; }
        public string nomeCliente { get; set; }
        public decimal valor { get; set; }
        public List<long> ids { get; set; }
        public string codigoProduto { get; set; }
        public bool retitiradatotal { get; set; }
        public int codigoProcesso { get; set; }
        public string justificativa { get; set; }
        public string usuario { get; set; }
    }
}