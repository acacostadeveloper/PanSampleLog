﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class EfetuarRetiradaRequest
    {
        public string cpfCnpj { get; set; }
        public string nomeCliente { get; set; }
        public string codigoProduto { get; set; }
        public List<items> items { get; set; }
        public int codigoProcesso { get; set; }
        public string justificativa { get; set; }
        public string usuario { get; set; }
    }

    public class items
    {
        public string codigoContrato { get; set; }
        public decimal valorDisponivel { get; set; }
        public decimal valorSolicitado { get; set; }
        public bool retitiradaTotal { get; set; }
        public List<long> ids { get; set; }
    }
}