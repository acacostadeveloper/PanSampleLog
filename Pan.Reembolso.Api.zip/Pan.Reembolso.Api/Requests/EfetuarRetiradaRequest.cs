﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class EfetuarRetiradaRequest
    {
        public string CpfCnpj { get; set; }
        public string NomeCliente { get; set; }
        public decimal Valor { get; set; }
        public List<long> Ids { get; set; }
        public string Produto { get; set; }
        public bool Retitiradatotal { get; set; }
        public string Justificativa { get; set; }
        public string Usuario { get; set; }
    }
}