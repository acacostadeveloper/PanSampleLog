﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class ManterContaCreditoRequest
    {
        public int idCliente { get; set; }
        public string numeroCpfCnpj { get; set; }
        public string numeroBanco { get; set; }
        public string numeroAgencia { get; set; }
        public string digitoAgencia { get; set; }
        public string numeroConta { get; set; }
        public string digitoConta { get; set; }
        public string tipoConta { get; set; }

    }
}