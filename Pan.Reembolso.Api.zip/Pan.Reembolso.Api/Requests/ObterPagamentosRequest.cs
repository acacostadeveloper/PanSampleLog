﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class ObterPagamentosRequest
    {
        public DateTime? dtInicial { get; set; }
        public DateTime? dtFinal { get; set; }
    }
}