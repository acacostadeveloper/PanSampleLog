﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class UploadFileRequest
    {
        public string nomeDocumento { get; set; }
        public string arrayBytesDocumento { get; set; }
    }
}