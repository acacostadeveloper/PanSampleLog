﻿using System;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Api.Requests
{
    public class ObterLoteRetiradaRequest
    {
        public int idLote { get; set; }
        public DateTime? dataIni { get; set; } = null;
        public DateTime? dataFim { get; set; } = null;
        public ReembolsoTypes.StatusIntegracaoType status { get; set; } = ReembolsoTypes.StatusIntegracaoType.Undefined;
    }
}