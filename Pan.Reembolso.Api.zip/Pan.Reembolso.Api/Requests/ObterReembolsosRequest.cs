﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class ObterReembolsosRequest
    {
        public int? idLote { get; set; }
        public int? idProduto { get; set; }
        public DateTime? dtInicial { get; set; }
        public DateTime? dtFinal { get; set; }
        public string cpfCliente { get; set; }
        public string statusReembolso { get; set; }
    }
}