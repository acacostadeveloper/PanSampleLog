﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Transactions;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Pan.Reembolso.Api.Filters
{
    public class TransactionAttribute : ActionFilterAttribute
    {
    }
}