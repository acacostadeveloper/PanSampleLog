﻿using AutoMapper;
using Pan.Reembolso.Api.Requests;
using Pan.Reembolso.Repositorio.Filters;

namespace Pan.Reembolso.Api.Mappers
{
    public class AutoMapperConfig
    {
        public static void Initialize()
        {
            Mapper.Reset();
            Mapper.Initialize((config) =>
            {
                config.CreateMap<ObterReembolsosRequest, ReembolsoFilter>().ReverseMap();
            });
        }
    }
}