using System;

namespace Pan.Credito.Domain.Services
{
    public interface IBoletoServices:IDisposable
    {
        byte[] GerarPDFBinarioParcelaFuncao(string numeroContrato, int proximos = 0);
        byte[] GerarPDFBinarioAcordoFuncao(string numeroAcordo, string numeroContrato);
        string[] GerarLinhasDigitaveisAcordoFuncao(string contrato);
    }
}