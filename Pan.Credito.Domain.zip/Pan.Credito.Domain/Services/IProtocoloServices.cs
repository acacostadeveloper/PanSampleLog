﻿using System;
using Pan.Credito.Domain.Entidades.Protocolo;

namespace Pan.Credito.Domain.Services
{
    public interface IProtocoloServices : IDisposable
    {
        long AbrirProtocolo(ProtocoloModel protocolo);
    }
}