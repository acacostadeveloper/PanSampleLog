﻿using System;
using System.Collections.Generic;

namespace Pan.Credito.Domain.Services
{
    public interface IExtratoServices : IDisposable 
    {
        string ObterExtratoDePagamentos(int ano, string documento,string email,bool enviaEmail);
        string ObterExtratoTarifas(int ano, string documento, string email, bool enviaEmail);
        string ObterInformeDeRedimentos(int ano, string documento, string email, bool enviaEmail);
        string DeclaracaoContratoQuitado(string contrato, string email, bool enviaEmail);
        string ObterCartaResumo(string documento, string contrato, string email, bool enviaEmail);
        Dictionary<string, string> GuiaTransferenciaDivida(string email, bool enviarEmail);
        Dictionary<string, string> GuiaSubstituicaoDeGarantia(string email, bool enviarEmail);
    }
}