﻿using System;
using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Services
{
    public interface IClienteServices : IDisposable
    {
        Cliente ObterCliente(string Documento);
        string GravarCliente(Cliente cliente);
    }
}