﻿using System;
using System.Collections.Generic;
using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Services
{
    public interface ICorrespondenteServices : IDisposable
    {
       List<Correspondente> ObterCorrespondente(string cep);
    }
}