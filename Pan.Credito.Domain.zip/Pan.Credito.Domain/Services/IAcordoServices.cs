﻿using System;
using System.Collections.Generic;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Services
{
    public interface IAcordoServices :IDisposable
    {
        string CancelarAcordo(Origens origem,string acordo,string contrato);
        Acordo SimularAcordoQuitar(SolicitaAcordo solicitaAcordo);
        Acordo SimularAcordoRenegocie(AcordoRenegocie acordoRenegocie);
        Acordo EfetuarAcordoFuncao(SolicitaAcordo solicitaAcordo);
        Acordo EfetuarAcordoRenegocie(AcordoRenegocie solicitaAcordo);
        List<Acordo> ObterAcordosFuncao(string contrato);
        List<Acordo> ObterAcordosFuncao(string contrato, List<Parcela> parcelas);
    }
}