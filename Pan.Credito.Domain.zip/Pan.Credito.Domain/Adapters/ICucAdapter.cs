﻿using System;
using System.Xml;
using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Adapters
{
    public interface ICucAdapter:IDisposable
    {
        Cliente ObterCliente(Int64 Documento);
        string GravarClienteCUC(XmlDocument objXmlDocument, string mensagem); 
    }
}