﻿using System;
using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Adapters
{
    public interface ICyberAdapter:IDisposable
    {
        Cobradora Assessoria_Obter(long p_intDocumento, string p_strContrato, string p_strGrupo);
    }
}