﻿using System;
using System.Collections.Generic;
using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Adapters
{
    public interface IFuncaoAdapter : IDisposable
    {
        ClienteExtrato Extrato_Pagamentos(Int64 p_intDocumento, DateTime p_dtmInicio, DateTime p_dtmFim);
        ClienteExtrato ObterDeclaracaoQuitacao(Int64 Documento, string Contrato);
        ClienteExtrato ObterExtratoPagamentosCliente(Int64 Documento, DateTime Inicio, DateTime Fim);
        ClienteExtrato ObterExtratoTaxas(Int64 Documento, int Ano);
        ClienteExtrato ConsultaContratoQuitado(string Contrato, Int64 Documento);
        string GravarCliente(Cliente cliente);
        Cliente ObterCliente(string Contrato);
        Cliente ConsultarCliente(string Contrato);
        List<OperacaoCredito> ObterOperacoes(string contrato, Int64 documento);
        OperacaoCredito ObterOperacao(string contrato, Int64 documento);
        OperacaoCredito ObterParcelasAcordo(string Contrato);
        List<Contrato> ObterContratos(Int64 Documento);
        byte[] GerarBoletoAcordo(string acordo, string contrato, int parcelaIni, int parcelaFim);
        byte[] GerarBoletoParcela(string Contrato, int parcela);
        byte[] GerarBoletoParcela(string Contrato, int parcelaInicial, int parcelaFinal);
        List<Parcela> ObterParcelas(string Contrato, DateTime? Data = null);
        string CancelarAcordo(string Acordo, string contrato);
        string EfetuarAcordo(string Contrato, DateTime Pagamento, List<Parcela> parcelas, bool desconto);
        Acordo SimularAcordo(String Contrato, DateTime Pagamento, List<DateTime> DatasVencimento);
        Acordo SimularAcordoRenegocie(AcordoRenegocie acordoRenegocie);
        List<string> ObterLinhaDigitavelAcordo(string Contrato, bool apenasAcordosAtivos);
        List<Acordo> ConsultarAcordo(string Contrato);
        List<Acordo> ConsultarAcordo(string Contrato, bool apenasAcordosAtivos);
        List<Acordo> ConsultarAcordo(string Contrato, List<Parcela> parcelas, bool apenasAcordosAtivos);
        Acordo ConsultarAcordo(string Contrato, string NumAcordo, List<Parcela> parcelas, bool WithPDF);
        string EfetuarAcordoRenegocie(string Contrato, DateTime Pagamento, List<Parcela> parcelas, string codProduto,int qtdeParcelas = 1);

    }
}