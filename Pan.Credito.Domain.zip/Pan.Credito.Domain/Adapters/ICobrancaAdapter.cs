﻿using System.Collections.Generic;
using Pan.Credito.Domain.Entidades.Cobranca;

namespace Pan.Credito.Domain.Adapters
{
    public interface ICobrancaAdapter
    {
        List<RegrasCobranca> ObterRegras(string codigoProduto, int qtdeParcelas, int DiasAtraso,
            bool ContratoAntesSet2017);
    }
}