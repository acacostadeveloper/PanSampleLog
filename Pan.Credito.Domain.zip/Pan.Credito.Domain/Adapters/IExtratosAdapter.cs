﻿using System;
using System.Collections.Generic;

namespace Pan.Credito.Domain.Adapters
{
    public interface IExtratosAdapter : IDisposable 
    {
        byte[] ObterExtratoDepagamentos(int ano, string documento, string email, bool enviarEmail = false);
        byte[] ObterExtratoTarifas(int ano, string documento, string email, bool enviarEmail = false);
        byte[] ObterInformeDeRedimentos(int ano, string documento, string email, bool enviarEmail = false);
        byte[] DeclaracaoContratoQuitado(string contrato, string email, bool enviarEmail = false);
        byte[] ObterCartaResumo(string documento, string contrato, string email, bool enviarEmail = false);
        Dictionary<string, byte[]> GuiaTransferenciaDivida(string email, bool enviarEmail);
        Dictionary<string, byte[]> GuiaSubstituicaoDeGarantia(string email, bool enviarEmail);
    }
}