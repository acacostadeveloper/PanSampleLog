﻿using System;

namespace Pan.Credito.Domain.Common
{
    public interface ISmsDispatcher : IDisposable
    {
        bool EnviarSms(int DDD,int celular, string linhaDigitavel, string cpf);
        bool EnviarSmsCode(int DDD, int celular, string body, string cpf);
        bool EnviarSms( int DDD, int celular, string linhaDigitavel, string cpf, DateTime DataVenc,decimal valorFatura);
    }
}