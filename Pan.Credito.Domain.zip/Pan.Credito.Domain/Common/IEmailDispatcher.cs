﻿using System.Collections.Generic;

namespace Pan.Credito.Domain.Common
{
    public interface IEmailDispatcher
    {
        void EnviarEmail(string email, ref byte[] anexos);
        void EnviarEmail(string email, string assunto,string fileName, ref byte[] anexos);
        void EnviarEmail(string email, string assunto, string corpoEmail, string anexoNome, byte[] anexos = null);
        void EnviarEmail(string email, string assunto, string corpoMsg, ref Dictionary<string, byte[]> anexos);
        void SendTokenEmail(string email,string token);
    }
}