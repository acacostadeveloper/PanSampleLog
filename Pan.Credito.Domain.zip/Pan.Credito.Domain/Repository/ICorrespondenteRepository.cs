﻿using System;
using System.Collections.Generic;
using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Repository
{
    public interface ICorrespondenteRepository : IDisposable
    {
        List<Correspondente> ObterCorrespondente(string subregiao);
    }
}