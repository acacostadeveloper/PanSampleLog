﻿using System;

namespace Pan.Credito.Domain.Repository
{
    public interface IRenegocieRepository : IDisposable
    {
        bool HabilitaRenegocie(string contrato);
    }
}