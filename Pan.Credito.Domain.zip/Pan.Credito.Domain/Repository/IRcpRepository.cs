using System;
using Pan.Credito.Domain.Entidades.Boletos.AutBank;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Protocolo;

namespace Pan.Credito.Domain.Repository
{
    public interface IRcpRepository :IDisposable
    {
        bool RegistrarEnvioEmail(String p_strEmail, Int32 p_intEmailTipo, Int64 p_intDocumento, Int32 p_intIP4, Boolean p_blnAutorizar);
        DUT VerificarTransferenciaDUT(string p_contrato);
        long? AddChamadoSpa(SAC_SDC sacSdc);
        bool CancelaBoletoGerado(string contrato, DateTime dataVencimento);
        bool GravaBoleto(AutBank autBank);
        TipoBoleto GetConfig();
        BoletoGerado BuscaBoletoGerado(string contrato, DateTime dataVencimento);
        string GetLastNossoNumero(string contrato);
    }
}