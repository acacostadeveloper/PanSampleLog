﻿using System;
using Pan.Credito.Domain.Entidades.Helpers;

namespace Pan.Credito.Domain.Repository
{
    public interface IVerificationCodeRepository : IDisposable
    {
        bool CheckToken(string code, string documento);
        int? InsertToken(TokenWorkFlow token);
        void UpdateToken(TokenWorkFlow value); 
    }
}