﻿using System.ComponentModel.DataAnnotations;

namespace Pan.Credito.Domain.Entidades.Protocolo
{
    public class ProtocoloModel
    {
        [Required]
        public string CpfCnpj { get; set; }
        [Required]
        public string Contrato { get; set; }
        [Required]
        public string NomeCliente { get; set; }
        [Required]
        public string CdAtendimento { get; set; }
        public string Email { get; set; }
        public string DDD1 { get; set; }
        public string Fone1 { get; set; }
        public string DDD2 { get; set; }
        public string Fone2 { get; set; }
    }
}
