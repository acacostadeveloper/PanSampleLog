﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Credito.Domain.Entidades.Protocolo
{
    [Table("SAC_SDC_CONTRATOS")]
    [Serializable]
    public class SAC_SDC_CONTRATOS
    {
        [Key]
        public decimal NR_ATENDIMENTO { get; set; }
        public string DS_LEGADO { get; set; }
        public string NR_CONTRATO { get; set; }
        public string CD_CORRESPONDENTE_LEGADO { get; set; }
        public string DS_CORRESPONDENTE_LEGADO { get; set; }
        public string CD_PRODUTO_LEGADO { get; set; }
        public string DS_PRODUTO_LEGADO { get; set; }
        public int? PRAZOTOTAL { get; set; }
        public decimal? SALDODEVEDOR { get; set; }
        public DateTime? DATAHORACADASTRO { get; set; }
        public decimal? USUARIOCADASTROID { get; set; }
        public decimal? NR_ATENDIMENTO_ORIGEM { get; set; }
    }
}