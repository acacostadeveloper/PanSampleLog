﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Configuration;

namespace Pan.Credito.Domain.Entidades.Protocolo
{
    [Table("SAC_SDC")]
    [Serializable]
    public class SAC_SDC
    {
        public SAC_SDC()
        {
            CD_USU_ABERTURA = Convert.ToInt32(ConfigurationManager.AppSettings["CD_USU_ABERTURA"]);
            DH_INI_ABERTURA = DateTime.Now;
            DH_FIM_ABERTURA = DateTime.Now; 
            DS_OBS_ABERTURA = string.Empty;
            NR_CPF = decimal.Zero;
            ST_ATENDIMENTO = "2";
            DH_RESOLUCAO = DateTime.Now;
            CD_USU_FECHA = Convert.ToInt32(ConfigurationManager.AppSettings["CD_USU_ABERTURA"]);
            CD_ATEN_RESP_FECHA = 21;
            CD_REGATENDIMENTO = 140;
            DS_EMAIL = string.Empty;
            CD_FILIAL = 1;
            ST_UTILIZA = "1";
            CD_ATENDIMENTO = decimal.Zero;
            DS_NOME = string.Empty;
            NR_FONE1 = decimal.Zero;
            NR_DDDFONE1 = decimal.Zero;
            ST_FILA_POS_ATEND = "1";
            DH_ENCERRA_POS_ATEND = DateTime.Now;
            CD_REGATEND_POS = 140;
            TP_ATENDIMENTO = "2";
            ST_TRATAMENTO = 2;
            NR_UF = 25;
            ST_EXPIRACAO = 1;
            ST_RESP_ABERTURA = 0;
            ST_RESP_FECHA = 0;
            TP_ENV_RESP = 4;
            TP_FLUXO_ATEND = 2;
            CD_CANAL = 4;
            CD_SUB_CANAL = Convert.ToInt32(ConfigurationManager.AppSettings["CD_SUB_CANAL"]);
            CD_DIRETORIA_ABERTURA = 2;
            IP_ABERTURA = string.Empty;
        }


        [Key]
        public decimal NR_ATENDIMENTO { get; set; }
        public decimal? CD_USU_ABERTURA { get; set; }
        public DateTime? DH_INI_ABERTURA { get; set; }
        public DateTime? DH_FIM_ABERTURA { get; set; }
        public string DS_OBS_ABERTURA { get; set; }
        public decimal? NR_CARTAO { get; set; }
        public decimal? NR_COTA { get; set; }
        public decimal? NR_GRUPO { get; set; }
        public DateTime? DT_VENC_PARC { get; set; }
        public decimal? NR_CPF { get; set; }
        public decimal? NR_CONTRATO { get; set; }
        public decimal? NR_CTA_CORRENTE { get; set; }
        public decimal? CD_AGENCIA { get; set; }
        public decimal? NR_APOLICE { get; set; }
        public string ST_ATENDIMENTO { get; set; }
        public DateTime? DH_RESOLUCAO { get; set; }
        public decimal? CD_USU_FECHA { get; set; }
        public string DS_GRA_TELEFONE { get; set; }
        public decimal? CD_ATEN_RESP_FECHA { get; set; }
        public string ST_GEROU_NV_FILA { get; set; }
        public decimal NR_PROTOCOLO { get; set; }
        public decimal? CD_REGATENDIMENTO { get; set; }
        public string DS_EMAIL { get; set; }
        public decimal? CD_FILIAL { get; set; }
        public string DS_OBS_FECHA { get; set; }
        public string ST_SLA_VENCIDO { get; set; }
        public string ST_UTILIZA { get; set; }
        public decimal? CD_ATENDIMENTO { get; set; }
        public string ST_REABERTURA { get; set; }
        public string DS_NOME { get; set; }
        public decimal? NR_FONE2 { get; set; }
        public decimal? NR_DDDFONE2 { get; set; }
        public decimal? NR_FONE1 { get; set; }
        public decimal? NR_DDDFONE1 { get; set; }
        public string ST_FALTA_2_DIAS { get; set; }
        public string CD_CLIENTE_LEGADO { get; set; }
        public decimal? NR_VIAS_CARTAO { get; set; }
        public decimal? CD_USUARIO_RESP_POS_ATEN { get; set; }
        public string ST_FILA_POS_ATEND { get; set; }
        public DateTime? DH_ENCERRA_POS_ATEND { get; set; }
        public decimal? CD_REGATEND_POS { get; set; }
        public string TP_ATENDIMENTO { get; set; }
        public DateTime? DH_AGENDA { get; set; }
        public string ST_OUVIDORIA { get; set; }
        public DateTime? DH_OUVIDORIA { get; set; }
        public decimal? ST_TRATAMENTO { get; set; }
        public decimal? ST_CANAL_ABERTURA { get; set; }
        public decimal? NR_DIAS_JUIZ { get; set; }
        public decimal? NR_UF { get; set; }
        public string TP_RECLAMACAO { get; set; }
        public decimal? ST_EXPIRACAO { get; set; }
        public DateTime? DH_EXPIROU_SLA { get; set; }
        public decimal? ST_RESP_ABERTURA { get; set; }
        public decimal? ST_RESP_FECHA { get; set; }
        public decimal? TP_ENV_RESP { get; set; }
        public decimal? TP_FLUXO_ATEND { get; set; }
        public decimal? TP_FLUXO_SLA { get; set; }
        public string DS_EMPREGADOR { get; set; }
        public string DS_SALDODEVEDOR { get; set; }
        public int? COD_EMPREGADOR { get; set; }
        public string NR_CONTRATO_CONSIG { get; set; }
        public DateTime? DH_VENC_BOL_CONSIG { get; set; }
        public DateTime? DH_VALID_CONSIG { get; set; }
        public decimal? CD_CANAL { get; set; }
        public int? CD_SUB_CANAL { get; set; }
        public decimal? CD_DIRETORIA_ABERTURA { get; set; }
        public decimal? CD_DIRETORIA_SLA { get; set; }
        public string IP_ABERTURA { get; set; }
        public decimal? CD_USU_APROVADOR { get; set; }
        public DateTime? DH_FIM_APROVA_RECOMPRA { get; set; }
        public DateTime? DH_INI_APROVA_RECOMPRA { get; set; }
        public decimal? NR_CEP { get; set; }
        public string CD_ORIGEM { get; set; }
        public decimal? NR_FONE3 { get; set; }
        public decimal? NR_DDDFONE3 { get; set; }
        public string ST_PROCEDENTE { get; set; }
        public string DS_FILIAL { get; set; }
        public string DS_PRODUTO { get; set; }
        public decimal? CD_PRODUTO { get; set; }
        public string TP_RECLAMACAO_ATEND_POS { get; set; }
        public string ST_SOLUCIONADO_POS { get; set; }
        public decimal? CD_CANAL_OUVIDORIA { get; set; }
        public int? CD_SUB_CANAL_OUVIDORIA { get; set; }
        public decimal? CD_USU_OUVIDORIA { get; set; }
        public decimal? CD_ATEND_DUP { get; set; }
        public decimal? TP_FLUXO_DUP { get; set; }
        public int? CD_PONTO_RELACIONADO { get; set; }
    }
}


