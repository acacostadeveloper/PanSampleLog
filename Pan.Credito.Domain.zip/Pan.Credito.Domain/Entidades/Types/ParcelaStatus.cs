﻿using System.ComponentModel;

namespace Pan.Credito.Domain.Entidades.Types
{
    public enum ParcelaStatus
    {
        [Description("aberto")]
        EmDia = 1,

        [Description("pago")]
        Quitado = 2,

        [Description("atrasado")]
        Atrasado = 3
    }
}