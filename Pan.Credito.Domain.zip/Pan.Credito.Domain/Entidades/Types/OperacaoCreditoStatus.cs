﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum OperacaoCreditoStatus
    {
        EmDia      = 1,
        Atrasada   = 2,
        Quitada    = 3,
        EmCobranca = 4,
        SemParcela = 5,
        Cancelada  = 6,
        Prejuizo   = 7,
        Inibido    = 8,
        CreditoCedido = 9,
        BNDU = 10
    }
}