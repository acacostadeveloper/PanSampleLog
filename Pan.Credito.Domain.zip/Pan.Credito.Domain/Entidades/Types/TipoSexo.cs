﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum TipoSexo
    {
        NAO_DEFINIDO,
        MASCULINO,
        FEMININO,
    }
}