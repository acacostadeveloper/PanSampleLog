namespace Pan.Credito.Domain.Entidades.Types
{
    public enum TipoResidencia
    {
        NAO_DEFINIDO = 0,
        PROPRIA,
        ALUGADA,
        DE_FAMILIARES,
        DA_EMPRESA,
        FINANCIADA,
        HOTEL,
    }
}