﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum Origens
    {
        Todas       = 0,
        PanSolution = 1,
        Funcao      = 2,
        Montreal    = 3,
        Viveri      = 4,
        FIS         = 5
    }
}