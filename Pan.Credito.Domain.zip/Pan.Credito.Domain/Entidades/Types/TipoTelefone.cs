﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum TipoTelefone
    {
        Telefone,
        Celular,
        Recado,
        Comercial
    }
}