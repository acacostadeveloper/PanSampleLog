﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum BoletosTipos
    {
        Parcela = 1,
        Acordo = 2,
        Fatura = 3
    }
}