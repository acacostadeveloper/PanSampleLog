﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum OperacaoLiquidacaoTipos
    {
        Indefinido    = 0,
        Dinheiro      = 1,
        Boleto        = 2,
        Cheque        = 3,
        DebitoConta   = 4,
        BoletoECheque = 5,
        BoletoEDebito = 6,
        ChequeEDebito = 7,
        Interface     = 8,
        Misto         = 9
    }
}