namespace Pan.Credito.Domain.Entidades.Types
{
    public enum TipoNacionalidade
    {
        NAO_DEFINIDO = 0,
        BRASILEIRA,
        ESTRANGEIRA,
    }
}