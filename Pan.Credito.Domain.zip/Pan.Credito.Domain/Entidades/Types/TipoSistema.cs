﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum TipoSistema
    {
        Pansolution = 0,
        CUC,
        Funcao,
    }
}