﻿namespace Pan.Credito.Domain.Entidades.Types
{
    public enum TipoEstadoCivil
    {
        NAO_DEFINIDO,
        SOLTEIRO,
        CASADO,
        DESQUITADO,
        DIVORCIADO,
        VIUVO,
        OUTROS,
    }
}