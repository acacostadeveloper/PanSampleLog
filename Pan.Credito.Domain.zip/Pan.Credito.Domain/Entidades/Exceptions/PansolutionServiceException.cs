﻿using System;

namespace Pan.Credito.Domain.Entidades.Exceptions
{
    public class PansolutionServiceException : Exception
    {
        public PansolutionServiceException()
        {
        }

        public PansolutionServiceException(string message)
            : base(message)
        {
        }

        public PansolutionServiceException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}