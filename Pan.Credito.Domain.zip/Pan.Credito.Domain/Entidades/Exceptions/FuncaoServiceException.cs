﻿using System;

namespace Pan.Credito.Domain.Entidades.Exceptions
{
    public class FuncaoServiceException : Exception
    {
          public FuncaoServiceException()
        {
        }

        public FuncaoServiceException(string message)
            : base(message)
        {
        }

        public FuncaoServiceException(string message, Exception inner)
            : base(message, inner)
        {
        }
    }
}