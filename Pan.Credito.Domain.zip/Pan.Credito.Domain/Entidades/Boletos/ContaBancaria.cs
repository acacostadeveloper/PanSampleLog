﻿namespace Pan.Credito.Domain.Entidades.Boletos
{
    public class ContaBancaria
    {
        public string Agencia { get; set; }
        public string Conta { get; set; }
        public string DigitoAgencia { get; set; }
        public string DigitoConta { get; set; }
    }
}