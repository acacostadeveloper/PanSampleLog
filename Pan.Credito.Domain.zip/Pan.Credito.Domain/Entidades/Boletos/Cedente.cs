﻿using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Entidades.Boletos
{
    public class Cedente
    {
        public int Codigo { get; set; }
        public ContaBancaria ContaBancaria { get; set; }
        public int Convenio { get; set; }
        public string CPFCNPJ { get; set; }
        public int DigitoCedente { get; set; }
        public string Nome { get; set; }
        public Endereco Endereco { get; set; }
    }
}