﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Pan.Credito.Domain.Entidades.Boletos.AutBank
{
    public class AutBank
    {
        private string _digitoNossoNumero;
        private DateTime _dataVencimento;


        public AutBank()
        {
            ResponseCip = new ResponseCip();
        }

        public string CodCliente { get; set; }
        public string NumContaHeader { get; set; }
        public string NumCarteira { get; set; }
        public string NossoNumero { get; set; }
        public string CodBanco { get; set; }
        public string CodModalBancos { get; set; }
        public string NossoNumeroBancos { get; set; }
        public string CodEspecieDoc { get; set; }
        public decimal VlrNominal { get; set; }
        public decimal VlrAbatimento { get; set; }
        public DateTime DataEmissao { get; set; }
        public DateTime DataVencimento
        {
            get
            {
                 return _dataVencimento.AddDays((_dataVencimento.DayOfWeek == DayOfWeek.Saturday ? 2 : _dataVencimento.DayOfWeek == DayOfWeek.Sunday ? 1 : 0));
            }
            set
            {
                _dataVencimento = value;
            }
        }
        public string SeuNumero { get; set; }
        public string Aceite { get; set; }
        public string CNPJCPF { get; set; }
        public string TipoPessoa { get; set; }
        public string Nome { get; set; }
        public string Endereco { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string UF { get; set; }
        public string Cep { get; set; }
        public string Email { get; set; }
        public string DDD { get; set; }
        public string Telefone { get; set; }
        public string CampoLivre { get; set; }
        public string TipoPessoaSacador { get; set; }
        public string CNPJCPFSacador { get; set; }
        public string NomeSacador { get; set; }
        public string EnderecoSacador { get; set; }
        public string BairroSacador { get; set; }
        public string CepSacador { get; set; }
        public string CidadeSacador { get; set; }
        public string UFSacador { get; set; }
        public string Mensagem1 { get; set; }
        public string Mensagem2 { get; set; }
        public string Mensagem3 { get; set; }
        public string Mensagem4 { get; set; }
        public string Mensagem5 { get; set; }
        public string CodDesconto1 { get; set; }
        public decimal VlrDesconto1 { get; set; }
        public decimal TxDesconto1 { get; set; }
        public string DataDesconto1 { get; set; }
        public string CodDesconto2 { get; set; }
        public decimal VlrDesconto2 { get; set; }
        public decimal TxDesconto2 { get; set; }
        public string DataDesconto2 { get; set; }
        public string CodDesconto3 { get; set; }
        public decimal VlrDesconto3 { get; set; }
        public decimal TxDesconto3 { get; set; }
        public string DataDesconto3 { get; set; }
        public string CodMulta { get; set; }
        public string DataMulta { get; set; }
        public decimal TxMulta { get; set; }
        public decimal VlrMulta { get; set; }
        public string CodMora { get; set; }
        public string DataMora { get; set; }
        public decimal txMora { get; set; }
        public decimal VlrMora { get; set; }
        public string PossuiAgenda { get; set; }
        public string TipoAgendamento { get; set; }
        public string CriterioDias { get; set; }
        public int NumDiasAgenda { get; set; }
        public string CodIndice { get; set; }
        public string IndPagtoParcial { get; set; }
        public int QtdPagtosParciais { get; set; }
        public string TipoVlrPercMinimo { get; set; }
        public decimal VlrPercMinimo { get; set; }
        public string TipoVlrPercMaximo { get; set; }
        public decimal VlrPercMaximo { get; set; }
        public string TipoAutRecDivergente { get; set; }
        public int IdUsuario { get; set; }
        public string Usuario { get; set; }
        public string Senha { get; set; }
        public string CodContrato { get; set; }
        public int TipoBoleto { get; set; }
        public string CodAgencia { get; set; }
        public string DVNossoNumero
        {
            get
            {
                var results = new List<int>();
                var numbers = string.Format("{0}{1}{2}", CodAgencia, NumCarteira, NossoNumero).Select(x => Convert.ToInt32(x.ToString())).ToList();

                for (var i = 0; i < numbers.Count; i++)
                {
                    if (i % 2 == 0)
                        results.Add(numbers[i] * 2);
                    else
                        results.Add(numbers[i]);
                }
                var sum = results.Sum(x => x >= 10 ? ((x / 10) + x % 10) : x);

                var dv = 0;

                dv = (sum * 9) % 10;

                return dv.ToString();
            }
            internal set { _digitoNossoNumero = value; }
        }
        public ResponseCip ResponseCip { get; set; }

    }
}