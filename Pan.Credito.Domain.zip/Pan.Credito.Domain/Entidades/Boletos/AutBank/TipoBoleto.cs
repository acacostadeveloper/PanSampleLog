﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Credito.Domain.Entidades.Boletos.AutBank
{
    [Table("TIPOBOLETO")]
    public class TipoBoleto
    {
        public TipoBoleto()
        {
            Configuracao = new TbConfiguracoes();
        }
        [Key]
        public int CODIGOTIPOBOLETO { get; set; }
        public string CONTACORRENTE { get; set; }
        public string CODBANCO { get; set; }
        public string NOSSONUMEROINICIAL { get; set; }
        public string NOSSONUMEROFINAL { get; set; }
        public int? IDOPERACAO { get; set; }
        public string NOMETIPO { get; set; }
        public string CODIGOCLIENTE { get; set; }
        public string NUMEROCONTAHEADER { get; set; }
        public string SEUNUMERO { get; set; }
        public string CD_PRODUTO { get; set; }
        public string NUMEROCARTEIRA { get; set; }
        public string LastNossoNumero { get; set; }        
        public TbConfiguracoes Configuracao { get; set; }
    }
}












