﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Credito.Domain.Entidades.Boletos.AutBank
{
    [Table("TB_CONFIGURACOES")]
    public class TbConfiguracoes
    {
        [Key]
        public int ID_CONFIGURACAO { get; set; }
        public string SERVICO { get; set; }
        public string USUARIO { get; set; }
        public string SENHA { get; set; }
        public DateTime? DATA_INICIAL_CIP { get; set; }
    }
}