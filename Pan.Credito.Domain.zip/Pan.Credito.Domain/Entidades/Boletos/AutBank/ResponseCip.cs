﻿namespace Pan.Credito.Domain.Entidades.Boletos.AutBank
{
    public class ResponseCip
    {
        public string CodAgencia { get; set; }
        public string CodAgenciaCob { get; set; }
        public string CodBanco { get; set; }
        public string CodBarras { get; set; }
        public string CodColigada { get; set; }
        public string CodErro { get; set; }
        public string CodModalBancos { get; set; }
        public string IndPagadorEletronico { get; set; }
        public string LinhaDigitavel { get; set; }
        public string MotivoErroCIP { get; set; }
        public string MsgErro { get; set; }
        public string NossoNumero { get; set; }
        public string NossoNumeroBancos { get; set; }
        public string NumCarteira { get; set; }
        public string NumIdentcDDA { get; set; }
        public string SitInclusaoCIP { get; set; }
        public string Retorna_MSG_CIP { get; set; }
    }
}