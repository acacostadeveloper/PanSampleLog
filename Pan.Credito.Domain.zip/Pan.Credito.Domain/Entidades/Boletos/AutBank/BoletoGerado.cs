﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Credito.Domain.Entidades.Boletos.AutBank
{
    [Table("BOLETOGERADO")]
    public class BoletoGerado
    {
        [Key]
        public int CODIGOBOLETO { get; set; }
        public string CODIGOCLIENTE { get; set; }
        public string NUMEROCONTAHEADER { get; set; }
        public string NUMEROCARTEIRA { get; set; }
        public string NOSSONUMERO { get; set; }
        public string CODIGOBANCO { get; set; }
        public string CODIGOMODALBANCOS { get; set; }
        public string NOSSONUMEROBANCOS { get; set; }
        public string CODIGOESPECIEDOC { get; set; }
        public decimal VALORNOMINAL { get; set; }
        public decimal VALORABATIMENTO { get; set; }
        public DateTime? DATAEMISSAO { get; set; }
        public DateTime? DATAVENCIMENTO { get; set; }
        public string SEUNUMERO { get; set; }
        public string ACEITE { get; set; }
        public string CPFCNPJ { get; set; }
        public int? PESSOA { get; set; }
        public string NOME { get; set; }
        public string EMAIL { get; set; }
        public string DDD { get; set; }
        public string TELEFONE { get; set; }
        public int? SACADORPESSOA { get; set; }
        public string CPFCNPJSACADOR { get; set; }
        public string NOMESACADOR { get; set; }
        public string MENSAGEM1 { get; set; }
        public string MENSAGEM2 { get; set; }
        public string MENSAGEM3 { get; set; }
        public string MENSAGEM4 { get; set; }
        public string MENSAGEM5 { get; set; }
        public string POSSUIAGENDA { get; set; }
        public string TIPOAGENDAMENTO { get; set; }
        public string CRITERIODIAS { get; set; }
        public int? NUMDIASAGENDA { get; set; }
        public string CODIGOINDICEMOEDA { get; set; }
        public string INDICADORPAGAMENTOPARCIAL { get; set; }
        public int? QUANTIDADEPAGAMENTOSPARCIAIS { get; set; }
        public string TIPOPERCENTUALVALORMINIMO { get; set; }
        public decimal? VALORPERCENTUALMINIMO { get; set; }
        public string TIPOPERCENTUALVALORMAXIMO { get; set; }
        public decimal VALORPERCENTUALMAXIMO { get; set; }
        public string TIPOAUTRECEBDIVERGENTE { get; set; }
        public string CODIGOBARRAS { get; set; }
        public string LINHADIGITAVEL { get; set; }
        public int? CODIGOTIPOBOLETO { get; set; }
        public int? NROVEZESENVIO { get; set; }
        public string COD_CONTRATO { get; set; }
        public int? BOLETOAVULSO { get; set; }
        public string STATUS { get; set; }
        public int? ID_MOTIVO_CANC { get; set; }
        public int CD_USUARIO { get; set; }
        public DateTime DATA_GERACAO { get; set; }
        public DateTime? DATA_INTEGRACAO { get; set; }
        public int? DVNOSSONUMERO { get; set; }
    }
}








