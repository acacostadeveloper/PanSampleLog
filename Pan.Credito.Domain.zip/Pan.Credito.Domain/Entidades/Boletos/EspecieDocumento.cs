﻿namespace Pan.Credito.Domain.Entidades.Boletos
{
    public class EspecieDocumento
    {
        public int Codigo { get; set; }
        public string Especie { get; set; }
        public string Sigla { get; set; }
    }
}