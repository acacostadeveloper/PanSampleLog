namespace Pan.Credito.Domain.Entidades.Boletos
{
    public class CodigoBarra
    {
        public string Chave { get; set; }
        public string Codigo { get; set; }
        public string Imagem { get; set; }
        public string LinhaDigitavel { get; set; }
    }
}