﻿using Pan.Credito.Domain.Entidades.Credito;

namespace Pan.Credito.Domain.Entidades.Boletos
{
    public class Sacado
    {
        public string Nome { get; set; }
        public string CPFCNPJ { get; set; }
        public Endereco Endereco { get; set; }
        public string TipoPessoa { get; set; }
    }
}