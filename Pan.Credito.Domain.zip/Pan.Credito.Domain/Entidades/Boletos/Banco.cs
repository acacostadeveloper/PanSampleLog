namespace Pan.Credito.Domain.Entidades.Boletos
{
    public class Banco
    {
        public Banco()
        {
        }

        public Banco(int p_intCodigo, int p_intDigito)
        {
            Codigo = p_intCodigo;
            Digito = p_intDigito;
        }

        public int Codigo { get; set; }
        public int Digito { get; set; }

        public string Nome
        {
            get
            {
                var strBanco = "";

                switch (Codigo)
                {
                    case 654:
                        strBanco = "Banco A.J.Renner S.A.";
                        break;
                    case 246:
                        strBanco = "Banco ABC Brasil S.A.";
                        break;
                    case 25:
                        strBanco = "Banco Alfa S.A.";
                        break;
                    case 641:
                        strBanco = "Banco Alvorada S.A.";
                        break;
                    case 213:
                        strBanco = "Banco Arbi S.A.";
                        break;
                    case 19:
                        strBanco = "Banco Azteca do Brasil S.A.";
                        break;
                    case 29:
                        strBanco = "Banco Banerj S.A.";
                        break;
                    case 0:
                        strBanco = "Banco Bankpar S.A.";
                        break;
                    case 740:
                        strBanco = "Banco Barclays S.A.";
                        break;
                    case 107:
                        strBanco = "Banco BBM S.A.";
                        break;
                    case 31:
                        strBanco = "Banco Beg S.A.";
                        break;
                    case 739:
                        strBanco = "Banco BGN S.A.";
                        break;
                    case 96:
                        strBanco = "Banco BM&F de Servi�os de Liquida��o e Cust�dia S.A";
                        break;
                    case 318:
                        strBanco = "Banco BMG S.A.";
                        break;
                    case 752:
                        strBanco = "Banco BNP Paribas Brasil S.A.";
                        break;
                    case 248:
                        strBanco = "Banco Boavista Interatl�ntico S.A.";
                        break;
                    case 218:
                        strBanco = "Banco Bonsucesso S.A.";
                        break;
                    case 65:
                        strBanco = "Banco Bracce S.A.";
                        break;
                    case 36:
                        strBanco = "Banco Bradesco BBI S.A.";
                        break;
                    case 204:
                        strBanco = "Banco Bradesco Cart�es S.A.";
                        break;
                    case 394:
                        strBanco = "Banco Bradesco Financiamentos S.A.";
                        break;
                    case 237:
                        strBanco = "Banco Bradesco S.A.";
                        break;
                    case 225:
                        strBanco = "Banco Brascan S.A.";
                        break;
                    case 208:
                        strBanco = "Banco BTG Pactual S.A.";
                        break;
                    case 44:
                        strBanco = "Banco BVA S.A.";
                        break;
                    case 263:
                        strBanco = "Banco Cacique S.A.";
                        break;
                    case 473:
                        strBanco = "Banco Caixa Geral - Brasil S.A.";
                        break;
                    case 412:
                        strBanco = "Banco Capital S.A.";
                        break;
                    case 40:
                        strBanco = "Banco Cargill S.A.";
                        break;
                    case 266:
                        strBanco = "Banco C�dula S.A.";
                        break;
                    case 745:
                        strBanco = "Banco Citibank S.A.";
                        break;
                    case 241:
                        strBanco = "Banco Cl�ssico S.A.";
                        break;
                    case 215:
                        strBanco = "Banco Comercial e de Investimento Sudameris S.A.";
                        break;
                    case 756:
                        strBanco = "Banco Cooperativo do Brasil S.A. - BANCOOB";
                        break;
                    case 748:
                        strBanco = "Banco Cooperativo Sicredi S.A.";
                        break;
                    case 75:
                        strBanco = "Banco CR2 S.A.";
                        break;
                    case 721:
                        strBanco = "Banco Credibel S.A.";
                        break;
                    case 222:
                        strBanco = "Banco Credit Agricole Brasil S.A.";
                        break;
                    case 505:
                        strBanco = "Banco Credit Suisse (Brasil) S.A.";
                        break;
                    case 229:
                        strBanco = "Banco Cruzeiro do Sul S.A.";
                        break;
                    case 3:
                        strBanco = "Banco da Amaz�nia S.A.";
                        break;
                    case 707:
                        strBanco = "Banco Daycoval S.A.";
                        break;
                    case 300:
                        strBanco = "Banco de La Nacion Argentina";
                        break;
                    case 495:
                        strBanco = "Banco de La Provincia de Buenos Aires";
                        break;
                    case 494:
                        strBanco = "Banco de La Republica Oriental del Uruguay";
                        break;
                    case 24:
                        strBanco = "Banco de Pernambuco S.A. - BANDEPE";
                        break;
                    case 456:
                        strBanco = "Banco de Tokyo-Mitsubishi UFJ Brasil S.A.";
                        break;
                    case 214:
                        strBanco = "Banco Dibens S.A.";
                        break;
                    case 1:
                        strBanco = "Banco do Brasil S.A.";
                        break;
                    case 47:
                        strBanco = "Banco do Estado de Sergipe S.A.";
                        break;
                    case 37:
                        strBanco = "Banco do Estado do Par� S.A.";
                        break;
                    case 39:
                        strBanco = "Banco do Estado do Piau� S.A. - BEP";
                        break;
                    case 41:
                        strBanco = "Banco do Estado do Rio Grande do Sul S.A.";
                        break;
                    case 4:
                        strBanco = "Banco do Nordeste do Brasil S.A.";
                        break;
                    case 265:
                        strBanco = "Banco Fator S.A.";
                        break;
                    case 224:
                        strBanco = "Banco Fibra S.A.";
                        break;
                    case 626:
                        strBanco = "Banco Ficsa S.A.";
                        break;
                    case 233:
                        strBanco = "Banco GE Capital S.A.";
                        break;
                    case 734:
                        strBanco = "Banco Gerdau S.A.";
                        break;
                    case 612:
                        strBanco = "Banco Guanabara S.A.";
                        break;
                    case 63:
                        strBanco = "Banco Ibi S.A. Banco M�ltiplo";
                        break;
                    case 604:
                        strBanco = "Banco Industrial do Brasil S.A.";
                        break;
                    case 320:
                        strBanco = "Banco Industrial e Comercial S.A.";
                        break;
                    case 653:
                        strBanco = "Banco Indusval S.A.";
                        break;
                    case 630:
                        strBanco = "Banco Intercap S.A.";
                        break;
                    case 249:
                        strBanco = "Banco Investcred Unibanco S.A.";
                        break;
                    case 184:
                        strBanco = "Banco Ita� BBA S.A.";
                        break;
                    case 479:
                        strBanco = "Banco Ita�Bank S.A";
                        break;
                    case 376:
                        strBanco = "Banco J. P. Morgan S.A.";
                        break;
                    case 74:
                        strBanco = "Banco J. Safra S.A.";
                        break;
                    case 217:
                        strBanco = "Banco John Deere S.A.";
                        break;
                    case 76:
                        strBanco = "Banco KDB S.A.";
                        break;
                    case 757:
                        strBanco = "Banco KEB do Brasil S.A.";
                        break;
                    case 600:
                        strBanco = "Banco Luso Brasileiro S.A.";
                        break;
                    case 212:
                        strBanco = "Banco Matone S.A.";
                        break;
                    case 243:
                        strBanco = "Banco M�xima S.A.";
                        break;
                    case 389:
                        strBanco = "Banco Mercantil do Brasil S.A.";
                        break;
                    case 746:
                        strBanco = "Banco Modal S.A.";
                        break;
                    case 738:
                        strBanco = "Banco Morada S.A.";
                        break;
                    case 66:
                        strBanco = "Banco Morgan Stanley S.A.";
                        break;
                    case 45:
                        strBanco = "Banco Opportunity S.A.";
                        break;
                    case 623:
                        strBanco = "Banco PAN S.A.";
                        break;
                    case 611:
                        strBanco = "Banco Paulista S.A.";
                        break;
                    case 613:
                        strBanco = "Banco Pec�nia S.A.";
                        break;
                    case 643:
                        strBanco = "Banco Pine S.A.";
                        break;
                    case 724:
                        strBanco = "Banco Porto Seguro S.A.";
                        break;
                    case 735:
                        strBanco = "Banco Pottencial S.A.";
                        break;
                    case 638:
                        strBanco = "Banco Prosper S.A.";
                        break;
                    case 747:
                        strBanco = "Banco Rabobank International Brasil S.A.";
                        break;
                    case 356:
                        strBanco = "Banco Real S.A.";
                        break;
                    case 633:
                        strBanco = "Banco Rendimento S.A.";
                        break;
                    case 741:
                        strBanco = "Banco Ribeir�o Preto S.A.";
                        break;
                    case 72:
                        strBanco = "Banco Rural Mais S.A.";
                        break;
                    case 453:
                        strBanco = "Banco Rural S.A.";
                        break;
                    case 422:
                        strBanco = "Banco Safra S.A.";
                        break;
                    case 33:
                        strBanco = "Banco Santander (Brasil) S.A.";
                        break;
                    case 250:
                        strBanco = "Banco Schahin S.A.";
                        break;
                    case 743:
                        strBanco = "Banco Semear S.A.";
                        break;
                    case 749:
                        strBanco = "Banco Simples S.A.";
                        break;
                    case 366:
                        strBanco = "Banco Soci�t� G�n�rale Brasil S.A.";
                        break;
                    case 637:
                        strBanco = "Banco Sofisa S.A.";
                        break;
                    case 12:
                        strBanco = "Banco Standard de Investimentos S.A.";
                        break;
                    case 464:
                        strBanco = "Banco Sumitomo Mitsui Brasileiro S.A.";
                        break;
                    case 634:
                        strBanco = "Banco Tri�ngulo S.A.";
                        break;
                    case 655:
                        strBanco = "Banco Votorantim S.A.";
                        break;
                    case 610:
                        strBanco = "Banco VR S.A.";
                        break;
                    case 370:
                        strBanco = "Banco WestLB do Brasil S.A.";
                        break;
                    case 21:
                        strBanco = "BANESTES S.A. Banco do Estado do Esp�rito Santo";
                        break;
                    case 719:
                        strBanco = "Banif-Banco Internacional do Funchal (Brasil)S.A.";
                        break;
                    case 755:
                        strBanco = "Bank of America Merrill Lynch Banco M�ltiplo S.A.";
                        break;
                    case 744:
                        strBanco = "BankBoston N.A.";
                        break;
                    case 73:
                        strBanco = "BB Banco Popular do Brasil S.A.";
                        break;
                    case 78:
                        strBanco = "BES Investimento do Brasil S.A.-Banco de Investimento";
                        break;
                    case 69:
                        strBanco = "BPN Brasil Banco M�ltiplo S.A.";
                        break;
                    case 70:
                        strBanco = "BRB - Banco de Bras�lia S.A.";
                        break;
                    case 104:
                        strBanco = "Caixa Econ�mica Federal";
                        break;
                    case 477:
                        strBanco = "Citibank N.A.";
                        break;
                    case 487:
                        strBanco = "Deutsche Bank S.A. - Banco Alem�o";
                        break;
                    case 751:
                        strBanco = "Dresdner Bank Brasil S.A. - Banco M�ltiplo";
                        break;
                    case 64:
                        strBanco = "Goldman Sachs do Brasil Banco M�ltiplo S.A.";
                        break;
                    case 62:
                        strBanco = "Hipercard Banco M�ltiplo S.A.";
                        break;
                    case 399:
                        strBanco = "HSBC Bank Brasil S.A. - Banco M�ltiplo";
                        break;
                    case 168:
                        strBanco = "HSBC Finance (Brasil) S.A. - Banco M�ltiplo";
                        break;
                    case 492:
                        strBanco = "ING Bank N.V.";
                        break;
                    case 652:
                        strBanco = "Ita� Unibanco Holding S.A.";
                        break;
                    case 341:
                        strBanco = "Ita� Unibanco S.A.";
                        break;
                    case 79:
                        strBanco = "JBS Banco S.A.";
                        break;
                    case 488:
                        strBanco = "JPMorgan Chase Bank";
                        break;
                    case 14:
                        strBanco = "Natixis Brasil S.A. Banco M�ltiplo";
                        break;
                    case 753:
                        strBanco = "NBC Bank Brasil S.A. - Banco M�ltiplo";
                        break;
                    case 254:
                        strBanco = "Paran� Banco S.A.";
                        break;
                    case 409:
                        strBanco = "UNIBANCO - Uni�o de Bancos Brasileiros S.A.";
                        break;
                    case 230:
                        strBanco = "Unicard Banco M�ltiplo S.A.";
                        break;
                    case 84:
                        strBanco = "Unicred Norte do Paran�";
                        break;
                }

                return strBanco;
            }
            set { }
        }

        public string NomeAbreviado
        {
            get
            {
                var strBanco = "";

                switch (Codigo)
                {
                    case 654:
                        strBanco = "Banco A.J.Renner S.A.";
                        break;
                    case 246:
                        strBanco = "Banco ABC Brasil S.A.";
                        break;
                    case 25:
                        strBanco = "Banco Alfa S.A.";
                        break;
                    case 641:
                        strBanco = "Banco Alvorada S.A.";
                        break;
                    case 213:
                        strBanco = "Banco Arbi S.A.";
                        break;
                    case 19:
                        strBanco = "Banco Azteca do Brasil S.A.";
                        break;
                    case 29:
                        strBanco = "Banco Banerj S.A.";
                        break;
                    case 0:
                        strBanco = "Banco Bankpar S.A.";
                        break;
                    case 740:
                        strBanco = "Banco Barclays S.A.";
                        break;
                    case 107:
                        strBanco = "Banco BBM S.A.";
                        break;
                    case 31:
                        strBanco = "Banco Beg S.A.";
                        break;
                    case 739:
                        strBanco = "Banco BGN S.A.";
                        break;
                    case 96:
                        strBanco = "Banco BM&F de Servi�os de Liquida��o e Cust�dia S.A";
                        break;
                    case 318:
                        strBanco = "Banco BMG S.A.";
                        break;
                    case 752:
                        strBanco = "Banco BNP Paribas Brasil S.A.";
                        break;
                    case 248:
                        strBanco = "Banco Boavista Interatl�ntico S.A.";
                        break;
                    case 218:
                        strBanco = "Banco Bonsucesso S.A.";
                        break;
                    case 65:
                        strBanco = "Banco Bracce S.A.";
                        break;
                    case 36:
                        strBanco = "Banco Bradesco BBI S.A.";
                        break;
                    case 204:
                        strBanco = "Banco Bradesco Cart�es S.A.";
                        break;
                    case 394:
                        strBanco = "Banco Bradesco Financiamentos S.A.";
                        break;
                    case 237:
                        strBanco = "Bradesco";
                        break; //Banco Bradesco S.A.
                    case 225:
                        strBanco = "Banco Brascan S.A.";
                        break;
                    case 208:
                        strBanco = "BTG Pactual";
                        break;
                    case 44:
                        strBanco = "Banco BVA S.A.";
                        break;
                    case 263:
                        strBanco = "Banco Cacique S.A.";
                        break;
                    case 473:
                        strBanco = "Banco Caixa Geral - Brasil S.A.";
                        break;
                    case 412:
                        strBanco = "Banco Capital S.A.";
                        break;
                    case 40:
                        strBanco = "Banco Cargill S.A.";
                        break;
                    case 266:
                        strBanco = "Banco C�dula S.A.";
                        break;
                    case 745:
                        strBanco = "Banco Citibank S.A.";
                        break;
                    case 241:
                        strBanco = "Banco Cl�ssico S.A.";
                        break;
                    case 215:
                        strBanco = "Banco Comercial e de Investimento Sudameris S.A.";
                        break;
                    case 756:
                        strBanco = "Banco Cooperativo do Brasil S.A. - BANCOOB";
                        break;
                    case 748:
                        strBanco = "Banco Cooperativo Sicredi S.A.";
                        break;
                    case 75:
                        strBanco = "Banco CR2 S.A.";
                        break;
                    case 721:
                        strBanco = "Banco Credibel S.A.";
                        break;
                    case 222:
                        strBanco = "Banco Credit Agricole Brasil S.A.";
                        break;
                    case 505:
                        strBanco = "Banco Credit Suisse (Brasil) S.A.";
                        break;
                    case 229:
                        strBanco = "Banco Cruzeiro do Sul S.A.";
                        break;
                    case 3:
                        strBanco = "Banco da Amaz�nia S.A.";
                        break;
                    case 707:
                        strBanco = "Banco Daycoval S.A.";
                        break;
                    case 300:
                        strBanco = "Banco de La Nacion Argentina";
                        break;
                    case 495:
                        strBanco = "Banco de La Provincia de Buenos Aires";
                        break;
                    case 494:
                        strBanco = "Banco de La Republica Oriental del Uruguay";
                        break;
                    case 24:
                        strBanco = "Banco de Pernambuco S.A. - BANDEPE";
                        break;
                    case 456:
                        strBanco = "Banco de Tokyo-Mitsubishi UFJ Brasil S.A.";
                        break;
                    case 214:
                        strBanco = "Banco Dibens S.A.";
                        break;
                    case 1:
                        strBanco = "Banco do Brasil S.A.";
                        break;
                    case 47:
                        strBanco = "Banco do Estado de Sergipe S.A.";
                        break;
                    case 37:
                        strBanco = "Banco do Estado do Par� S.A.";
                        break;
                    case 39:
                        strBanco = "Banco do Estado do Piau� S.A. - BEP";
                        break;
                    case 41:
                        strBanco = "Banco do Estado do Rio Grande do Sul S.A.";
                        break;
                    case 4:
                        strBanco = "Banco do Nordeste do Brasil S.A.";
                        break;
                    case 265:
                        strBanco = "Banco Fator S.A.";
                        break;
                    case 224:
                        strBanco = "Banco Fibra S.A.";
                        break;
                    case 626:
                        strBanco = "Banco Ficsa S.A.";
                        break;
                    case 233:
                        strBanco = "Banco GE Capital S.A.";
                        break;
                    case 734:
                        strBanco = "Banco Gerdau S.A.";
                        break;
                    case 612:
                        strBanco = "Banco Guanabara S.A.";
                        break;
                    case 63:
                        strBanco = "Banco Ibi S.A. Banco M�ltiplo";
                        break;
                    case 604:
                        strBanco = "Banco Industrial do Brasil S.A.";
                        break;
                    case 320:
                        strBanco = "Banco Industrial e Comercial S.A.";
                        break;
                    case 653:
                        strBanco = "Banco Indusval S.A.";
                        break;
                    case 630:
                        strBanco = "Banco Intercap S.A.";
                        break;
                    case 249:
                        strBanco = "Banco Investcred Unibanco S.A.";
                        break;
                    case 184:
                        strBanco = "Banco Ita� BBA S.A.";
                        break;
                    case 479:
                        strBanco = "Banco Ita�Bank S.A";
                        break;
                    case 376:
                        strBanco = "Banco J. P. Morgan S.A.";
                        break;
                    case 74:
                        strBanco = "Banco J. Safra S.A.";
                        break;
                    case 217:
                        strBanco = "Banco John Deere S.A.";
                        break;
                    case 76:
                        strBanco = "Banco KDB S.A.";
                        break;
                    case 757:
                        strBanco = "Banco KEB do Brasil S.A.";
                        break;
                    case 600:
                        strBanco = "Banco Luso Brasileiro S.A.";
                        break;
                    case 212:
                        strBanco = "Banco Matone S.A.";
                        break;
                    case 243:
                        strBanco = "Banco M�xima S.A.";
                        break;
                    case 389:
                        strBanco = "Banco Mercantil do Brasil S.A.";
                        break;
                    case 746:
                        strBanco = "Banco Modal S.A.";
                        break;
                    case 738:
                        strBanco = "Banco Morada S.A.";
                        break;
                    case 66:
                        strBanco = "Banco Morgan Stanley S.A.";
                        break;
                    case 45:
                        strBanco = "Banco Opportunity S.A.";
                        break;
                    case 623:
                        strBanco = "Banco PAN";
                        break;
                    case 611:
                        strBanco = "Banco Paulista S.A.";
                        break;
                    case 613:
                        strBanco = "Banco Pec�nia S.A.";
                        break;
                    case 643:
                        strBanco = "Banco Pine S.A.";
                        break;
                    case 724:
                        strBanco = "Banco Porto Seguro S.A.";
                        break;
                    case 735:
                        strBanco = "Banco Pottencial S.A.";
                        break;
                    case 638:
                        strBanco = "Banco Prosper S.A.";
                        break;
                    case 747:
                        strBanco = "Banco Rabobank International Brasil S.A.";
                        break;
                    case 356:
                        strBanco = "Banco Real S.A.";
                        break;
                    case 633:
                        strBanco = "Banco Rendimento S.A.";
                        break;
                    case 741:
                        strBanco = "Banco Ribeir�o Preto S.A.";
                        break;
                    case 72:
                        strBanco = "Banco Rural Mais S.A.";
                        break;
                    case 453:
                        strBanco = "Banco Rural S.A.";
                        break;
                    case 422:
                        strBanco = "Banco Safra S.A.";
                        break;
                    case 33:
                        strBanco = "Banco Santander (Brasil) S.A.";
                        break;
                    case 250:
                        strBanco = "Banco Schahin S.A.";
                        break;
                    case 743:
                        strBanco = "Banco Semear S.A.";
                        break;
                    case 749:
                        strBanco = "Banco Simples S.A.";
                        break;
                    case 366:
                        strBanco = "Banco Soci�t� G�n�rale Brasil S.A.";
                        break;
                    case 637:
                        strBanco = "Banco Sofisa S.A.";
                        break;
                    case 12:
                        strBanco = "Banco Standard de Investimentos S.A.";
                        break;
                    case 464:
                        strBanco = "Banco Sumitomo Mitsui Brasileiro S.A.";
                        break;
                    case 634:
                        strBanco = "Banco Tri�ngulo S.A.";
                        break;
                    case 655:
                        strBanco = "Banco Votorantim S.A.";
                        break;
                    case 610:
                        strBanco = "Banco VR S.A.";
                        break;
                    case 370:
                        strBanco = "Banco WestLB do Brasil S.A.";
                        break;
                    case 21:
                        strBanco = "BANESTES S.A. Banco do Estado do Esp�rito Santo";
                        break;
                    case 719:
                        strBanco = "Banif-Banco Internacional do Funchal (Brasil)S.A.";
                        break;
                    case 755:
                        strBanco = "Bank of America Merrill Lynch Banco M�ltiplo S.A.";
                        break;
                    case 744:
                        strBanco = "BankBoston N.A.";
                        break;
                    case 73:
                        strBanco = "BB Banco Popular do Brasil S.A.";
                        break;
                    case 78:
                        strBanco = "BES Investimento do Brasil S.A.-Banco de Investimento";
                        break;
                    case 69:
                        strBanco = "BPN Brasil Banco M�ltiplo S.A.";
                        break;
                    case 70:
                        strBanco = "BRB - Banco de Bras�lia S.A.";
                        break;
                    case 104:
                        strBanco = "Caixa";
                        break; //Caixa Econ�mica Federal
                    case 477:
                        strBanco = "Citibank";
                        break;
                    case 487:
                        strBanco = "Deutsche Bank";
                        break;
                    case 751:
                        strBanco = "Dresdner Bank Brasil S.A. - Banco M�ltiplo";
                        break;
                    case 64:
                        strBanco = "Goldman Sachs do Brasil Banco M�ltiplo S.A.";
                        break;
                    case 62:
                        strBanco = "Hipercard Banco M�ltiplo S.A.";
                        break;
                    case 399:
                        strBanco = "HSBC Bank Brasil S.A. - Banco M�ltiplo";
                        break;
                    case 168:
                        strBanco = "HSBC Finance (Brasil) S.A. - Banco M�ltiplo";
                        break;
                    case 492:
                        strBanco = "ING Bank N.V.";
                        break;
                    case 652:
                        strBanco = "Ita� Unibanco Holding S.A.";
                        break;
                    case 341:
                        strBanco = "Ita�";
                        break; //Ita� Unibanco S.A.
                    case 79:
                        strBanco = "JBS Banco S.A.";
                        break;
                    case 488:
                        strBanco = "JPMorgan Chase Bank";
                        break;
                    case 14:
                        strBanco = "Natixis Brasil S.A. Banco M�ltiplo";
                        break;
                    case 753:
                        strBanco = "NBC Bank Brasil S.A. - Banco M�ltiplo";
                        break;
                    case 254:
                        strBanco = "Paran� Banco S.A.";
                        break;
                    case 409:
                        strBanco = "UNIBANCO - Uni�o de Bancos Brasileiros S.A.";
                        break;
                    case 230:
                        strBanco = "Unicard Banco M�ltiplo S.A.";
                        break;
                    case 84:
                        strBanco = "Unicred Norte do Paran�";
                        break;
                }

                return strBanco;
            }
            set { }
        }
    }
}