namespace Pan.Credito.Domain.Entidades.Helpers
{
    public enum MensagemItemTipoLista
    {
        Valores = 1,
        Listas = 2
    }
}