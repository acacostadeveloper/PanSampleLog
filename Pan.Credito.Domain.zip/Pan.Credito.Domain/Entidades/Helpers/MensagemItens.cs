using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pan.Credito.Domain.Entidades.Helpers
{
    public class MensagemItens : ICollection<MensagemItem>
    {
        private Dictionary<string, MensagemItem> m_dicItens = new Dictionary<string, MensagemItem>();
        public MensagemItens(MensagemItemTipoLista p_intTipoLista = MensagemItemTipoLista.Valores,String p_strCampoQtde = "")
        {
            this.CampoQtde = p_strCampoQtde;
            this.TipoLista = p_intTipoLista;

            if (MensagemItemTipoLista.Listas == p_intTipoLista)
            {
                this.ItensModelos = new Dictionary<String, MensagemItem>();
            }
        }
        public String CampoQtde { get; set; }
        public MensagemItem[] Itens { get { return this.m_dicItens.Values.ToArray(); } }
        public Dictionary<String, MensagemItem> ItensModelos { get; set; }
        public MensagemItemTipoLista TipoLista { get; set; }
        public String ValorTexto
        {
            get
            {
                StringBuilder objSB = new StringBuilder();

                // Recupera valores dos elementos filhos
                foreach (var objItem in this.m_dicItens.Values)
                {
                    objSB.Append(objItem.ValorTexto);
                }

                return objSB.ToString();
            }
        }
        public MensagemItem this[Int32 p_intIndice]
        {
            get
            {
                return m_dicItens[m_dicItens.Keys.ToArray()[p_intIndice]];
            }
            set
            {
                m_dicItens[m_dicItens.Keys.ToArray()[p_intIndice]] = value;
            }
        }
        public MensagemItem this[String p_strNome]
        {
            get
            {
                return m_dicItens[p_strNome];
            }
            set
            {
                m_dicItens[p_strNome] = value;
            }
        }
        public Int32 Count
        {
            get
            {
                return m_dicItens.Count;
            }
        }
        public Boolean IsReadOnly
        {
            get
            {
                return false;
            }
        }
        public void Add(MensagemItem p_objMensagemItem)
        {
            m_dicItens.Add(p_objMensagemItem.Nome, p_objMensagemItem);
            p_objMensagemItem.Parent = this;
        }
        public void Clear()
        {
            m_dicItens.Clear();
        }
        public Boolean Contains(MensagemItem p_objMensagemItem)
        {
            return m_dicItens.ContainsKey(p_objMensagemItem.Nome);
        }
        public void CopyTo(MensagemItem[] p_arrMensagensItens,Int32 p_intIndice)
        {
            foreach (MensagemItem objItem in m_dicItens.Values)
            {
                p_arrMensagensItens.SetValue(objItem, p_intIndice);
                p_intIndice++;
            }
        }
        public IEnumerator<MensagemItem> GetEnumerator()
        {
            return new MensagemItemEnumerator<MensagemItem>(this);
        }
        IEnumerator IEnumerable.GetEnumerator()
        {
            return new MensagemItemEnumerator<MensagemItem>(this);
        }
        public Boolean Remove(MensagemItem p_objMensagemItem)
        {
            return m_dicItens.Remove(p_objMensagemItem.Nome);
        }

    }
}