using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using RestSharp;

namespace Pan.Credito.Domain.Entidades.Helpers
{
    public class Mensagem
    {
        private MensagemItens m_colItensEnvio;
        private MensagemItens m_colItensRetorno;
        private String m_strRetorno;
        public Mensagem(String p_strPrograma, String p_strFuncao, params MensagemItem[] p_arrItens)
        {
            this.m_colItensEnvio = new MensagemItens();
            this.m_colItensRetorno = new MensagemItens();
            this.m_strRetorno = "";

            this.Codigo = "";
            this.EnderecoWeb = ConfigurationManager.AppSettings["Pansolution_COBOL_URL"];
            this.Funcao = p_strFuncao;
            this.Programa = p_strPrograma;
            this.ProgramaCaminho = ConfigurationManager.AppSettings["Pansolution_COBOL_Programa"];
            

            foreach (var objItem in p_arrItens)
            {
                this.ItensEnvio.Add(objItem);
            }
        }
        public String Chamada
        {
            get
            {
                return this.ItensEnvio.ValorTexto;
            }
        }
        public String Codigo { get; set; }
        public String EnderecoWeb { get; set; }
        public String ErroMensagem { get; set; }
        public Int32 ErroNumero { get; set; }
        public String Funcao { get; set; }
        public MensagemItens ItensEnvio { get { return m_colItensEnvio; } }
        public MensagemItens ItensRetorno { get { return m_colItensRetorno; } }
        public String Programa { get; set; }
        public String ProgramaCaminho { get; set; }
        public String Retorno
        {
            get
            {
                return m_strRetorno;
            }
        }
        public void AdicionarItensRetorno(params MensagemItem[] p_arrItens)
        {
            foreach (var objItem in p_arrItens)
            {
                this.ItensRetorno.Add(objItem);
            }
        }
        public void Executar()
        {
            var endPoint = string.Format("{0}?prog={1}{2}&parametro={3}", EnderecoWeb, ProgramaCaminho, Programa,Chamada);
            var client = new RestClient(endPoint);
            var request = new RestRequest(Method.GET);
            var response = client.Execute(request);
            if (response.ResponseStatus == ResponseStatus.Error) throw new Exception(string.Format("ERRO NO RETORNO PANSOLUTION [{0}]", response.ErrorMessage));
            m_strRetorno = response.Content;
            PreencherRetorno();
        }
        private void PreencherRetorno()
        {
            var intA = 0;
          //  if (Retorno.Length<=8) throw new Exception(string.Format("ERRO NO RETORNO PANSOLUTION [{0}]", Retorno));
          
            if (!Regex.IsMatch(Retorno.Substring(3, 5), @"\d"))
            {
                ErroNumero = 1;
                ErroMensagem = Retorno.Substring(3, Retorno.Length - 3).Trim('\r', '\n');
                return;
            }
            
            ErroNumero = Convert.ToInt32(Retorno.Substring(3, 5));
            if (0 != ErroNumero)
            {
                ErroMensagem = Retorno.Substring(8, Retorno.Length - 8).Trim('\r', '\n');
                return;
            }

            foreach (var objItem in ItensRetorno)
            {
                PreencherValorRetorno(objItem, ref intA);
            }
        }
        private void PreencherValorRetorno(MensagemItem p_objMensagemItem, ref Int32 p_intPosicao)
        {
            if (p_objMensagemItem.TipoDado != MensagemItemTipoDado.Lista)
            {
                p_objMensagemItem.ValorTexto = m_strRetorno.Substring(p_intPosicao, p_objMensagemItem.Tamanho);
                p_intPosicao += p_objMensagemItem.Tamanho;
            }
            else
            {
                if (MensagemItemTipoLista.Valores == p_objMensagemItem.Itens.TipoLista)
                {
                    foreach (var objItem2 in p_objMensagemItem.Itens)
                    {
                        objItem2.ValorTexto = m_strRetorno.Substring(p_intPosicao, objItem2.Tamanho);
                        p_intPosicao += objItem2.Tamanho;
                    }
                }
                else
                {
                    var  intB = Convert.ToInt32(p_objMensagemItem.Parent[p_objMensagemItem.Itens.CampoQtde].Valor);

                    for (var intC = 1; intC <= intB; intC++)
                    {
                        var objMsgItem = new MensagemItem("_ListaItem" + intC, MensagemItemTipoLista.Valores, "");

                        foreach (var objItem2 in p_objMensagemItem.Itens.ItensModelos.Values)
                        {
                            if (objItem2.TipoDado != MensagemItemTipoDado.Lista)
                            {
                                objMsgItem.Itens.Add(new MensagemItem(objItem2.Nome,
                                    objItem2.Tamanho,
                                    objItem2.TipoDado,
                                    this.m_strRetorno.Substring(p_intPosicao, objItem2.Tamanho),
                                    objItem2.Decimais,
                                    objItem2.FormatoData));
                                p_intPosicao += objItem2.Tamanho;
                            }
                            else
                            {
                                var objMsgItem2 = new MensagemItem(objItem2.Nome,
                                    objItem2.Itens.TipoLista,
                                    objItem2.Itens.CampoQtde,
                                    objItem2.Itens.ItensModelos.Values.ToArray());
                                objMsgItem.Itens.Add(objMsgItem2);
                                PreencherValorRetorno(objMsgItem2, ref p_intPosicao);
                            }
                        }
                        p_objMensagemItem.Itens.Add(objMsgItem);
                    }
                }
            }
        }
        public static Mensagem CriarMensagem(String p_strPrograma, String p_strFuncao, params KeyValuePair<String, String>[] p_arrParametros)
        {
            Mensagem objMensagem = null;

            switch (p_strPrograma.ToLower())
            {
                case "isisf001":
                case "isisff01":
                    switch (p_strFuncao.ToUpper())
                    {
                        case "UF1":
                            objMensagem = CriarMensagem_isisfa01_UF1();
                            break;
                    }
                    break;
                case "isisf009":
                case "isisf040":
                case "isisf005":
                case "isisf003":
                case "isisf006":
                    break;
                case "isisfa08":
                    switch (p_strFuncao.ToUpper())
                    {
                        case "U18":
                            objMensagem = CriarMensagem_isisfa08_U18();
                            break;
                    }
                    break;


                case "aate300a":

                    switch (p_strFuncao.ToUpper())
                    {
                        case "U30":
                            objMensagem = CriarMensagem_aate300a_U30();
                            break;
                    }
                    break;


                case "aate300b":
                    switch (p_strFuncao.ToUpper())
                    {
                        case "30B":
                            objMensagem = CriarMensagem_aate300b_30B();
                            break;
                    }
                    break;



                case "aate30bb":
                    switch (p_strFuncao.ToUpper())
                    {
                        case "3BB":
                            objMensagem = CriarMensagem_aate30bb_3BB();
                            break;
                    }
                    break;

                case "aate300d":
                    switch (p_strFuncao.ToUpper())
                    {
                        case "30F":
                            objMensagem = CriarMensagem_aate300d_30F();
                            break;
                    }
                    break;
                case "isisfpes":
                    switch (p_strFuncao.ToUpper())
                    {
                        case "UPE":
                            objMensagem = CriarMensagem_isisfpes_UPE();
                            break;
                    }
                    break;
            }

            // Verifica se a mensagem solicitada foi criada
            if (null == objMensagem)
                throw new NotImplementedException();

            // Preenche par�metros

            // Par�metros da mensagem (espec�fico para cada mensagem)
            foreach (var objValor in p_arrParametros)
            {
                objMensagem.ItensEnvio[objValor.Key].ValorTexto = objValor.Value;
            }

            // Par�metros de configura��o (comum para todas as mensagens)
            objMensagem.ItensEnvio["USUARIO DO BANCO DE DADOS"].ValorTexto = ConfigurationManager.AppSettings["Pansolution_COBOL_BD_Usuario"];
            objMensagem.ItensEnvio["SENHA DO BANCO DE DADOS"].ValorTexto = ConfigurationManager.AppSettings["Pansolution_COBOL_BD_Senha"];
            objMensagem.ItensEnvio["NOME DO BANCO DE DADOS"].ValorTexto = ConfigurationManager.AppSettings["Pansolution_COBOL_BD_Nome"];
            objMensagem.ItensEnvio["TIPO DO BANCO DE DADOS"].ValorTexto = ConfigurationManager.AppSettings["Pansolution_COBOL_BD_Tipo"];

            return objMensagem;
        }
        private static Mensagem CriarMensagem_aate300a_U30()
        {
            Mensagem objMsg = new Mensagem("aate300a",
                "U30",
                new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto, "U30"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("NUMERO DO CLIENTE NA SYSIN", 3, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("CODIGO DO USUARIO", 15, MensagemItemTipoDado.Texto, ConfigurationManager.AppSettings["Pansolution_COBOL_Usuario"]),
                new MensagemItem("SISTEMA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("TIPO DA PASTA", 1, MensagemItemTipoDado.Texto, "A"),
                new MensagemItem("CODIGO CONTRATO INTERNO", 13, MensagemItemTipoDado.Inteiro, "0"),
                new MensagemItem("DATA DA AMORTIZACAO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("DATA DO PAGAMENTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("CODIGO DA LOJA", 5, MensagemItemTipoDado.Inteiro),
                new MensagemItem("CODIGO DO PRODUTO", 4, MensagemItemTipoDado.Texto),
                new MensagemItem("TIPO DA PESSOA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("VALOR DA MOEDA INFORMADO", 12, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("FLAG SE LIQUIDACAO ANTEC. FINAME", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("DATA DA DECOMPOSICAO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("FLAG SIMULACAO", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("VALOR DA PARCELA RECEBIDA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TAXA DA MORA", 12, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TIPO DA TAXA MORA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("PERIODICIDADE DA TAXA MORA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("PERCENTUAL DA MULTA", 5, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("BASE MULTA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("TAXA DE CP", 12, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TIPO DA TAXA CP", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("PERIODICIDADE DA TAXA CP", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("QTDE PARCELAS RENEGOCIACAO", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("DATA DA PRIMEIRA PARCELA", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("CODIGO DA COBRADORA", 12, MensagemItemTipoDado.Inteiro),
                new MensagemItem("PERCENTUAL DA DESCONTO INFORMADO", 5, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("CODIGO TABELA DE MORA", 5, MensagemItemTipoDado.Inteiro),
                new MensagemItem("DT PARCELA MAIS ANTIGA EM ABERTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"));

            objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DO ERRO", 5, MensagemItemTipoDado.Inteiro),
                new MensagemItem("VALOR DA DESPESA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR DA TARIFA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("DIAS SISTEMA E ULTIMA PARCELA REN", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("PERCENTUAL DOS HONORARIOS", 5, MensagemItemTipoDado.Decimal, "", 3), /*   TRES DECIMAIS*/
                new MensagemItem("BASE DO HONORARIO", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("QUANTIDADE DE PARCELAS", 3, MensagemItemTipoDado.Inteiro),

                new MensagemItem("PARCELAS", MensagemItemTipoLista.Listas, "QUANTIDADE DE PARCELAS",
                    new MensagemItem("DATA DA AMORTIZACAO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"), /*  AAAAMMDD  ***/
                    new MensagemItem("FLAG PARCELA FAZ PARTE DA RENEG.", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("VALOR DA PARCELA", 15, MensagemItemTipoDado.Decimal, "", 2), /* Valor da Parcela*/
                    new MensagemItem("VALOR DA PARCELA NA CURVA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DA MORA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DA COMISSAO DE PERMANENCIA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DA MULTA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("TAXA DA MORA", 12, MensagemItemTipoDado.Decimal, "", 6), /* SEIS DECIMAIS */
                    new MensagemItem("TIPO DA TAXA MORA", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("PERIODICIDADE DA TAXA MORA", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("PERCENTUAL DA MULTA", 5, MensagemItemTipoDado.Decimal, "", 3), /* TRES DECIMAIS*/
                    new MensagemItem("BASE MULTA", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("TAXA DE CP", 12, MensagemItemTipoDado.Decimal, "", 6), /* SEIS DECIMAIS */
                    new MensagemItem("TIPO DA TAXA CP", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("PERIODICIDADE DA TAXA CP", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("VALOR DO DESCONTO SOBRE MORA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DO DESCONTO SOBRE CP", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DO DESCONTO SOBRE MULTA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DO DESCONTO SOBRE PARCELA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("QUANTIDADE DE DIAS EM ATRASO", 5, MensagemItemTipoDado.Inteiro),    /* ZEROS */
                    new MensagemItem("FLAG LIQUIDADO", 1, MensagemItemTipoDado.Texto),      /* Se tipo de liquida��o for bloqueto vir� 'T' no campo. Se tipo de liquida��o for mista vir� 'T' somente na parcela que for bloqueto. A tarifa s� incidir� sobre as parcelas que tiverem 'T' no flag liquidado*/
                    new MensagemItem("NUMERO DA PARCELA", 3, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("VALOR DOS HONORARIOS", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR DA COMISSAO", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("Flag teve Estorno", 1, MensagemItemTipoDado.Texto)),    /* S/N�����*** */

                new MensagemItem("FLAG APROVA AUTOM�TICO", 1, MensagemItemTipoDado.Texto),�        /* S/N�����*/
                new MensagemItem("DATA LIMITE PARA 1� VENCIMENTO", 8, MensagemItemTipoDado.Inteiro),�      /* ************** */
                new MensagemItem("PERCENTUAL DA COMISSAO", 5, MensagemItemTipoDado.Decimal, "", 3),    /* TRES DECIMAIS */
                new MensagemItem("BASE DA COMISSAO", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("MAIOR PARCELA COM APROV AUTOM", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("VALOR DESPESA NOTIFICACAO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR DESPESA TELEFONIA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR DESPESA DEP.IDENTIFICADO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("PERCENTUAL DE DESCONTO DE TIR", 5, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("Espacos", 51, MensagemItemTipoDado.Texto),
                new MensagemItem("Tipo Liquida��o", 1, MensagemItemTipoDado.Texto),         /* B=Boleto; C=Cheque; M ou A=Mista; D= Debito em Cta*/
                new MensagemItem("Flag cedido sem coobrigacao", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("Banco Cedido", 30, MensagemItemTipoDado.Texto),         /* somente se o flag cedido = 'S'*/
                new MensagemItem("Espa�os", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("Compensa��o", 3, MensagemItemTipoDado.Texto),         /* somente se o tipo de liquida��o = 'D'*/
                new MensagemItem("Banco", 3, MensagemItemTipoDado.Texto),         /* somente se o tipo de liquida��o = 'D'*/
                new MensagemItem("Agencia", 5, MensagemItemTipoDado.Texto),         /* somente se o tipo de liquida��o = 'D'*/
                new MensagemItem("Digito Agencia", 1, MensagemItemTipoDado.Texto),         /* somente se o tipo de liquida��o = 'D'*/
                new MensagemItem("Cta Corrente", 10, MensagemItemTipoDado.Texto),         /* somente se o tipo de liquida��o = 'D'*/
                new MensagemItem("Digito Cta Corrente", 2, MensagemItemTipoDado.Texto));        /* somente se o tipo de liquida��o = 'D'*/

            return objMsg;
        }
        private static Mensagem CriarMensagem_aate300b_30B()
        {
            Mensagem objMsg = new Mensagem("aate300b",
                "30B",
                new MensagemItem("CD_FUNCAO", 3, MensagemItemTipoDado.Texto, "30B"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto, "I"),
                new MensagemItem("NUMERO DO CLIENTE NA SYSIN", 3, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("CD_OPERADOR", 15, MensagemItemTipoDado.Texto, ConfigurationManager.AppSettings["Pansolution_COBOL_Usuario"]),
                new MensagemItem("CODIGO CONTRATO INTERNO", 12, MensagemItemTipoDado.Inteiro),
                new MensagemItem("VALOR_MOEDA", 12, MensagemItemTipoDado.Decimal, "1000000", 2),
                new MensagemItem("TIPO_LIQUIDACAO", 1, MensagemItemTipoDado.Texto, "B"),
                new MensagemItem("VALOR TOTAL DO SALDO DE PARCELAS", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL DA MORA", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL DA COMIS.PERM.", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL DA MULTA", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL DAS DESPESAS", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL HONOR�RIO", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL DESCONTO ANTECIPADO", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("VALOR TOTAL DESCONTO CONCEDIDO", 15, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("TAXA CP - RENEGOCIA��O", 12, MensagemItemTipoDado.Decimal, "100", 2),
                new MensagemItem("FORA DE ALCADA", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("QTDE. PARCELAS DA RENEGOCIA��O", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("PARCELAS1", MensagemItemTipoLista.Listas, "QTDE. PARCELAS DA RENEGOCIA��O",
                    new MensagemItem("DATA VENCIMENTO DO RENEGOCIA��O", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("VALOR PRINCIPAL", 15, MensagemItemTipoDado.Decimal, "1000", 2),
                    new MensagemItem("VALOR_CP", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("CODIGO CMC7", 30, MensagemItemTipoDado.Texto, "")),

                new MensagemItem("QTDE. PARCELAS RENEGOCIADAS", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("PARCELAS2", MensagemItemTipoLista.Listas, "QTDE. PARCELAS RENEGOCIADAS",
                    new MensagemItem("DATA AMORTIZA��O", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("SALDO", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("ENCARGOS", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("DESCONTOS", 15, MensagemItemTipoDado.Decimal, "", 2)),

                new MensagemItem("DATA FINAL DE REFINANCIAMENTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("VALOR DESCONTO MAXIMO PERMITIDO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR COMISSAO ASSESSORIA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR NO ATO PARA O CONTRATO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("CMC7 DO VALOR NO ATO", 30, MensagemItemTipoDado.Texto),
                new MensagemItem("DATA PAGAMENTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("QTD. MAX.PARCELAMENTO", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("IMPRESSAO DE BLOQUETO", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("COD_CUSTODIANTE", 12, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("COD_BANCO", 3, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("� MULTI RENEGOCIA��O", 27, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("PERCENTUAL DE DESC.ANTECIPADO", 6, MensagemItemTipoDado.Decimal, "", 3),
                new MensagemItem("Codigo de Campanha", 8, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("Tarifa de Liquida��o Antecipada", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("Numero Dep�sito Identificado", 16, MensagemItemTipoDado.Texto, ""),   // S� da primeira parcela
                new MensagemItem("Flag se � campanha", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("C�digo do supervisor liberou desconto", 15, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("VALOR MAX.DESC.PRINCIPAL PERMITIDO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR DESCONTO DE PRINCIPAL", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TIPO DE ENTRADA", 1, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("JUDICIAL", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("Flag se v�m do cgreneg ou da tela", 1, MensagemItemTipoDado.Texto, ""));    // 'C':CGRENEG; ' ':Tela


            objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DO ERRO", 5, MensagemItemTipoDado.Texto),
                new MensagemItem("DESCRI��O DO ERRO", 100, MensagemItemTipoDado.Texto),
                new MensagemItem("Sequencia Capa Multi Renegocia��o", 8, MensagemItemTipoDado.Texto),
                new MensagemItem("Qtd.Bloquetos Mult.Reneg.", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("BOLETOS", MensagemItemTipoLista.Listas, "Qtd.Bloquetos Mult.Reneg.",
                    new MensagemItem("C�DIGO BOLETO", 15, MensagemItemTipoDado.Texto, "")));
            return objMsg;
        }
        private static Mensagem CriarMensagem_aate300d_30F()
        {
            Mensagem objMsg = new Mensagem("aate300d",
                "30F",
                new MensagemItem("CD_FUNCAO", 3, MensagemItemTipoDado.Texto, "30F"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("NUMERO DO CLIENTE NA SYSIN", 3, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("CODIGO CONTRATO INTERNO", 12, MensagemItemTipoDado.Inteiro),
                new MensagemItem("TIPO_ACORDO", 1, MensagemItemTipoDado.Texto, "A"),
                new MensagemItem("SITUACAO DA GRAVACAO", 1, MensagemItemTipoDado.Texto, "E"),
                new MensagemItem("TIPO DE LIQUIDACAO", 1, MensagemItemTipoDado.Texto, "B"),
                new MensagemItem("QUANTIDADE DE PARCELAS", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("PARCELAS", MensagemItemTipoLista.Listas, "QUANTIDADE DE PARCELAS",
                    new MensagemItem("DATA DO VENCIMENTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("CD_CMC7", 30, MensagemItemTipoDado.Texto)),
                new MensagemItem("MENSAGEM", 500, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("CD_OPERADOR", 15, MensagemItemTipoDado.Texto, ConfigurationManager.AppSettings["Pansolution_COBOL_Usuario"]));

            //objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO",             3, MensagemItemTipoDado.Texto),
            //                             new MensagemItem("CODIGO DO ERRO",               5, MensagemItemTipoDado.Texto),
            //                             new MensagemItem("RETORNO",                     10, MensagemItemTipoDado.Texto),
            //                             new MensagemItem("DESCRICAO",                   10, MensagemItemTipoDado.Texto));
            return objMsg;
        }
        private static Mensagem CriarMensagem_aate30bb_3BB()
        {
            Mensagem objMsg = new Mensagem("aate30bb",
                "3BB",
                new MensagemItem("CD_FUNCAO", 3, MensagemItemTipoDado.Texto, "3BB"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("NUMERO DO CLIENTE NA SYSIN", 3, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("CD_OPERADOR", 15, MensagemItemTipoDado.Texto, ConfigurationManager.AppSettings["Pansolution_COBOL_Usuario"]),
                new MensagemItem("CODIGO CONTRATO INTERNO", 13, MensagemItemTipoDado.Inteiro),
                new MensagemItem("VALOR_MOEDA", 12, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TIPO_LIQUIDACAO", 1, MensagemItemTipoDado.Texto, "B"),
                new MensagemItem("VALOR_HONORARIOS", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR_DESPESAS", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TIPO_ACORDO", 1, MensagemItemTipoDado.Texto, "B"),
                new MensagemItem("JUDICIAL_ACORDO", 1, MensagemItemTipoDado.Inteiro, "0"),
                new MensagemItem("DATA_PAGAMENTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("DATA_VENCIMENTO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("DATA_VENCIMENTO2", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("DATA_VENCIMENTO3", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                new MensagemItem("NUMERO_DEPOSITO_IDENTIFICADO", 16, MensagemItemTipoDado.Inteiro),
                new MensagemItem("FORA_ALCADA", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("CD_CMC7", 30, MensagemItemTipoDado.Texto),
                new MensagemItem("E_CAIXA", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("E_RENEGOCIACAO", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("VALOR_DESCONTO_MAXIMO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR_RECEBIDO_NO_CAIXA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR_COMISSAO_ASSESSORIA", 15, MensagemItemTipoDado.Decimal, "0", 2),
                new MensagemItem("QUANTIDADE DE PARCELAS", 3, MensagemItemTipoDado.Inteiro),

                new MensagemItem("PARCELAS", MensagemItemTipoLista.Listas, "QUANTIDADE DE PARCELAS",
                    new MensagemItem("DATA_AMORTIZACAO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("SALDO_DA_PARCELA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR_CP", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR_MORA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR_MULTA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR_TARIFA", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR_DESCONTO_ANTECIPADO", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("VALOR_DESCONTO_CONCEDIDO", 15, MensagemItemTipoDado.Decimal, "", 2)),

                new MensagemItem("CD_DO_BANCO", 3, MensagemItemTipoDado.Inteiro, ""),
                new MensagemItem("TIPO_EMISSAO", 1, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("E_MULTI_ACORDO", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("CD_BLOQUETO", 15, MensagemItemTipoDado.Texto),
                new MensagemItem("SEQUENCIA_CAPA_MULTI_ACORDO", 8, MensagemItemTipoDado.Inteiro),
                new MensagemItem("VALOR_DE_RESTITUICAO_DE_SEGURO", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TARIFA_DE_LIQUIDACAO_ANTECIPADA", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("PERCENTUAL_DE_DESC_ANTECIPADO", 6, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("CD_SUPERVISOR_LIBEROU_DESCONTO", 15, MensagemItemTipoDado.Texto),
                new MensagemItem("VERBAS_RESCISORIAS", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("VALOR_MAXIMO_DESC_PRINCIPAL", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("VALOR_DESCONTO_DE_PRINCIPAL", 15, MensagemItemTipoDado.Decimal, "", 2),
                new MensagemItem("TEM_TARIFA_DE_TROCA_DE_CHEQUE", 1, MensagemItemTipoDado.Texto, "N"),
                new MensagemItem("ORIGEM_DO_ACORDO_CONSIGNADO", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("IMPRIME_BOLETO", 1, MensagemItemTipoDado.Texto));

            objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DO ERRO", 5, MensagemItemTipoDado.Texto),
                new MensagemItem("SEQUENCIA_DE_AUTENTICACAO", 8, MensagemItemTipoDado.Texto),
                new MensagemItem("CD_EMPRESA", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CD_INDEXADOR", 4, MensagemItemTipoDado.Texto),
                new MensagemItem("CD_BANCO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CD_CARTEIRA", 4, MensagemItemTipoDado.Texto),
                new MensagemItem("CD_AGENCIA", 5, MensagemItemTipoDado.Texto),
                new MensagemItem("DG_AGENCIA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("CD_CONTA", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("DG_CONTA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("DATA_AMORTIZACAO", 8, MensagemItemTipoDado.Texto),
                new MensagemItem("DATA_PAGAMENTO", 8, MensagemItemTipoDado.Texto),
                new MensagemItem("NOSSO_NUMERO", 15, MensagemItemTipoDado.Texto),
                new MensagemItem("VALOR_ACORDO", 15, MensagemItemTipoDado.Texto));
            return objMsg;
        }
        private static Mensagem CriarMensagem_isisfa01_UF1()
        {
            Mensagem objMsg = new Mensagem("isisff01",
                "UF1",
                new MensagemItem("CD_FUNCAO", 3, MensagemItemTipoDado.Texto, "UF1"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("NUMERO DO CLIENTE NA SYSIN", 3, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("BRANCO01", 15, MensagemItemTipoDado.Texto),
                new MensagemItem("ZERO01", 2, MensagemItemTipoDado.Inteiro),
                new MensagemItem("BRANCO02", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("ZERO02", 2, MensagemItemTipoDado.Inteiro),
                new MensagemItem("BRANCO03", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("ZERO03", 10, MensagemItemTipoDado.Inteiro),
                new MensagemItem("FN", 2, MensagemItemTipoDado.Texto, "FN"),
                new MensagemItem("DOCUMENTO", 15, MensagemItemTipoDado.Inteiro),
                new MensagemItem("BRANCO04", 34, MensagemItemTipoDado.Texto),
                new MensagemItem("TIPO PESSOA", 1, MensagemItemTipoDado.Texto, "F"));

            objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DO ERRO", 5, MensagemItemTipoDado.Inteiro),
                new MensagemItem("QUANTIDADE DE CONTRATOS", 5, MensagemItemTipoDado.Inteiro),
                new MensagemItem("CONTRATOS", MensagemItemTipoLista.Listas, "QUANTIDADE DE CONTRATOS",
                    new MensagemItem("CONTRATO", 12, MensagemItemTipoDado.Texto),
                    new MensagemItem("NUMERO TRANSACAO", 7, MensagemItemTipoDado.Texto),
                    new MensagemItem("CODIGO LOJA", 5, MensagemItemTipoDado.Texto),
                    new MensagemItem("TIPO CONTRATO", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("TIPO_SIT_CONTRATO", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("CLIENTE NOME", 60, MensagemItemTipoDado.Texto),
                    new MensagemItem("DOCUMENTO", 15, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("CODIGO LOJA PARAM", 5, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("PRODUTO", 4, MensagemItemTipoDado.Texto),
                    new MensagemItem("REGIONAL", 5, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("CATEGORIA CLIENTE", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("LOJA NOME", 35, MensagemItemTipoDado.Texto),
                    new MensagemItem("FLAG INTEGRAR", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("GERENCIA", 8, MensagemItemTipoDado.Texto),
                    new MensagemItem("AREA DE RESPONSABILIDADE", 8, MensagemItemTipoDado.Texto),
                    new MensagemItem("DDD", 4, MensagemItemTipoDado.Texto),
                    new MensagemItem("TELEFONE", 10, MensagemItemTipoDado.Texto),
                    new MensagemItem("RAMAL", 4, MensagemItemTipoDado.Texto),
                    new MensagemItem("NOME DA REGIONAL", 35, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA DO AGENDAMENTO", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("VALOR DO PRINCIPAL", 12, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA DO PRIMEIRO VENCIMENTO", 8, MensagemItemTipoDado.Texto),
                    new MensagemItem("QUANTIDADE DE PRESTACOES", 3, MensagemItemTipoDado.Texto),
                    new MensagemItem("CODIGO DA TABELA DE JUROS", 8, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA INICIO ATENDIMENTO", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA FIM ATENDIMENTO", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA INICIO ANALISE", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA FIM ANALISE", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA ANALISE PENDENTE", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA E HORA DO FAX", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("FLAG PRE PROPOSTA", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("PERCENTUAL FINANCIADO", 5, MensagemItemTipoDado.Texto),
                    new MensagemItem("TIPO APROV CRED", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("FLAG PRE ANALISE", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Flag Validacao", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Tipo Liquidacao", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Tipo Base Repasse", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Flag Agendamento", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Data e Hora de Rean�lise", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("Data e Hora de In�cio de Rean�lise", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("Data e Hora de Fim de Rean�lise", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("Data e Hora de Pendente de Rean�lise", 14, MensagemItemTipoDado.Texto),
                    new MensagemItem("Flag Se Tem Documentos Pendentes", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Tipo de Opera��o", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("Flag valida manual", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("CODIGO DO USUARIO AUTORIZADOR", 15, MensagemItemTipoDado.Texto),
                    new MensagemItem("Brancos", 109, MensagemItemTipoDado.Texto)));

            return objMsg;
        }
        private static Mensagem CriarMensagem_isisfa08_U18()
        {
            Mensagem objMsg = new Mensagem("isisfa08",
                "U18",
                new MensagemItem("CD_FUNCAO", 3, MensagemItemTipoDado.Texto, "30F"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("NUMERO DO CLIENTE NA SYSIN", 3, MensagemItemTipoDado.Inteiro, "2"),
                new MensagemItem("CODIGO DO CLIENTE", 12, MensagemItemTipoDado.Inteiro),
                new MensagemItem("CODIGO DO CONTRATO", 12, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DA COBRADORA", 12, MensagemItemTipoDado.Inteiro));

            objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DO ERRO", 5, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO CLIENTE", 60, MensagemItemTipoDado.Texto),
                new MensagemItem("CPF DO CLIENTE", 14, MensagemItemTipoDado.Inteiro),
                new MensagemItem("TIPO DA PESSOA", 1, MensagemItemTipoDado.Texto),
                new MensagemItem("QUANTIDADE DE CONTRATOS", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("CONTRATOS", MensagemItemTipoLista.Listas, "QUANTIDADE DE CONTRATOS",
                    new MensagemItem("CODIGO DO CONTRATO", 12, MensagemItemTipoDado.Texto),
                    new MensagemItem("CODIGO DO CONTRATO INTERNO", 12, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("CODIGO DO CLIENTE", 12, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("CODIGO DO PRODUTO", 4, MensagemItemTipoDado.Texto),
                    new MensagemItem("CODIGO DA LOJA", 5, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("DATA DA LIBERACAO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("DATA DO VENCIMENTO DO CONTRATO", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("VALOR DO SALDO", 15, MensagemItemTipoDado.Decimal, "", 2),
                    new MensagemItem("TIPO DE LIQUIDACAO", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("CODIGO DO INDEXADOR DO CONTRATO", 4, MensagemItemTipoDado.Texto),
                    new MensagemItem("TIPO DO INDEXADOR DO CONTRATO", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("QUANTIDADE DE PARCELAS TOTAL", 3, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("QUANTIDADE DE PARCELAS EM ABERTO", 3, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("DESCRICAO DA EMPRESA", 30, MensagemItemTipoDado.Texto),
                    new MensagemItem("SITUACAO DO CONTRATO", 20, MensagemItemTipoDado.Texto),
                    new MensagemItem("SITUACAO EM ACORDO/RENEGOCIACAO", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("SITUACAO DO ACORDO/RENEGOCIACAO", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("DATA VALIDADE ACORDO/RENEG.", 8, MensagemItemTipoDado.Data, "", 0, "yyyyMMdd"),
                    new MensagemItem("CODIGO DA COBRADORA", 15, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("QUANTIDADE DE GARANTIAS DE VEICULOS", 3, MensagemItemTipoDado.Inteiro),
                    new MensagemItem("GARANTIAS", MensagemItemTipoLista.Listas, "QUANTIDADE DE GARANTIAS DE VEICULOS",
                        new MensagemItem("Descri��o Marca / Modelo", 60, MensagemItemTipoDado.Texto),
                        new MensagemItem("Cor", 35, MensagemItemTipoDado.Texto),
                        new MensagemItem("Combustivel", 1, MensagemItemTipoDado.Texto),
                        new MensagemItem("Ano Fabrica��o", 4, MensagemItemTipoDado.Inteiro),
                        new MensagemItem("Ano Modelo", 4, MensagemItemTipoDado.Inteiro),
                        new MensagemItem("Placa", 7, MensagemItemTipoDado.Texto),
                        new MensagemItem("Chassis", 60, MensagemItemTipoDado.Texto),
                        new MensagemItem("Renavan", 10, MensagemItemTipoDado.Inteiro))));
            return objMsg;
        }
        private static Mensagem CriarMensagem_isisfpes_UPE()
        {
            Mensagem objMsg = new Mensagem("isisfpes",
                "UPE",
                new MensagemItem("CD_FUNCAO", 3, MensagemItemTipoDado.Texto, "UPE"),
                new MensagemItem("USUARIO DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("SENHA DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto),
                new MensagemItem("NOME DO BANCO DE DADOS", 10, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("TIPO DO BANCO DE DADOS", 1, MensagemItemTipoDado.Texto, ""),
                new MensagemItem("CODIGO1", 3, MensagemItemTipoDado.Inteiro),
                new MensagemItem("CODIGO2", 2, MensagemItemTipoDado.Texto),
                new MensagemItem("DOCUMENTO", 15, MensagemItemTipoDado.Inteiro),
                new MensagemItem("OPCAO", 1, MensagemItemTipoDado.Inteiro));

            objMsg.AdicionarItensRetorno(new MensagemItem("CODIGO DA FUNCAO", 3, MensagemItemTipoDado.Texto),
                new MensagemItem("CODIGO DO ERRO", 5, MensagemItemTipoDado.Texto),
                new MensagemItem("NADA", 12, MensagemItemTipoDado.Texto),
                new MensagemItem("CONTRATOS", 2, MensagemItemTipoDado.Texto),
                new MensagemItem("CONTRATO", MensagemItemTipoLista.Listas, "CONTRATOS",
                    new MensagemItem("COD_CONTRATO", 12, MensagemItemTipoDado.Texto),
                    new MensagemItem("FLAG_ASSESSORIA", 1, MensagemItemTipoDado.Texto),
                    new MensagemItem("VAL_QUITACAO_D0", 8, MensagemItemTipoDado.Texto),
                    new MensagemItem("VAL_QUITACAO_D1", 8, MensagemItemTipoDado.Texto),
                    new MensagemItem("STRING_CYBER", 60, MensagemItemTipoDado.Texto),
                    new MensagemItem("BRANCO", 16, MensagemItemTipoDado.Texto)));

            return objMsg;
        }
    }
}