﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace Pan.Credito.Domain.Entidades.Helpers
{
    [Serializable]
    public class Logguer
    {
        [JsonIgnore]
        public int LogId { get; set; }
        public Guid CorrelationId { get; set; }
        public string Application { get; set; }           
        public string User { get; set; }                 
        public string Machine { get; set; }           
        public string IpAddress { get; set; }     
        public dynamic RequestBody { get; set; }   
        public string RequestUri { get; set; }     
        public string RequestMethod { get; set; }    
        public int? ResponseStatusCode { get; set; }  
        public IDictionary<string, string> RequestHeaders { get; set; } 
        public IDictionary<string, string> ResponseHeaders { get; set; } 
        public dynamic ResponseContentBody { get; set; }    
        public DateTime? RequestTimestamp { get; set; }
        public DateTime? ResponseTimestamp { get; set; }
        public string TotalTime
        {
            get
            {
                if (ResponseTimestamp == null || RequestTimestamp == null) return null;
                var interval = ResponseTimestamp.Value.Subtract(RequestTimestamp.Value);
                return string.Format("{0:c}", interval);
            }
            set
            {
                throw new NotImplementedException(); 
            }
        }
        public dynamic HttpError { get; set; } 
    }
}