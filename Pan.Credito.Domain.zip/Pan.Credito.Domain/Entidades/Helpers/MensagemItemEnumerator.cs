using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Pan.Credito.Domain.Entidades.Helpers
{
    public class MensagemItemEnumerator<T> : IEnumerator<T> where T : MensagemItem
    {

        protected MensagemItens m_colItens;
        protected Int32 m_intIndice;
        protected MensagemItem m_objItemAtual;
        public MensagemItemEnumerator()
        {
        }
        public MensagemItemEnumerator(MensagemItens collection)
        {
            m_colItens = collection;
            m_intIndice = -1;
            m_objItemAtual = null;
        }
        public T Current
        {
            get
            {
                return (T)m_objItemAtual;
            }
        }
        Object IEnumerator.Current
        {
            get
            {
                return m_objItemAtual;
            }
        }
        public void Dispose()
        {
            m_colItens = null;
            m_objItemAtual = null;
            m_intIndice = -1;
        }
        public bool MoveNext()
        {
            // Verifica se n�o ultrapassou o limite da lista
            if (++m_intIndice >= m_colItens.Count())
            {
                return false;
            }

            //Define o objeto atual
            m_objItemAtual = m_colItens[m_intIndice];
            return true;
        }
        public void Reset()
        {
            m_objItemAtual = null;
            m_intIndice = -1;
        }
    }
}