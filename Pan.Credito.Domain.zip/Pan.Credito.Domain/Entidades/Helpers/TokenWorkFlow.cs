﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Credito.Domain.Entidades.Helpers
{
    [Table("TOKEN_WORK_FLOW")]
    public class TokenWorkFlow
    {
        public int Id { get; set; }
        public DateTime Data { get; set; }
        public string Documento { get; set; }
        public int DDD { get; set; }
        public int Celular { get; set; }
        public string Code { get; set; }
        public bool Validado { get; set; }
        public string Channel { get; set; }
        public string Email { get; set; }
        public DateTime? DataValidado { get; set; }
    }
}