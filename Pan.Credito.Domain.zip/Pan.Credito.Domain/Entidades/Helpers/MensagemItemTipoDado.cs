namespace Pan.Credito.Domain.Entidades.Helpers
{
    public enum MensagemItemTipoDado
    {
        Texto = 1,
        Inteiro = 2,
        Decimal = 3,
        Data = 4,
        Lista = 5
    }
}