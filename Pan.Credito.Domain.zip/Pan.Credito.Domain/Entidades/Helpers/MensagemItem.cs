using System;

namespace Pan.Credito.Domain.Entidades.Helpers
{
    public class MensagemItem
    {
        private MensagemItens m_colItens = null;
        private String m_strValor = "";
        public MensagemItem(String p_strNome,Int32 p_intTamanho,MensagemItemTipoDado p_intTipoDado,String p_strValor = "",Int32 p_intDecimais = 0,String p_strFormatoData = "")
        {
            this.m_colItens = null;

            this.Decimais = p_intDecimais;
            this.FormatoData = p_strFormatoData;
            this.Nome = p_strNome;
            this.Tamanho = p_intTamanho;
            this.TipoDado = p_intTipoDado;
            this.ValorTexto = p_strValor;
            //---------------------------------------------------------------------------------------------------------
        }
        public MensagemItem(String p_strNome,MensagemItemTipoLista p_intTipoLista,String p_strCampoQtde,params MensagemItem[] p_arrItens)
        {
            if (MensagemItemTipoLista.Listas == p_intTipoLista && p_strCampoQtde == "")
            {
                throw new ArgumentException("Caso o tipo de lista seja 'Listas', � necess�rio definir um campo que registra a quantidade de registros",
                    "p_intTipoLista");
            }


            // Define valor das propriedades
            this.m_colItens = new MensagemItens(p_intTipoLista, p_strCampoQtde);

            this.Nome = p_strNome;
            this.Tamanho = 0;
            this.TipoDado = MensagemItemTipoDado.Lista;
            this.ValorTexto = "";

            // Preenche itens filhos
            // Caso seja uma lista de listas (v�rias parcelas, por exemplo)
            if (MensagemItemTipoLista.Listas == p_intTipoLista)
            {
                foreach (var objItem in p_arrItens)
                {
                    this.Itens.ItensModelos.Add(objItem.Nome, objItem);
                }
            }

            // Caso seja uma lista de valores (uma �rvore)
            else
            {
                foreach (var objItem in p_arrItens)
                {
                    this.Itens.Add(objItem);
                }
            }
        }
        public Int32 Decimais { get; set; }
        public String FormatoData { get; set; }
        public MensagemItens Itens { get { return m_colItens; } }
        public String Nome { get; set; }
        public MensagemItens Parent { get; set; }
        public Int32 Tamanho { get; set; }
        public MensagemItemTipoDado TipoDado { get; set; }
        public Object Valor
        {
            get
            {
                switch (this.TipoDado)
                {
                    case MensagemItemTipoDado.Lista:
                        return "";


                    case MensagemItemTipoDado.Inteiro:
                        return Convert.ToInt64(this.ValorTexto);


                    case MensagemItemTipoDado.Decimal:
                        return Convert.ToDecimal(this.ValorTexto) / Convert.ToDecimal(Math.Pow(10, this.Decimais));


                    case MensagemItemTipoDado.Data:
                        return DateTime.ParseExact(this.ValorTexto, this.FormatoData, null);


                    case MensagemItemTipoDado.Texto:
                    default:
                        return this.ValorTexto;
                }
            }

            set
            {
                switch (this.TipoDado)
                {
                    case MensagemItemTipoDado.Lista:
                        this.ValorTexto = "";
                        break;


                    case MensagemItemTipoDado.Inteiro:
                        this.ValorTexto = Convert.ToInt64(value).ToString();
                        break;


                    case MensagemItemTipoDado.Decimal:
                        this.ValorTexto = Math.Round(Convert.ToDecimal(value), this.Decimais).ToString().Replace(".", "").Replace(",", "");
                        break;


                    case MensagemItemTipoDado.Data:
                        this.ValorTexto = Convert.ToDateTime(value).ToString(this.FormatoData);
                        break;


                    case MensagemItemTipoDado.Texto:
                    default:
                        this.ValorTexto = Convert.ToString(value);
                        break;
                }
            }
        }
        public String ValorTexto
        {
            get
            {
                // Recupera valor do elemento atual e adapta retorno de acordo com tipo do dado
                if (this.TipoDado != MensagemItemTipoDado.Lista)
                {
                    switch (TipoDado)
                    {
                        case MensagemItemTipoDado.Texto:
                            return this.m_strValor.PadRight(this.Tamanho, ' ');

                        case MensagemItemTipoDado.Data:
                        case MensagemItemTipoDado.Decimal:
                        case MensagemItemTipoDado.Inteiro:
                            return this.m_strValor.PadLeft(this.Tamanho, '0');

                        default:
                            return "";
                    }
                }
                // Recupera valores dos elementos filhos
                else
                {
                    return this.Itens.ValorTexto;
                }
            }

            set
            {
                m_strValor = value;
            }
        }
        public MensagemItem this[Int32 p_intIndice]
        {
            get
            {
                return this.Itens[p_intIndice];
            }
        }
        public MensagemItem this[string p_strNome]
        {
            get
            {
                return this.Itens[p_strNome];
            }
        }
        public void InserirItem(params String[] p_arrValores)
        {
            if (MensagemItemTipoLista.Listas == this.Itens.TipoLista)
            {
                Int32 intA = 0;
                var objMsg = new MensagemItem("_ListaItem" + (this.Itens.Count + 1).ToString(), MensagemItemTipoLista.Valores, "");

                foreach (var objItem in this.Itens.ItensModelos.Values)
                {
                    objMsg.Itens.Add(new MensagemItem(objItem.Nome,
                        objItem.Tamanho,
                        objItem.TipoDado,
                        p_arrValores[intA],
                        objItem.Decimais,
                        objItem.FormatoData));
                    intA++;
                }
                this.Itens.Add(objMsg);
            }
        }
        public override String ToString()
        {
            return this.Nome + ": " + this.Valor.ToString();
        }
    }
}