﻿using System;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;

namespace Pan.Credito.Domain.Entidades.Common
{
    public static class UtilNew
    {
        public static bool IsInteger(string p_strValor)
        {
            long intValor;
            return long.TryParse(p_strValor, out intValor);
        }
        public static object Escolher(object p_objValor,params object[] p_arrValores)
        {
            var intA = 0;
            for (intA = 0; intA < p_arrValores.Count() - 1; intA += 2)
            {
                if (p_objValor.Equals(p_arrValores[intA]))
                {
                    return p_arrValores[intA + 1];
                }
            }
            return p_arrValores[intA];
        }
        public static string IsNull(object p_objValor,string p_strValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_strValorAlternativo;
            }
                return Convert.ToString(p_objValor);
        }
        public static decimal IsNull(object p_objValor,decimal p_decValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_decValorAlternativo;
            }
                return Convert.ToDecimal(p_objValor);

        }
        public static DateTime IsNull(object p_objValor,DateTime p_dtmValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_dtmValorAlternativo;
            }
                return Convert.ToDateTime(p_objValor);
        }
        public static int IsNull(object p_objValor,int p_intValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_intValorAlternativo;
            }
                return Convert.ToInt16(p_objValor);
        }
        public static int ReadData(IDataReader p_objReader,string p_strCampo,int p_intValorAlternativo)
        {
            var intOrdinal = p_objReader.GetOrdinal(p_strCampo);
            return p_objReader.IsDBNull(intOrdinal) ? p_intValorAlternativo : p_objReader.GetInt32(intOrdinal);
        }
        public static void RegistrarMensagem(string origemMensagem, string conteudoMensagem, EventLogEntryType tipoMensagem)
        {
            try
            {
                if (string.IsNullOrEmpty(origemMensagem))
                    origemMensagem = "Não Informado";

                if (!EventLog.SourceExists(origemMensagem))
                    EventLog.CreateEventSource(origemMensagem, "Application");

                var log = new EventLog {Source = origemMensagem};
                log.WriteEntry(conteudoMensagem, tipoMensagem);
            }
            catch (Exception)
            {

            }
        }
        public static long ObterNumeros(string texto)
        {
            var ret = texto.ToCharArray().Where(Char.IsDigit);

            var enumerable = ret as char[] ?? ret.ToArray();
            return !enumerable.Any() ? 0 : Convert.ToInt64(string.Join("", enumerable));
        }
        public static string RemoveAcentos(string texto)
        {
            const string C_acentos = "ÄÅÁÂÀÃäáâàãÉÊËÈéêëèÍÎÏÌíîïìÖÓÔÒÕöóôòõÜÚÛüúûùÇçñº°ª§¹²³&";
            const string S_acentos = "AAAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUuuuuCcNooaS123E";
            const string C_especiais = ";:^~`´!{}[]#$%¨*£¢¬+|";

            for (var i = 0; i < S_acentos.Length; i++)
                texto = texto.Replace(C_acentos[i].ToString(), S_acentos[i].ToString()).Trim();
            return C_especiais.Aggregate(texto, (current, t) => current.Replace(t.ToString(), "").Trim());
        }
        public static DateTime DataReferencia
        {
            get
            {
                var DataSistema = ConfigurationManager.AppSettings["DataSistema"];
                var DiasSistema = ConfigurationManager.AppSettings["DiasSistema"];

                if (string.IsNullOrEmpty(DataSistema))
                    return string.IsNullOrEmpty(DiasSistema) ? DateTime.Today : DateTime.Today.AddDays(Convert.ToInt32(DiasSistema));
                return Convert.ToDateTime(DataSistema, new CultureInfo("pt-BR"));
            }
        }
        public static bool ValidarCPF(string cpf)
        {
            cpf = cpf.PadLeft(11, '0');

            var multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };
            var multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            cpf = cpf.Trim();

            cpf = cpf.Replace(".", "").Replace("-", "");

            if (cpf.Length != 11)

                return false;

            var tempCpf = cpf.Substring(0, 9);

            var soma = 0;

            for (int i = 0; i < 9; i++)

                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];

            var resto = soma % 11;

            if (resto < 2)

                resto = 0;

            else

                resto = 11 - resto;

            var digito = resto.ToString();

            tempCpf = tempCpf + digito;

            soma = 0;

            for (int i = 0; i < 10; i++)

                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

            resto = soma % 11;

            if (resto < 2)

                resto = 0;

            else

                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cpf.EndsWith(digito);

        }
        public static bool ValidarCNPJ(string cnpj)
        {
            var multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            var multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");

            if (cnpj.Length != 14)
                return false;

            var tempCnpj = cnpj.Substring(0, 12);

            var soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];

            var resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            var digito = resto.ToString();

            tempCnpj = tempCnpj + digito;
            soma = 0;

            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];

            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cnpj.EndsWith(digito);
        }
        public static string FormataDocumento(long Documento)
        {
            return Documento.ToString(Documento.ToString().Length <=11 ? @"000\.000\.000-00" : @"00\.000\.000\/0000-00");
        }

    }
}