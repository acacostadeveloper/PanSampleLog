﻿using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Loja
    {
        public Loja()
        {
            Endereco = new Endereco();
            Officer = new Officer();
            Regional = new Regional();
        }

        public Loja(long p_intCNPJ, string p_intCodigo, Endereco p_objEndereco, DateTime p_dtmInicioAtividade,
            string p_strNome, Officer p_objOfficer, string p_strRazaoSocial, Regional p_objRegional,
            string p_strTelefone, string p_strTipo)
        {
            CNPJ = p_intCNPJ;
            Codigo = p_intCodigo;
            Endereco = p_objEndereco;
            InicioAtividade = p_dtmInicioAtividade;
            Nome = p_strNome;
            Officer = p_objOfficer;
            RazaoSocial = p_strRazaoSocial;
            Regional = p_objRegional;
            Telefone = p_strTelefone;
            Tipo = p_strTipo;
        }

        public long CNPJ { get; set; }
        public string Codigo { get; set; }
        public Endereco Endereco { get; set; }
        public DateTime InicioAtividade { get; set; }
        public string Nome { get; set; }
        public Officer Officer { get; set; }
        public string RazaoSocial { get; set; }
        public Regional Regional { get; set; }
        public string Telefone { get; set; }
        public string Tipo { get; set; }
        public DateTime FimAtividade { get; set; }
        public string Status { get; set; }
    }
}