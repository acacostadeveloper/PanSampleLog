﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Pan.Credito.Domain.Entidades.Common;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class OperacaoCredito
    {

        public OperacaoCredito()
        {
            Acordos = new List<Acordo>();
            Empresa = new Empresa();
            Ocorrencias = new List<Ocorrencia>();
            Parcelas = new List<Parcela>();
            Garantias = new List<Garantia>();
            Fluxo = new List<FluxoItem>();
            HabRenegocie = true;
        }
        [JsonIgnore]
        public string StatusContrato { get; set; }
        public string Contrato { get; set; }
       
        public string Operacao { get; set; }
       
        [JsonConverter(typeof(StringEnumConverter))]
        public OperacaoLiquidacaoTipos FormaLiquidacao { get; set; }
       
        [JsonConverter(typeof(StringEnumConverter))]
        public Origens Origem { get; set; }
       
        public string CodigoProduto { get; set; }
       
        public decimal ValorQuitacao
        {
            get
            {
                return Parcelas.Where(objParcela => !objParcela.Liquidado).Sum(objParcela => objParcela.ValorAtual);
            }
            set { }
        }

        [JsonIgnore]
        public long ContratoInterno { get; set; }
       
        public int DiasAtraso
        {
            get
            {
                if (Parcelas.Count == 0)
                    return 0;

                var intDiasAtrasos = 0;
                var dtmPrimeiraParcelaAberta = DateTime.MinValue;
                if (StatusDaOperacao != OperacaoCreditoStatus.Quitada && StatusDaOperacao != OperacaoCreditoStatus.Cancelada)
                {
                    var xcol = Parcelas.Where(X => !X.Liquidado && !X.Estorno);
                    if (xcol.Count() > 0)
                        dtmPrimeiraParcelaAberta = xcol.Select(X => X.DataVencimento).Min();
                    else
                        dtmPrimeiraParcelaAberta = DateTime.Now.Date;
                    if (dtmPrimeiraParcelaAberta < UtilNew.DataReferencia.Date)
                        intDiasAtrasos =
                            Convert.ToInt32(UtilNew.DataReferencia.Date.Subtract(dtmPrimeiraParcelaAberta).TotalDays);
                }

                return intDiasAtrasos;
            }
            set { }
        }
        [JsonIgnore]
        public int QuantidadeParcelas { get; set; }
        [JsonIgnore]
        public bool Prejuizo { get; set; }
        [JsonIgnore]
        public bool Regular { get; set; }
        [JsonIgnore]
        public int SituacaoCodigo { get; set; }
        [JsonIgnore]
        public bool BuscaApreensao { get; set; }
        [JsonIgnore]
        public bool IsBNDU { get; set; }
       
        [JsonConverter(typeof(StringEnumConverter))]
        public OperacaoCreditoStatus StatusDaOperacao
        {
            get
            {
                if (IsBNDU || BuscaApreensao) return OperacaoCreditoStatus.BNDU;
                
                if (Empresa.Codigo != "001" && Empresa.Codigo != "023" && Empresa.Codigo!="500") return OperacaoCreditoStatus.CreditoCedido;

                var ocorrenciasInibidoras = ConfigurationManager.AppSettings["Pansolution_Operacao_OcorrenciasInibidorasFuncao"].Split(',');
                
                if (ocorrenciasInibidoras.Any(strOcorrencia => Ocorrencias.Exists(o => o.Codigo == Convert.ToInt64(strOcorrencia) && o.Ativo))) return OperacaoCreditoStatus.Inibido;
                
                if (Parcelas == null || Parcelas.Count == 0) return OperacaoCreditoStatus.Prejuizo;
             
                if (Parcelas.Any(t => (DateTime.Now - t.DataVencimento).TotalDays > 60 && (t.Status != ParcelaStatus.Quitado && t.Status != ParcelaStatus.EmDia))) return OperacaoCreditoStatus.EmCobranca;
                
                if (Parcelas.Count(t => t.Status == ParcelaStatus.Atrasado) > 0) return OperacaoCreditoStatus.Atrasada;

                if (StatusContrato == "L") return OperacaoCreditoStatus.Quitada;

                return OperacaoCreditoStatus.EmDia;
            }
            set { }
        }
       
        public Cliente Cliente { get; set; }

        public List<Acordo> Acordos { get; set; }

        public Cobradora Cobradora { get; set; }
        
        public List<Garantia> Garantias { get; set; }
         
        public Empresa Empresa { get; set; }
        
        [JsonIgnore]
        public List<FluxoItem> Fluxo { get; set; }

        [JsonIgnore]
        public Loja Loja { get; set; }
        
        public List<Ocorrencia> Ocorrencias { get; set; }

        public List<Parcela> Parcelas { get; set; }
        public List<Parcela> ParcelasAtrasadas
        {
            get
            {
                return Parcelas.Where(t=>t.Status == ParcelaStatus.Atrasado).ToList();
            }
        }

        public bool HabRenegocie { get; set; }
    }
}