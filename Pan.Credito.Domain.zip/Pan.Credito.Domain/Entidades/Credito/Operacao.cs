﻿using System;
using System.Collections.Generic;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Operacao
    {
        public string Nome { get; set; }
        public long CNPJ { get; set; }
        public DateTime Data_Contrato { get; set; }
        public string Codigo { get; set; }
        public string Contrato { get; set; }
        public bool Quitado { get; set; }
        public decimal ValorParcelas { get; set; }
        public decimal ValorAcrescimos { get; set; }
        public decimal ValorDescontos { get; set; }
        public decimal ValorExtras { get; set; }
        public List<ParcelasExtrato> Parcelas { get; set; }
        public string CodigoProduto { get; set; }
        public DateTime DataLiquidacao { get; set; }
    }
}
