﻿using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Pricing
    {
        public decimal ValorVenda { get; set; }
        public string Ano { get; set; }
        public string Produto { get; set; }
        public int Carencia { get; set; }
        public int TotalParcelas { get; set; }
        public double TaxaPactuadaAno { get; set; }

        public double TaxaPactuadaMes
        {
            get
            {
                return TaxaPactuadaAno > 0
                    ? (Math.Pow(Convert.ToDouble(1 + TaxaPactuadaAno/100), Convert.ToDouble(1/12M)) - 1)*100
                    : 0;
            }
        }

        public decimal ValorFincanceiro { get; set; }
        public decimal ValorPrestacao { get; set; }
        public int ContratoCedido { get; set; }
        public DateTime DataCessao { get; set; }
        public double TaxaCessaoAno { get; set; }

        public double TaxaCessaoMes
        {
            get
            {
                return TaxaCessaoAno > 0
                    ? (Math.Pow(Convert.ToDouble(1 + TaxaCessaoAno/100), Convert.ToDouble(1/12M)) - 1)*100
                    : 0;
            }
        }

        public string Cessionario { get; set; }
    }
}