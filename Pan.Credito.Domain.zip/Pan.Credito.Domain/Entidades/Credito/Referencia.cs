﻿
namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Referencia
    {
        public int Codigo { get; set; }
        public string TipoReferencia { get; set; }
        public string Nome { get; set; }
        public string DDD { get; set; }
        public string Telefone { get; set; }
    }
}
