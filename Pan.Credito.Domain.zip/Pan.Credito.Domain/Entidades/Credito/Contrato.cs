﻿using System;
using System.ComponentModel.DataAnnotations;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Contrato
    {
        [Display(Name = "Cliente_Codigo")]
        public Int64 ClienteCodigo { get; set; }

        [Display(Name = "Cliente_Documento")]
        public Int64 Documento { get; set; }

        [Display(Name = "Cliente_Nome")]
        public string ClienteNome { get; set; }

        [Display(Name = "Cliente_TipoPessoa")]
        public char TipoPessoa { get; set; }

        public string EmpresaCodigo { get; set; }

        public decimal QuitacaoD0 { get; set; }

        public decimal QuitacaoD1 { get; set; }

        public string StringCyber { get; set; }

        public DateTime DataAmortizacao { get; set; }

        public string LinhaDigitavel { get; set; }

        public decimal ValorParcelaDia { get; set; }

        [Display(Name = "Empresa_Nome")]
        public string EmpresaNome { get; set; }

        [Display(Name = "Operacao_Contrato")]
        public string NumeroContrato { get; set; }

        [Display(Name = "Operacao_Liquidada")]
        public char Liquidada { get; set; }

        [Display(Name = "Operacao_SituacaoDesc")]
        public string Atraso { get; set; }

        [Display(Name = "Operacao_DataVencimento")]
        public DateTime Vencimento { get; set; }

        [Display(Name = "Operacao_DataLiberacao")]
        public DateTime DataLiberacao { get; set; }

        [Display(Name = "Operacao_PrimeiroVencimento")]
        public DateTime PrimeiroVencimento { get; set; }

        [Display(Name = "Operacao_ProdutoCodigo")]
        public string ProdutoCodigo { get; set; }

        [Display(Name = "Operacao_Valor")]
        public decimal Valor { get; set; }

        [Display(Name = "Operacao_Parcelas")]
        public int Parcelas { get; set; }

        [Display(Name = "Operacao_ParcelasAbertas")]
        public int ParcelasAbertas { get; set; }

        [Display(Name = "Operacao_TipoSituacao")]
        public string TipoSituacao { get; set; }

        [Display(Name = "Operacao_InicioAtendimento")]
        public DateTime InicioAtendimento { get; set; }

        [Display(Name = "Operacao_Status")]
        public String Status { get; set; }

        [Display(Name = "Operacao_Tipo")]
        public String TipoOperacao { get; set; }

        public decimal SaldoDevedor { get; set; }

        public decimal ValorParcelaAtraso { get; set; }

        public DateTime DataAmortizacaoAtraso { get; set; }

        public string Assessoria { get; set; }

        public Cobradora Cobradora { get; set; }

        public Origens Origem { get; set; }
    }
}
