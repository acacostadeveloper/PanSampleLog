﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class DUT 
    {
        public bool DutTransferido { get; set; }

        public string DataReferencia { get; set; }

        public DUT()
        {

        }

        public DUT(bool p_dutTransferido, string p_dtReferencia)
        {
            this.DutTransferido = p_dutTransferido;
            this.DataReferencia = p_dtReferencia;
        }
    }
}
