﻿using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Debito
    {
        public int Parcela { get; set; }
        public DateTime Vencimento { get; set; }
        public int Banco { get; set; }
        public string Agencia { get; set; }
        public string Conta { get; set; }
        public int Interface { get; set; }
        public string InterfaceDescricao { get; set; }
        public DateTime Envio { get; set; }
        public DateTime Retorno { get; set; }
        public int Erro { get; set; }
        public string ErroDescricao { get; set; }
    }
}
