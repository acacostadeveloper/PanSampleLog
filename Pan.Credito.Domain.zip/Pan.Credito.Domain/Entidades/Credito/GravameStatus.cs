﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class GravameStatus
    {
        public bool Liberado { get; set; }
        public string CriticaCodigo { get; set; }
        public string CriticaMsg { get; set; }
    }
}