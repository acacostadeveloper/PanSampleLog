﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Cliente 
    {
        public string Codigo { get; set; }
        public string Nome { get; set; }
        public string FirstName
        {
            get
            {
                var firstName = Nome.TrimStart();
                return firstName.Substring(0, firstName.IndexOf(' '));
            }
        }
        public string PessoaTipo { get; set; }
        public long Documento { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoNacionalidade Nacionalidade { get; set; }
        public string NaturalidadeUF { get; set; }
        public string Naturalidade { get; set; }
        public string NumeroDocumento { get; set; }
        public string RG { get; set; }
        public string RGEmissor { get; set; }
        public DateTime? RGData { get; set; }
        public string RGUF { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoSexo Sexo { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoEstadoCivil EstadoCivil { get; set; }
        public string NomeMae { get; set; }
        public string NomePai { get; set; }
        public short Dependentes { get; set; }
        public bool Emancipado { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoResidencia TipoResidencia { get; set; }
        public DateTime? Nascimento { get; set; }
        public Endereco Endereco { get; set; }
        public Conta Conta { get; set; }
        public List<Telefone> Telefones { get; set; }
        public string Email { get; set; }
        public string NomeRecado { get; set; }
        public DateTime Atualizacao { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoSistema TipoSistema { get; set; }
        public decimal Renda { get; set; }
        [JsonIgnore]
        public Comercial Comercial { get; set; }
        public Endereco Correspondencia { get; set; }
        public List<Contrato> Contratos { get; set; }
    }
}