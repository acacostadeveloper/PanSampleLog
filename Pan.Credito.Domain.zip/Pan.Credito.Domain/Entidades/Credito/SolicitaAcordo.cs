﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class SolicitaAcordo
    {
        public string Contrato { get; set; }
        [Required]
        [DataType(DataType.DateTime, ErrorMessage = "Data Invalida")]
        public DateTime DataPagamento { get; set; }
        public bool Desconto { get; set; }
        public List<DateTime> DatasVencimento { get; set; }
        public bool WithPDF { get; set; }
        public SolicitaAcordo()
        {
            Desconto = false;
            DatasVencimento = new List<DateTime>();
        }
    }
    public class AcordoRenegocie
    {
        [Required]
        public string Contrato { get; set; }
        [Required]
        [DataType(DataType.DateTime, ErrorMessage = "Data Invalida")]
        public DateTime DataPagamento { get; set; }
        public List<DateTime> DatasVencimento { get; set; }
        [Required]
        public string CodigoProduto { get; set; }
        public int QtdeParcelas { get; set; }
        public bool WithPDF { get; set; }
        
        public AcordoRenegocie()
        {
            DatasVencimento = new List<DateTime>();
        }
    }
}