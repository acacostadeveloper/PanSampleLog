﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Correspondente
    {
        public string Tipo { get; set; }
        public string Endereco { get; set; }
        public string Cidade { get; set; }
        public string UF { get; set; }
        public string Cep { get; set; }
        public string DDD { get; set; }
        public string Telefone { get; set; }
    }
}