using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class ParcelasExtrato
    {
        public string ContratoInter { get; set; }
        public DateTime DataAmortizacao { get; set; }
        public DateTime DataLiquidacao { get; set; }
        public decimal Valor { get; set; }
        public decimal ValorPago { get; set; }
        public decimal Acrescimos { get; set; }
        public decimal Descontos { get; set; }
    }
}