﻿using System;
using System.Collections.Generic;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class ClienteExtrato
    {
        public long Codigo { get; set; }
        public long Documento { get; set; }
        public char Tipo_Pessoa { get; set; }
        public string Nome { get; set; }
        public DateTime Nascimento { get; set; }
        public List<Operacao> Operacoes { get; set; }
        public List<TarifasExtrato> Tarifas { get; set; }
    }
}
