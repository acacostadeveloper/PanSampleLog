using System.Collections.Generic;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Empresa 
    {
        public Empresa()
        {
            Endereco = new Endereco();
            Atributos = new Dictionary<string, string>();
        }

        public Empresa(long p_intDocumento, string p_strNome, string p_strRazaoSocial, Endereco p_objEndereco)
        {
            Documento = p_intDocumento;
            Endereco = p_objEndereco;
            Nome = p_strNome;
            RazaoSocial = p_strRazaoSocial;
            Atributos = new Dictionary<string, string>();
        }
        public string Codigo { get; set; }
        public Dictionary<string, string> Atributos { get; set; }
        public long Documento { get; set; }
        public Endereco Endereco { get; set; }
        public string Nome { get; set; }
        public string RazaoSocial { get; set; }
    }
}