﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class SolicitaBoleto
    {
        public SolicitaBoleto()
        {
            Liquidados = false;
        }
       
        [Required]
        [JsonConverter(typeof(StringEnumConverter))]
        public Origens Origem { get; set; }
        
        [Required]
        [JsonConverter(typeof(StringEnumConverter))]
        public BoletosTipos Tipo { get; set; }

        [Required]
        public string Contrato { get; set; }

        [Required]
        public DateTime DataPagamento { get; set; }
        
        [Required]
        public bool PDF { get; set; }

        public DateTime DataInicio { get; set; }

        public DateTime DataFim { get; set; }

        public int Proximos { get; set; }

        public bool Liquidados { get; set; }

        public string BoletoFormato { get; set; }

        public string Email { get; set; }

        public string Celular { get; set; }
        
        
    }
}