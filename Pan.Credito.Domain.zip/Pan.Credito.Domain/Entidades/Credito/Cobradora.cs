using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Cobradora 
    {
        public Cobradora()
        {
            Endereco = new Endereco();
        }
        public Cobradora(long p_intCodigo,DateTime p_dtmDistribuicao,string p_strEmail,Endereco p_objEndereco,string p_strNome,string p_strTelefone)
        {
            Codigo = p_intCodigo;
            DataDistribuicao = p_dtmDistribuicao;
            Email = p_strEmail;
            Endereco = p_objEndereco;
            Nome = p_strNome;
            Telefone = p_strTelefone;
        }
        public long Codigo { get; set; }
        public DateTime DataDistribuicao { get; set; }
        public string Email { get; set; }
        public Endereco Endereco { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }
    }
}