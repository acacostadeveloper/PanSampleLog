﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Endereco
    {
        public Endereco()
        {
        }
        public Endereco(string p_strLogradouro, string p_strNumero, string p_strComplemento, string p_strBairro,string p_strCEP, string p_strCidade, string p_strUF)
        {
            Logradouro = p_strLogradouro;
            Numero = p_strNumero;
            Complemento = p_strComplemento;
            Bairro = p_strBairro;
            CEP = p_strCEP;
            Cidade = p_strCidade;
            UF = p_strUF;
        }
        public string Bairro { get; set; }
        public string CEP { get; set; }
        public string Cidade { get; set; }
        public string Complemento { get; set; }
        public string EnderecoCompleto
        {
            get
            {
                var strLogradouro = " ";
                var strNumero = "";
                var strBairro = "";
                var strCidade = "";
                var strUF = "";

                if (!string.IsNullOrWhiteSpace(Logradouro))
                    strLogradouro = ", " + Logradouro;
                if (!string.IsNullOrWhiteSpace(Numero))
                    strNumero = ", " + Numero;
                if (!string.IsNullOrWhiteSpace(Bairro))
                    strBairro = ", " + Bairro;
                if (!string.IsNullOrWhiteSpace(Cidade))
                    strCidade = ", " + Cidade;
                if (!string.IsNullOrWhiteSpace(UF))
                    strUF = ", " + UF;


                return strLogradouro + strNumero + strBairro + strCidade + strUF;
            }
            set { }
        }
        public string Logradouro { get; set; }
        public string Numero { get; set; }
        public string UF { get; set; }
        public char Tipo { get; set; }
    }
}