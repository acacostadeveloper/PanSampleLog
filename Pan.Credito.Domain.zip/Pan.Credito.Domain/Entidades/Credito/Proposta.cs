﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Proposta
    {
        public string Status { get; set; }
    }
}
