﻿using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Ocorrencia
    {
        public Ocorrencia()
        {
        }
        public Ocorrencia(long p_intCodigo,string p_strNome,string p_strCodigoAcao,string p_strAcao,DateTime p_dtmInclusao,DateTime p_dtmValidade,DateTime p_dtmParcela,bool p_blnAtiva)
        {
            Acao = p_strAcao;
            Ativo = p_blnAtiva;
            Codigo = p_intCodigo;
            CodigoAcao = p_strCodigoAcao;
            DataInclusao = p_dtmInclusao;
            DataParcela = p_dtmParcela;
            DataValidade = p_dtmValidade;
            Nome = p_strNome;
        }

        public string DescricaoCodigo { get; set; }
        public string Acao { get; set; }
        public bool Ativo { get; set; }
        public long Codigo { get; set; }
        public string CodigoAcao { get; set; }
        public DateTime DataInclusao { get; set; }
        public DateTime DataParcela { get; set; }
        public DateTime DataValidade { get; set; }
        public string Nome { get; set; }
    }
}