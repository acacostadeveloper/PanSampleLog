﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Fonte
    {
        public int ID { get; set; }
        public long Documento { get; set; }
        public string Nome { get; set; }
        public sbyte Tipo { get; set; }
    }
}
