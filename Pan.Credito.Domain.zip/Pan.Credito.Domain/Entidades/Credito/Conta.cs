﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Conta
    {
        public int Banco { get; set; }
        public string Agencia { get; set; }
        public string Numero { get; set; }
    }
}
