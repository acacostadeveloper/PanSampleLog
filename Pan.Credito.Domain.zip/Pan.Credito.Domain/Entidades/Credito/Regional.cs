namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Regional
    {
        public Regional()
        {
            Endereco = new Endereco();
        }

        public Regional(long p_intCodigo,string p_strNome,Endereco p_objEndereco,string p_strTelefone)
        {
            Codigo = p_intCodigo;
            Nome = p_strNome;
            Endereco = p_objEndereco;
            Telefone = p_strTelefone;
        }
        public long CNPJ { get; set; }
        public long Codigo { get; set; }
        public Endereco Endereco { get; set; }
        public string Nome { get; set; }
        public string Telefone { get; set; }
        public string Status { get; set; }
    }
}