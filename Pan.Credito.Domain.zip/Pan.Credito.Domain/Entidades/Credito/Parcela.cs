using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Pan.Credito.Domain.Entidades.Boletos;
using Pan.Credito.Domain.Entidades.Common;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Parcela 
    {
        public Parcela()
        {
        }

        public Parcela(int p_intNumeroParcela,
            DateTime p_dtmDataCalculo,
            DateTime p_dtmDataVencimento,
            DateTime p_dtmDataPagamento,
            short p_intDiasAtraso,
            short p_intDiasAdiantamento,
            bool p_blnEstorno,
            [JsonConverter(typeof(StringEnumConverter))]
            OperacaoLiquidacaoTipos p_intFormaLiquidacao,
            bool p_blnLiquidado,
            bool p_blnRenegociado,
            decimal p_decValor,
            decimal p_decValorCurva,
            decimal p_decValorJuros,
            decimal p_decValorPrincipal,
            decimal p_decValorRecebido,
            decimal p_decValorMora,
            decimal p_decValorCP,
            decimal p_decValorMulta,
            decimal p_decValorDescontoMora,
            decimal p_decValorDescontoCP,
            decimal p_decValorDescontoMulta,
            decimal p_decValorDescontoParcela,
            decimal p_decValorHonorarios,
            decimal p_decValorComissao,
            decimal p_decMoraTaxa,
            string p_strMoraTipo,
            string p_strMoraPeriodicidade,
            decimal p_decMultaTaxa,
            string p_strMultaBase,
            decimal p_decCPTaxa,
            string p_strCPTipo,
            string p_strCPPeriodicidade,
            decimal p_decEncargosMoratorios,
            decimal p_decDescontos,
            decimal p_decDespesas,
            decimal p_decSaldoAcumulado,
            decimal p_decSaldoPagar,
            decimal p_decValorDescontos,
            decimal p_decValorAcrescimos,
            decimal p_decValorVRG,
            string p_LinhaDigitavel)
        {
            NumeroParcela = p_intNumeroParcela;
            DataCalculo = p_dtmDataCalculo;
            DataVencimento = p_dtmDataVencimento;
            DataPagamento = p_dtmDataPagamento;
            DiasAtraso = p_intDiasAtraso;
            DiasAdiantamento = p_intDiasAdiantamento;
            Estorno = p_blnEstorno;
            FormaLiquidacao = p_intFormaLiquidacao;
            Liquidado = p_blnLiquidado;
            Renegociado = p_blnRenegociado;
            Valor = p_decValor;
            ValorCurva = p_decValorCurva;
            ValorJuros = p_decValorJuros;
            ValorPrincipal = p_decValorPrincipal;
            ValorRecebido = p_decValorRecebido;
            ValorMora = p_decValorMora;
            ValorCP = p_decValorCP;
            ValorMulta = p_decValorMulta;
            ValorDescontoMora = p_decValorDescontoMora;
            ValorDescontoCP = p_decValorDescontoCP;
            ValorDescontoMulta = p_decValorDescontoMulta;
            ValorDescontoParcela = p_decValorDescontoParcela;
            ValorHonorarios = p_decValorHonorarios;
            ValorComissao = p_decValorComissao;
            MoraTaxa = p_decMoraTaxa;
            MoraTipo = p_strMoraTipo;
            MoraPeriodicidade = p_strMoraPeriodicidade;
            MultaTaxa = p_decMultaTaxa;
            MultaBase = p_strMultaBase;
            CPTaxa = p_decCPTaxa;
            CPTipo = p_strCPTipo;
            CPPeriodicidade = p_strCPPeriodicidade;
            EncargosMoratorios = p_decEncargosMoratorios;
            Descontos = p_decDescontos;
            Despesas = p_decDespesas;
            SaldoAcumulado = p_decSaldoAcumulado;
            SaldoPagar = p_decSaldoPagar;
            ValorDescontos = p_decValorDescontos;
            ValorAcrescimos = p_decValorAcrescimos;
            ValorVRG = p_decValorVRG;
            LinhaDigitavel = p_LinhaDigitavel;
        }
        public bool Cedida
        {
            get { return CessaoCodigo > 0; }
            set { }
        }
        public Banco CessaoBanco { get; set; }
        public long CessaoCodigo { get; set; }
        public bool CessaoCoobrigacao { get; set; }
        public DateTime CessaoData { get; set; }
        public string CPPeriodicidade { get; set; }
        public decimal CPTaxa { get; set; }
        public string CPTipo { get; set; }
        public DateTime DataCalculo { get; set; }
        public DateTime DataPagamento { get; set; }
        public DateTime DataVencimento { get; set; }
        public decimal Descontos { get; set; }
        public decimal Despesas { get; set; }
        public short DiasAdiantamento
        {
            get
            {
                if (DataPagamento != DateTime.MinValue && (Liquidado || PagamentoParcial) &&
                    DataPagamento < DataVencimento)
                    return Math.Abs(Convert.ToInt16(DataPagamento.Subtract(DataVencimento).TotalDays));
                return 0;
            }
            set { }
        }
        [JsonConverter(typeof(StringEnumConverter))]
        public ParcelaStatus Status
        {
            get
            {
                if (Liquidado)
                    return ParcelaStatus.Quitado;
                if (DiasAtraso > 0 && ValorAcrescimos > 0.0m)
                    return ParcelaStatus.Atrasado;

                return ParcelaStatus.EmDia;
            }
            set { }
        }

        public short DiasAtraso
        {
            get
            {
                if ((Liquidado || PagamentoParcial) && DataPagamento > DataVencimento)
                    return Convert.ToInt16(DataPagamento.Subtract(DataVencimento).TotalDays);
                if ((!Liquidado || !PagamentoParcial) && DataVencimento < UtilNew.DataReferencia && ValorAcrescimos > 0.0m)
                    return Convert.ToInt16(UtilNew.DataReferencia.Subtract(DataVencimento).TotalDays);
                return 0;
            }
            set { }
        }
        public decimal EncargosMoratorios { get; set; }
        public bool Estorno { get; set; }
         [JsonConverter(typeof(StringEnumConverter))]
        public OperacaoLiquidacaoTipos FormaLiquidacao { get; set; }
        public bool Liquidado { get; set; }
        public string MoraPeriodicidade { get; set; }
        public decimal MoraTaxa { get; set; }
        public string MoraTipo { get; set; }
        public string MultaBase { get; set; }
        public decimal MultaTaxa { get; set; }
        public int NumeroParcela { get; set; }
        public bool Renegociado { get; set; }
        public decimal SaldoAcumulado { get; set; }
        public decimal SaldoPagar { get; set; }
        public decimal Valor { get; set; }
        public decimal ValorAcrescimos { get; set; }
        public decimal ValorAtual
        {
            get { return Valor - ValorDescontos + ValorAcrescimos; }
            set {}
        }
        public decimal ValorComissao { get; set; }
        public decimal ValorCP { get; set; }
        public decimal ValorCurva { get; set; }
        public decimal ValorDescontoCP { get; set; }
        public decimal ValorDescontoMora { get; set; }
        public decimal ValorDescontoMulta { get; set; }
        public decimal ValorDescontoParcela { get; set; }
        public decimal ValorDescontos { get; set; }
        public decimal ValorHonorarios { get; set; }
        public decimal ValorJuros { get; set; }
        public decimal ValorMora { get; set; }
        public decimal ValorMulta { get; set; }
        public decimal ValorPrincipal { get; set; }
        public decimal ValorRecebido
        {
            get
            {
                if (Liquidado)
                    return Valor + ValorAcrescimos - ValorDescontos;
                return 0.0m;
            }
            set { }
        }
        public decimal ValorPagamentoParcial { get; set; }
        public decimal ValorVRG { get; set; }
        public string LinhaDigitavel { get; set; }
        public bool PagamentoParcial { get; set; }
        public int Controle { get; set; }
        public string TipoMovimentacao { get; set; }
        public bool SaldoDeParcela { get; set; }
        public int Plano { get; set; }
    }
}