﻿
namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Comercial
    {
        public string EmpresaNome { get; set; }
        public string EmpresaCnpj { get; set; }
        public Endereco Endereco { get; set; }
        public string NaturezaOcupacao { get; set; }
        public string Profissao { get; set; }
        public decimal Salario { get; set; }
        public decimal RendaMensal { get; set; }
        public short TempoAtividadeAno { get; set; }
        public short TempoAtividadeMeses { get; set; }
    }
}