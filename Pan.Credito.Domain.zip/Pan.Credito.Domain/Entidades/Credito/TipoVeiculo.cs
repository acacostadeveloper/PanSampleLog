﻿
namespace Pan.Credito.Domain.Entidades.Credito
{
    public class TipoVeiculo
    {
        public decimal ID { get; set; }
        public string Descricao { get; set; }
    }
}
