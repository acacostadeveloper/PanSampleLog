﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Profissao
    {
        public int ID { get; set; }
        public string Descricao { get; set; }

    }
}
