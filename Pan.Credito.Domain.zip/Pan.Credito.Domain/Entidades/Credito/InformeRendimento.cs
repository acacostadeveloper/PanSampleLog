﻿using System.Collections.Generic;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class InformeRendimento
    {
        public ClienteExtrato Cliente { get; set; }
        public Fonte Fonte { get; set; }
        public List<Extrato> Rendimentos { get; set; }
        public List<Extrato> Saldos { get; set; }
    }
}
