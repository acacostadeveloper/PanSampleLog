﻿using System;
using System.Globalization;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Moeda
    {
        public String simbolo;
        public String valor;

        public decimal GetDecimal() 
        {
           decimal decValue = decimal.Parse(valor, NumberStyles.Currency, new CultureInfo("pt-BR"));
           return decValue;
        }

        public static Moeda Reais(Double p_dblValor)
        {
            return new Moeda
            {
                simbolo = "R$",
                valor   = p_dblValor.ToString("#,##0.00", new CultureInfo("pt-BR"))
            };
        }

        public static Moeda Reais(Decimal p_decValor)
        {
            return new Moeda
            {
                simbolo = "R$",
                valor   = p_decValor.ToString("#,##0.00", new CultureInfo("pt-BR"))
            };
        }


        public static Moeda Dolar(Double p_dblValor)
        {
            return new Moeda
            {
                simbolo = "US$",
                valor   = p_dblValor.ToString("#,##0.00", new CultureInfo("pt-BR"))
            };
        }

        public static Moeda Dolar(Decimal p_decValor)
        {
            return new Moeda
            {
                simbolo = "US$",
                valor   = p_decValor.ToString("#,##0.00", new CultureInfo("pt-BR"))
            };
        }



        public static Moeda SetMoeda(Double p_dblValor, 
                                     String p_strSimbolo,
                                     IFormatProvider culture = null)
        {
            return new Moeda
            {
                simbolo = p_strSimbolo,
                valor   = p_dblValor.ToString("#,##0.00",culture)
            };
        }

        public override string ToString()
        {
            if (this.GetDecimal() == 0)
            {
                return "";
            }
            return string.Format("{0} {1}", this.simbolo, this.valor);
        }
    }
}
