﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class BandeiraCartao
    {
        public int ID { get; set; }
        public string Nome { get; set; }
    }
}
