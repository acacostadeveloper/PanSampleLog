﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Telefone
    {
        public string DDD { get; set; }
        public long Numero { get; set; }
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoTelefone Tipo { get; set; }
    }
}