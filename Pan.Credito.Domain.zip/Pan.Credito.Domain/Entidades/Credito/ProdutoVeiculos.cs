﻿namespace Pan.Credito.Domain.Entidades.Credito
{
    public class ProdutoVeiculos
    {
        public string COD_PRODUTO { get; set; }
        public string DESC_PRODUTO { get; set; }
    }
}
