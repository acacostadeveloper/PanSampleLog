﻿using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Extrato
    {
        public int ID { get; set; }
        public string Descricao { get; set; }
        public DateTime Data { get; set; }
        public decimal Valor { get; set; }
    }
}
