using System;
using System.Collections.Generic;
using System.Linq;
using Pan.Credito.Domain.Entidades.Common;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Acordo 
    {
        public Acordo()
        {
            Parcelas = new List<Parcela>();
        }

        public Acordo(string p_intContratoInterno, DateTime p_dtmDataCancelamento, DateTime p_dtmDataInclusao,
            DateTime p_dtmDataPagamento, DateTime p_dtmDataVencimento,
            string p_strNossoNumero,
            int p_intSequenciaPagamento,
            string p_strFlagPagamento,
            params Parcela[] p_arrParcelas)
        {
            ContratoInterno = p_intContratoInterno;
            DataCancelamento = p_dtmDataCancelamento;
            DataInclusao = p_dtmDataInclusao;
            DataPagamento = p_dtmDataPagamento;
            DataVencimento = p_dtmDataVencimento;
            NossoNumero = p_strNossoNumero;
            SequenciaPagamento = p_intSequenciaPagamento;
            Parcelas = new List<Parcela>();
            FlagPagamento = p_strFlagPagamento;
            foreach (var objParcela in p_arrParcelas)
                Parcelas.Add(objParcela);
        }
        public bool Cancelado
        {
            get
            {
                return DataCancelamento != DateTime.MinValue || FlagPagamento.Trim() == "8" ||
                       FlagPagamento.Trim() == "9";
            }
            set { }
        }
        public string ContratoInterno { get; set; }
        public DateTime DataCancelamento { get; set; }
        public DateTime DataInclusao { get; set; }
        public DateTime DataPagamento { get; set; }
        public DateTime DataVencimento { get; set; }
        public string FlagPagamento { get; set; }
        public bool Liquidado
        {
            get { return DataPagamento != DateTime.MinValue; }
            set { }
        }
        public string NossoNumero { get; set; }
        public List<Parcela> Parcelas { get; set; }
        public int SequenciaPagamento { get; set; }
        public decimal Valor
        {
            get
            {
                return Parcelas.Sum(objParcela => objParcela.ValorAtual);
            }
            set { }
        }
        public decimal ValorDescontos
        {
            get
            {
                return Parcelas.Sum(objParcela => objParcela.ValorDescontos);
            }
            set { }
        }
        public decimal ValorEncargos
        {
            get
            {
                return Parcelas.Sum(objParcela => objParcela.ValorCP + objParcela.ValorMora + objParcela.ValorMulta);
            }
            set { }
        }
        public decimal ValorOriginal
        {
            get
            {
                return Parcelas.Sum(objParcela => objParcela.Valor);
            }
            set { }
        }
        public bool Vencido
        {
            get { return DataVencimento < UtilNew.DataReferencia; }
            set { }
        }
        public string LinhaDigitavel { get; set; }
        public string PDF { get; set; }
    }
}