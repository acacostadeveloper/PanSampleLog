using System.ComponentModel.DataAnnotations;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Despesas
    {
        [Display(Name = "COD_EVENTO_FLUXO")]
        public string COD_EVENTO_FLUXO { get; set; }

        [Display(Name = "LABL_EVENTO_FLUXO")]
        public string LABL_EVENTO_FLUXO { get; set; }
    }
}