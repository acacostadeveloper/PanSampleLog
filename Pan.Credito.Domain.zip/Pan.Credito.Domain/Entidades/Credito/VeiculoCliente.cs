﻿using System.Collections.Generic;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class VeiculoCliente
    {
        public long CPF { get; set; }
        public string Nome { get; set; }
        public long Codigo { get; set; }
        public double SeguroValor { get; set; }
        public long CNPJ { get; set; }
        public long OfficerCpfCnpj { get; set; }
        public sbyte OfficerTipo { get; set; }
        public long CNPJProm { get; set; }
        public List<Endereco> Enderecos { get; set; }
        public List<Telefone> Telefones { get; set; }
    }
}
