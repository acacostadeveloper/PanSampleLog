﻿using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Liberacao
    {
        public int Quantidade { get; set; }
        public string Favorecido { get; set; }
        public long Documento { get; set; }
        public string TipoLiberacao { get; set; }
        public DateTime DataRepasse { get; set; }
        public int BancoCodigo { get; set; }
        public int Agencia { get; set; }
        public string AgenciaDigito { get; set; }
        public int Conta { get; set; }
        public string Conta_Digito { get; set; }
        public decimal Valor { get; set; }
        public string TipoGeracao { get; set; }
    }
}
