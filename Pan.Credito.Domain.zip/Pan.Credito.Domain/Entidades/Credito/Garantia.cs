﻿using System;
using Newtonsoft.Json;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Garantia
    {
        public Garantia()
        {
            Veiculo = new Veiculo();
            Transferencia = new DUT();
           
        }

        public Garantia(long p_intCodigo,
            long p_intCodigoClasseGarantia,
            long p_intCodigoGarantiaSubstituida,
            string p_strCodigoMoeda,
            DateTime p_dtmDataContabilizacao,
            DateTime p_dtmDataContabilizacaoBaixa,
            DateTime p_dtmDataContabilizacaoEfetiva,
            DateTime p_dtmDataDesativacao,
            DateTime p_dtmDataInicioValorizacao,
            DateTime p_dtmDataVencimento,
            bool p_blnGarantiaPrincipal,
            int p_intNumeroSequencia,
            string p_strTipoBaixa,
            string p_strTipoValorizacao,
            decimal p_decValor,
            decimal p_decValorHistorico,
            Veiculo p_objVeiculo)
        {
            Codigo = p_intCodigo;
            CodigoClasseGarantia = p_intCodigoClasseGarantia;
            CodigoGarantiaSubstituida = p_intCodigoGarantiaSubstituida;
            CodigoMoeda = p_strCodigoMoeda;
            DataContabilizacao = p_dtmDataContabilizacao;
            DataContabilizacaoBaixa = p_dtmDataContabilizacaoBaixa;
            DataContabilizacaoEfetiva = p_dtmDataContabilizacaoEfetiva;
            DataDesativacao = p_dtmDataDesativacao;
            DataInicioValorizacao = p_dtmDataInicioValorizacao;
            DataVencimento = p_dtmDataVencimento;
            GarantiaPrincipal = p_blnGarantiaPrincipal;
            NumeroSequencia = p_intNumeroSequencia;
            TipoBaixa = p_strTipoBaixa;
            TipoValorizacao = p_strTipoValorizacao;
            Valor = p_decValor;
            ValorHistorico = p_decValorHistorico;
            Veiculo = p_objVeiculo;
        }
        [JsonIgnore]
        public long Codigo { get; set; }
        [JsonIgnore]
        public long CodigoClasseGarantia { get; set; }
        [JsonIgnore]
        public long CodigoGarantiaSubstituida { get; set; }
        [JsonIgnore]
        public string CodigoMoeda { get; set; }
        [JsonIgnore]
        public DateTime DataContabilizacao { get; set; }
        [JsonIgnore]
        public DateTime DataContabilizacaoBaixa { get; set; }
        [JsonIgnore]
        public DateTime DataContabilizacaoEfetiva { get; set; }
        [JsonIgnore]
        public DateTime DataDesativacao { get; set; }
        [JsonIgnore]
        public DateTime DataInicioValorizacao { get; set; }
        [JsonIgnore]
        public DateTime DataVencimento { get; set; }
        [JsonIgnore]
        public bool GarantiaPrincipal { get; set; }
        [JsonIgnore]
        public int NumeroSequencia { get; set; }
        [JsonIgnore]
        public bool Substituicao
        {
            get { return CodigoGarantiaSubstituida != 0; }
            set { }
        }
        [JsonIgnore]
        public string TipoBaixa { get; set; }
        [JsonIgnore]
        public string TipoValorizacao { get; set; }
        [JsonIgnore]
        public decimal Valor { get; set; }
        [JsonIgnore]
        public decimal ValorHistorico { get; set; }
      
        public Veiculo Veiculo { get; set; }
        [JsonIgnore]
        public string NumeroCertificadoAtu { get; set; }
        [JsonIgnore]
        public DateTime DataCertificadoAtu { get; set; }
        [JsonIgnore]
        public DateTime DataInclusao { get; set; }
        [JsonIgnore]
        public DUT Transferencia { get; set; }
      
    }

   
}