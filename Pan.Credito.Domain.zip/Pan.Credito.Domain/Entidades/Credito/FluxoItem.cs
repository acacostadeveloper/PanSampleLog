using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class FluxoItem 
    {
        public Cobradora Cobradora { get; set; }
        public int CodigoAtraso { get; set; }
        public long CodigoEvento { get; set; }
        public int CodigoOrgaoRecebedor { get; set; }
        public DateTime DataAmortizacao { get; set; }
        public DateTime DataContabilizacao { get; set; }
        public DateTime DataLiberacao { get; set; }
        public DateTime DataRetCobradora { get; set; }
        public DateTime DataValor { get; set; }
        public string Descricao { get; set; }
        public bool Estorno { get; set; }
        public int NumeroSequencia { get; set; }
        public long NumeroSequenciaMovimento { get; set; }
        public string TipoLiquidacao { get; set; }
        public string TipoMovimento { get; set; }
        public string TipoOrgaoRecebedor { get; set; }
        public decimal Valor { get; set; }
    }
}