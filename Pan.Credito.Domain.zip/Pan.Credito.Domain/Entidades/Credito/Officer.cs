﻿
namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Officer 
    {
        public Officer()
        {
        }

        public Officer(long p_intCodigo,string p_strNome)
        {
            Codigo = p_intCodigo;
            Nome = p_strNome;
        }
        public long Codigo { get; set; }
        public long CPF { get; set; }
        public string Nome { get; set; }
    }
}