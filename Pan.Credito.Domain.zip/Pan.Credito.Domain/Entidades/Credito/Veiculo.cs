using System;

namespace Pan.Credito.Domain.Entidades.Credito
{
    public class Veiculo
    {
        public Veiculo()
        {
            Gravame = new Gravame();
        }

        public Veiculo(bool p_blnAlienacao,
            bool p_blnAssistencia,
            bool p_blnApreensao,
            string p_strApreensaoMotivo,
            string p_strApreensaoTipo,
            string p_strBloqueiaIL_Flag,
            string p_strCategoria,
            string p_strChassi,
            bool p_blnChassiRemarcado,
            long p_intCodigo,
            long p_intCodigoTipoVeiculo,
            string p_strCombustivel,
            string p_strCor,
            DateTime p_dtmDataAlienacao,
            DateTime p_dtmDataGeracaoAlienacao,
            DateTime p_dtmDataRegAssist,
            DateTime p_dtmDataInclusaoDUT,
            string p_strEnvioAssistencia_Flag,
            short p_intFabricacaoAno,
            long p_intGravame,
            string p_strMarca,
            string p_strModelo,
            short p_intModeloAno,
            string p_strPlaca_Codigo,
            string p_strPlaca_UF,
            string p_strRegistroContrato_Flag,
            long p_intRenavam,
            decimal p_decValorNotaFiscal,
            bool p_blnVeiculoZero)
        {
            Alienacao = p_blnAlienacao;
            Assistencia = p_blnAssistencia;
            Apreensao = p_blnApreensao;
            ApreensaoMotivo = p_strApreensaoMotivo;
            ApreensaoTipo = p_strApreensaoTipo;
            BloqueiaIL_Flag = p_strBloqueiaIL_Flag;
            Categoria = p_strCategoria;
            Chassi = p_strChassi;
            ChassiRemarcado = p_blnChassiRemarcado;
            Codigo = p_intCodigo;
            CodigoTipoVeiculo = p_intCodigoTipoVeiculo;
            Combustivel = p_strCombustivel;
            Cor = p_strCor;
            DataAlienacao = p_dtmDataAlienacao;
            DataGeracaoAlienacao = p_dtmDataGeracaoAlienacao;
            DataRegAssist = p_dtmDataRegAssist;
            DataInclusaoDUT = p_dtmDataInclusaoDUT;
            EnvioAssistencia_Flag = p_strEnvioAssistencia_Flag;
            FabricacaoAno = p_intFabricacaoAno;
            NumeroGravame = p_intGravame;
            Marca = p_strMarca;
            Modelo = p_strModelo;
            ModeloAno = p_intModeloAno;
            Placa_Codigo = p_strPlaca_Codigo;
            Placa_UF = p_strPlaca_UF;
            RegistroContrato_Flag = p_strRegistroContrato_Flag;
            Renavam = p_intRenavam;
            ValorNotaFiscal = p_decValorNotaFiscal;
            VeiculoZero = p_blnVeiculoZero;
        }

        public bool Alienacao { get; set; }

        public bool Apreensao { get; set; }
      
        public string ApreensaoMotivo { get; set; }

        public string ApreensaoTipo { get; set; }

        public bool Assistencia { get; set; }

        public string BloqueiaIL_Flag { get; set; }

        public string Categoria { get; set; }

        public string Chassi { get; set; }

        public bool ChassiRemarcado { get; set; }

        public long Codigo { get; set; }

        public long CodigoTipoVeiculo { get; set; }

        public string Combustivel { get; set; }

        public string Cor { get; set; }

        public DateTime DataAlienacao { get; set; }

        public DateTime DataGeracaoAlienacao { get; set; }

        public DateTime DataInclusaoDUT { get; set; }

        public DateTime DataRegAssist { get; set; }

        public string EnvioAssistencia_Flag { get; set; }

        public short FabricacaoAno { get; set; }

        public long NumeroGravame { get; set; }

        public string Marca { get; set; }

        public string Modelo { get; set; }

        public short ModeloAno { get; set; }

        public string Placa_Codigo { get; set; }

        public string Placa_UF { get; set; }

        public string RegistroContrato_Flag { get; set; }

        public long Renavam { get; set; }

        public decimal ValorNotaFiscal { get; set; }

        public bool VeiculoZero { get; set; }

        public string CertificadoAtu { get; set; }

        public DateTime DataCertificadoAtu { get; set; }

        public DateTime DataInclusao { get; set; }

        public Gravame Gravame { get; set; }
    }

    public class Gravame
    {
        public int CodigoGravame { get; set; }
        public string CriticaCetip { get; set; }
        public int StatusRegistroCetip { get; set; }
        public DateTime DataRegistro { get; set; }
    }
}