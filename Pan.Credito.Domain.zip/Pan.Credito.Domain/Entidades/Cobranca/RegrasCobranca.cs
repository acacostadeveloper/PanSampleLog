﻿using System;

namespace Pan.Credito.Domain.Entidades.Cobranca
{
    public class RegrasCobranca
    {
        public int CodigoRegraManual { get; set; }
        public int LogImportacaoExecucaoId { get; set; }
        public int Status { get; set; }
        public int QtdDiasAtrasoInicio { get; set; }
        public int QtdDiasAtrasoFim { get; set; }
        public int QtdParcelasQuitacao { get; set; }

        public decimal ValorPercMaximoDescontoParcela { get; set; }
        public decimal ValorPercMaximoDescontoMulta { get; set; }
        public decimal ValorPercMaximoDescontoMora { get; set; }
        public bool AnteriorSetembro2017 { get; set; }
        public int Id { get; set; }
        public DateTime DataCriacao { get; set; }
    }
}