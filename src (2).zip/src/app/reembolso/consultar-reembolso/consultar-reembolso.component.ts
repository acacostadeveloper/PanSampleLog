import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { Reembolso } from '../../models/reembolso.model';
import { Produto } from '../../models/produto.model';
import { ProdutoService } from '../../produto/produto.service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ModalDialogService, SimpleModalComponent } from 'ngx-modal-dialog'; //https://github.com/Greentube/ngx-modal/blob/master/demo/src/app/app.component.ts#L30-L32
import { HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment'
import { ReembolsoConsulta } from '../../models/reembolsoConsulta.model';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';

@Component({
  selector: 'pan-consultar-reembolso',
  templateUrl: './consultar-reembolso.component.html',
  styleUrls: ['./consultar-reembolso.component.css']
})
export class ConsultarReembolsoComponent implements OnInit {
  public reembolsos: ReembolsoConsulta[] = [];
  reembolso = new ReembolsoConsulta();
  produtos: Produto[];
  statusReembolsos = environment.StatusReembolso;
  
  //Filtros:
  filterIdLote: string;
  filterIdProduto: string;
  filterDtInicial: IMyDateModel;
  filterDtFinal: IMyDateModel;
  filterCpfClientes: string;
  filterStatusReembolso: string;
  statusReembolso: string[];

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };

  constructor(
    private reembolsoService: ReembolsoService,
    private produtoService: ProdutoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef
  ) { }

  ngOnInit() {
    this.carregarProdutos();
    
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data;
        }
      ),
      error => {
        console.log(error)
      }
      ;
  }



  mensagemModal(mensagem: string) {
    this.modalService.openDialog(this.viewRef, {
      title: 'Atenção:',
      childComponent: SimpleModalComponent,
      settings: {
        closeButtonClass: 'close theme-icon-close'
      },
      data: {
        text: mensagem
      },
      actionButtons: [
        {
          text: 'Ok',
          buttonClass: 'btn btn-success',
          onAction: () => new Promise((resolve: any) => {
            setTimeout(() => {
              resolve();
            }, 20);
          })
        }]
    });
  }

  openPromptModal(mensagem: string, idReembolso: number) {
    this.modalService.openDialog(this.viewRef, {
      title: 'Atenção',
      childComponent: SimpleModalComponent,
      data: {
        text: mensagem
      },
      settings: {
        closeButtonClass: 'close theme-icon-close'
      },
      actionButtons: [
        {
          text: 'Sim',
          buttonClass: 'btn btn-success',
          onAction: () => {
            if (idReembolso != null) {
              console.log('individual')
              this.deletarReembolso(idReembolso);
            }
            else {
              this.deletarReembolsos();
            }
          }
        },

        {
          text: 'Não',
          buttonClass: 'btn btn-danger',
          onAction: () => new Promise((resolve: any) => {
            setTimeout(() => {
              resolve();
            }, 20);
          })
        }
      ]
    });
  }

  carregarReembolsos() {
    let dtInicial: string;
    let dtFinal: string;
    
    if (this.validarCampos()) {
      this
        .reembolsoService
        .obterReembolsos(
          this.filterIdLote,
          this.filterIdProduto,
          FuncoesApoio.formatarDataInicial(this.filterDtInicial),
          FuncoesApoio.formatarDataFinal(this.filterDtFinal),
          this.filterCpfClientes,
          this.statusReembolso,
        )
        .subscribe(
          (data: ReembolsoConsulta[]) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data;
              if (retorno.status == 502) {
                this.mensagemModal("Não foram encontrados registros com este parametro");
                this.reembolsos = [];
              }
              else {
                this.mensagemModal("Ocorreu o erro: " + data.statusText);
              }

            }
            else {
              this.reembolsos = data;
            }
          }
        ),
        error => {
          this.mensagemModal("Ocorreu o erro: " + error);
        }
        ;
    }
  }

  deletarReembolsos() {

    let ids = this.reembolsos;

    let loop = (id: ReembolsoConsulta) => {
      if (ids.length > 0) {
        if (id.estornar == true) {
          this.reembolsoService.deletarReembolso(id.idReembolso).subscribe(
            (data) => {
              if (data instanceof HttpErrorResponse) {
                this.mensagemModal("Erro ao excluir o reembolso " + id);
              }
              loop(ids.shift())
            }),
            error => {
              if (error instanceof HttpErrorResponse) {
                this.mensagemModal("Erro ao excluir o reembolso " + id);
              }
            }
        }
        else {
          loop(ids.shift())
        }
      }
      else {
        this.mensagemModal("Registros excluídos com sucesso.");
        this.carregarReembolsos();
      }
    }

    loop(ids.shift());
  }

  /* deletarReembolsos() {

    this.reembolsos.forEach(element => {
      if (element.estornar == true) {
        console.log(element);
        this.reembolsoService.deletarReembolso(element.idReembolso).subscribe(
          data => {
            console.log("registro excluido");
          },
          error => {
            if (error instanceof HttpErrorResponse) {
              this.mensagemModal("Ocorreu o erro: " + error.statusText);
            }
          },
        );
      }
    });

    this.mensagemModal("Registros excluídos com sucesso.");
    this.carregarReembolsos();
  }
 */

  deletarReembolso(idReembolso: number) {

    this.reembolsoService.deletarReembolso(idReembolso).subscribe(
      data => {
        this.mensagemModal("Registro excluído com sucesso.");
        this.carregarReembolsos();
      },
      error => {
        if (error instanceof HttpErrorResponse) {
          this.mensagemModal("Ocorreu o erro: " + error.statusText);
        }
      },
    );

  }

  montarStatusReembolso() {
    let retorno = this.statusReembolsos.find(item => item.entrada === this.filterStatusReembolso);
    return retorno.saida.split(",");
  }

  limparFiltros(){
    this.filterIdLote = "";
    this.filterIdProduto = "";
    this.filterDtInicial = null;
    this.filterDtFinal = null;
    this.filterCpfClientes = "";
    this.filterStatusReembolso = null;
    this.statusReembolso = undefined;
  }

  validarCampos() {
    let mensagemRetorno: string = "";

    if (this.filterCpfClientes == undefined) {
      this.filterCpfClientes = "";
    }
    console.log(this.statusReembolso);
    if (this.filterStatusReembolso == undefined || this.filterStatusReembolso == null) {
      this.statusReembolso = [];
    }
    else {
      this.statusReembolso = this.montarStatusReembolso();
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null;
      this.filterDtFinal = null;
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>";
      }
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagemModal(mensagemRetorno);
      return false;
    }
  }
}

