import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { ModalDialogService, SimpleModalComponent } from 'ngx-modal-dialog';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { ReembolsoConsulta } from '../../models/reembolsoConsulta.model';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'pan-aprovar-reembolso',
  templateUrl: './aprovar-reembolso.component.html',
  styleUrls: ['./aprovar-reembolso.component.css']
})
export class AprovarReembolsoComponent implements OnInit {
  public reembolsos: ReembolsoConsulta[] = [];
  reembolso = new ReembolsoConsulta();
  qtdeEstonar: number;
  
  //Filtros:
  filterDtInicial: IMyDateModel;
  filterDtFinal: IMyDateModel;
  
  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };

  constructor(
    private reembolsoService: ReembolsoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef) {

  }

  ngOnInit() {
    this.qtdeEstonar = this.reembolsos.map(reembolsos => reembolsos.estornar).length;
  }

  atualizarInformacoes()
  {
    this.qtdeEstonar = this.reembolsos.map(reembolsos => reembolsos.estornar).filter(x => x == true).length;
  }

  limparFiltros(){
    this.filterDtInicial = null;
    this.filterDtFinal = null;
  }

  validarCampos() {
    let mensagemRetorno: string = "";

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) 
    {
      mensagemRetorno = mensagemRetorno + "- Informe as datas para consulta.<br>";
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>";
      }
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagemModal(mensagemRetorno);
      return false;
    }
  }

  carregarReembolsos() {
    let dtInicial: string;
    let dtFinal: string;
    
    

    if (this.validarCampos()) {
      this
        .reembolsoService
        .obterReembolsos(
          null,
          null,
          FuncoesApoio.formatarDataInicial(this.filterDtInicial),
          FuncoesApoio.formatarDataFinal(this.filterDtFinal),
          "",
          [],
        )
        .subscribe(
          (data: ReembolsoConsulta[]) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data;
              if (retorno.status == 502) {
                this.mensagemModal("Não foram encontrados registros com este parametro");
              }
              else {
                this.mensagemModal("Ocorreu o erro: " + data.statusText);
              }

            }
            else {
              this.reembolsos = data;
              console.log(this.reembolsos.map(reembolsos => reembolsos.estornar).length);
            }
          }
        ),
        error => {
          this.mensagemModal("Ocorreu o erro: " + error);
        }
        ;
    }
  }

  mensagemModal(mensagem: string) {
    this.modalService.openDialog(this.viewRef, {
      title: 'Atenção:',
      childComponent: SimpleModalComponent,
      settings: {
        closeButtonClass: 'close theme-icon-close'
      },
      data: {
        text: mensagem
      },
      actionButtons: [
        {
          text: 'Ok',
          buttonClass: 'btn btn-success',
          onAction: () => new Promise((resolve: any) => {
            setTimeout(() => {
              resolve();
            }, 20);
          })
        }]
    });
  }

}
