import { Component, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { FileUploader, FileItem, ParsedResponseHeaders } from 'ng2-file-upload';
import { ElementRef } from '@angular/core';
import { APP_API } from '../../app.api'
import { ReembolsoService } from '../reembolso.service';
import { Reembolso } from '../../models/reembolso.model';
import { environment } from '../../../environments/environment'
import { FormControl, Validators } from '@angular/forms';
import { ProdutoService } from '../../produto/produto.service';
import { Produto } from '../../models/produto.model';
import { ModalDialogService, SimpleModalComponent } from 'ngx-modal-dialog';
import { Sigla } from '../../models/sigla.model';
import { SiglaService } from '../../sigla/sigla.service';
import { HttpErrorResponse } from '@angular/common/http';


const URL = APP_API + 'reembolso/upload';

@Component({
  selector: 'pan-incluir-reembolso',
  templateUrl: './incluir-reembolso.component.html',
  styleUrls: ['./incluir-reembolso.component.css']
})
export class IncluirReembolsoComponent implements OnInit {
  @ViewChild("txtUploader")
  private txtUploader: ElementRef;

  @ViewChild("form")
  private form: ElementRef;

  @ViewChild("txtValor")
  private txtValor: ElementRef;

  @ViewChild("txtCpf")
  private txtCpf: ElementRef;

  rateControl = new FormControl("", [Validators.max(100), Validators.min(0)])

  nomeCliente: string;
  reembolso = new Reembolso();
  produtos: Produto[];
  siglas: Sigla[];

  meses = environment.meses;
  anoAtual: number = (new Date()).getFullYear();
  anos: number[] = [];

  public hasBaseDropZoneOver: boolean = false;
  public hasAnotherDropZoneOver: boolean = false;
  public successUpLoad: any;
  public errorUpLoad: any;
  public uploader: FileUploader = new FileUploader({ url: URL, removeAfterUpload: false, queueLimit: 1, });

  public fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  public fileOverAnother(e: any): void {
    this.hasAnotherDropZoneOver = e;
  }

  constructor(
    private reembolsoService: ReembolsoService,
    private produtoService: ProdutoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef,
    private siglaService: SiglaService,
  ) { }

  ngOnInit():
    void {
    this.uploader.onErrorItem = (item, response, status, headers) => this.onErrorItem(item, response, status, headers);
    this.uploader.onSuccessItem = (item, response, status, headers) => this.onSuccessItem(item, response, status, headers);
    this.carregarAnos();
    this.carregarProdutos();
    this.carregarSiglas();
    this.inicializaCombos();
  }

  onSuccessItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    this.successUpLoad = JSON.parse(response); //success server response
    console.log("valor sucesso:" + this.successUpLoad);
  }

  onErrorItem(item: FileItem, response: string, status: number, headers: ParsedResponseHeaders): any {
    this.errorUpLoad = JSON.parse(response); //error server response
    this.errorUpLoad = this.errorUpLoad.Exception._errors[0]["<ErrorMessage>k__BackingField"];//captura somente mensagem
  }

  upLoadFile() {
    this.errorUpLoad = undefined;
    this.successUpLoad = undefined;
    this.uploader.clearQueue();
    this.txtUploader.nativeElement.click();
  }
  inserirReembolso() {
    if (this.validaCampos()) {
      this.reembolso.contrato.cliente.tipoPessoa = "F";
      this.reembolso.departamento.codigoDepartamento = environment.codigoDepartamento;
      this.reembolso.contrato.coligada.codigoColigada = environment.codigoColigada;

      //retirar colocado para teste
      this.reembolso.usuario.codigoUsuario = "Teste";

      this.reembolsoService.adicionarReembolso(this.reembolso).subscribe(
        data => {
          this.mensagemModal("Registro inserido com sucesso");
        },
        error => {
          if (error instanceof HttpErrorResponse) {
            this.mensagemModal("Ocorreu o erro: " + error.statusText);
          }
        },
      );
    }
  }

  mensagemModal(mensagem: string) {
    this.modalService.openDialog(this.viewRef, {
      title: 'Atenção:',
      childComponent: SimpleModalComponent,
      settings: {
        closeButtonClass: 'close theme-icon-close'
      },
      data: {
        text: mensagem
      }
    });
  }

  validaCampos() {
    let mensagemRetorno: string = "";

    if (this.reembolso.contrato.cliente.nomeCliente == "" ||
      this.reembolso.contrato.cliente.nomeCliente == undefined ||
      this.reembolso.contrato.cliente.nomeCliente == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Nome deve ser preenchido.<br>";
    }

    if (this.reembolso.contrato.numeroContrato == "" ||
      this.reembolso.contrato.numeroContrato == undefined ||
      this.reembolso.contrato.numeroContrato == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Número Contrato deve ser preenchido.<br>";
    }

    if (this.reembolso.valorReembolso == "" ||
      this.reembolso.valorReembolso == undefined ||
      this.reembolso.valorReembolso == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Valor Reembolso deve ser preenchido.<br>";
    }

    if (this.reembolso.contrato.convenio == "" ||
      this.reembolso.contrato.convenio == undefined ||
      this.reembolso.contrato.convenio == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Convênio deve ser preenchido.<br>";
    }

    if (this.reembolso.mesCompetencia == undefined ||
      this.reembolso.mesCompetencia == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Mês deve ser preenchido.<br>";
    }

    if (this.reembolso.anoCompetencia == undefined ||
      this.reembolso.anoCompetencia == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Ano deve ser preenchido.<br>";
    }

    if (this.reembolso.contrato.cliente.numeroCpfCnpj == "" ||
      this.reembolso.contrato.cliente.numeroCpfCnpj == undefined ||
      this.reembolso.contrato.cliente.numeroCpfCnpj == null) {
      mensagemRetorno = mensagemRetorno + "- Campo CPF deve ser preenchido.<br>";
    }

    if (this.reembolso.sigla.codigoSigla == "" ||
      this.reembolso.sigla.codigoSigla == undefined ||
      this.reembolso.sigla.codigoSigla == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Sigla deve ser preenchido.<br>";
    }

    if (this.reembolso.processoRegistro.codigoProcessoRegistro == "" ||
      this.reembolso.processoRegistro.codigoProcessoRegistro == undefined ||
      this.reembolso.processoRegistro.codigoProcessoRegistro == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Código Processo Entrada deve ser preenchido.<br>";
    }

    if (this.reembolso.contrato.produto.codigoProduto == "" ||
      this.reembolso.contrato.produto.codigoProduto == undefined ||
      this.reembolso.contrato.produto.codigoProduto == null) {
      mensagemRetorno = mensagemRetorno + "- Campo Produto deve ser preenchido.<br>";
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagemModal(mensagemRetorno);
      return false;
    }
  }

  carregarAnos() {
    for (let i = this.anoAtual - 10; i < this.anoAtual; i++) {
      this.anos.push(i + 1);
    }
  }

  carregarSiglas() {
    this
      .siglaService
      .obterSiglas()
      .subscribe(
        (data: Sigla[]) => {
          this.siglas = data;
        }
      ),
      error => {
        console.log(error)
      }
      ;
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data;
        }
      ),
      error => {
        console.log(error)
      };
  }
  inicializaCombos() {
    this.reembolso.contrato.produto.codigoProduto = null;
    this.reembolso.mesCompetencia = null;
    this.reembolso.anoCompetencia = this.anoAtual;
    this.reembolso.sigla.codigoSigla = null;
  }

  limparCampos() {
    this.reembolso = new Reembolso();
    this.inicializaCombos();
    this.txtValor.nativeElement.value = "";
    this.txtCpf.nativeElement.value = "";
  }

}


