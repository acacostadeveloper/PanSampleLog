export class ContaCredito {
    numeroBanco: string
    numeroAgencia: string
    digitoAgencia: string
    numeroConta: string
    digitoConta:string
    tipoConta: string
    fraude: string
}