export class Endereco {
    nomeLogradouro: string
    numero: string
    complemento: string
    cep: string
    bairro: string
    cidade: string
    estado: string
}