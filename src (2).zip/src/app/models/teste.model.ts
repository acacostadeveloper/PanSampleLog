export class Reembolso {
  idReembolso: number
};