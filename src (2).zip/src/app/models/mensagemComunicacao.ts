export class MensagemComunicacao {
    tipoComunicacao: string
    mensagemComunicacao: string
    numeroVersao: string
}