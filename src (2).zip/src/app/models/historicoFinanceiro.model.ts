export class HistoricoFinanceiro {
    motivo: string
    origemInformacao: string
    codigoHistoricoFinanceiro: string
}