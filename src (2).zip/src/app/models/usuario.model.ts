export class Usuario {
  codigoUsuario: string
  nomeUsuario: string
}