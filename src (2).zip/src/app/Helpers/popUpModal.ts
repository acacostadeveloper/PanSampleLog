import { ModalDialogService, SimpleModalComponent } from "ngx-modal-dialog";
import { ViewContainerRef } from "@angular/core";

export class PopUpModal{

    constructor(
        private modalService: ModalDialogService,
        private viewRef: ViewContainerRef
      ) { }

    mensagemModal(mensagem: string) {
        this.modalService.openDialog(this.viewRef, {
          title: 'Atenção:',
          childComponent: SimpleModalComponent,
          settings: {
            closeButtonClass: 'close theme-icon-close'
          },
          data: {
            text: mensagem
          },
          actionButtons: [
            {
              text: 'Ok',
              buttonClass: 'btn btn-success',
              onAction: () => new Promise((resolve: any) => {
                setTimeout(() => {
                  resolve();
                }, 20);
              })
            }]
        });
      }
    
      openPromptModal(mensagem: string, callback: () => any) {
        this.modalService.openDialog(this.viewRef, {
          title: 'Atenção',
          childComponent: SimpleModalComponent,
          data: {
            text: mensagem
          },
          settings: {
            closeButtonClass: 'close theme-icon-close'
          },
          actionButtons: [
            {
              text: 'Sim',
              buttonClass: 'btn btn-success',
              onAction: () => {
                callback();
              }
            },
    
            {
              text: 'Não',
              buttonClass: 'btn btn-danger',
              onAction: () => new Promise((resolve: any) => {
                setTimeout(() => {
                  resolve();
                }, 20);
              })
            }
          ]
        });
      }
    
}