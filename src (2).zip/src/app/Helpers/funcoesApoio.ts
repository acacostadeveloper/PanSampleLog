import { IMyDateModel } from "mydatepicker";

export class FuncoesApoio {
    static verificarDataFinalMenor(dataInicial, dataFinal) {
        let _dataInicial: IMyDateModel;
        let _dataFinal: IMyDateModel;

        _dataInicial = dataInicial;
        _dataFinal = dataFinal;

        if (_dataFinal.epoc < _dataInicial.epoc) {
            return true;
        }
        else {
            return false;
        }
    }

    static formatarDataInicial(date: IMyDateModel) {
        let retorno: string
        if (date == undefined || date == null) {
            retorno = "";
        }
        else {
            retorno = date.date.month + "/" + date.date.day + "/" + date.date.year + " 00:00:00";
        }
        return retorno;
    }

    static formatarDataFinal(date: IMyDateModel) {
        let retorno: string
        if (date == undefined || date == null) {
            retorno = "";
        }
        else {
            retorno = date.date.month + "/" + date.date.day + "/" + date.date.year + " 23:59:59";
        }
        return retorno;
    }
}