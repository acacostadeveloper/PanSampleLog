import { Usuario } from "../models/usuario.model";
import { Departamento } from "../models/departamento.model";
import { Contrato } from "../models/contrato.model";
import { Sigla } from "../models/sigla.model";
import { ProcessoRegistro } from "../models/processoRegistro.model";

export interface IReembolso {
    idReembolso: number;
    usuario: Usuario;
    departamento: Departamento;
    contrato: Contrato;
    dataSolicitacao: string;
    valorReembolso: string;
    mesCompetencia: number;
    anoCompetencia: number;
    sigla: ISigla;
    idLote: number;
    statusReembolso: string;
    processoRegistro: ProcessoRegistro;
  };

  export interface ISigla {
    codigoSigla: string
    nomeSigla: string
}