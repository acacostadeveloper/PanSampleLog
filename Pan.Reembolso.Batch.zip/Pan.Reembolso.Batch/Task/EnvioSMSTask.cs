﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using System.Xml;
using System.IO;

namespace Pan.Reembolso.Batch
{
    internal class EnvioSMSTask
    {
        private ILogRepository _LogRepository;
        private IClienteRepository _ClienteRepository;
        private IComunicacaoRepository _ComunicacaoRepository;
        private ISmsLobApp _smsLobApp;
        private int _loteComunicacao = -1;

        public EnvioSMSTask(ILogRepository LogRepository,
            IClienteRepository ClienteRepository,
            IComunicacaoRepository ComunicacaoRepository,
            ISmsLobApp smsLobApp)
        {
            _LogRepository = LogRepository;
            _ClienteRepository = ClienteRepository;
            _ComunicacaoRepository = ComunicacaoRepository;
            _smsLobApp = smsLobApp;
        }

        internal string DoWork()
        {
            _loteComunicacao = -1;
            LogRepository l = new LogRepository();

            Console.WriteLine("EnvioSMSTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioSMSTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("EnvioSMSTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioSMSTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioSMSTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (var item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioSMSTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioSMSTask.DoWork(): task complete.", MessageError = "" });

            return "EnvioSMSTask.DoWork(): task complete.";
        }

        internal IList<ClienteReembolsos> GetCollection()
        {
            return _ClienteRepository.ConsultarClientesASeremComunicados();
        }

        private void ItemProcess(ClienteReembolsos clienteReembolsos)
        {
            var cli = clienteReembolsos.cliente;
                var resposta = _smsLobApp.SendSMS(cli.numeroCpfCnpj,cli.tipoPessoa,cli.numeroDDDCelular+cli.numeroCelular,cli.nomeCliente);

            if (resposta.Result.CodigoRetorno == 0)
            {
                var comunicacao = new Comunicacao()
                {
                    idLoteComunicacao = _loteComunicacao,
                    indicadorEfetivacao = ReembolsoTypes.StatusComunicacaoType.Enviado.ToString(),
                    dataEnvioComunicacao = DateTime.Now,
                    descricaoErro = resposta.Result.Descricao,
                    protocolo =  resposta.Result.IdMensagemEntrada.ToString(),
                    mensagemComunicacao = _ComunicacaoRepository.ObterMensagemComunicacao(ReembolsoTypes.ComunicacaoType.SMS)
                };
                _ComunicacaoRepository.IncluirComunicacao(comunicacao, clienteReembolsos.reembolsos);
                _loteComunicacao = comunicacao.idLoteComunicacao;
            }
                
        }
    }

}
