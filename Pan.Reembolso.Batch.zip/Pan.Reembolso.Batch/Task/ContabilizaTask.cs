﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Iterator;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;


namespace Pan.Reembolso.Batch
{
    internal class ContabilizaTask
    {
        private IReembolsoRepository _objReembolsoRep;

        public ContabilizaTask()
        {
            _objReembolsoRep = GetReembolsoRepository();
        }

        private IReembolsoRepository GetReembolsoRepository()
        {
            return new ReembolsoRepository();
        }

        internal string DoWork()
        {
            LogRepository l = new LogRepository();
            
            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Getting collection...");
            l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });
            ConcreteAggregate a = GetCollection();

            Iterator.Iterator i = a.CreateIterator();

            Console.WriteLine("ContabilizaTask.DoWork(): Iterating over collection...");
            l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Iterating over collection...", MessageError = "" });

            object item = i.First();
            while (item != null)
            {
                Console.WriteLine(item);
                item = i.Next();
            }

            l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "ContabilizaTask.DoWork(): task complete.", MessageError = "" });

            return "ContabilizaTask.DoWork(): task complete.";
        }

        internal static ConcreteAggregate GetCollection()
        {
            ConcreteAggregate a = new ConcreteAggregate();

            // HistoricoReembolsoRepository.ObterContabilReembolso()

            a[0] = "Item A";
            a[1] = "Item B";
            a[2] = "Item C";
            a[3] = "Item D";

            return a;
        }

    }
}
