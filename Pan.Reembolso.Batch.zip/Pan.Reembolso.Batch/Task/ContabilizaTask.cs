﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration; 
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Batch
{
    internal class ContabilizaTask
    {
        private IContabilRepository _ContabilRepository;
        private IHistoricoReembolsoRepository _HistoricoReembolsoRepository;
        private IReembolsoRepository _ReembolsoRepository;
        private IContabilLobApp _ContabilLobApp;
        private ILogRepository _LogRepository;
        private IProcessoRegistroRepository _processoRegistroRepository;

        public ContabilizaTask(IContabilRepository ContabilRepository,
                               IHistoricoReembolsoRepository HistoricoReembolsoRepository,
                               IReembolsoRepository ReembolsoRepository,
                               IContabilLobApp ContabilLobApp,
                               ILogRepository LogRepository,
                               IProcessoRegistroRepository processoRegistroRepository)
        {
            _ContabilRepository = ContabilRepository;
            _HistoricoReembolsoRepository = HistoricoReembolsoRepository;
            _ReembolsoRepository = ReembolsoRepository;
            _ContabilLobApp = ContabilLobApp;
            _LogRepository = LogRepository;
            _processoRegistroRepository = processoRegistroRepository;
        }

        internal string DoWork()
        {           
            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilizaTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });
            var iterator = GetCollection();

            if (iterator.Count > 0)
            {
                Console.WriteLine("ContabilizaTask.DoWork(): Iterating over collection...");
                _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilizaTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Iterating over collection...", MessageError = "" });

                string remessa = GetRemessa();
                int registro = 1;
                string literalRegistro = string.Empty;

                foreach (HistoricoReembolso item in iterator)
                {
                    if (registro == 1)
                        literalRegistro = "PRIMEIRO";

                    if (iterator.Count == 1)
                        literalRegistro = "PRIMEIRO_E_ULTIMO";

                    if (iterator.Count == registro)
                        literalRegistro = "ULTIMO";

                    ItemProcess(item, remessa, registro, literalRegistro);
                    literalRegistro = "SUBSEQUENTES";
                    registro++;
                }

                SaveRemessa(remessa);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilizaTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "ContabilizaTask.DoWork(): task complete.", MessageError = "" });

            return "ContabilizaTask.DoWork(): task complete.";
        }

        private void SaveRemessa(string remessa)
        {
            _ContabilRepository.SaveRemessa(Int32.Parse(remessa));
        }

        private string GetRemessa()
        {
            int next = _ContabilRepository.GetNextRemessa();
            return  next.ToString().PadLeft(6,'0');
        }

        private IList<HistoricoReembolso> GetCollection()
        {
            return _HistoricoReembolsoRepository.ObterContabilReembolso();
        }

        private void ItemProcess(HistoricoReembolso value, string remessa, int numeroRegistro, string literalRegistro)
        {
            var reembolso = _ReembolsoRepository.ObterReembolso(value.reembolso);
            var movimentoContabil = new MovimentoContabil
            {
                movimentoPadrao = _ContabilRepository.ObterMovimentoContabilPadrao(reembolso.contrato.produto.codigoProduto),
                codigoUsuario = reembolso.usuarioInclusao,
                dataDocumento = String.Format("{0:MM/dd/yyyy}", value.dataEvento),
                dataIntegracao = DateTime.Now,
                dataLancamento = String.Format("{0:MM/dd/yyyy}", value.dataEvento),
                dataSistema = String.Format("{0:MM/dd/yyyy}", DateTime.Now),
                dataUltimaAtualizacao = string.Empty,
                descricaoComplemento1 = reembolso.processoRegistro.processoRegistro,
                nomeArquivoIntegrado = String.Format("SSA_{0:yyyy-MM-dd}", value.dataEvento),
                numeroOrigem = numeroRegistro.ToString().PadLeft(10, '0'),
                numeroRegistro = literalRegistro,
                numeroRemessa = remessa,
                valorEntrada = reembolso.valorReembolso,
                idHistoricoReembolso = value.idHistoricoReembolso
            };

            switch (value.evento.fluxo)
            {
                case "ENTRADA":
                    movimentoContabil.numeroCentroCustoCredito = (reembolso.processoRegistro.centroCusto ?? "0000000"); 
                    movimentoContabil.numeroCentroCustoDebito = (reembolso.processoRegistro.centroCusto ?? "0000000");
                    movimentoContabil.numeroModelo = reembolso.processoRegistro.modeloContabil.PadLeft(5,'0');
                    movimentoContabil.descricaoHistorico = _ContabilLobApp.ObterHistoricoModelo(reembolso.processoRegistro.modeloContabil.PadLeft(5, '0'));
                    break;
                case "SAIDA":

                    var processoRegistro = _processoRegistroRepository.ObterProcessoRegistroPorCodigoFluxo(value.ProcessoRegistro, ReembolsoConstantes.FLUXO_SAIDA) ?? reembolso.processoRegistro; 

                    movimentoContabil.numeroCentroCustoCredito = (processoRegistro.centroCusto ?? "0000000");
                    movimentoContabil.numeroCentroCustoDebito = (processoRegistro.centroCusto ?? "0000000");
                    movimentoContabil.numeroModelo = processoRegistro.modeloContabil;
                    movimentoContabil.descricaoHistorico = _ContabilLobApp.ObterHistoricoModelo(processoRegistro.modeloContabil.PadLeft(5, '0'));
                    break;

                case "REVERSAO_ENTRADA":
                    movimentoContabil.numeroCentroCustoCredito = (reembolso.processoRegistro.centroCusto ?? "0000000");
                    movimentoContabil.numeroCentroCustoDebito = (reembolso.processoRegistro.centroCusto ?? "0000000");
                    movimentoContabil.numeroModelo = reembolso.processoRegistro.modeloContabilReversao.PadLeft(5, '0');
                    movimentoContabil.descricaoHistorico = _ContabilLobApp.ObterHistoricoModelo(reembolso.processoRegistro.modeloContabilReversao.PadLeft(5, '0'));
                    break;
                default:
                    break;
            }

            IDictionary<string, string> contabilizado = _ContabilLobApp.IntegrarMovimentoContabil(movimentoContabil);
            _ContabilRepository.IncluirHistoricoContabil(movimentoContabil, contabilizado);

            if (contabilizado["erroSucesso"] == "SUCESSO")
            {
                value.statusContabil = "INTEGRADO";
                _HistoricoReembolsoRepository.AtualizarHistoricoContabilizado(value);
            }
        }

    }
}
