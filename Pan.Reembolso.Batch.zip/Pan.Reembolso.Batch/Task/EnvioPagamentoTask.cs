﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;

namespace Pan.Reembolso.Batch
{
    internal class EnvioPagamentoTask
    {
        private ILogRepository _LogRepository;
        private IPagamentoRepository _pagamentoRepository;
        private IMensagemRepository _mensagemRepository;
        private ITesourariaLobApp _tesourariaLobApp;
        private IReembolsoRepository _reembolsoRepository;
        private IHistoricoReembolsoRepository _historicoReembolsoRepository;
        private IEventoRepository _eventoRepository;

        public EnvioPagamentoTask(ILogRepository LogRepository, 
                                  IPagamentoRepository pagamentoRepository,
                                  IMensagemRepository mensagemRepository,
                                  ITesourariaLobApp tesourariaLobApp,
                                  IReembolsoRepository reembolsoRepository,
                                  IHistoricoReembolsoRepository historicoReembolsoRepository,
                                  IEventoRepository eventoRepository)
        {
            _LogRepository = LogRepository;
            _pagamentoRepository = pagamentoRepository;
            _mensagemRepository = mensagemRepository;
            _tesourariaLobApp = tesourariaLobApp;
            _reembolsoRepository = reembolsoRepository;
            _historicoReembolsoRepository = historicoReembolsoRepository;
            _eventoRepository = eventoRepository;
        }

        internal string DoWork()
        {
            Console.WriteLine("EnvioPagamentoTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork() Getting collection...", MessageError = "" });

            var iterator = GetCollection();
             
            Console.WriteLine("EnvioPagamentoTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): Iterating over collection...", MessageError = "" });
             
            foreach (Pagamento item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): task complete.", MessageError = "" });

            return "EnvioPagamentoTask.DoWork(): task complete.";
        }

        internal IList<Pagamento> GetCollection()
        {
            return _pagamentoRepository.ObterPagamentosPorStatus(ReembolsoTypes.StatusPagamentoType.Aprovado);
        }

        private void ItemProcess(Pagamento value)
        {
            value.tipoPagamento = ReembolsoTypes.PagamentoType.TED.ToString();
            value.mensagem = _mensagemRepository.ObterMensagemPadrao();
            value.mensagem.dataRegistro = DateTime.Now;
            value.mensagem.valorTransferencia = value.valorPagamento;
            value.mensagem.favorecido = value.favorecido;
            value.mensagem.numeroOrigem = value.numeroPagamento.ToString();

            IDictionary<string, string> result = _tesourariaLobApp.RequisitarTransferenciaEletronica(value.mensagem);

            if (result["erroSucesso"] == "SUCESSO")
            {
                value.mensagem.numeroRequisicao = result["numeroRequisicao"];
                value.mensagem.statusMensagem = ReembolsoTypes.StatusMensagemTransferenciaType.Integrado.ToString();

                _mensagemRepository.PersistirMensagem(value);

                value.statusPagamento = ReembolsoTypes.StatusPagamentoType.EnviadoPagamento.ToString();

                _pagamentoRepository.PersistirPagamento(value);

                foreach(Entidades.Reembolso reemb in value.listaReembolsos)
                {
                    string statusAtual = reemb.statusReembolso;

                    _reembolsoRepository.AtualizarStatusReembolso(reemb.idReembolso, ReembolsoTypes.StatusReembolsoType.EmTransito);

                    Evento eventoPag = _eventoRepository.ObterEvento("ENVIO DE PAGAMENTO");
                    HistoricoReembolso historico = new HistoricoReembolso()
                    {
                        evento = eventoPag,
                        dataEvento = DateTime.Now,
                        reembolso = reemb.idReembolso,
                        statusIni = statusAtual,
                        statusFim = ReembolsoTypes.StatusReembolsoType.EmTransito.ToString(),
                        usuarioInclusao = "Processo batch",
                        statusContabil = ""
                    };

                    _historicoReembolsoRepository.PersistirHistoricoReembolso(historico);
                }
            }

            if (result["erroSucesso"] == "ERRO")
            {
                value.mensagem.statusMensagem = "";

                _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.ItemProcess()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Erro ao enviar o pagmento " + value.numeroPagamento, MessageError = result["mensagem"] });

                //tratar pagamentos 

                // tratar reembolsos

            }

        }
    }
}
