﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Iterator;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Log.Interface;

namespace Pan.Reembolso.Batch
{
    internal class EnvioPagamentoTask
    {
        private ILogRepository _LogRepository;

        public EnvioPagamentoTask(ILogRepository LogRepository)
        {
            _LogRepository = LogRepository;
        }

        internal string DoWork()
        {
            LogRepository l = new LogRepository();

            Console.WriteLine("EnvioPagamentoTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("EnvioPagamentoTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (PagamentoReembolso item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): task complete.", MessageError = "" });

            return "EnvioPagamentoTask.DoWork(): task complete.";
        }

        internal IList<PagamentoReembolso> GetCollection()
        {
            return null;
        }

        private void ItemProcess(PagamentoReembolso value)
        {

        }
    }
}
