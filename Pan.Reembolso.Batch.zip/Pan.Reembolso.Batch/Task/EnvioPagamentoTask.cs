﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Servico.Helper.Interface;

namespace Pan.Reembolso.Batch
{
    internal class EnvioPagamentoTask
    {
        private ILogRepository _LogRepository;
        private IPagamentoRepository _pagamentoRepository;
        private IMensagemRepository _mensagemRepository;
        private ITesourariaLobApp _tesourariaLobApp;
        private IReembolsoStatusHelper _reembolsoStatusHelper;
        private IMotivoBloqueioRepository _MotivoBloqueioRepository;

        public EnvioPagamentoTask(ILogRepository LogRepository,
                                  IPagamentoRepository pagamentoRepository,
                                  IMensagemRepository mensagemRepository,
                                  ITesourariaLobApp tesourariaLobApp,
                                  IReembolsoStatusHelper reembolsoStatusHelper,
                                  IMotivoBloqueioRepository motivoBloqueioRepository)
        {
            _LogRepository = LogRepository;
            _pagamentoRepository = pagamentoRepository;
            _mensagemRepository = mensagemRepository;
            _tesourariaLobApp = tesourariaLobApp;
            _reembolsoStatusHelper = reembolsoStatusHelper;
            _MotivoBloqueioRepository = motivoBloqueioRepository;
        }

        internal string DoWork()
        {
            Console.WriteLine("EnvioPagamentoTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork() Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("EnvioPagamentoTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (Pagamento item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): task complete.", MessageError = "" });

            return "EnvioPagamentoTask.DoWork(): task complete.";
        }

        internal IList<Pagamento> GetCollection()
        {
            return _pagamentoRepository.ObterPagamentosPorStatus(ReembolsoTypes.StatusPagamentoType.Aprovado);
        }

        private void ItemProcess(Pagamento value)
        {
            try
            {
                value.tipoPagamento = ReembolsoTypes.PagamentoType.TED.ToString();
                value.mensagem = _mensagemRepository.ObterMensagemPadrao();
                value.mensagem.dataRegistro = DateTime.Now;
                value.mensagem.valorTransferencia = value.valorPagamento;
                value.mensagem.nomeFavorecido = value.favorecido.nome;
                value.mensagem.tipoPessoaFavorecido = value.favorecido.tipoPesssoa;
                value.mensagem.numeroCpfCnpjFavorecido = value.favorecido.numeroCpfCnpj;
                value.mensagem.numeroSequenciaFavorecido = value.favorecido.sequenciaCpfCnpj;
                value.mensagem.tipoContaFavorecido = value.favorecido.contaCredito.tipoConta;
                value.mensagem.numeroBancoFavorecido = value.favorecido.contaCredito.numeroBanco;
                value.mensagem.numeroAgenciaFavorecido = value.favorecido.contaCredito.numeroAgencia;
                value.mensagem.digitoAgenciaFavorecido = value.favorecido.contaCredito.digitoAgencia;
                value.mensagem.numeroContaFavorecido = value.favorecido.contaCredito.numeroConta;
                value.mensagem.digitoContaFavorecido = value.favorecido.contaCredito.digitoConta;
                value.mensagem.numeroOrigem = value.numeroPagamento.ToString();

                var result = _tesourariaLobApp.RequisitarTransferenciaEletronica(value.mensagem);

                MotivoBloqueio motivoBloqueio = null;

                ReembolsoTypes.StatusReembolsoType statusReembolso = ReembolsoTypes.StatusReembolsoType.Undefined;

                string msgError = string.Empty;

                var listaIdsReembolsos = value.listaReembolsos.Select(s => s.numeroReembolso).ToList();

                if (result["erroSucesso"] == "SUCESSO")
                {
                    value.mensagem.numeroRequisicao = result["numeroRequisicao"];

                    value.mensagem.statusMensagem = ReembolsoTypes.StatusMensagemTransferenciaType.Integrada.ToString();
                    value.statusPagamento = ReembolsoTypes.StatusPagamentoType.EnviadoPagamento.ToString();
                    statusReembolso = ReembolsoTypes.StatusReembolsoType.EmTransito;
                }

                if (result["erroSucesso"] == "ERRO")
                {
                    _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.ItemProcess()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Erro ao enviar o pagmento " + value.numeroPagamento, MessageError = result["mensagem"] });

                    motivoBloqueio = _MotivoBloqueioRepository.ObterMotivoBloqueio(ReembolsoTypes.MotivoBloqueioType.PagamentoErroIntegracao);

                    value.mensagem.statusMensagem = ReembolsoTypes.StatusMensagemTransferenciaType.ErroIntegracao.ToString();
                    value.statusPagamento = ReembolsoTypes.StatusPagamentoType.Recusado.ToString();
                    statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado;

                    msgError = motivoBloqueio.descricaoMotivoBloqueio;
                }

                _mensagemRepository.PersistirMensagem(value.mensagem, value.numeroPagamento);

                _pagamentoRepository.AtualizarPagamento(value);

                _reembolsoStatusHelper.AlterarStatusReembolso(listaIdsReembolsos, statusReembolso, msgError, "ENVIO DE PAGAMENTO", motivoBloqueio, "", 0, "EnvioPagamentoTask");

            }
            catch (Exception ex)
            {
                _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork() Processing Item...", MessageError = ex.Message + " -- " + ex.StackTrace });
            }
        }
    }
}
