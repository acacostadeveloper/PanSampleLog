﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using System.Xml;

namespace Pan.Reembolso.Batch
{
    internal class ComunicaoTask
    {
        private ILogRepository _LogRepository;
        private IClienteRepository _ClienteRepository;
        private IGraficaLobApp _GraficaLobApp;

        public ComunicaoTask(ILogRepository LogRepository,
            IClienteRepository ClienteRepository,
            IGraficaLobApp GraficaLobApp
            )
        {
            _LogRepository = LogRepository;
            _ClienteRepository = ClienteRepository;
            _GraficaLobApp = GraficaLobApp;
        }

        internal string DoWork()
        {
            
            //LogRepository l = new LogRepository();

            Console.WriteLine("ComunicaoTask.DoWork(): Getting collection...");
            //_LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ComunicaoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("ComunicaoTask.DoWork(): Iterating over collection...");
            //_LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ComunicaoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "ComunicaoTask.DoWork(): Iterating over collection...", MessageError = "" });

            XmlDocument doc = new XmlDocument();
            XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(docNode);

            XmlNode rootNode = doc.CreateElement("root");
            
            foreach (Cliente item in iterator)
            {
                //verificar se já existe 
                //se já existe consultar resposta
                //  se existir resposta alterar status da comunicação
                
                //se não existir criar novo documento de envio
                var grafica = new GraficaEnvio()
                {
                    identificador = _ClienteRepository.ObterIdCliente(item.numeroCpfCnpj).ToString(),
                    bairro = item.endereco.bairro,
                    cep = item.endereco.cep,
                    cidade = item.endereco.cidade,
                    logradouro = item.endereco.nomeLogradouro,
                    nome = item.nomeCliente,
                    numero = item.endereco.numero,
                    estado = item.endereco.estado,
                    complemento = item.endereco.complemento
                };
                ItemProcess(grafica, doc);
                Console.WriteLine("ComunicaoTask.DoWork(): Carta gerada...");
            }
            doc.AppendChild(rootNode);
            //checar se algum nó foi criado
            //se algum nó foi criado salvar documento

            //doc.Save();



            //_LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ComunicaoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "ComunicaoTask.DoWork(): task complete.", MessageError = "" });

            return "ComunicaoTask.DoWork(): task complete.";
        }

        internal IList<Cliente> GetCollection()
        {
            return _ClienteRepository.ConsultarClientesASeremComunicados();
        }

        private void ItemProcess(GraficaEnvio graficaEnvio, XmlDocument doc)
        {
            XmlNode entryNode = doc.CreateElement("carta");
            
            WriteXmlNode(doc, entryNode, "identificador", graficaEnvio.identificador ?? "");
            WriteXmlNode(doc, entryNode, "nome", graficaEnvio.nome ?? "");
            WriteXmlNode(doc, entryNode, "logradouro", graficaEnvio.logradouro ?? "");
            WriteXmlNode(doc, entryNode, "numero", graficaEnvio.numero ?? "");
            WriteXmlNode(doc, entryNode, "complemento", graficaEnvio.complemento ?? "");
            WriteXmlNode(doc, entryNode, "bairro", graficaEnvio.bairro ?? "");
            WriteXmlNode(doc, entryNode, "cep", graficaEnvio.cep ?? "");
            WriteXmlNode(doc, entryNode, "cidade", graficaEnvio.cidade ?? "");
            WriteXmlNode(doc, entryNode, "estado", graficaEnvio.estado ?? "");
            doc.AppendChild(entryNode);
        }

        private static void WriteXmlNode(XmlDocument doc, XmlNode entryNode, string name, string value)
        {
            XmlNode createdNode = doc.CreateElement(name);

            if (value != String.Empty)
                createdNode.AppendChild(doc.CreateTextNode(value));

            entryNode.AppendChild(createdNode);
        }
    }
}
