﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using System.Xml;
using System.IO;
using System.Configuration;

namespace Pan.Reembolso.Batch
{
    internal class EnvioCartaTask
    {
        private ILogRepository _LogRepository;
        private IClienteRepository _ClienteRepository;
        private IComunicacaoRepository _ComunicacaoRepository;
        private int _loteComunicacao = -1;

        public EnvioCartaTask(ILogRepository LogRepository,
            IClienteRepository ClienteRepository,
            IComunicacaoRepository ComunicacaoRepository)
        {
            _LogRepository = LogRepository;
            _ClienteRepository = ClienteRepository;
            _ComunicacaoRepository = ComunicacaoRepository;
        }

        internal string DoWork()
        {
            _loteComunicacao = -1;
            LogRepository l = new LogRepository();

            Console.WriteLine("EnvioCartaTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioCartaTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("EnvioCartaTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioCartaTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioCartaTask.DoWork(): Iterating over collection...", MessageError = "" });

            XmlDocument doc = new XmlDocument();
            XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(docNode);

            XmlNode rootNode = doc.CreateElement("root");

            foreach (var item in iterator)
            {
                var grafica = new GraficaEnvio()
                {
                    identificador = _ClienteRepository.ObterIdCliente(item.cliente.numeroCpfCnpj).ToString("000000000"),
                    bairro = item.cliente.endereco.bairro,
                    cep = long.Parse(item.cliente.endereco.cep).ToString("00000-000"),
                    cidade = item.cliente.endereco.cidade,
                    logradouro = item.cliente.endereco.nomeLogradouro,
                    nome = item.cliente.nomeCliente,
                    numero = item.cliente.endereco.numero,
                    estado = item.cliente.endereco.estado,
                    complemento = item.cliente.endereco.complemento
                };
                ItemProcess(doc, rootNode, grafica, item.reembolsos);
            }

            doc.AppendChild(rootNode);

            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var directoryPath = config.AppSettings.Settings["GraficaEnvioPath"].Value;
            var fileName = "SSADI" + config.AppSettings.Settings["NumeroRotina"].Value
                + "_" + DateTime.Now.ToString("yyyyMMdd")
                + "_" + _loteComunicacao.ToString("00000")
                + "_ENVIO.xml";
            doc.Save(directoryPath + fileName);


            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioCartaTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioCartaTask.DoWork(): task complete.", MessageError = "" });

            return "EnvioCartaTask.DoWork(): task complete.";
        }

        internal IList<ClienteReembolsos> GetCollection()
        {
            return _ClienteRepository.ObterClientesSMSErro();
        }

        private void ItemProcess(XmlDocument doc, XmlNode rootNode, GraficaEnvio grafica, List<Entidades.Reembolso> reembolsos)
        {

            XmlNode cartaNode = doc.CreateElement("carta");
            WriteXmlNode(doc, cartaNode, "identificador", grafica.identificador);
            WriteXmlNode(doc, cartaNode, "nome", grafica.nome);
            WriteXmlNode(doc, cartaNode, "logradouro", grafica.logradouro);
            WriteXmlNode(doc, cartaNode, "numero", grafica.numero);
            WriteXmlNode(doc, cartaNode, "complemento", grafica.complemento);
            WriteXmlNode(doc, cartaNode, "bairro", grafica.bairro);
            WriteXmlNode(doc, cartaNode, "cep", grafica.cep);
            WriteXmlNode(doc, cartaNode, "cidade", grafica.cidade);
            WriteXmlNode(doc, cartaNode, "estado", grafica.estado);

            rootNode.AppendChild(cartaNode);

            Console.WriteLine("ComunicaoTask.DoWork(): Carta gerada...");

            var comunicacao = new Comunicacao()
            {
                idLoteComunicacao = _loteComunicacao,
                indicadorEfetivacao = ReembolsoTypes.StatusComunicacaoType.Enviado.ToString(),
                dataEnvioComunicacao = DateTime.Now,
                descricaoErro = "Carta Enviada",
                mensagemComunicacao = _ComunicacaoRepository.ObterMensagemComunicacao(ReembolsoTypes.ComunicacaoType.SMS)
            };
            _ComunicacaoRepository.IncluirComunicacao(comunicacao, reembolsos);
            _loteComunicacao = comunicacao.idLoteComunicacao;


        }

        private static void WriteXmlNode(XmlDocument doc, XmlNode entryNode, string name, string value)
        {
            XmlNode createdNode = doc.CreateElement(name);

            if (value != String.Empty)
                createdNode.AppendChild(doc.CreateTextNode(value));

            entryNode.AppendChild(createdNode);
        }

    }

}
