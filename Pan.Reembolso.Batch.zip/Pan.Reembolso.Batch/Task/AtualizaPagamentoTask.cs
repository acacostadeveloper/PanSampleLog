﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;

namespace Pan.Reembolso.Batch
{
    internal class AtualizaPagamentoTask
    {
        private ILogRepository _LogRepository;
        private IPagamentoRepository _pagamentoRepository;

        public AtualizaPagamentoTask(ILogRepository LogRepository,
                                     IPagamentoRepository pagamentoRepository)
        {
            _LogRepository = LogRepository;
            _pagamentoRepository = pagamentoRepository;
        }

        internal string DoWork()
        {
            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (Pagamento item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "EnvioPagamentoTask.DoWork(): task complete.", MessageError = "" });

            return "AtualizaPagamentoTask.DoWork(): task complete.";
        }

        internal IList<Pagamento> GetCollection()
        {
            return _pagamentoRepository.ObterPagamentosPorStatus(Entidades.ImplementationTypes.ReembolsoTypes.StatusPagamentoType.EnviadoPagamento);
        }

        private void ItemProcess(Pagamento value)
        {


        }
    }
}