﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Iterator;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Batch
{
    internal class AtualizaPagamentoTask
    {
        internal string DoWork()
        {
            LogRepository l = new LogRepository();

            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Getting collection...");
            l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });

            ConcreteAggregate a = GetCollection();

            Iterator.Iterator i = a.CreateIterator();

            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Iterating over collection...");
            l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Iterating over collection...", MessageError = "" });

            object item = i.First();
            while (item != null)
            {
                Console.WriteLine(item);
                item = i.Next();
            }

            l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "AtualizaPagamentoTask.DoWork(): task complete.", MessageError = "" });

            return "AtualizaPagamentoTask.DoWork(): task complete.";
        }

        internal static ConcreteAggregate GetCollection()
        {
            ConcreteAggregate a = new ConcreteAggregate();

            a[0] = "Item B";
            a[1] = "Item B";
            a[2] = "Item C";
            a[3] = "Item D";

            return a;
        }

    }
}
