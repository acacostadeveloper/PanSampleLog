﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Servico.Helper.Interface;

namespace Pan.Reembolso.Batch
{
    internal class AtualizaPagamentoTask
    {
        private ILogRepository _LogRepository;
        private IPagamentoRepository _pagamentoRepository;
        private IMensagemRepository _mensagemRepository;
        private ITesourariaLobApp _tesourariaLobApp;
        private IReembolsoStatusHelper _reembolsoStatusHelper;


        public AtualizaPagamentoTask(ILogRepository LogRepository,
                                  IPagamentoRepository pagamentoRepository,
                                  IMensagemRepository mensagemRepository,
                                  ITesourariaLobApp tesourariaLobApp,
                                  IReembolsoStatusHelper reembolsoStatusHelper)
        {
            _LogRepository = LogRepository;
            _pagamentoRepository = pagamentoRepository;
            _mensagemRepository = mensagemRepository;
            _tesourariaLobApp = tesourariaLobApp;
            _reembolsoStatusHelper = reembolsoStatusHelper;
        }

        internal string DoWork()
        {
            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "AtualizaPagamentoTask.DoWork(): Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("AtualizaPagamentoTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "AtualizaPagamentoTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (MensagemTransferencia item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "AtualizaPagamentoTask.DoWork(): task completed.", MessageError = "" });

            return "AtualizaPagamentoTask.DoWork(): task complete.";
        }

        internal IList<MensagemTransferencia> GetCollection()
        {
            return _mensagemRepository.ObterMensagemPorStatus(ReembolsoTypes.StatusMensagemTransferenciaType.Integrada);
        }

        private void ItemProcess(MensagemTransferencia value)
        {
            IDictionary<string, string> result = _tesourariaLobApp.ConsultarTransferenciaEletronica(value);

            ReembolsoTypes.StatusMensagemTransferenciaType statusMensagem;
            ReembolsoTypes.StatusPagamentoType statusPagamento;
            ReembolsoTypes.StatusReembolsoType statusReembolso;

            if (result["erroSucesso"] == "SUCESSO")
            {
                KeyValueTypes returnedType = new KeyValueTypes();

                bool matchedType = returnedType.StatusIntegracaoMensagemTransferencia.TryGetValue(result["StatusRequisicao"], out statusMensagem);

                if (matchedType)
                {
                    var pagamento = _pagamentoRepository.ObterPagamentoPorMensagemTransferencia(value);

                    switch (statusMensagem)
                    {
                        case ReembolsoTypes.StatusMensagemTransferenciaType.Devolvida:
                            statusPagamento = ReembolsoTypes.StatusPagamentoType.Devolvido;
                            statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado;

                            ProcessaRetornoMensagem(value, pagamento, statusMensagem, statusPagamento, statusReembolso);
                            break;

                        case ReembolsoTypes.StatusMensagemTransferenciaType.Efetivada:
                            statusPagamento = ReembolsoTypes.StatusPagamentoType.Efetivado;
                            statusReembolso = ReembolsoTypes.StatusReembolsoType.Reembolsado;

                            ProcessaRetornoMensagem(value, pagamento, statusMensagem, statusPagamento, statusReembolso);
                            break;

                        case ReembolsoTypes.StatusMensagemTransferenciaType.Integrada:
                            break;

                        case ReembolsoTypes.StatusMensagemTransferenciaType.ErroIntegracao:
                            statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado;
                            statusPagamento = ReembolsoTypes.StatusPagamentoType.Recusado;

                            ProcessaRetornoMensagem(value, pagamento, statusMensagem, statusPagamento, statusReembolso, "Erro retorno mensagem Transferencia : " + result["mensagem"]);
                            break;
                    }
                }

                if (!matchedType)
                    throw new Exception(String.Format("O valor retornado para a consulta de status da mensagem de transferência {0} não foi reconhecido!",value.numeroRequisicao));
            }

            if (result["erroSucesso"] == "ERRO")
            {
                statusMensagem = ReembolsoTypes.StatusMensagemTransferenciaType.ErroIntegracao;
                statusReembolso = ReembolsoTypes.StatusReembolsoType.Bloqueado;
                statusPagamento = ReembolsoTypes.StatusPagamentoType.Recusado;

                var pagamento = _pagamentoRepository.ObterPagamentoPorMensagemTransferencia(value);

                ProcessaRetornoMensagem(value, pagamento, statusMensagem, statusPagamento, statusReembolso, result["mensagem"]);
            }
        }

        private void ProcessaRetornoMensagem(MensagemTransferencia value
                              , Pagamento pagamento
                              , ReembolsoTypes.StatusMensagemTransferenciaType statusMensagem
                              , ReembolsoTypes.StatusPagamentoType statusPagamento
                              , ReembolsoTypes.StatusReembolsoType statusReembolso
                              , string messageError = "")
        {
            try
            {
                value.statusMensagem = statusMensagem.ToString();
                _mensagemRepository.AtualizarMensagem(value);

                pagamento.statusPagamento = statusPagamento.ToString();
                _pagamentoRepository.AtualizarPagamento(pagamento);

                var listaIdsReembolsos = pagamento.listaReembolsos.Select(s => s.numeroReembolso).ToList();
                _reembolsoStatusHelper.AlterarStatusReembolso(listaIdsReembolsos, statusReembolso, messageError, "ENVIO DE PAGAMENTO");
            }
            catch (Exception ex)
            {
                // TODO - Setar erro apenas para a mensagem atual
                //throw ex;
            }
        }
    }
}