﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using System.Xml;
using System.IO;

namespace Pan.Reembolso.Batch
{
    internal class RespostaSMSTask
    {
        private ILogRepository _LogRepository;
        private IClienteRepository _ClienteRepository;
        private IComunicacaoRepository _ComunicacaoRepository;
        private ISmsLobApp _smsLobApp;

        public RespostaSMSTask(ILogRepository LogRepository,
            IClienteRepository ClienteRepository,
            IComunicacaoRepository ComunicacaoRepository,
            ISmsLobApp smsLobApp)
        {
            _LogRepository = LogRepository;
            _ClienteRepository = ClienteRepository;
            _ComunicacaoRepository = ComunicacaoRepository;
            _smsLobApp = smsLobApp;
        }

        internal string DoWork()
        {

            LogRepository l = new LogRepository();
            
            Console.WriteLine("RespostaSMSTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "RespostaSMSTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("RespostaSMSTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "RespostaSMSTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "RespostaSMSTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (var item in iterator)
            {
                ItemProcess(item);
            }


            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "RespostaSMSTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "RespostaSMSTask.DoWork(): task complete.", MessageError = "" });

            return "RespostaSMSTask.DoWork(): task complete.";
        }


        //private List<List<ComunicacaoResposta>> ObterRespostaGrafica()
        //{

        //    var listaPaths = new List<string>();
        //    /**/
        //    DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(@"C:\Felipe\comunicacao\");
        //    FileInfo[] filesInDir = hdDirectoryInWhichToSearch.GetFiles("SSADI*_*_*_RETORNO.xml");

        //    foreach (FileInfo foundFile in filesInDir)
        //    {
        //        listaPaths.Add(foundFile.FullName);
        //    }
        //    /**/

        //    var lista = new List<List<ComunicacaoResposta>>();

        //    foreach (var path in listaPaths)
        //    {
        //        XmlTextReader reader = new XmlTextReader(path);
        //        List<ComunicacaoResposta> listaResposta = null;
        //        ComunicacaoResposta resposta = null;


        //        while (reader.Read())
        //        {
        //            if (reader.NodeType == XmlNodeType.Whitespace) continue;
        //            if (reader.NodeType == XmlNodeType.Element && reader.Name == "root")
        //            {
        //                listaResposta = new List<ComunicacaoResposta>();
        //            }
        //            else if (reader.NodeType == XmlNodeType.Element && reader.Name == "carta")
        //            {
        //                resposta = new ComunicacaoResposta();
        //            }
        //            else if (reader.NodeType == XmlNodeType.Element && reader.Name == "identificador")
        //            {
        //                reader.Read();
        //                if (reader.NodeType == XmlNodeType.Text)
        //                {
        //                    resposta.identificador = reader.Value;
        //                }
        //            }
        //            else if (reader.NodeType == XmlNodeType.Element && reader.Name == "protocolo")
        //            {
        //                reader.Read();
        //                if (reader.NodeType == XmlNodeType.Text)
        //                {
        //                    resposta.protocolo = reader.Value;
        //                }
        //            }
        //            else if (reader.NodeType == XmlNodeType.Element && reader.Name == "situacao")
        //            {
        //                reader.Read();
        //                if (reader.NodeType == XmlNodeType.Text)
        //                {
        //                    switch (reader.Value)
        //                    {
        //                        case "entregue":
        //                            resposta.situacao = ReembolsoTypes.StatusComunicacaoType.Efetivado;
        //                            break;
        //                        case "devolvido":
        //                            resposta.situacao = ReembolsoTypes.StatusComunicacaoType.Erro;
        //                            break;
        //                        default:
        //                            resposta.situacao = ReembolsoTypes.StatusComunicacaoType.Undefined;
        //                            break;
        //                    }
        //                }

        //            }
        //            else if (reader.NodeType == XmlNodeType.EndElement && reader.Name == "carta")
        //            {
        //                resposta.origem = path;
        //                listaResposta.Add(resposta);
        //                resposta = null;
        //            }
        //            else if (reader.NodeType == XmlNodeType.EndElement && reader.Name == "root")
        //            {
        //                lista.Add(listaResposta);
        //                listaResposta = null;

        //            }
        //        }
        //    }
        //    return lista;
        //}

        internal IList<Comunicacao> GetCollection()
        {
            return _ComunicacaoRepository.ObterSMSEnviados();
        }

        private void ItemProcess(Comunicacao comunicacao)
        {
            var resposta = _smsLobApp.SMSResposta(comunicacao.protocolo);

            var status = ReembolsoTypes.ObterStatusRespostaSMS( resposta.Result.idStatus);

            if (status == ReembolsoTypes.StatusComunicacaoType.Efetivado)
            {
                comunicacao.indicadorEfetivacao = ReembolsoTypes.StatusComunicacaoType.Efetivado.ToString();
                comunicacao.descricaoErro = resposta.Result.mensagem;
                comunicacao.protocolo = resposta.Result.idMensagemEntrada.ToString();
                _ComunicacaoRepository.AtualizarComunicacao(comunicacao);
            }
            if (status == ReembolsoTypes.StatusComunicacaoType.Erro)
            {
                comunicacao.indicadorEfetivacao = ReembolsoTypes.StatusComunicacaoType.Erro.ToString();
                comunicacao.descricaoErro = resposta.Result.mensagem;
                comunicacao.protocolo = resposta.Result.idMensagemEntrada.ToString();
                _ComunicacaoRepository.AtualizarComunicacao(comunicacao);
            }
        }
    }

}
