﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Batch
{
    internal class DevolucaoTedTask
    {
        private ILogRepository _LogRepository;
        private IPagamentoRepository _pagamentoRepository;
        private IMensagemRepository _mensagemRepository;
        private ITesourariaLobApp _tesourariaLobApp;
        private IReembolsoRepository _reembolsoRepository;
        private IHistoricoReembolsoRepository _historicoReembolsoRepository;
        private IEventoRepository _eventoRepository;

        public DevolucaoTedTask(ILogRepository LogRepository,
                                  IPagamentoRepository pagamentoRepository,
                                  IMensagemRepository mensagemRepository,
                                  ITesourariaLobApp tesourariaLobApp,
                                  IReembolsoRepository reembolsoRepository,
                                  IHistoricoReembolsoRepository historicoReembolsoRepository,
                                  IEventoRepository eventoRepository)
        {
            _LogRepository = LogRepository;
            _pagamentoRepository = pagamentoRepository;
            _mensagemRepository = mensagemRepository;
            _tesourariaLobApp = tesourariaLobApp;
            _reembolsoRepository = reembolsoRepository;
            _historicoReembolsoRepository = historicoReembolsoRepository;
            _eventoRepository = eventoRepository;
        }

        internal string DoWork()
        {
            Console.WriteLine("DevolucaoTedTask.DoWork(): Getting collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "DevolucaoTedTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "DevolucaoTedTask.DoWork(): Getting collection...", MessageError = "" });

            var iterator = GetCollection();

            Console.WriteLine("DevolucaoTedTask.DoWork(): Iterating over collection...");
            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "DevolucaoTedTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "DevolucaoTedTask.DoWork(): Iterating over collection...", MessageError = "" });

            foreach (DevolucaoSPB item in iterator)
            {
                ItemProcess(item);
            }

            _LogRepository.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "DevolucaoTedTask.DoWork()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "DevolucaoTedTask.DoWork(): task completed.", MessageError = "" });

            return "DevolucaoTedTask.DoWork(): task completed.";
        }

        internal IList<DevolucaoSPB> GetCollection()
        {
            return _tesourariaLobApp.ObterDevolucaoSPB("SSAFUNCAO",2);
        }

        private void ItemProcess(DevolucaoSPB value)
        {

        }
    }
}
