﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Entidades;
using SimpleInjector;
using Pan.Reembolso.Batch.Ioc;

namespace Pan.Reembolso.Batch
{
    class Program
    {
        private static ILogRepository _log;

        static void Main(string[] args)
        {
            Console.WriteLine("Batch started.");

            var container = new Container();
            Bootstrap.Start(container);

            _log = container.GetInstance<ILogRepository>();

            Task[] tasks = new Task[]
            {
                Task.Factory.StartNew(() => ExecuteContabilTask(container)),

                Task.Factory.StartNew(() => ExecuteEnvioPagamentoTask(container)),

                Task.Factory.StartNew(() => ExecuteAtualizaPagamentoTask(container)),

                Task.Factory.StartNew(() => ExecuteDevolucaoTedTask(container)),

                Task.Factory.StartNew(() => ExecuteEnvioSMSTask(container)),

                Task.Factory.StartNew(() => ExecuteEnvioCartaTask(container)),

                Task.Factory.StartNew(() => ExecuteRespostaGraficaTask(container)),

                Task.Factory.StartNew(() => ExecuteRespostaSMSTask(container))

            };

            Task.WaitAll(tasks);

            Console.WriteLine("Batch completed.");
        }

        private static void ExecuteDevolucaoTedTask(Container container)
        {
            try
            {
                Console.WriteLine("DevolucaoTedTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "DevolucaoTedTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = container.GetInstance<DevolucaoTedTask>();
                string result = workTask.DoWork();
                Console.WriteLine("DevolucaoTedTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "DevolucaoTedTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "DevolucaoTedTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("DevolucaoTedTask() Error: " + ex.Message);
                Console.WriteLine("DevolucaoTedTask() Error Detail: " + ex.StackTrace);
            }

        }
        private static void ExecuteContabilTask(Container container)
        {
            try
            {
                Console.WriteLine("ContabilTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = container.GetInstance<ContabilizaTask>();
                string result = workTask.DoWork();
                Console.WriteLine("ContabilTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("ContabilTask() Error: " + ex.Message);
                Console.WriteLine("ContabilTask() Error Detail: " + ex.StackTrace);
            }

        }
        private static void ExecuteRespostaSMSTask(Container container)
        {
            var nomeTask = nameof(RespostaSMSTask);
            try
            {
                Console.WriteLine(nomeTask + " Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                
                var workTask = container.GetInstance<RespostaSMSTask>();
                string result = workTask.DoWork();

                Console.WriteLine(nomeTask + " Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine(nomeTask + " Error: " + ex.Message);
                Console.WriteLine(nomeTask + " Error Detail: " + ex.StackTrace);
            }
        }
        private static void ExecuteRespostaGraficaTask(Container container)
        {
            var nomeTask = nameof(RespostaGraficaTask);
            try
            {
                Console.WriteLine(nomeTask + " Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });

                var workTask = container.GetInstance<RespostaGraficaTask>();
                string result = workTask.DoWork();

                Console.WriteLine(nomeTask + " Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine(nomeTask + " Error: " + ex.Message);
                Console.WriteLine(nomeTask + " Error Detail: " + ex.StackTrace);
            }
        }
        private static void ExecuteEnvioSMSTask(Container container)
        {
            var nomeTask = nameof(EnvioSMSTask);
            try
            {
                Console.WriteLine(nomeTask + " Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });

                var workTask = container.GetInstance<EnvioSMSTask>();
                string result = workTask.DoWork();

                Console.WriteLine(nomeTask + " Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine(nomeTask + " Error: " + ex.Message);
                Console.WriteLine(nomeTask + " Error Detail: " + ex.StackTrace);
            }

        }
        private static void ExecuteEnvioCartaTask(Container container)
        {
            var nomeTask = nameof(EnvioCartaTask);
            try
            {
                Console.WriteLine(nomeTask + " Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });

                var workTask = container.GetInstance<EnvioCartaTask>();
                string result = workTask.DoWork();

                Console.WriteLine(nomeTask + " Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = nomeTask + "()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine(nomeTask + " Error: " + ex.Message);
                Console.WriteLine(nomeTask + " Error Detail: " + ex.StackTrace);
            }

        }
        private static void ExecuteEnvioPagamentoTask(Container container)
        {
            try
            {
                Console.WriteLine("EnvioPagamentoTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = container.GetInstance<EnvioPagamentoTask>();
                string result = workTask.DoWork();
                Console.WriteLine("EnvioPagamentoTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("EnvioPagamentoTask() Error: " + ex.Message);
                Console.WriteLine("EnvioPagamentoTask() Error Detail: " + ex.StackTrace);
            }
        }
        private static void ExecuteAtualizaPagamentoTask(Container container)
        {
            try
            {
                Console.WriteLine("AtualizaPagamentoTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = container.GetInstance<AtualizaPagamentoTask>();
                string result = workTask.DoWork();
                Console.WriteLine("AtualizaPagamentoTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("AtualizaPagamentoTask() Error: " + ex.Message);
                Console.WriteLine("AtualizaPagamentoTask() Error Detail: " + ex.StackTrace);
            }

        }

    }
}
