﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Entidades; 

namespace Pan.Reembolso.Batch
{
    class Program
    {
        static void Main(string[] args)
        {
            LogRepository l = new LogRepository();

            try
            {
                Console.WriteLine("ContabilTask() Starting... ");
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = new ContabilizaTask();
                string result = workTask.DoWork();
                Console.WriteLine("ContabilTask() Result Message: " + result);
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("ContabilTask() Error: " + ex.Message);
                Console.WriteLine("ContabilTask() Error Detail: " + ex.StackTrace);
            }

            try
            {
                Console.WriteLine("AtualizaPagamentoTask() Starting... ");
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = new AtualizaPagamentoTask();
                string result = workTask.DoWork();
                Console.WriteLine("AtualizaPagamentoTask() Result Message: " + result);
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("AtualizaPagamentoTask() Error: " + ex.Message);
                Console.WriteLine("AtualizaPagamentoTask() Error Detail: " + ex.StackTrace);
            }

            try
            {
                Console.WriteLine("EnvioPagamentoTask() Starting... ");
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = new EnvioPagamentoTask();
                string result = workTask.DoWork();
                Console.WriteLine("EnvioPagamentoTask() Result Message: " + result);
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                l.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("EnvioPagamentoTask() Error: " + ex.Message);
                Console.WriteLine("EnvioPagamentoTask() Error Detail: " + ex.StackTrace);
            }
        }
    }
}
