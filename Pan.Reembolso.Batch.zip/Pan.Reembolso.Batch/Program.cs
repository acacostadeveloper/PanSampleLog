﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Batch.Parameter;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Entidades;
using SimpleInjector;
using Pan.Reembolso.Batch.Ioc;

namespace Pan.Reembolso.Batch
{
    class Program
    {
        private static ILogRepository _log;

        static void Main(string[] args)
        {
            var container = new Container();
            Bootstrap.Start(container);

            _log = container.GetInstance<ILogRepository>();

            try
            {
                Console.WriteLine("ContabilTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = container.GetInstance<ContabilizaTask>(); 
                string result = workTask.DoWork();
                Console.WriteLine("ContabilTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "ContabilTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("ContabilTask() Error: " + ex.Message);
                Console.WriteLine("ContabilTask() Error Detail: " + ex.StackTrace);
            }

            try
            {
                Console.WriteLine("AtualizaPagamentoTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = new AtualizaPagamentoTask();
                string result = workTask.DoWork();
                Console.WriteLine("AtualizaPagamentoTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "AtualizaPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("AtualizaPagamentoTask() Error: " + ex.Message);
                Console.WriteLine("AtualizaPagamentoTask() Error Detail: " + ex.StackTrace);
            }

            try
            {
                Console.WriteLine("EnvioPagamentoTask() Starting... ");
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Task Started", MessageError = "" });
                var workTask = new EnvioPagamentoTask();
                string result = workTask.DoWork();
                Console.WriteLine("EnvioPagamentoTask() Result Message: " + result);
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Result Message: " + result, MessageError = "" });
            }
            catch (Exception ex)
            {
                _log.PersistirLog(new LogConsoleApp() { Application = LogParameter.Application, BatchTask = "EnvioPagamentoTask()", IpAddress = LogParameter.IpAddress, Machine = LogParameter.Machine, Timestamp = DateTime.Now, TextLog = "Error: " + ex.Message, MessageError = ex.Message + ": " + ex.StackTrace });
                Console.WriteLine("EnvioPagamentoTask() Error: " + ex.Message);
                Console.WriteLine("EnvioPagamentoTask() Error Detail: " + ex.StackTrace);
            }
        }
    }
}
