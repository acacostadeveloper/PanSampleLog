﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;

namespace Pan.Reembolso.Batch.Parameter
{
    internal static class LogParameter
    {
        public static string Application = Application = "Pan.Reembolso.Batch";
        public static string Machine = Environment.MachineName;
        public static string IpAddress = Dns.GetHostEntry(Machine).AddressList[0].ToString();
    }
}
