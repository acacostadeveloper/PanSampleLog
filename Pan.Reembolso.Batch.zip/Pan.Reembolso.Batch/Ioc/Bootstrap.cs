﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleInjector;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Infra.Log.Implementation;

namespace Pan.Reembolso.Batch.Ioc
{
    class Bootstrap
    {
        public static void Start(Container container)
        {
            container.Register<IContabilRepository, ContabilRepository>(Lifestyle.Transient);
            container.Register<IHistoricoReembolsoRepository, HistoricoReembolsoRepository>(Lifestyle.Transient);
            container.Register<IReembolsoRepository, ReembolsoRepository>(Lifestyle.Transient);
            container.Register<IContabilLobApp, ContabilLobApp>(Lifestyle.Transient);
            container.Register<ILogRepository, LogRepository>(Lifestyle.Transient);
            container.Register<IPagamentoRepository, PagamentoRepository>(Lifestyle.Transient);
            container.Register<IMensagemRepository, MensagemRepository>(Lifestyle.Transient);
            container.Register<ITesourariaLobApp, TesourariaLobApp>(Lifestyle.Transient);
            container.Register<IClienteRepository, ClienteRepository>(Lifestyle.Transient);
            container.Register<IGraficaLobApp, GraficaLobApp>(Lifestyle.Transient);
            container.Register<IEventoRepository, EventoRepository>(Lifestyle.Transient);
            

            container.Register<EnvioPagamentoTask>();
            container.Register<ContabilizaTask>();
            container.Register<AtualizaPagamentoTask>();
            container.Register<ComunicaoTask>();

            container.Verify();
        }
    }
}
