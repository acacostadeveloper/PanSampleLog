﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleInjector;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Infra.Log.Implementation;

namespace Pan.Reembolso.Batch.Ioc
{
    class Bootstrap
    {
        public static void Start(Container container)
        {
            container.Register<IContabilRepository, ContabilRepository>(Lifestyle.Transient);
            container.Register<IHistoricoReembolsoRepository, HistoricoReembolsoRepository>(Lifestyle.Transient);
            container.Register<IReembolsoRepository, ReembolsoRepository>(Lifestyle.Transient);
            container.Register<IContabilLobApp, ContabilLobApp>(Lifestyle.Transient);
            container.Register<ILogRepository, LogRepository>(Lifestyle.Transient);

            container.Register<ContabilizaTask>();

            container.Verify();
        }
    }
}
