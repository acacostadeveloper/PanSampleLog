﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SimpleInjector;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Implementation;
using Pan.Reembolso.Agente.Interface;
using Pan.Reembolso.Agente.Implementation;
using Pan.Reembolso.Infra.Log.Interface;
using Pan.Reembolso.Infra.Log.Implementation;
using Pan.Reembolso.Servico.Helper.Interface;
using Pan.Reembolso.Servico.Helper.Implementation;
using Pan.Reembolso.Servico.Interface;
using Pan.Reembolso.Servico.Implementation;


namespace Pan.Reembolso.Batch.Ioc
{
    class Bootstrap
    {
        public static void Start(Container container)
        {
            container.Register<IContabilRepository, ContabilRepository>(Lifestyle.Transient);
            container.Register<IHistoricoReembolsoRepository, HistoricoReembolsoRepository>(Lifestyle.Transient);
            container.Register<IReembolsoRepository, ReembolsoRepository>(Lifestyle.Transient);
            container.Register<IProcessoRegistroRepository, ProcessoRegistroRepository>(Lifestyle.Transient);
            container.Register<IContabilLobApp, ContabilLobApp>(Lifestyle.Transient);
            container.Register<ILogRepository, LogRepository>(Lifestyle.Transient);
            container.Register<IPagamentoRepository, PagamentoRepository>(Lifestyle.Transient);
            container.Register<IMensagemRepository, MensagemRepository>(Lifestyle.Transient);
            container.Register<ITesourariaLobApp, TesourariaLobApp>(Lifestyle.Transient);
            container.Register<IClienteRepository, ClienteRepository>(Lifestyle.Transient);
            container.Register<IEventoRepository, EventoRepository>(Lifestyle.Transient);
            container.Register<IComunicacaoRepository, ComunicacaoRepository>(Lifestyle.Transient);

            container.Register<IHistoricoReembolsoService, HistoricoReembolsoService>(Lifestyle.Transient);
            container.Register<IMotivoBloqueioRepository, MotivoBloqueioRepository>(Lifestyle.Transient);
            container.Register<IReembolsoStatusHelper, ReembolsoStatusHelper>(Lifestyle.Transient);

            

            container.Register<ISmsLobApp, SmsLobApp>(Lifestyle.Transient);

            container.Register<EnvioPagamentoTask>();
            container.Register<ContabilizaTask>();
            container.Register<AtualizaPagamentoTask>();
            container.Register<RespostaGraficaTask>();
            container.Register<RespostaSMSTask>();
            container.Register<EnvioCartaTask>();
            container.Register<EnvioSMSTask>();

            container.Verify();
        }
    }
}
