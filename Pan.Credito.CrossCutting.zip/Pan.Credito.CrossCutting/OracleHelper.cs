﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Data;
using System.Linq;
using Oracle.ManagedDataAccess.Client;

namespace Pan.Credito.CrossCutting
{
    public class OracleHelper
    {
        private readonly string _conn;
        private List<OracleParameter> parametros;

        public OracleHelper()
        {
            _conn = ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString;
        }

        public OracleHelper(string NomeConnectionString)
        {
            _conn = ConfigurationManager.ConnectionStrings[NomeConnectionString].ConnectionString;
        }

        public void AddParameter(string nome, DbType tipo, object valor, bool output = false)
        {
            try
            {
                if (parametros == null)
                    parametros = new List<OracleParameter>();

                var par = new OracleParameter(nome, valor);
                par.DbType = tipo;
                if (output)
                {
                    par.Direction = ParameterDirection.Output;
                    par.Size = 1000;
                }
                parametros.Add(par);
            }
            catch (Exception)
            {
                throw;
            }
        }

        public object GetOutPut(string NomeParametro)
        {
            try
            {
                OracleParameter pa = parametros.FirstOrDefault(p => p.ParameterName == "@" + NomeParametro);
                if (pa != null)
                    return pa.Value;

                return null;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<T> ExecuteEntity<T>(string NomeProcedure)
        {
            OracleDataReader dataHeader = null;
            OracleConnection conn = new OracleConnection(_conn);
            try
            {
                conn.Open();
                OracleCommand command = new OracleCommand(NomeProcedure, conn);
                command.CommandType = CommandType.StoredProcedure;

                if (parametros != null)
                    parametros.ForEach(p => command.Parameters.Add(p));

                dataHeader = command.ExecuteReader();

                return ConvertToEntity<T>(dataHeader).ToList();
            }
            catch (Exception)
            {
                conn.Close();
                conn.Dispose();
                throw;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        public List<T> ExecuteEntityText<T>(string Query)
        {
            OracleDataReader dataReader = null;
            OracleConnection conn = new OracleConnection(_conn);
            try
            {
                conn.Open();
                using (OracleCommand command = new OracleCommand(Query, conn))
                {
                    if (parametros != null)
                        parametros.ForEach(p => command.Parameters.Add(p.Clone()));

                    dataReader = command.ExecuteReader();

                    return ConvertToEntity<T>(dataReader).ToList();
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        public T ExecuteEntityTextNTable<T>(string Query, List<string> NomeTabela = null)
        {
            OracleConnection conn = new OracleConnection(_conn);
            try
            {
                conn.Open();
                using (OracleCommand command = new OracleCommand(Query, conn))
                {
                    if (parametros != null)
                        parametros.ForEach(p => command.Parameters.Add(p));

                    DataSet ds = new DataSet();
                    using (OracleDataAdapter da = new OracleDataAdapter(command))
                    {
                        da.Fill(ds);
                    }

                    if (ds.Tables.Count == 0)
                        return default(T);

                    if (NomeTabela != null)
                    {
                        for (int i = 0; i < NomeTabela.Count; i++)
                            ds.Tables[i].TableName = NomeTabela[i];
                    }

                    return ConvertToEntity<T>(ds);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        public int ExecuteNonQuery(string NomeProcedure)
        {
            OracleConnection conn = new OracleConnection(_conn);
            try
            {
                conn.Open();
                OracleCommand command = new OracleCommand(NomeProcedure, conn);
                command.CommandType = CommandType.StoredProcedure;

                if (parametros != null)
                    parametros.ForEach(p => command.Parameters.Add(p));

                return command.ExecuteNonQuery();
            }
            catch (Exception)
            {
                conn.Close();
                conn.Dispose();
                throw;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        DataTable ExecuteDataTable(string NomeProcedure)
        {
            OracleDataReader dataHeader = null;
            DataTable result = new DataTable();
            OracleConnection conn = new OracleConnection(_conn);
            try
            {
                conn.Open();
                OracleCommand command = new OracleCommand(NomeProcedure, conn);
                command.CommandType = CommandType.StoredProcedure;

                if (parametros != null)
                    parametros.ForEach(p => command.Parameters.Add(p));

                dataHeader = command.ExecuteReader();
                result.Load(dataHeader);
                return result;
            }
            catch (Exception)
            {
                conn.Close();
                conn.Dispose();
                throw;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        public T ExecuteScalar<T>(string NomeProcedure, CommandType CommandType = CommandType.Text)
        {
            OracleConnection conn = new OracleConnection(_conn);
            try
            {
                conn.Open();
                OracleCommand command = new OracleCommand(NomeProcedure, conn);
                command.CommandType = CommandType;

                if (parametros != null)
                    parametros.ForEach(p => command.Parameters.Add(p));

                object ret = command.ExecuteScalar();

                if (ret == null)
                    return default(T);

                return ((T)Convert.ChangeType(ret, typeof(T)));
            }
            catch (Exception)
            {
                conn.Close();
                conn.Dispose();
                throw;
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }
        }

        IEnumerable<T> ConvertToEntity<T>(OracleDataReader dataReader)
        {
            List<T> colecaoRetorno = new List<T>();

            try
            {
                while (dataReader.Read())
                {
                    IEnumerable<DataRow> rows = dataReader.GetSchemaTable().Rows.OfType<DataRow>();

                    if (typeof(T).IsValueType || typeof(T) == typeof(string))
                    {
                        colecaoRetorno.Add((T)dataReader[0]);
                        continue;
                    }

                    T instance = ((T)Activator.CreateInstance(typeof(T)));

                    instance.GetType().GetProperties().ToList().ForEach(p =>
                    {
                        DisplayAttribute att = instance.GetAttributeFrom<DisplayAttribute>(p.Name);

                        if (att == default(DisplayAttribute))
                        {
                            return;
                        }

                        string columnName = att.GetName();

                        if (rows.Any(r => columnName.ToLower().Equals(r["ColumnName"].ToString().ToLower())))
                        {
                            if (dataReader[columnName] != DBNull.Value)
                            {
                                if (p.PropertyType.IsValueType)
                                {
                                    if (p.PropertyType.IsGenericType && p.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                                    {
                                        p.SetValue(instance, Convert.ChangeType(dataReader[columnName], p.PropertyType.GetGenericArguments()[0]), null);
                                    }
                                    else if (p.PropertyType.IsEnum)
                                    {
                                        p.SetValue(instance, Convert.ToInt32(dataReader[columnName]), null);
                                    }
                                    else
                                    {
                                        p.SetValue(instance, Convert.ChangeType(dataReader[columnName], p.PropertyType), null);
                                    }
                                }
                                else
                                {
                                    if (p.PropertyType.GetProperty("ID") == null)
                                    {
                                        p.SetValue(instance, Convert.ChangeType(dataReader[columnName], p.PropertyType), null);
                                    }
                                    else
                                    {
                                        object subInstance = Activator.CreateInstance(p.PropertyType);
                                        p.SetValue(instance, subInstance, null);

                                        if (dataReader[columnName].GetType() == typeof(string))
                                        {
                                            p.PropertyType.GetProperty("ID_Str").SetValue(subInstance, dataReader[columnName].ToString(), null);
                                        }
                                        else
                                        {
                                            p.PropertyType.GetProperty("ID").SetValue(subInstance, (int)dataReader[columnName], null);
                                        }
                                    }
                                }
                            }
                        }
                    });

                    colecaoRetorno.Add(instance);
                }
                return colecaoRetorno;
            }
            catch (Exception)
            {
                throw;
            }
        }

        T ConvertToEntity<T>(DataSet ds)
        {
            try
            {
                T instance1 = ((T)Activator.CreateInstance(typeof(T)));

                instance1.GetType().GetProperties().ToList().ForEach(p1 =>
                {
                    var instance = Activator.CreateInstance(p1.PropertyType);
                    IList instanceG = null;

                    if (instance.GetType().IsGenericType)
                    {
                        instanceG = (IList)Activator.CreateInstance(p1.PropertyType);
                        Type lst = instance.GetType().GetGenericArguments()[0];
                        instance = Convert.ChangeType(Activator.CreateInstance(lst), lst);
                    }

                    var t = ds.Tables[p1.Name];

                    List<DataRow> rows = t.Rows.OfType<DataRow>().ToList();

                    if (typeof(T).IsValueType || typeof(T) == typeof(string))
                    {
                        //colecaoRetorno.Add((T)t[0]);
                        //return;
                    }

                    rows.ForEach(r =>
                    {
                        instance.GetType().GetProperties().ToList().ForEach(p =>
                        {
                            DisplayAttribute att = instance.GetAttributeFrom<DisplayAttribute>(p.Name);

                            if (att == default(DisplayAttribute))
                            {
                                return;
                            }

                            string columnName = att.GetName();

                            if (r.Table.Columns.Contains(columnName))
                            {
                                if (r[columnName] != DBNull.Value)
                                {
                                    if (p.PropertyType.IsValueType)
                                    {
                                        p.SetValue(instance, Convert.ChangeType(r[columnName], p.PropertyType), null);
                                    }
                                    else
                                    {
                                        if (p.PropertyType.GetProperty("ID") == null)
                                        {
                                            p.SetValue(instance, Convert.ChangeType(r[columnName], p.PropertyType), null);
                                        }
                                        else
                                        {
                                            object subInstance = Activator.CreateInstance(p.PropertyType);
                                            p.SetValue(instance, subInstance, null);

                                            if (r[columnName].GetType() == typeof(string))
                                            {
                                                p.PropertyType.GetProperty("ID_Str").SetValue(subInstance, r[columnName].ToString(), null);
                                            }
                                            else
                                            {
                                                p.PropertyType.GetProperty("ID").SetValue(subInstance, (int)r[columnName], null);
                                            }
                                        }
                                    }
                                }
                            };
                        });

                        if (p1.PropertyType.IsGenericType)
                        {
                            instanceG.Add(instance);

                            instance = Activator.CreateInstance(instance.GetType());
                        }
                    });

                    if (p1.PropertyType.IsGenericType)
                    {
                        p1.SetValue(instance1, instanceG, null);
                    }
                    else
                    {
                        p1.SetValue(instance1, instance, null);
                    }
                });
                return instance1;
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}
