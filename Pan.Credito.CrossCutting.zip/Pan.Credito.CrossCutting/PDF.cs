﻿using System;
using System.Collections.Generic;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Pan.Credito.CrossCutting
{
    public class PDF
    {
        [Obsolete("Metodo gerar arquivos muito grandes utilizar MergePdFs")]
        public static byte[] concatAndAddContent(List<byte[]> pdf)
        {
            byte[] all;
            if (pdf.Count == 0)
                return null;

            using (MemoryStream ms = new MemoryStream())
            {
                Document doc = new Document();

                PdfCopy writer = new PdfCopy(doc, ms);

                doc.Open();
                PdfImportedPage page;

                PdfReader reader;
                foreach (byte[] p in pdf)
                {
                    reader = new PdfReader(p);
                    int pages = reader.NumberOfPages;

                    // loop over document pages
                    for (int i = 1; i <= pages; i++)
                    {
                        page = writer.GetImportedPage(reader, i);
                        writer.AddPage(page);
                    }
                }

                doc.Close();
                all = ms.GetBuffer();
                ms.Flush();
                ms.Dispose();
            }

            return all;
        }
        public static byte[] MergePdFs(List<byte[]> pdfFiles)
        {
            byte[] merge;
            if (pdfFiles.Count <= 1) return pdfFiles[0];

            using (MemoryStream stream = new MemoryStream())
            {
                PdfReader reader;
                Document documentContainer;
                PdfWriter smartCopy;
                reader = new PdfReader(pdfFiles[0]);
                documentContainer = new Document();


                smartCopy = new PdfSmartCopy(documentContainer, stream);
                documentContainer.Open();
                foreach (byte[] t in pdfFiles)
                {
                    reader = new PdfReader(t);

                    for (int i = 1; i < reader.NumberOfPages + 1; i++)
                    {
                        var page = smartCopy.GetImportedPage(reader, i);
                        ((PdfSmartCopy)smartCopy).AddPage(page);
                    }
                    smartCopy.FreeReader(reader);
                }
                reader.Close();
                smartCopy.Close();
                documentContainer.Close();
                merge = stream.GetBuffer();
            }
            return merge;
        }

    }
}
