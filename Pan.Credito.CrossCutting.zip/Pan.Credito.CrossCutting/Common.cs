using System;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace Pan.Credito.CrossCutting
{
    public static class Common
    {
        /// <summary>
        /// Verifica se a string representa um n�mero inteiro
        /// </summary>
        /// <param name="p_strValor"></param>
        /// <returns>True, caso a string represente um n�mero inteiro</returns>
        public static Boolean IsInteger(String p_strValor)
        {
            Int64 intValor;
            return Int64.TryParse(p_strValor, out intValor);
        }
        public static DateTime HourBrazilNow()
        {
            return TimeZoneInfo.ConvertTime(DateTime.Now,TimeZoneInfo.FindSystemTimeZoneById("E. South America Standard Time"));
        }

        public static bool IsNumeric(string valor)
        {
            var reNum = new Regex(@"^\d+$");
            return reNum.Match(valor).Success;
        }

        public static Object Escolher(Object p_objValor,
            params Object[] p_arrValores)
        {
            Int32 intA = 0;

            for (intA = 0; intA < p_arrValores.Count() - 1; intA += 2)
            {
                if (p_objValor.Equals(p_arrValores[intA]))
                {
                    return p_arrValores[intA + 1];
                }
            }

            return p_arrValores[intA];
        }


        #region M�todos para tratar valores nulos


        /// <summary>
        /// Verifica se o valor passado � igual a DBNull. Retorna o pr�prio valor ou o valor alternativo.
        /// </summary>
        /// <param name="p_objValor">Valor que se quer verificar</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor principal for igual a DBNull</param>
        /// <returns></returns>
        public static String IsNull(Object p_objValor,
            String p_strValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_strValorAlternativo;
            }
            else
            {
                return Convert.ToString(p_objValor);
            }
        }



        /// <summary>
        /// Verifica se o valor passado � igual a DBNull. Retorna o pr�prio valor ou o valor alternativo.
        /// </summary>
        /// <param name="p_objValor">Valor que se quer verificar</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor principal for igual a DBNull</param>
        /// <returns></returns>
        public static Decimal IsNull(Object p_objValor,
            Decimal p_decValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_decValorAlternativo;
            }
            else
            {
                return Convert.ToDecimal(p_objValor);
            }
        }



        /// <summary>
        /// Verifica se o valor passado � igual a DBNull. Retorna o pr�prio valor ou o valor alternativo.
        /// </summary>
        /// <param name="p_objValor">Valor que se quer verificar</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor principal for igual a DBNull</param>
        /// <returns></returns>
        public static DateTime IsNull(Object p_objValor,
            DateTime p_dtmValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_dtmValorAlternativo;
            }
            else
            {
                return Convert.ToDateTime(p_objValor);
            }
        }



        /// <summary>
        /// Verifica se o valor passado � igual a DBNull. Retorna o pr�prio valor ou o valor alternativo.
        /// </summary>
        /// <param name="p_objValor">Valor que se quer verificar</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor principal for igual a DBNull</param>
        /// <returns></returns>
        public static Int64 IsNull(Object p_objValor,
            Int64 p_intValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_intValorAlternativo;
            }
            else
            {
                return Convert.ToInt64(p_objValor);
            }
        }




        /// <summary>
        /// Verifica se o valor passado � igual a DBNull. Retorna o pr�prio valor ou o valor alternativo.
        /// </summary>
        /// <param name="p_objValor">Valor que se quer verificar</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor principal for igual a DBNull</param>
        /// <returns></returns>
        public static Int32 IsNull(Object p_objValor,
            Int32 p_intValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_intValorAlternativo;
            }
            else
            {
                return Convert.ToInt32(p_objValor);
            }
        }



        /// <summary>
        /// Verifica se o valor passado � igual a DBNull. Retorna o pr�prio valor ou o valor alternativo.
        /// </summary>
        /// <param name="p_objValor">Valor que se quer verificar</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor principal for igual a DBNull</param>
        /// <returns></returns>
        public static Int16 IsNull(Object p_objValor,
            Int16 p_intValorAlternativo)
        {
            if (p_objValor == null || p_objValor == DBNull.Value)
            {
                return p_intValorAlternativo;
            }
            else
            {
                return Convert.ToInt16(p_objValor);
            }
        }

        #endregion

        #region M�todos leitura de data readers


        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static String ReadData(IDataReader p_objReader,
            String p_strCampo,
            String p_strValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_strValorAlternativo;
            }
            else
            {
                return p_objReader.GetString(intOrdinal);
            }
        }





        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static Boolean ReadData(IDataReader p_objReader,
            String p_strCampo,
            Boolean p_blnValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_blnValorAlternativo;
            }
            else
            {
                return p_objReader.GetBoolean(intOrdinal);
            }
        }





        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static Decimal ReadData(IDataReader p_objReader,
            String p_strCampo,
            Decimal p_decValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_decValorAlternativo;
            }
            else
            {
                return p_objReader.GetDecimal(intOrdinal);
            }
        }





        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static DateTime ReadData(IDataReader p_objReader,
            String p_strCampo,
            DateTime p_dtmValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_dtmValorAlternativo;
            }
            else
            {
                return p_objReader.GetDateTime(intOrdinal);
            }
        }





        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static Int64 ReadData(IDataReader p_objReader,
            String p_strCampo,
            Int64 p_intValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_intValorAlternativo;
            }
            else
            {
                return p_objReader.GetInt64(intOrdinal);
            }
        }





        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static Int32 ReadData(IDataReader p_objReader,
            String p_strCampo,
            Int32 p_intValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_intValorAlternativo;
            }
            else
            {
                return p_objReader.GetInt32(intOrdinal);
            }
        }





        /// <summary>
        /// L� um valor de um DataReader e devolve um valor padr�o caso seja nulo.
        /// </summary>
        /// <param name="p_objReader">Objeto DataReader</param>
        /// <param name="p_strChave">Nome do campo no DataReader</param>
        /// <param name="p_strValorAlternativo">Valor que ser� retornado se o valor no DataReader for igual a DBNull</param>
        /// <returns>Valor do DataReader ou valor alternativo</returns>
        public static Int16 ReadData(IDataReader p_objReader,
            String p_strCampo,
            Int16 p_intValorAlternativo)
        {
            Int32 intOrdinal = p_objReader.GetOrdinal(p_strCampo);


            if (p_objReader.IsDBNull(intOrdinal))
            {
                return p_intValorAlternativo;
            }
            else
            {
                return p_objReader.GetInt16(intOrdinal);
            }
        }






        #endregion

        public static void RegistrarMensagem(string origemMensagem, string conteudoMensagem, EventLogEntryType tipoMensagem)
        {
            try
            {
                if (string.IsNullOrEmpty(origemMensagem))
                    origemMensagem = "N�o Informado";

                if (!EventLog.SourceExists(origemMensagem))
                    EventLog.CreateEventSource(origemMensagem, "Application");

                EventLog log = new EventLog();
                log.Source = origemMensagem;
                log.WriteEntry(conteudoMensagem, tipoMensagem);
            }
            catch (Exception)
            {

            }
        }

        public static Int64 ObterNumeros(string texto)
        {
            var ret = texto.ToCharArray().Where(Char.IsDigit);

            return ret.Count() == 0 ? 0 : Convert.ToInt64(string.Join("", ret));
        }

        public static string RemoveAcentos(string texto)
        {
            string C_acentos = "����������������������������������������������񺰪����&";
            string S_acentos = "AAAAAAaaaaaEEEEeeeeIIIIiiiiOOOOOoooooUUUuuuuCcNooaS123E";

            string C_especiais = ";:^~`�!{}[]#$%�*���+|";

            for (int i = 0; i < S_acentos.Length; i++)
                texto = texto.Replace(C_acentos[i].ToString(), S_acentos[i].ToString()).Trim();

            for (int i = 0; i < C_especiais.Length; i++)
                texto = texto.Replace(C_especiais[i].ToString(), "").Trim();


            return texto;
        }

        public static DateTime DataReferencia
        {
            get
            {
                var DataSistema = ConfigurationManager.AppSettings["DataSistema"];
                var DiasSistema = ConfigurationManager.AppSettings["DiasSistema"];

                if (string.IsNullOrEmpty(DataSistema))
                    return string.IsNullOrEmpty(DiasSistema) ? DateTime.Today : DateTime.Today.AddDays(Convert.ToInt32(DiasSistema));

                return Convert.ToDateTime(DataSistema, new CultureInfo("pt-BR"));
            }
        }

        public static bool ValidarCPF(string cpf)
        {
            cpf = cpf.PadLeft(11, '0');

            int[] multiplicador1 = new int[9] { 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            int[] multiplicador2 = new int[10] { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

            string tempCpf;

            string digito;

            int soma;

            int resto;

            cpf = cpf.Trim();

            cpf = cpf.Replace(".", "").Replace("-", "");

            if (cpf.Length != 11)

                return false;

            tempCpf = cpf.Substring(0, 9);

            soma = 0;

            for (int i = 0; i < 9; i++)

                soma += int.Parse(tempCpf[i].ToString()) * multiplicador1[i];

            resto = soma % 11;

            if (resto < 2)

                resto = 0;

            else

                resto = 11 - resto;

            digito = resto.ToString();

            tempCpf = tempCpf + digito;

            soma = 0;

            for (int i = 0; i < 10; i++)

                soma += int.Parse(tempCpf[i].ToString()) * multiplicador2[i];

            resto = soma % 11;

            if (resto < 2)

                resto = 0;

            else

                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cpf.EndsWith(digito);

        }

        public static bool ValidarCNPJ(string cnpj)
        {
            int[] multiplicador1 = new int[12] { 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int[] multiplicador2 = new int[13] { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };
            int soma;
            int resto;
            string digito;
            string tempCnpj;

            cnpj = cnpj.Trim();
            cnpj = cnpj.Replace(".", "").Replace("-", "").Replace("/", "");

            if (cnpj.Length != 14)
                return false;

            tempCnpj = cnpj.Substring(0, 12);

            soma = 0;
            for (int i = 0; i < 12; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador1[i];

            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = resto.ToString();

            tempCnpj = tempCnpj + digito;
            soma = 0;

            for (int i = 0; i < 13; i++)
                soma += int.Parse(tempCnpj[i].ToString()) * multiplicador2[i];

            resto = (soma % 11);
            if (resto < 2)
                resto = 0;
            else
                resto = 11 - resto;

            digito = digito + resto.ToString();

            return cnpj.EndsWith(digito);
        }

        public static string FormataDocumento(long Documento)
        {
            if (Documento.ToString().Length<=11)
                return Documento.ToString(@"000\.000\.000-00");
            else
            {
                var x = Documento;
                return Documento.ToString(@"00\.000\.000\/0000-00");
            }
        }

    }
}