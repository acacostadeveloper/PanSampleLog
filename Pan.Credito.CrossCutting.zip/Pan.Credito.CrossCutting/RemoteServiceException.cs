﻿using System;

namespace Pan.Credito.CrossCutting
{
    public class RemoteServiceException : Exception
    {

        public RemoteServiceException(Exception innerException) : base(string.Format("Erro de comunicação interna: {0}", innerException.Message), innerException)
        {
        }

        public RemoteServiceException(string message) : base(message) { }
    }
}
