﻿using System;

namespace Pan.Credito.CrossCutting
{
    public static class Format
    {

        public static String CPF(String Valor)
        {
            try
            {
                return CPF(Convert.ToInt64(Valor));
            }
            catch
            {
                return Valor;
            }
        }


        public static String CPF(Int64 Valor)
        {
            try
            {
                return Valor.ToString(@"000\.000\.000\-00");
            }
            catch
            {
                return Valor.ToString();
            }
        }


        public static String CNPJ(String Valor)
        {
            try
            {
                return CNPJ(Convert.ToInt64(Valor));
            }
            catch
            {
                return Valor.ToString();
            }
        }


        public static String CNPJ(Int64 Valor)
        {
            try
            {
                return Valor.ToString(@"00\.000\.000/0000\-00");
            }
            catch
            {
                return Valor.ToString();
            }
        }




        public static String Telefone(Int32 p_intDDD,
                                      Int32 p_intTelefone)
        {
            return Telefone(p_intDDD.ToString(),
                            p_intTelefone.ToString());
        }

        public static String Telefone(String p_strDDD,
                                      String p_strTelefone)
        {
            Int32 intA;
            Int32 intB;


            // Verifica se string de telefone contém DDD
            //---------------------------------------------------------------------------------------------------------
            intA = p_strTelefone.IndexOf("(");
            if (intA >= 0)
            {
                intB          = p_strTelefone.IndexOf(")", intA);
                p_strDDD      = p_strTelefone.Substring(intA, intB - intA - 1);
                p_strTelefone = p_strTelefone.Substring(intB);
            }
            //---------------------------------------------------------------------------------------------------------




            // Ajusta valores
            //---------------------------------------------------------------------------------------------------------
            p_strDDD      = p_strDDD.Replace("(", "").Replace(")", "").Trim().TrimStart('0');
            p_strTelefone = p_strTelefone.Replace("-", "").Replace(" ", "").Trim();
            //---------------------------------------------------------------------------------------------------------




            // Ajusta DDD
            //---------------------------------------------------------------------------------------------------------
            if ("" != p_strDDD)
            {
                p_strDDD = "(" + p_strDDD + ") ";
            }
            //---------------------------------------------------------------------------------------------------------




            // Ajusta telefone
            //---------------------------------------------------------------------------------------------------------

            // 0800
            if (p_strTelefone.Length >= 4)
            {
                if ("0800" == p_strTelefone.Substring(0, 4))
                {
                    p_strTelefone = p_strTelefone.PadRight(11, ' ');
                    p_strTelefone = p_strTelefone.Substring(0, 4) + "-" + p_strTelefone.Substring(4, 3) + "-" +
                                    p_strTelefone.Substring(7, 4);
                    p_strTelefone = p_strTelefone.Trim();
                }

                // Outros telefones
                else if (p_strTelefone.Length <= 9)
                {
                    p_strTelefone = p_strTelefone.PadLeft(9, ' ');
                    p_strTelefone = p_strTelefone.Substring(0, 5) + "-" + p_strTelefone.Substring(5, 4);
                }
            }
            //---------------------------------------------------------------------------------------------------------
            
            
            return p_strDDD + p_strTelefone;
        }        
    }
}
