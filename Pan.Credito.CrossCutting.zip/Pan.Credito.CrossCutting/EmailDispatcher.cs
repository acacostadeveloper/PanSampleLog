﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net.Mail;
using System.Web;
using Pan.Credito.Domain.Common;

namespace Pan.Credito.CrossCutting
{
    public class EmailDispatcher : IEmailDispatcher
    {
        public void EnviarEmail(string email, ref byte[] anexos)
        {
            try
            {
                using (var smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTP_HOST"],Convert.ToInt32(ConfigurationManager.AppSettings["SMTP_PORT"])))
                {
                    smtp.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTP_USER"], ConfigurationManager.AppSettings["SMTP_PASSWORD"]);
                    smtp.EnableSsl = true;
                    smtp.DeliveryFormat = SmtpDeliveryFormat.International;
                    if (ConfigurationManager.AppSettings["SMTP_SSL"] == "0")
                    {
                        smtp.EnableSsl = false;
                        smtp.UseDefaultCredentials = false;
                    }

                    var msg = new MailMessage(ConfigurationManager.AppSettings["SMTP_EMAIL"], email, "Banco Pan - Reemissão de Boleto", Properties.Resources.index) { IsBodyHtml = true };
                   
                    if (anexos != null)
                    {
                        var ms = new MemoryStream(anexos);
                        var anexo = new Attachment(ms, string.Format("boleto.pdf"));
                        msg.Attachments.Add(anexo);
                    }
                    smtp.Send(msg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ERRO AO ENVIAR EMAIL", ex);
            }
        }
        public void EnviarEmail(string email,string assunto,string fileName, ref byte[] anexos)
        {
            try
            {
                using (var smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTP_HOST"], Convert.ToInt32(ConfigurationManager.AppSettings["SMTP_PORT"])))
                {
                    smtp.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTP_USER"], ConfigurationManager.AppSettings["SMTP_PASSWORD"]);
                    smtp.EnableSsl = true;
                    smtp.DeliveryFormat = SmtpDeliveryFormat.International;
                    if (ConfigurationManager.AppSettings["SMTP_SSL"] == "0")
                    {
                        smtp.EnableSsl = false;
                        smtp.UseDefaultCredentials = false;
                    }

                    var msg = new MailMessage(ConfigurationManager.AppSettings["SMTP_EMAIL"], email, assunto, Properties.Resources.index) { IsBodyHtml = true };

                    if (anexos != null)
                    {
                        var ms = new MemoryStream(anexos);
                        var anexo = new Attachment(ms, string.Format(fileName));
                        msg.Attachments.Add(anexo);
                    }
                    smtp.Send(msg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ERRO AO ENVIAR EMAIL", ex);
            }
        }
        public void EnviarEmail(string email, string assunto,string corpoMsg,ref Dictionary<string, byte[]> anexos)
        {
            try
            {
                using (var smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTP_HOST"], Convert.ToInt32(ConfigurationManager.AppSettings["SMTP_PORT"])))
                {
                    smtp.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTP_USER"], ConfigurationManager.AppSettings["SMTP_PASSWORD"]);
                    smtp.EnableSsl = true;
                    smtp.DeliveryFormat = SmtpDeliveryFormat.International;

                    if (ConfigurationManager.AppSettings["SMTP_SSL"] == "0")
                    {
                        smtp.EnableSsl = false;
                        smtp.UseDefaultCredentials = false;
                    }

                    var msg = new MailMessage(ConfigurationManager.AppSettings["SMTP_EMAIL"], email, assunto, corpoMsg) { IsBodyHtml = true };

                    if (anexos.Count > 0)
                    {
                        foreach(var anexo in anexos)
                        {
                             var ms = new MemoryStream(anexo.Value);
                             msg.Attachments.Add(new Attachment(ms, string.Format(anexo.Key)));
                        }
                    }
                    smtp.Send(msg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ERRO AO ENVIAR EMAIL", ex);
            }
        }
        public void EnviarEmail(string email, string assunto, string corpoEmail, string anexoNome, byte[] anexos = null)
        {
            try
            {
                using (var smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTP_HOST"], Convert.ToInt32(ConfigurationManager.AppSettings["SMTP_PORT"])))
                {
             
                    smtp.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTP_USER"], ConfigurationManager.AppSettings["SMTP_PASSWORD"]);
                    smtp.EnableSsl = true;
                    smtp.DeliveryFormat = SmtpDeliveryFormat.International;
                    if (ConfigurationManager.AppSettings["SMTP_SSL"] == "0")
                    {
                        smtp.EnableSsl = false;
                        smtp.UseDefaultCredentials = false;
                    }
                    var msg = new MailMessage(ConfigurationManager.AppSettings["SMTP_EMAIL"], email, assunto, corpoEmail) { IsBodyHtml = true };

                    if (anexos != null)
                    {
                        var ms = new MemoryStream(anexos);
                        var anexo = new Attachment(ms, anexoNome);
                        msg.Attachments.Add(anexo);
                    }
                    smtp.Send(msg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ERRO AO ENVIAR EMAIL", ex);
            }
        }
        public void SendTokenEmail(string email, string token)
        {
            const string tokenString = "{{TokenNumber}}";
            var body = Properties.Resources.security_token.Replace(tokenString, token);

            try
            {
                using (var smtp = new SmtpClient(ConfigurationManager.AppSettings["SMTP_HOST"], Convert.ToInt32(ConfigurationManager.AppSettings["SMTP_PORT"])))
                {
                    smtp.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["SMTP_USER"], ConfigurationManager.AppSettings["SMTP_PASSWORD"]);
                    smtp.EnableSsl = true;
                    smtp.DeliveryFormat = SmtpDeliveryFormat.International;
                    if (ConfigurationManager.AppSettings["SMTP_SSL"] == "0")
                    {
                        smtp.EnableSsl = false;
                        smtp.UseDefaultCredentials = false;
                    }
                    var msg = new MailMessage(ConfigurationManager.AppSettings["SMTP_EMAIL"], email, "Banco Pan - Security Code", body) { IsBodyHtml = true };
                    smtp.Send(msg);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("ERRO AO ENVIAR EMAIL", ex);
            }
        }

        private static string GenerateFileHtml(string email, string token, string templateName)
        {
            const string tokenString = "{{TokenNumber}}";
            const string emailString = "{{UserEmail}}";
            const string urlWebBanking = "{{UrlWebBanking}}";

            string urlWebBankingConfig = System.Configuration.ConfigurationManager.AppSettings["UrlWebBanking"];

            //Adicionando o complemento do path.
            var pathApplication = string.Format(@"{0}Templates\Email\", AppDomain.CurrentDomain.BaseDirectory);

            var streamFile = new StreamReader(string.Concat(pathApplication, templateName));
            var html = streamFile.ReadToEnd();

            html = html.Replace(emailString, email).Replace(tokenString, token);
            html = html.Replace(HttpUtility.HtmlEncode(emailString), email).Replace(HttpUtility.HtmlEncode(tokenString), token);
            html = html.Replace(urlWebBanking, urlWebBankingConfig);

            return html;
        }
        public void Dispose()
        {
        }
    }
}