﻿using System;
using System.ComponentModel;
using System.Data.Common;
using System.Linq;
using System.Reflection;

namespace Pan.Credito.CrossCutting
{
    public static class Extensoes
    {
        public static T ConverterPara<T>(this Object value)
        {
            T obj = default(T);

            if (value == DBNull.Value)
            {
                return default(T);
            }


            try
            {
                obj = (T)Convert.ChangeType(value,
                                             typeof(T));
            }
            catch
            {
                obj = default(T);
            }

            return obj;
        }

        public static T ConverterPara<T>(this Object value, T defaultValue, IFormatProvider provider = null)
        {
            T obj = default(T);

            if (value == DBNull.Value)
            {
                return defaultValue;
            }

            try
            {
                obj = (T)Convert.ChangeType(value,
                                             typeof(T),
                                             provider);
            }
            catch
            {
                obj = defaultValue;
            }

            return obj;
        }

        public static string ToEnumDescription(this Enum en)
        {
            Type objType = en.GetType();
            MemberInfo[] arrMembers = objType.GetMember(en.ToString());
            Object[] arrAttributes;


            if (arrMembers != null && arrMembers.Length > 0)
            {
                arrAttributes = arrMembers[0].GetCustomAttributes(typeof(DescriptionAttribute), false);

                if (arrAttributes != null && arrAttributes.Length > 0)
                {
                    return ((DescriptionAttribute)arrAttributes[0]).Description;
                }
            }
            return en.ToString();
        }
        
        public static T GetValue<T>(this DbDataReader DR, String Campo)
        {
            if (DR[Campo] == DBNull.Value)
                return default(T);
            else
                return (T)Convert.ChangeType(DR[Campo], typeof(T));
        }

        public static T GetValue<T>(this DbDataReader DR, String Campo, T ValorAlternativo)
        {
            if (DR[Campo] == DBNull.Value)
                return ValorAlternativo;
            else
                return (T)Convert.ChangeType(DR[Campo], typeof(T));
        }

        public static T GetAttributeFrom<T>(this object instance, string propertyName)
        {
            var attrType = typeof(T);
            var property = instance.GetType().GetProperty(propertyName);

            object[] re = property.GetCustomAttributes(attrType, false);

            if (re.Length > 0)
                return (T)property.GetCustomAttributes(attrType, false).First();
            else
                return default(T);
        }

        public enum TipoTexto
        {
            Numero,
            Palavra
        }

        public static string Left(this string param, int length)
        {
            string result = param.Trim().Length < length ? param : param.Substring(0, length);
            return result;
        }

        public static string Right(this string param, int length)
        {
            string result = param.Trim().Length < length ? param : param.Substring(param.Length - length, length);
            return result;
        }

        public static string Right(this string param, int length, TipoTexto numeroOuPalavra)
        {
            string result = string.Empty;

            if (numeroOuPalavra == TipoTexto.Numero)
                result = param.Trim().Length < length ? param.PadRight(length, '9') : param.Substring(param.Length - length, length);
            else
                result = param.Trim().Length < length ? param.PadRight(length, ' ') : param.Substring(param.Length - length, length);

            return result;
        }

        public static string Mid(string param, int startIndex, int length)
        {
            //start at the specified index in the string ang get N number of
            //characters depending on the lenght and assign it to a variable
            string result = param.Substring(startIndex, length);
            //return the result of the operation
            return result;
        }

        public static string Mid(string param, int startIndex)
        {
            //start at the specified index and return all characters after it
            //and assign it to a variable
            string result = param.Substring(startIndex);
            //return the result of the operation
            return result;
        }
    }
}
