using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using BoletoNet;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using Boleto = Pan.Credito.Domain.Entidades.Boletos.Boleto;

namespace Pan.Credito.CrossCutting
{
    public class PdfGenerate
    {

        private readonly string strCaminhoBase = AppDomain.CurrentDomain.BaseDirectory + "App_Data\\";

        public Byte[] GerarBoletos(String p_strFormato, string formatoSaida, List<Boleto> boletos)
        {
            var strNomeArquivo = "";
            var strArquivoPDF = "";
            var strArquivoHTML = "";
            var intA = 0;
            var objSB = new StringBuilder();
            byte[] pdf = null;

            if (string.IsNullOrEmpty(formatoSaida))
            {
                formatoSaida = "pdf";
            }


            if (formatoSaida != "pdf" && formatoSaida != "jpg")
            {
                formatoSaida = "pdf";
            }

            if (string.IsNullOrWhiteSpace(p_strFormato)) p_strFormato = "c";

            strNomeArquivo = Guid.NewGuid().ToString();
            var arrArquivosHTM = new List<string>();
            strArquivoPDF = string.Format("{0}Temp\\{1}_{2}.pdf", strCaminhoBase, strNomeArquivo, p_strFormato);
            var arrArquivosCodigoBarra = new List<string>();

            try
            {
                Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("pt-BR");

                if (!boletos.Any()) throw new ArgumentException("N�O FOI FORNECIDA NENHUMA INFORMA��O PARA GERA��O DE BOLETOS");

                var boleto = boletos.FirstOrDefault();
                var lstBoletosNet = GerarBoletosBoletoNet(boletos);
                foreach (var objBoleto in lstBoletosNet)
                {
                    if ("b" == p_strFormato || (intA % 3) == 0)
                        strArquivoHTML = string.Format("{0}Temp\\{1}_{2}{3}.htm", strCaminhoBase, strNomeArquivo, p_strFormato, intA);
                    var objBoletoBancario = new BoletoBancario()
                    {
                        CaminhoArquivos = string.Format("{0}Temp\\", strCaminhoBase),
                        CodigoBanco = Convert.ToInt16(objBoleto.Banco.Codigo),
                        Boleto = objBoleto,
                        MostrarCodigoCarteira = false,
                        MostrarEnderecoCedenteCarne = true
                    };
                    if ("c" == p_strFormato)
                    {
                        objBoletoBancario.FormatoCarne = true;
                        objBoletoBancario.OcultarInstrucoes = true;
                    }
                    else
                    {
                        objBoletoBancario.MostrarComprovanteEntrega = false;
                    }
                    try
                    {

                        objBoleto.Valida();

                        if (boleto.Cartao)
                        {
                            objBoleto.CodigoBarra.Codigo = boleto.CodigoBarras;
                            objBoleto.CodigoBarra.LinhaDigitavel = boleto.LinhaDigitavel;
                            objBoleto.LocalPagamento = boleto.LocalPagamento;
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new Exception("Ocorreu um erro durante a valida��o dos dados do boleto: " + ex.Message, ex.InnerException);
                    }
                    var strHTML = objBoletoBancario.MontaHtml();

                    if ("b" == p_strFormato)
                    {
                        File.WriteAllText(strArquivoHTML, strHTML, Encoding.UTF8);

                        arrArquivosHTM.Add(strArquivoHTML);
                    }
                    else
                    {
                        strHTML = strHTML.Substring(0, strHTML.IndexOf("</body>"));

                        if ((intA % 3) != 0)
                        {
                            strHTML = strHTML.Substring(strHTML.IndexOf("<body>") + 6);
                            objSB.Append("<table width=\"100%\"><tr class=\"h1\"><td /></tr><tr><td class=\"cut\" /></tr><tr class=\"h1\"><td /></tr></table>");
                        }
                        objSB.Append(strHTML);
                        if (((intA % 3) == 2) || ((intA + 1) == lstBoletosNet.Count))
                        {
                            objSB.Append("<table width=\"100%\"><tr class=\"h1\"><td /></tr><tr><td class=\"cut\" /></tr><tr class=\"h1\"><td /></tr></table>");
                            objSB.Append("</body></html>");

                            File.WriteAllText(strArquivoHTML, objSB.ToString(), Encoding.UTF8);
                            objSB.Clear();
                            arrArquivosHTM.Add(strArquivoHTML);
                        }
                    }
                    arrArquivosCodigoBarra.Add(objBoletoBancario.CaminhoArquivoCodigoBarra);
                    intA++;
                }

                if (formatoSaida == "pdf")
                {
                    if (!FromHTMLToPdf(strArquivoPDF, arrArquivosHTM, (Int16)(p_strFormato == "c" ? 9 : 18), (Int16)(p_strFormato == "c" ? 9 : 18), (Int16)(p_strFormato == "c" ? 4 : 12), 0))
                    {
                        throw new Exception("Ocorreu um erro durante a gera��o do arquivo PDF");
                    }
                }
                pdf = File.ReadAllBytes(strArquivoPDF);
            }
            finally
            {
                foreach (var strArquivo in arrArquivosHTM)
                {
                    if (!string.IsNullOrEmpty(strArquivo)) File.Delete(strArquivo);
                }
                foreach (var strArquivo in arrArquivosCodigoBarra)
                {
                    if (!string.IsNullOrEmpty(strArquivo)) File.Delete(strArquivo);
                }
                if (!string.IsNullOrEmpty(strArquivoPDF)) File.Delete(strArquivoPDF);
            }
            return pdf;
        }
        public List<BoletoNet.Boleto> BindLinhaDigitavel(List<Boleto> boletos)
        {
            if (boletos.Count == 0) return new List<BoletoNet.Boleto>();

            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("pt-BR");

            var lstBoletosNet = GerarBoletosBoletoNet(boletos);
            foreach (var objBoleto in lstBoletosNet)
            {
                var objBoletoBancario = new BoletoBancario()
                {
                    CaminhoArquivos = string.Format("{0}Temp\\", strCaminhoBase),
                    CodigoBanco = Convert.ToInt16(objBoleto.Banco.Codigo),
                    Boleto = objBoleto,
                    MostrarCodigoCarteira = false,
                    MostrarEnderecoCedenteCarne = true
                };
                objBoletoBancario.FormatoCarne = true;
                objBoletoBancario.OcultarInstrucoes = true;
                try
                {
                    objBoleto.Valida();
                }
                catch { }
            }
            return lstBoletosNet;
        }


        public bool FromHTMLToPdf(String p_strArquivoPDF, List<string> p_arrArquivosHTM, Int16 p_intMargemEsquerda, Int16 p_intMargemDireita, Int16 p_intMargemSuperior, Int16 p_intMargemInferior)
        {
            var objProcess = new Process();
            var strArquivosHTM = string.Join(" ", p_arrArquivosHTM);
            objProcess.StartInfo.FileName = strCaminhoBase + "ConversorPDF\\wkhtmltopdf.exe";
            objProcess.StartInfo.Arguments = "-O Portrait -B " + p_intMargemInferior + " -L " + p_intMargemEsquerda + " -R " + p_intMargemDireita + " -T " + p_intMargemSuperior + " --page-size A4 --disable-smart-shrinking -q " + strArquivosHTM + " " + p_strArquivoPDF;
            objProcess.StartInfo.CreateNoWindow = true;
            objProcess.StartInfo.UseShellExecute = false;
            objProcess.StartInfo.RedirectStandardOutput = true;
            objProcess.StartInfo.RedirectStandardError = true;
            objProcess.StartInfo.RedirectStandardInput = true;
            objProcess.StartInfo.WorkingDirectory = strCaminhoBase + "ConversorPDF";
            objProcess.Start();
            objProcess.StandardOutput.ReadToEnd();

            objProcess.WaitForExit(10000);
            var intReturnCode = objProcess.ExitCode;
            objProcess.Close();
            return (intReturnCode == 0 || intReturnCode == 2);
        }
        public List<BoletoNet.Boleto> GerarBoletosBoletoNet(List<Boleto> p_lstBoletos)
        {
            var lstBoletos = new List<BoletoNet.Boleto>();
            BoletoNet.Boleto objBoletoNet;
            foreach (var objBoleto in p_lstBoletos)
            {
                if (objBoleto == null) return null;

                try
                {
                    objBoleto.Banco.Codigo = objBoleto.Banco.Codigo;// Convert.ToInt32(objBoleto.LinhaDigitavel.Substring(0, 3));

                    objBoletoNet = new BoletoNet.Boleto()
                    {
                        Banco = new BoletoNet.Banco(objBoleto.Banco.Codigo),
                        Cedente = new BoletoNet.Cedente()
                        {
                            Codigo = objBoleto.Cedente.Codigo,
                            CPFCNPJ = objBoleto.Cedente.CPFCNPJ.PadLeft(14, '0'),
                            Nome = objBoleto.Cedente.Nome,
                            ContaBancaria = new BoletoNet.ContaBancaria()
                            {
                                Agencia = objBoleto.Cedente.ContaBancaria.Agencia,
                                DigitoAgencia = objBoleto.Cedente.ContaBancaria.DigitoAgencia,
                                Conta = objBoleto.Cedente.ContaBancaria.Conta.PadLeft(5, '0'),
                                DigitoConta = objBoleto.Cedente.ContaBancaria.DigitoConta
                            },
                            Endereco = new BoletoNet.Endereco()
                            {
                                Numero = objBoleto.Cedente.Endereco.Numero,
                                Complemento = objBoleto.Cedente.Endereco.Complemento,
                                Bairro = objBoleto.Cedente.Endereco.Bairro,
                                Cidade = objBoleto.Cedente.Endereco.Cidade,
                                UF = objBoleto.Cedente.Endereco.UF,
                                CEP = objBoleto.Cedente.Endereco.CEP,
                                Logradouro = objBoleto.Cedente.Endereco.Logradouro,
                                End = objBoleto.Cedente.Endereco.Logradouro + ((objBoleto.Cedente.Endereco.Numero != "") ? ", " + objBoleto.Cedente.Endereco.Numero : "") + ((objBoleto.Cedente.Endereco.Complemento != "") ? " - " + objBoleto.Cedente.Endereco.Complemento : "")
                            }
                        },
                        Sacado = new BoletoNet.Sacado(objBoleto.Sacado.CPFCNPJ.PadLeft((objBoleto.Sacado.TipoPessoa == "F" ? 11 : 14), '0'), objBoleto.Sacado.Nome)
                        {
                            Endereco = new BoletoNet.Endereco()
                            {
                                Logradouro = objBoleto.Sacado.Endereco.Logradouro,
                                Numero = objBoleto.Sacado.Endereco.Numero,
                                Complemento = objBoleto.Sacado.Endereco.Complemento,
                                Bairro = objBoleto.Sacado.Endereco.Bairro,
                                Cidade = objBoleto.Sacado.Endereco.Cidade,
                                UF = objBoleto.Sacado.Endereco.UF,
                                CEP = objBoleto.Sacado.Endereco.CEP,
                                End = objBoleto.Sacado.Endereco.Logradouro + ((objBoleto.Sacado.Endereco.Numero != "") ? ", " + objBoleto.Sacado.Endereco.Numero : "") + ((objBoleto.Sacado.Endereco.Complemento != "") ? " - " + objBoleto.Sacado.Endereco.Complemento : "")
                            }
                        },
                        NumeroParcela = objBoleto.NumeroParcela,
                        NumeroParcelas = objBoleto.NumeroParcelas,
                        DataVencimento = objBoleto.DataVencimento,
                        ValorBoleto = objBoleto.ValorBoleto,
                        Carteira = objBoleto.Carteira,
                        NumeroDocumento = objBoleto.NumeroDocumento,
                        Aceite = objBoleto.Aceite,
                        LocalPagamento = "Lot�ricas"
                    };
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                switch (objBoleto.Banco.Codigo)
                {
                    case 623:
                        objBoletoNet.NossoNumero = objBoleto.NossoNumero.Substring(0, 10);//.Substring(1, objBoleto.NossoNumero.Length - 1).PadLeft(10, '0');

                        objBoletoNet.Cedente.ContaBancaria.Agencia = objBoletoNet.Cedente.ContaBancaria.Agencia.PadLeft(4, '0');
                        break;

                    default:
                        objBoletoNet.NossoNumero = objBoleto.NossoNumero.Substring(0, objBoleto.NossoNumero.Length - 1);

                        break;
                }
                switch (objBoleto.Banco.Codigo)
                {
                    case 104: //Caixa
                        if (objBoletoNet.Cedente.Codigo == 0)
                            objBoletoNet.Cedente.Codigo = 245811;

                        break;

                    case 237: // Bradesco
                    case 341: // Ita�
                        objBoletoNet.Cedente.Codigo = 13000;
                        break;
                    default:
                        break;
                }
                switch (objBoleto.Banco.Codigo)
                {
                    case 104: //Caixa
                        objBoletoNet.EspecieDocumento = new EspecieDocumento_Caixa("17");

                        if ("14" == objBoleto.Carteira)
                        {
                            objBoletoNet.Carteira = "RG";
                            objBoletoNet.NossoNumero = "1400000" + objBoletoNet.NossoNumero.Substring(objBoletoNet.NossoNumero.Length - 10, 10);
                        }
                        else if ("24" == objBoleto.Carteira)
                        {
                            objBoletoNet.Carteira = "SR";
                            objBoletoNet.NossoNumero = "2400000" + objBoletoNet.NossoNumero.Substring(objBoletoNet.NossoNumero.Length - 10, 10);
                        }
                        else
                        {
                            objBoletoNet.Carteira = objBoleto.Carteira;
                            objBoletoNet.NossoNumero = objBoletoNet.NossoNumero.Substring(0, 10);//.Substring(objBoletoNet.NossoNumero.Length - 10, 10);
                        }
                        break;

                    case 237:
                        objBoletoNet.Carteira = objBoleto.Carteira.PadLeft(2, '0');
                        break;
                    case 623:
                        objBoletoNet.Carteira = objBoleto.Carteira.PadLeft(3, '0');
                        break;

                    default:
                        break;
                }
                foreach (string strInstrucao in objBoleto.Instrucoes)
                {
                    if (104 != objBoletoNet.Banco.Codigo)
                        objBoletoNet.Instrucoes.Add(new BoletoNet.Instrucao(objBoleto.Banco.Codigo) { Descricao = strInstrucao });
                    else
                        objBoletoNet.Instrucoes.Add(new BoletoNet.Instrucao_Caixa() { Descricao = strInstrucao });
                }
                lstBoletos.Add(objBoletoNet);
            }
            return lstBoletos;
        }

    }
}