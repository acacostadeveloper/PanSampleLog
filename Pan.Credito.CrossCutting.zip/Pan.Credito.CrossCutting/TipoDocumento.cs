﻿namespace Pan.Credito.CrossCutting
{
    public enum TipoDocumento
    {
        CPF,
        CNPJ
    }
}
