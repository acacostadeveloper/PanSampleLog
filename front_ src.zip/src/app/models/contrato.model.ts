import { Produto } from "./produto.model";
import { Cliente } from "./cliente.model";
import { Coligada } from "./coligada.model";

export class Contrato {
    produto: Produto = new Produto() 
    cliente: Cliente = new Cliente()
    coligada: Coligada = new Coligada()
    numeroContrato: string
    convenio: string
}