export class Produto {
    codigoProduto: string
    nomeProduto: string
}