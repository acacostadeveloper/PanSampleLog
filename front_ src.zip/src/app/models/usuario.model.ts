export class Usuario {
  codigoUsuario: string
}