export class Cliente {
    numeroCpfCnpj: string
    nomeCliente: string
    tipoPessoa: string
}