export class Sigla {
    codigoSigla: string
    nomeSigla: string
}