export class Coligada {
    codigoColigada: string
}