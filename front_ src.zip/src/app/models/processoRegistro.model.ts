export class ProcessoRegistro {
    codigoProcessoRegistro: string
}