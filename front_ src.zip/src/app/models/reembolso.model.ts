import { Usuario } from "./usuario.model";
import { Departamento } from "./departamento.model";
import { Contrato } from "./contrato.model";
import { Sigla } from "./sigla.model";
import { ProcessoRegistro } from "./processoRegistro.model";

export class Reembolso {
  idReembolso: number
  usuario: Usuario = new Usuario()
  departamento: Departamento = new Departamento()
  contrato: Contrato = new Contrato()
  dataSolicitacao: string
  valorReembolso: string
  mesCompetencia: number
  anoCompetencia: number
  sigla: Sigla = new Sigla()
  idLote: number
  statusReembolso: string
  processoRegistro: ProcessoRegistro = new ProcessoRegistro()
}


