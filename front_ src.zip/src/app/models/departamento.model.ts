export class Departamento {
    codigoDepartamento: string
}