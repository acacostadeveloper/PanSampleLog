import {environment} from '../environments/environment'

export const APP_API = environment.api
