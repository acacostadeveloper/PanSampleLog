import {Routes} from '@angular/router'

import {HomeComponent} from './home/home.component'
import { IncluirReembolsoComponent } from './reembolso/incluir-reembolso/incluir-reembolso.component';
import { ConsultarReembolsoComponent } from './reembolso/consultar-reembolso/consultar-reembolso.component';

export const ROUTES: Routes = [
  {path: '', component: HomeComponent},
  {path: 'incluir-reembolso', component: IncluirReembolsoComponent},
  {path: 'consultar-reembolso', component: ConsultarReembolsoComponent}
]
