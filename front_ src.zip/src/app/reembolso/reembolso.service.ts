import { Injectable } from '@angular/core'
import { Observable, of, observable } from 'rxjs'
import { APP_API } from '../app.api'
import { Reembolso } from '../models/reembolso.model';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReembolsoService {

  constructor(private http: HttpClient) { }

  addReembolso(reembolso: Reembolso): Observable<Reembolso[]> {
    let listaReembolso: Reembolso[] = [];
    listaReembolso.push(reembolso);
    return this.http.post<Reembolso[]>(`${APP_API}reembolso`, listaReembolso).pipe(
      catchError(
        (error: any, caught: Observable<HttpEvent<any>>) => {
          throw error;
        }
      ),

    );
  }

  obterReembolsos(
    idLote: string,
    idProduto: string,
    dtInicial: string,
    dtFinal: string,
    cpfCliente: string,
    statusReembolso: string
  ): Observable<any> {

    return this.http
      .get(`${APP_API}reembolso/obter`,
        {
          params: {
            idLote: idLote,
            idProduto: idProduto,
            dtInicial: dtInicial,
            dtFinal: dtFinal,
            cpfCliente: cpfCliente,
            statusReembolso: statusReembolso
          }
        }
      ).pipe(
        tap(data => data),
        catchError(
          (response: Response) => {
            return of(response);
            ;
          }
        )
      );
  }
}
