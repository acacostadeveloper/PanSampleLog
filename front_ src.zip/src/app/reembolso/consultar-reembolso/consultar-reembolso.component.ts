import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { Reembolso } from '../../models/reembolso.model';
import { Produto } from '../../models/produto.model';
import { ProdutoService } from '../../produto/produto.service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ModalDialogService, SimpleModalComponent } from 'ngx-modal-dialog'; //https://github.com/Greentube/ngx-modal/blob/master/demo/src/app/app.component.ts#L30-L32
import { HttpErrorResponse } from '@angular/common/http';


@Component({
  selector: 'pan-consultar-reembolso',
  templateUrl: './consultar-reembolso.component.html',
  styleUrls: ['./consultar-reembolso.component.css']
})
export class ConsultarReembolsoComponent implements OnInit {
  public reembolsos: Reembolso[] = [];
  reembolso = new Reembolso();
  produtos: Produto[];


  //Filtros:
  filterIdLote: string;
  filterIdProduto: string;
  filterDtInicial: IMyDateModel;
  filterDtFinal: IMyDateModel;
  filterCpfClientes: string;
  filterStatusReembolso: string;

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };

  constructor(
    private reembolsoService: ReembolsoService,
    private produtoService: ProdutoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef
  ) { }

  ngOnInit() {
    this.carregarProdutos();
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data;
        }
      ),
      error => {
        console.log(error)
      }
      ;
  }

  formatDate(date: IMyDateModel) {
    let retorno: string
    if (date == undefined || date == null) {
      retorno = "";
    }
    else {
      retorno = date.date.month + "/" + date.date.day + "/" + date.date.year;
    }
    return retorno;
  }

  mensagemModal(mensagem: string) {
    this.modalService.openDialog(this.viewRef, {
      title: 'Atenção:',
      childComponent: SimpleModalComponent,
      settings: {
        closeButtonClass: 'close theme-icon-close'
      },
      data: {
        text: mensagem
      }
    });
  }

  verificarDataFinalMenor(dataInicial, dataFinal) {
    let _dataInicial: IMyDateModel;
    let _dataFinal: IMyDateModel;

    _dataInicial = dataInicial;
    _dataFinal = dataFinal;

    if (_dataFinal.epoc < _dataInicial.epoc) {
      return true;
    }
    else {
      return false;
    }
  }

  carregarReembolsos() {

    if (this.validarCampos()) {
      this.formatDate(this.filterDtFinal);
      this
        .reembolsoService
        .obterReembolsos(
          this.filterIdLote,
          this.filterIdProduto,
          this.formatDate(this.filterDtInicial) + " 00:00:00",
          this.formatDate(this.filterDtFinal) + " 23:59:59",
          this.filterCpfClientes,
          this.filterStatusReembolso,
        )
        .subscribe(
          (data: Reembolso[]) => {
            if(data instanceof HttpErrorResponse)
            {
              var retorno: HttpErrorResponse;
              retorno = data;
              if(retorno.status == 502){
                this.mensagemModal("Não foram encontrados registros com este parametro");
              }
              else
              {
                this.mensagemModal("Ocorreu o erro: " + data.statusText);
              }
              
            }
            else
            {
              this.reembolsos = data;
            }
          }
        ),
        error => {
          this.mensagemModal("Ocorreu o erro: " + error);
        }
        ;
    }
  }

  validarCampos() {
    let mensagemRetorno: string = "";

    if(this.filterCpfClientes == undefined)
    {
      this.filterCpfClientes = "";
    }

    if(this.filterStatusReembolso == undefined)
    {
      this.filterStatusReembolso = "";
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null;
      this.filterDtFinal = null;
    }
    else {
      if (this.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>";
      }
    }

    if(mensagemRetorno == "")
    {
      return true;
    }
    else
    {
      this.mensagemModal(mensagemRetorno);
      return false;
    }
  }
}
