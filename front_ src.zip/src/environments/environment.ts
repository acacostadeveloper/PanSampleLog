// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  api: 'http://localhost:4200/api/api/',
  codigoDepartamento: "0000020",
  codigoColigada: "001",
  meses: [
    { id: 1, mes: "janeiro" },
    { id: 2, mes: "fevereiro" },
    { id: 3, mes: "março" },
    { id: 4, mes: "abril" },
    { id: 5, mes: "maio" },
    { id: 6, mes: "junho" },
    { id: 7, mes: "julho" },
    { id: 8, mes: "agosto" },
    { id: 9, mes: "setembro" },
    { id: 10, mes: "outubro" },
    { id: 11, mes: "novembro" },
    { id: 12, mes: "dezembro" }
  ]
};

/*
 * In development mode, for easier debugging, you can ignore zone related error
 * stack frames such as `zone.run`/`zoneDelegate.invokeTask` by importing the
 * below file. Don't forget to comment it out in production mode
 * because it will have a performance impact when errors are thrown
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
