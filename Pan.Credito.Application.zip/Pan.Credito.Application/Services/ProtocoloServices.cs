﻿using System;
using Pan.Credito.Domain.Entidades.Protocolo;
using Pan.Credito.Domain.Repository;
using Pan.Credito.Domain.Services;

namespace Pan.Credito.Application.Services
{
    public class ProtocoloServices : IProtocoloServices
    {
        private readonly IRcpRepository _rcpRepository;

        public ProtocoloServices(IRcpRepository rcpRepository)
        {
            _rcpRepository = rcpRepository;
        }

        public long AbrirProtocolo(ProtocoloModel protocolo)
        {
            var sac = new SAC_SDC
            {
                NR_CPF = Convert.ToDecimal(protocolo.CpfCnpj),
                DS_EMAIL = protocolo.Email,
                DS_NOME = protocolo.NomeCliente,
                CD_ATENDIMENTO = !string.IsNullOrEmpty(protocolo.CdAtendimento) ? Convert.ToDecimal(protocolo.CdAtendimento) : decimal.Zero,
                DS_OBS_ABERTURA =string.Format("[{0}] Atendimento realizado via CHATBOT no site institucional do Banco Pan.",protocolo.Contrato),
                NR_DDDFONE1 = !string.IsNullOrEmpty(protocolo.DDD1) ? Convert.ToDecimal(protocolo.DDD1) : decimal.Zero,
                NR_FONE1 = !string.IsNullOrEmpty(protocolo.Fone1) ? Convert.ToDecimal(protocolo.Fone1) : decimal.Zero,
                NR_DDDFONE2 = !string.IsNullOrEmpty(protocolo.DDD2) ? Convert.ToDecimal(protocolo.DDD2) : decimal.Zero,
                NR_FONE2 = !string.IsNullOrEmpty(protocolo.Fone2) ? Convert.ToDecimal(protocolo.Fone2) : decimal.Zero
            };

            var retorno =  _rcpRepository.AddChamadoSpa(sac);
           return retorno ?? 0;
        }

        public void Dispose()
        {
            _rcpRepository.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}