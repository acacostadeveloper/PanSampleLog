using System;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Types;

namespace Pan.Credito.Application.Services
{
    public class DeclaracaoServices
    {
        private readonly IFuncaoAdapter _funcaoAdapter;

        public DeclaracaoServices(IFuncaoAdapter funcaoAdapter)
        {
            _funcaoAdapter = funcaoAdapter;
        }

        public ClienteExtrato QuitacaoContrato(Origens Origem, Int64 Documento, string Contrato)
        {
            switch (Origem)
            {
                case Origens.Funcao:
                    return _funcaoAdapter.ObterDeclaracaoQuitacao(Documento, Contrato);
                case Origens.PanSolution:
                    throw new NotImplementedException();
            }
            return null;
        }
    }
}