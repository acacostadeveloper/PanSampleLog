﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Services;

namespace Pan.Credito.Application.Services
{
    public class ExtratoServices : IExtratoServices
    {
        private readonly IExtratosAdapter _extratosAdapter;

        public ExtratoServices(IExtratosAdapter extratosAdapter)
        {
            _extratosAdapter = extratosAdapter;
        }

        public string ObterExtratoDePagamentos(int ano, string documento, string email, bool enviaEmail)
        {
            var retorno = _extratosAdapter.ObterExtratoDepagamentos(ano, documento, email, enviaEmail);
            if (retorno != null) return enviaEmail ? null : Convert.ToBase64String(retorno);
            return null;
        }

        public string ObterExtratoTarifas(int ano, string documento, string email, bool enviaEmail)
        {
            var retorno = _extratosAdapter.ObterExtratoTarifas(ano, documento, email, enviaEmail);
            if (retorno != null) return enviaEmail ? null : Convert.ToBase64String(retorno);
            return null;
        }

        public string ObterInformeDeRedimentos(int ano, string documento, string email, bool enviaEmail)
        {
            var retorno = _extratosAdapter.ObterInformeDeRedimentos(ano, documento, email, enviaEmail);
            if (retorno != null) return enviaEmail ? null : Convert.ToBase64String(retorno);
            return null;
        }

        public string DeclaracaoContratoQuitado(string contrato, string email, bool enviaEmail)
        {
            var retorno = _extratosAdapter.DeclaracaoContratoQuitado(contrato, email, enviaEmail);
            if (retorno != null) return enviaEmail ? null : Convert.ToBase64String(retorno);
            return null;
        }

        public string ObterCartaResumo(string documento, string contrato, string email, bool enviaEmail)
        {
            var retorno = _extratosAdapter.ObterCartaResumo(documento, contrato, email, enviaEmail);
            if (retorno != null) return enviaEmail ? null : Convert.ToBase64String(retorno);
            return null;
        }

        public Dictionary<string, string> GuiaSubstituicaoDeGarantia(string email, bool enviarEmail)
        {
            var anexosByte = _extratosAdapter.GuiaSubstituicaoDeGarantia(email, enviarEmail);
            var anexos = anexosByte.ToDictionary(anexo => anexo.Key, anexo => Convert.ToBase64String(anexo.Value));
            return anexos;
        }

        public Dictionary<string, string> GuiaTransferenciaDivida(string email, bool enviarEmail)
        {
            var anexosByte = _extratosAdapter.GuiaTransferenciaDivida(email, enviarEmail);
            var anexos = anexosByte.ToDictionary(anexo => anexo.Key, anexo => Convert.ToBase64String(anexo.Value));
            return anexos;
        }

        public void Dispose()
        {
            _extratosAdapter.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}