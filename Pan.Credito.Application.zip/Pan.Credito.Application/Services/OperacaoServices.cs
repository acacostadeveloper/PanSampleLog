﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Services;

namespace Pan.Credito.Application.Services
{
    public class OperacaoServices : IOperacaoServices
    {
        private readonly IFuncaoAdapter _funcaoAdapter;
        private readonly IPansolutionAdapter _pansolutionAdapter;
        public OperacaoServices(IFuncaoAdapter funcaoAdapter, IPansolutionAdapter pansolutionAdapter)
        {
            _funcaoAdapter = funcaoAdapter;
            _pansolutionAdapter = pansolutionAdapter;
        }

        public OperacaoCredito ObterOperacao(string Contrato)
        {
            if (string.IsNullOrWhiteSpace(Contrato)) throw new ArgumentException("Contrato Invalido");
            var operacao = _funcaoAdapter.ObterOperacao(Contrato, 0);
            return operacao ?? null;
        }

        public List<OperacaoCredito> ObterOperacoes(string cpfCnpj)
        {
            if (string.IsNullOrWhiteSpace(cpfCnpj)) throw new ArgumentException("Cpf ou Cnpj invalido");

            var operacoes = _funcaoAdapter.ObterOperacoes(string.Empty, Convert.ToInt64(cpfCnpj));
            //try
            //{
            //    var contratos = _pansolutionAdapter.ObterContratos(Convert.ToInt64(cpfCnpj));
            //    operacoes.AddRange(contratos.Select(contrato => _pansolutionAdapter.ObterOperacaoPansolution(contrato.NumeroContrato)));
            //}
            //catch
            //{
            //    // ignored
            //}
            return operacoes;
        }
        public void Dispose()
        {
            GC.SuppressFinalize(this);
            _funcaoAdapter.Dispose();
        }
    }
}