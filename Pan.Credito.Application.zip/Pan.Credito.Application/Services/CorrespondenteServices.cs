﻿using System;
using System.Collections.Generic;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Repository;
using Pan.Credito.Domain.Services;
using Pan.Credito.Infrastructure.Repositories;

namespace Pan.Credito.Application.Services
{
    public class CorrespondenteServices : ICorrespondenteServices
    {
        private readonly ICorrespondenteRepository _repository;

        public CorrespondenteServices()
        {
            _repository = new CorrespondenteRepository();
        }
        public List<Correspondente> ObterCorrespondente(string cep)
        {
            var regiao = cep.Substring(0, 2);
            return _repository.ObterCorrespondente(regiao);
        }

        public void Dispose()
        {
            _repository.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}