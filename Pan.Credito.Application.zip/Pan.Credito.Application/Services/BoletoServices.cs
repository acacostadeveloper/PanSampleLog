﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pan.Credito.CrossCutting;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Services;

namespace Pan.Credito.Application.Services
{
    public class BoletoServices : IBoletoServices
    {
        private readonly IFuncaoAdapter _funcaoAdapter;

        public BoletoServices(IFuncaoAdapter funcaoAdapter)
        {
            _funcaoAdapter = funcaoAdapter;
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
            _funcaoAdapter.Dispose();
        }

        #region [ACORDO]

        public byte[] GerarPDFBinarioAcordoFuncao(string numeroAcordo, string numeroContrato)
        {
            var boleto = _funcaoAdapter.GerarBoletoAcordo(numeroAcordo, numeroContrato, 1, 1);
            return boleto;
        }

        public string[] GerarLinhasDigitaveisAcordoFuncao(string contrato)
        {
            return _funcaoAdapter.ObterLinhaDigitavelAcordo(contrato, true).ToArray();
        }


        #endregion

        #region [PARCELAS]

        public byte[] GerarPDFBinarioParcelaFuncao(string numeroContrato, int proximos = 0)
        {
            var operacao = _funcaoAdapter.ObterOperacao(numeroContrato, 0);
            var order = new Dictionary<int, byte[]>();
            if (operacao != null && operacao.Parcelas != null)
            {
                var DataAtual = CrossCutting.Common.HourBrazilNow();
                var total =
                    operacao.Parcelas.Count(
                        p =>
                            p.Status != ParcelaStatus.Quitado &&
                            (p.DataVencimento.AddDays(15)) >= DataAtual);
                var parcelas =
                    operacao.Parcelas.Where(
                        p => p.Status != ParcelaStatus.Quitado && (p.DataVencimento.AddDays(15)) >= DataAtual)
                        .Take(proximos == 0 ? total : proximos)
                        .ToList();
                {
                    var ini = parcelas.FirstOrDefault().NumeroParcela;
                    var fim = parcelas.LastOrDefault().NumeroParcela;
                    var boletoParcelas = _funcaoAdapter.GerarBoletoParcela(numeroContrato, ini, fim);
                    order.Add(ini, boletoParcelas);
                }
                if (order.Count > 0)
                {
                    var orderO = order.OrderBy(p => p.Key).Where(p => p.Value.Length > 0).ToList();
                    var todos = orderO.Select(p => p.Value).ToList();
                    var ret = PDF.MergePdFs(todos);
                    return ret;
                }
            }
            return null;
        }

        #endregion
    }
}