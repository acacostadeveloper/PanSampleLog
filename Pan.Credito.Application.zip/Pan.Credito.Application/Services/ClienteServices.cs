﻿using System;
using System.Collections.Generic;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Services;

namespace Pan.Credito.Application.Services
{
    public class ClienteServices : IClienteServices
    {
        private readonly ICucAdapter _cucAdapter;
        private readonly IFuncaoAdapter _funcaoAdapter;

        public ClienteServices(ICucAdapter cucAdapter, IFuncaoAdapter funcaoAdapter)
        {
            _cucAdapter = cucAdapter;
            _funcaoAdapter = funcaoAdapter;
        }

        public Cliente ObterCliente(string Documento)
        {
            var cliente = _funcaoAdapter.ObterCliente(Documento);
            if (cliente != null) return cliente;

            var clienteCUC = _cucAdapter.ObterCliente(Convert.ToInt64(Documento));
            cliente = clienteCUC;
            cliente.Contratos = new List<Contrato>();
            cliente.Contratos = ObterContratos(Convert.ToInt64(Documento));
            return cliente;
        }

        public string GravarCliente(Cliente cliente)
        {
            return _funcaoAdapter.GravarCliente(cliente);
        }

        public void Dispose()
        {
            _funcaoAdapter.Dispose();
            _cucAdapter.Dispose();
            GC.SuppressFinalize(this);
        }

        public List<Contrato> ObterContratos(long documento)
        {
            return _funcaoAdapter.ObterContratos(documento);
        }
    }
}