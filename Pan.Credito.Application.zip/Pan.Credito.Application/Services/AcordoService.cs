﻿using System;
using System.Collections.Generic;
using System.Linq;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Exceptions;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Services;

namespace Pan.Credito.Application.Services
{
    public class AcordoServices : IAcordoServices
    {
        private readonly IFuncaoAdapter _funcaoAdapter;
       

        public AcordoServices(IFuncaoAdapter funcaoAdapter)
        {
            _funcaoAdapter = funcaoAdapter;
        }

        public string CancelarAcordo(Origens origem, string acordo, string contrato)
        {
            switch (origem)
            {
                case Origens.Funcao:
                {
                    return _funcaoAdapter.CancelarAcordo(acordo, contrato);
                }
                case Origens.PanSolution:
                {
                    throw new NotImplementedException();
                }
            }

            return null;
        }

        public Acordo SimularAcordoRenegocie(AcordoRenegocie acordoRenegocie)
        {
            if (string.IsNullOrWhiteSpace(acordoRenegocie.Contrato))
                throw new BusinessRuleException(string.Format("O valor do parâmetro fornecido não é válido {0}",
                    acordoRenegocie.Contrato));
            var acordo = _funcaoAdapter.SimularAcordoRenegocie(acordoRenegocie);
            return acordo;
        }
        
        public Acordo SimularAcordoQuitar(SolicitaAcordo solicitaAcordo)
        {
            if (string.IsNullOrWhiteSpace(solicitaAcordo.Contrato))
                throw new BusinessRuleException(string.Format("O valor do parâmetro fornecido não é válido {0}",
                    solicitaAcordo.Contrato));
            var acordo = _funcaoAdapter.SimularAcordo(solicitaAcordo.Contrato, solicitaAcordo.DataPagamento,
                solicitaAcordo.DatasVencimento);
            return acordo;
        }

        public Acordo EfetuarAcordoFuncao(SolicitaAcordo solicitaAcordo)
        {
            if (string.IsNullOrWhiteSpace(solicitaAcordo.Contrato)) throw new BusinessRuleException(string.Format("O valor do parâmetro fornecido não é válido {0}",solicitaAcordo.Contrato));

            if (solicitaAcordo.DataPagamento < CrossCutting.Common.DataReferencia) throw new BusinessRuleException(string.Format("data de pagamento invalida {0}",solicitaAcordo.DataPagamento));

            var stringDataParcela = solicitaAcordo.DatasVencimento.ToArray();

            var parcelas = _funcaoAdapter.ObterParcelas(solicitaAcordo.Contrato, solicitaAcordo.DataPagamento);

            var parcelasAcordo = stringDataParcela
                .Select(data => parcelas.FirstOrDefault(p => p.DataVencimento == data))
                .Where(parcela => parcela != null).ToList();

            // CADASTRA ACORDO
            var numProposta = _funcaoAdapter.EfetuarAcordo(solicitaAcordo.Contrato, solicitaAcordo.DataPagamento,parcelasAcordo, solicitaAcordo.Desconto);
            
            // OBTEM ACORDO
            var acordo = _funcaoAdapter.ConsultarAcordo(solicitaAcordo.Contrato, numProposta, parcelas, solicitaAcordo.WithPDF);
            
            if (acordo == null) throw new BusinessRuleException(string.Format("ERRO AO EFETUAR ACORDO [ObterAcordosFuncao]  {0}", numProposta));
            
            return acordo;
        }
        
        public Acordo EfetuarAcordoRenegocie(AcordoRenegocie solicitaAcordo)
        {

            if (solicitaAcordo.DataPagamento < CrossCutting.Common.DataReferencia) throw new BusinessRuleException(string.Format("data de pagamento invalida {0}",solicitaAcordo.DataPagamento));

            var acordoTemp = _funcaoAdapter.SimularAcordoRenegocie(solicitaAcordo);

            var proposta = _funcaoAdapter.EfetuarAcordoRenegocie(solicitaAcordo.Contrato, solicitaAcordo.DataPagamento, acordoTemp.Parcelas, solicitaAcordo.CodigoProduto);
           
            var acordo = _funcaoAdapter.ConsultarAcordo(solicitaAcordo.Contrato, proposta, acordoTemp.Parcelas, solicitaAcordo.WithPDF);

            if (acordo == null) throw new BusinessRuleException(string.Format("ERRO AO EFETUAR ACORDO [ObterAcordosFuncao]  {0}", proposta));

            return acordo;
        }

        public List<Acordo> ObterAcordosFuncao(string contrato)
        {
            var acordos = _funcaoAdapter.ConsultarAcordo(contrato, true);
            return acordos.Count > 0 ? acordos : null;
        }

        public List<Acordo> ObterAcordosFuncao(string contrato, List<Parcela> parcelas)
        {
            var acordos = _funcaoAdapter.ConsultarAcordo(contrato, parcelas, true);
            return acordos.Count > 0 ? acordos : null;
        }


        public void Dispose()
        {
            _funcaoAdapter.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}