﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using ValidadorOperacao.Entity;
using Oracle.ManagedDataAccess.Client;

namespace ValidadorOperacao.Data
{
    public class dConexaoOracle : IDisposable
    {
        private readonly string strConnPan = ConfigurationManager.ConnectionStrings["CYBER"].ToString();

        public Oracle.ManagedDataAccess.Client.OracleConnection conexao { get; private set; }
        private OracleCommand oracleComm;

        public dConexaoOracle() 
        {
            AbreConexao();
        }

        /// <summary>
        /// Abre a conexão com o banco de dados
        /// </summary>
        private void AbreConexao()
        {
            try
            {
                conexao = new OracleConnection { ConnectionString = strConnPan };
                conexao.Open();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (AbrirConexao) - " + ex.Message);
            }
        }

        /// <summary>
        /// Fecha a conexao com o banco de dados
        /// </summary>
        public void FechaConexao()
        {
            if (conexao.State == ConnectionState.Open)
            {
                conexao.Close();
            }
        }

        /// <summary>
        /// Retorna um Data Reader com o resultado da pesquisa
        /// </summary>
        /// <param name="sqlComm"></param>
        /// <param name="conexao"></param>
        /// <returns></returns>
        public OracleDataReader RetornaDataReader(string comando, CommandType tipoDeComando)
        {
            try
            {
                oracleComm = new OracleCommand(comando, conexao);
                oracleComm.CommandType = tipoDeComando;
                if (oracleComm.Connection.State == ConnectionState.Open)
                {
                    return oracleComm.ExecuteReader(CommandBehavior.CloseConnection);
                }
            }
            catch (Exception ex)
            {
                FechaConexao();
                throw new Exception("Erro durante a uma consulta no Banco de Dados (RetornaDataReader) - " + ex.Message);
            }
            return null;
        }

        public void Dispose()
        {
            FechaConexao();
        }
    }
}
