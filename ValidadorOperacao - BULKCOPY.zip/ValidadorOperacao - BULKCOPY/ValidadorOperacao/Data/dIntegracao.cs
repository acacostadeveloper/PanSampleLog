﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using ValidadorOperacao.Entity;
using Oracle.ManagedDataAccess.Client;
using System.Data.OleDb;

namespace ValidadorOperacao.Data
{
    class dIntegracao
    {
        internal eMensagem ObterMensagemIntegracao(DateTime dtBase, int idSistema)
        {
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_MENSAGEM");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@DT_BASE", dtBase.Date));
            cmd.Parameters.Add(new SqlParameter("@ID_SISTEMA", idSistema));

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            dr.Read();

            eMensagem mensagem = new eMensagem();

            mensagem.IdMensagem = (dr["ID_MENSAGEM"] != DBNull.Value ? Convert.ToInt32(dr["ID_MENSAGEM"]) : 0);
            mensagem.DtBase = dtBase;

            return mensagem;
        }

        internal List<eSistema> ObterListaSistema() 
        {
            List<eSistema> lstSistema = new List<eSistema>();
            
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_SISTEMA");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            while (dr.Read()) 
            { 
                eSistema sistema = new eSistema();

                sistema.IdSistema = (dr["ID_SISTEMA"] != DBNull.Value ? Convert.ToInt32(dr["ID_SISTEMA"]) : 0);
                sistema.DsSistema = (dr["DS_SISTEMA"] != DBNull.Value ? Convert.ToString(dr["DS_SISTEMA"]) : String.Empty);
                sistema.NomeConnectionString = (dr["NM_CONNECTION_STRING"] != DBNull.Value ? Convert.ToString(dr["NM_CONNECTION_STRING"]) : String.Empty);
                sistema.TipoConnectionString = (dr["TP_CONNECTION_STRING"] != DBNull.Value ? Convert.ToString(dr["TP_CONNECTION_STRING"]) : String.Empty);
                sistema.QueryIntegracao = (dr["NM_QUERY_INTEGRACAO"] != DBNull.Value ? Convert.ToString(dr["NM_QUERY_INTEGRACAO"]) : String.Empty);

                sistema.ListaTipoInformacao = ObterTipoInformacaoSistema(sistema);

                lstSistema.Add(sistema);
            }

            return lstSistema; 
        }

        private List<eTipoInformacao> ObterTipoInformacaoSistema(eSistema sistema)
        {
            List<eTipoInformacao> lstTipoInformacao = new List<eTipoInformacao>();

            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_TIPO_INFORMACAO_SISTEMA");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@ID_SISTEMA", sistema.IdSistema));

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            while (dr.Read())
            {
                eTipoInformacao tipoInformacao = new eTipoInformacao();

                tipoInformacao.IdTipoInformacao = (dr["ID_TIPO_INFORMACAO"] != DBNull.Value ? Convert.ToInt32(dr["ID_TIPO_INFORMACAO"]) : 0);
                tipoInformacao.DescricaoTipoInformacao = (dr["DS_TIPO_INFORMACAO"] != DBNull.Value ? Convert.ToString(dr["DS_TIPO_INFORMACAO"]) : String.Empty);
                tipoInformacao.NomeTabelaIntegracao = (dr["NM_TABELA_INTEGRACAO"] != DBNull.Value ? Convert.ToString(dr["NM_TABELA_INTEGRACAO"]) : String.Empty);

                lstTipoInformacao.Add(tipoInformacao);
            }

            return lstTipoInformacao;
        }


        internal void ObterListaProcesso(eMensagem mensagem) 
        { 
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_PROCESSO");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            while (dr.Read())
            {
                eProcesso processo = new eProcesso();

                processo.IdProcesso = (dr["ID_PROCESSO"] != DBNull.Value ? Convert.ToInt32(dr["ID_PROCESSO"]) : 0);
                processo.DescricaoProcesso = (dr["DS_PROCESSO"] != DBNull.Value ? Convert.ToString(dr["DS_PROCESSO"]) : String.Empty);

                processo.ListaRegra = ObterListaRegra(processo.IdProcesso,mensagem.Sistema.IdSistema);

                mensagem.ListaProcesso.Add(processo);
            }
        }

        private List<eRegra> ObterListaRegra(int idProcesso, int idSistema) 
        {
            List<eRegra> lstRegra = new List<eRegra>();

            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_REGRA");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@ID_PROCESSO", idProcesso));
            cmd.Parameters.Add(new SqlParameter("@ID_SISTEMA", idSistema));

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            while (dr.Read())
            {
                eRegra regra = new eRegra();

                regra.IdRegra = (dr["ID_REGRA"] != DBNull.Value ? Convert.ToInt32(dr["ID_REGRA"]) : 0);
                regra.DescricaoRegra = (dr["DS_REGRA"] != DBNull.Value ? Convert.ToString(dr["DS_REGRA"]) : String.Empty);
                regra.NomeProcedure = (dr["NM_PROCEDURE"] != DBNull.Value ? Convert.ToString(dr["NM_PROCEDURE"]) : String.Empty);
                regra.IndicadorLogCritico = (dr["IC_LOG_CRITICO"] != DBNull.Value ? Convert.ToString(dr["IC_LOG_CRITICO"]) : String.Empty);
                regra.ValorCriticidade = (dr["VL_CRITICIDADE"] != DBNull.Value ? Convert.ToInt32(dr["VL_CRITICIDADE"]) : 0);
                regra.NumeroOrdem = (dr["NO_ORDEM"] != DBNull.Value ? Convert.ToInt32(dr["NO_ORDEM"]) : 0);

                lstRegra.Add(regra);
            }

            return lstRegra;         
        }

        private List<eTipoInformacao> ObterTipoInformacao(int idTipoInformacao)
        {
            List<eTipoInformacao> lstTipoInformacao = new List<eTipoInformacao>();

            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_TIPO_INFORMACAO");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            while (dr.Read())
            {
                eTipoInformacao tipoInformacao = new eTipoInformacao();

                tipoInformacao.IdTipoInformacao = idTipoInformacao;
                tipoInformacao.DescricaoTipoInformacao = (dr["DS_TIPO_INFORMACAO"] != DBNull.Value ? Convert.ToString(dr["DS_TIPO_INFORMACAO"]) : String.Empty);
                tipoInformacao.NomeTabelaIntegracao = (dr["NM_TABELA_INTEGRACAO"] != DBNull.Value ? Convert.ToString(dr["NM_TABELA_INTEGRACAO"]) : String.Empty);

                lstTipoInformacao.Add(tipoInformacao);
            }

            return lstTipoInformacao;
        }

        internal void ImportarDadosSistema(eMensagem mensagem) 
        {
            dSQLIntegracao sql = new dSQLIntegracao();

            switch(mensagem.Sistema.NomeConnectionString)
            {
                case "NPV":
                    dConexao conexao = new dConexao(eConexao.Dados.NPV);
                    SqlCommand cmd = new SqlCommand(sql.SqlIntegracao(dSQLIntegracao.enumSqlIntregracao.NPV_OPERACAO));
                    cmd.CommandType = System.Data.CommandType.Text;
                    SqlDataReader dr = conexao.RetornaDataReader(cmd);
                    
                    dConexao conexaoVO = new dConexao(eConexao.Dados.VO); 
                    conexaoVO.AbreConexao();
                    dBulkCopy copy = new dBulkCopy(conexaoVO.SqlConn);

                    foreach (eTipoInformacao tipoInformacao in mensagem.Sistema.ListaTipoInformacao)
                    {
                        this.ObterMapeamentoColunas(mensagem.Sistema, tipoInformacao, copy.bulkCopy);
                        copy.ExecuteBulkCopy(dr, tipoInformacao.NomeTabelaIntegracao);
                        this.AtualizarMensagemIntegracao(mensagem, tipoInformacao);
                    }
                    
                    break; 
                case "CYBER":
                    dConexaoOracle conexaoOracle = new dConexaoOracle();
                    OracleDataReader drOra = conexaoOracle.RetornaDataReader(sql.SqlIntegracao(dSQLIntegracao.enumSqlIntregracao.CYBER_COBRANCA), System.Data.CommandType.Text); 

                    dConexao conexaoVOcyber = new dConexao(eConexao.Dados.VO);
                    conexaoVOcyber.AbreConexao();
                    dBulkCopy copyCyber = new dBulkCopy(conexaoVOcyber.SqlConn);

                    foreach (eTipoInformacao tipoInformacao in mensagem.Sistema.ListaTipoInformacao)
                    {
                        this.ObterMapeamentoColunas(mensagem.Sistema, tipoInformacao, copyCyber.bulkCopy);
                        copyCyber.ExecuteBulkCopy(drOra, tipoInformacao.NomeTabelaIntegracao);
                        this.AtualizarMensagemIntegracao(mensagem, tipoInformacao);
                    }
                    
                    break; 
                case "SPC":
                    dConexaoExcell conexaoExcellSpc = new dConexaoExcell(eConexao.Dados.SPC);
                    OleDbCommand cmdSpc = new OleDbCommand(sql.SqlIntegracao(dSQLIntegracao.enumSqlIntregracao.SPC_NEGATIVACAO));
                    cmdSpc.CommandType = System.Data.CommandType.Text;
                    
                    OleDbDataReader drSPC = conexaoExcellSpc.RetornaDataReader(cmdSpc);

                    dConexao conexaoVOspc = new dConexao(eConexao.Dados.VO);
                    conexaoVOspc.AbreConexao();
                    dBulkCopy copySpc = new dBulkCopy(conexaoVOspc.SqlConn);

                    foreach (eTipoInformacao tipoInformacao in mensagem.Sistema.ListaTipoInformacao)
                    {
                        this.ObterMapeamentoColunas(mensagem.Sistema, tipoInformacao, copySpc.bulkCopy);
                        copySpc.ExecuteBulkCopy(drSPC, tipoInformacao.NomeTabelaIntegracao);
                        conexaoVOspc.FechaConexao();
                        this.AtualizarMensagemIntegracao(mensagem, tipoInformacao);
                    }

                    break;
                case "SERASA_PAN":
                    dConexaoExcell conexaoExcellSerasaPan = new dConexaoExcell(eConexao.Dados.SERASA_PAN);

                    OleDbCommand cmdSerasaPan = new OleDbCommand(sql.SqlIntegracao(dSQLIntegracao.enumSqlIntregracao.SERASA_PAN_NEGATIVACAO));
                    cmdSerasaPan.CommandType = System.Data.CommandType.Text;

                    OleDbDataReader drSerasaPan = conexaoExcellSerasaPan.RetornaDataReader(cmdSerasaPan);

                    dConexao conexaoVOserasaPan = new dConexao(eConexao.Dados.VO);
                    conexaoVOserasaPan.AbreConexao();
                    dBulkCopy copySerasaPan = new dBulkCopy(conexaoVOserasaPan.SqlConn);

                    foreach (eTipoInformacao tipoInformacao in mensagem.Sistema.ListaTipoInformacao)
                    {
                        this.ObterMapeamentoColunas(mensagem.Sistema, tipoInformacao, copySerasaPan.bulkCopy);
                        copySerasaPan.ExecuteBulkCopy(drSerasaPan, tipoInformacao.NomeTabelaIntegracao);
                        conexaoVOserasaPan.FechaConexao();
                        this.AtualizarMensagemIntegracao(mensagem, tipoInformacao);
                    }

                    break;
                case "SERASA_CAIXA":
                    dConexaoExcell conexaoExcellSerasaCaixa = new dConexaoExcell(eConexao.Dados.SERASA_CAIXA);

                    OleDbCommand cmdSerasaCaixa = new OleDbCommand(sql.SqlIntegracao(dSQLIntegracao.enumSqlIntregracao.SERASA_CAIXA_NEGATIVACAO));
                    cmdSerasaCaixa.CommandType = System.Data.CommandType.Text;

                    OleDbDataReader drSerasaCaixa = conexaoExcellSerasaCaixa.RetornaDataReader(cmdSerasaCaixa);

                    dConexao conexaoVOserasaCaixa = new dConexao(eConexao.Dados.VO);
                    conexaoVOserasaCaixa.AbreConexao();
                    dBulkCopy copySerasaCaixa = new dBulkCopy(conexaoVOserasaCaixa.SqlConn);

                    foreach (eTipoInformacao tipoInformacao in mensagem.Sistema.ListaTipoInformacao)
                    {
                        this.ObterMapeamentoColunas(mensagem.Sistema, tipoInformacao, copySerasaCaixa.bulkCopy);
                        copySerasaCaixa.ExecuteBulkCopy(drSerasaCaixa, tipoInformacao.NomeTabelaIntegracao);
                        conexaoVOserasaCaixa.FechaConexao();
                        this.AtualizarMensagemIntegracao(mensagem, tipoInformacao);
                    }

                    break;
            }
        }

        internal void ObterMapeamentoColunas(eSistema sistema, eTipoInformacao tipoInformacao, SqlBulkCopy bulkCopy)
        {
            bulkCopy.ColumnMappings.Clear();

            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_MAPEAMENTO_COLUNA");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@ID_SISTEMA", sistema.IdSistema));
            cmd.Parameters.Add(new SqlParameter("@ID_TIPO_INFORMACAO", tipoInformacao.IdTipoInformacao));

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            while (dr.Read())
            {
                SqlBulkCopyColumnMapping mapID =
                    new SqlBulkCopyColumnMapping(dr["NM_COLUNA_ORIGEM"].ToString(), dr["NM_COLUNA_DESTINO"].ToString());
                
                bulkCopy.ColumnMappings.Add(mapID);
            }
        }

        internal void AtualizarMensagemIntegracao(eMensagem mensagem, eTipoInformacao tipoInformacao) 
        {
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INT_GRAVA_MENSAGEM");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@ID_MENSAGEM", mensagem.IdMensagem));
            cmd.Parameters.Add(new SqlParameter("@ID_TIPO_INFORMACAO", tipoInformacao.IdTipoInformacao));

            conexao.ExecuteNonQuery(cmd);        
        }

        internal void ExecutarRegra(eMensagem mensagem, eRegra regra) 
        {
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand(regra.NomeProcedure);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@ID_MENSAGEM", mensagem.IdMensagem));
            cmd.Parameters.Add(new SqlParameter("@ID_REGRA", regra.IdRegra));

            conexao.ExecuteNonQuery(cmd);                
        }
    }
}
