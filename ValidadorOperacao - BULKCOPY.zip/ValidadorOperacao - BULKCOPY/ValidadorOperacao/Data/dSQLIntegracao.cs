﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorOperacao.Data
{
    class dSQLIntegracao
    {
        internal enum enumSqlIntregracao
        {
            NPV_OPERACAO = 1,
            CYBER_COBRANCA = 2,
            SPC_NEGATIVACAO = 3,
            SERASA_PAN_NEGATIVACAO = 4,
            SERASA_CAIXA_NEGATIVACAO = 5
        }

        private enumSqlIntregracao sqlIntegracao = new enumSqlIntregracao();

        internal string SqlIntegracao(enumSqlIntregracao pSQL)
        {
            string retorno = "";

            switch (pSQL)
            {
                case enumSqlIntregracao.NPV_OPERACAO:
                    retorno = NPV_OPERACAO; 
                    break; 
                case enumSqlIntregracao.CYBER_COBRANCA:
                    retorno = CYBER_COBRANCA;
                    break;
                case enumSqlIntregracao.SPC_NEGATIVACAO:
                    retorno = SPC_NEGATIVACAO;
                    break;
                case enumSqlIntregracao.SERASA_PAN_NEGATIVACAO:
                    retorno = SERASA_PAN_NEGATIVACAO;
                    break;
                case enumSqlIntregracao.SERASA_CAIXA_NEGATIVACAO:
                    retorno = SERASA_CAIXA_NEGATIVACAO;
                    break;
            }

            return retorno; 
        }

        internal const string NPV_OPERACAO = "  SELECT " + 
                                                "OPNROPER AS CONTRATO, " + 
                                                "OPDTLIQ AS DT_LIQ_CNTR, " + 
                                                "OPQTDDPARC AS PLANO, " + 
                                                "ISNULL(OPPARCLIQ,0) AS PARC_LIQUIDADAS, " + 
                                                "MAX(PP.PADTVCTO) AS ULTIMO_VECTO_PAGO, " +
                                                "MAX(PP.PADTLIQ) AS DT_LIQUIDACAO_ULTIMO_VECTO_PAGO, " + 
                                                "MIN(PA.PANRPARC) AS NR_PARCELA_ABERTA, " + 
                                                "MIN(PA.PADTVCTO) AS PROX_VECTO, " +
                                                "DATEDIFF(DD,MIN(PA.PADTVCTO),GETDATE()) AS DIAS_ATRASO, " + 
                                                "(SELECT CONVERT(VARCHAR,MAX(BCDTDESB),103) FROM GAPANVEIC..EBLOQ Q (NOLOCK) WHERE BCDTDESB > GETDATE() AND BCTPBLOQ IN ('NP','NR','TD') AND BCNROPER = OPNROPER) AS DT_INIBICAO, " +
                                                "CCCODBCO AS COD_CESSIONARIO " + 
                                                "FROM " + 
                                                "CDCPANVEIC..COPER (NOLOCK) " + 
                                                "LEFT JOIN CDCPANVEIC..CPARC PP (NOLOCK) ON PP.PANROPER = OPNROPER AND PP.PADTMOV IS NOT NULL " + 
                                                "INNER JOIN CDCPANVEIC..CPARC PA (NOLOCK) ON PA.PANROPER = OPNROPER AND PA.PADTMOV IS NULL " + 
                                                "LEFT JOIN CDCPANVEIC..CPCES (NOLOCK) ON PCNROPER = PA.PANROPER AND PCNRPARC = PA.PANRPARC " + 
                                                "LEFT JOIN CDCPANVEIC..CCCRE (NOLOCK) ON CCNRCESS = PCNRCESS " + 
                                                "LEFT JOIN CDCPANVEIC..CCLIE E (NOLOCK) ON E.CLCODCLI = OPCODAV1 " + 
                                                "LEFT JOIN CDCPANVEIC..CCLIE F (NOLOCK) ON F.CLCODCLI = OPCODAV2 " + 
                                                "WHERE " + 
                                                "OPNROPER NOT LIKE  '%////////%' AND PA.PANRPARC = (SELECT MIN(W.PANRPARC) FROM CDCPANVEIC..CPARC W WHERE W.PANROPER = PA.PANROPER AND W.PADTMOV IS NULL) " +
                                                "GROUP BY " + 
                                                "OPNROPER, OPDTLIQ, OPQTDDPARC, OPPARCLIQ, CCCODBCO " + 
                                                "UNION " + 
                                                "SELECT " + 
                                                "OPNROPER AS CONTRATO, " + 
                                                "OPDTLIQ AS DT_LIQ_CNTR, " + 
                                                "OPQTDDPARC AS PLANO, " + 
                                                "OPPARCLIQ AS PARC_LIQUIDADAS, " + 
                                                "NULL AS ULTIMO_VECTO_PAGO, " + 
                                                "NULL AS DT_LIQUIDACAO_ULTIMO_VECTO_PAGO, " + 
                                                "NULL AS NR_PARCELA_ABERTA, " + 
                                                "NULL AS PROX_VECTO, " + 
                                                "NULL AS DIAS_ATRASO, " + 
                                                "NULL AS DT_INIBICAO, " + 
                                                "NULL AS COD_CESSIONARIO " + 
                                                "FROM " + 
                                                "CDCPANVEIC..COPER   (NOLOCK) " + 
                                                "WHERE " + 
                                                "OPDTLIQ IS NOT NULL " +
                                                "GROUP BY " +
                                                "OPNROPER, OPDTLIQ, OPQTDDPARC, OPPARCLIQ, OPVLRPARC";

        internal const string CYBER_COBRANCA =  "SELECT * FROM ( " +
                                                " SELECT " +
                                                "    D.DMACCT CD_CONTRATO, " +
                                                "    DECODE(D.DMSTATUS, NULL, 'ATIVO', 'INATIVO') CD_STATUS, " +
                                                "    (SELECT COUNT(1) FROM RCVRY.TB_PARCELA WHERE CONTRATO = U1ACCT) QT_PARCELAS_PLANO, " +
                                                "    (SELECT COUNT(1) FROM RCVRY.TB_PARCELA WHERE CONTRATO = U1ACCT AND STATUS <> 'A') QT_PARCELAS_LIQUIDADAS, " +
                                                "    (SELECT MAX(DTVENC) FROM RCVRY.TB_PARCELA WHERE CONTRATO = U1ACCT AND STATUS <> 'A') DT_ULTIMO_VENCIMENTO_PAGO, " +
                                                "    (SELECT MIN(NUMPARCEL) FROM RCVRY.TB_PARCELA WHERE CONTRATO = U1ACCT AND STATUS = 'A') NR_PRIMEIRA_PARCELA_ABERTA, " +
                                                "    D.DMDLQDT DT_PROXIMO_VENCIMENTO_CONTRATO, " +
                                                "    (SELECT MIN(DTVENC) FROM RCVRY.TB_PARCELA WHERE CONTRATO = U1ACCT AND STATUS = 'A') DT_PROXIMO_VENCIMENTO_PARCELA, " +
                                                "    D.DMDAYS QT_DIAS_ATRASO, " +
                                                "    U.U1FLANEG IC_INIBICAO, " +
                                                "    U.U1DTNEGFIM DT_FIM_INIBICAO, " +
                                                "    U.U1CDCESS CD_CESSIONARIO, " +
                                                "    NVL(U.U1FLACNEGSPC,0) IC_NEGATIVACAO_SPC, " +
                                                "    U.U1CDCREDSCP CD_CREDENCIAL_SPC, " +
                                                "    U.U1CREDENVSCP CD_CREDENCIAL_ENVIO_SPC, " +
                                                "    U.U1DTACNEGSPC DT_NEGATIVACAO_SPC, " +
                                                "    NVL(U.U1FLACNEGSER,0) IC_NEGATIVACAO_SERASA, " +
                                                "    U.U1CDCREDSER CD_CREDENCIAL_SERASA, " +
                                                "    U.U1CREDENVSER CD_CREDENCIAL_ENVIO_SERASA, " +
                                                "    U.U1DTACNEGSER DT_NEGATIVACAO_SERASA, " +
                                                "    NVL(U.U1FLACNEGCYB,0) IC_NEGATIVACAO_CYBER, " +
                                                "    U.U1DTACNEGCYB DT_NEGATIVACAO_CYBER, " +
                                                "    NVL(U.U1FLATISEMAC,0) IC_STATUS_ACAO " +
                                                " FROM " +
                                                "    RCVRY.DELQMST D, " +
                                                "    RCVRY.UDA1 U " +
                                                " WHERE " +
                                                "    DMACCT  = U1ACCT " +
                                                " AND DMACCTG = U1ACCTG " +
                                                " AND U1FLGLEGADO = 'F' " +
                                                " ) A " ;

        internal const string SPC_NEGATIVACAO = "SELECT Trim(Bureau) as Bureau,Trim(Contrato) as Contrato,Trim(CPF) as CPF,Trim(Empresa) as Empresa,CDate(Mid(Inclusao,5,4) + '-' + Mid(Inclusao,3,2) + '-' + Mid(Inclusao,1,2)) as Inclusao,Trim(Legado) as Legado FROM [EXTRACAO$]";

        internal const string SERASA_PAN_NEGATIVACAO = "SELECT Trim(Bureau) as Bureau,Trim(Contrato) as Contrato,Trim(CPF) as CPF,Trim(Empresa) as Empresa,CDate(Mid(Inclusao,1,4) + '-' + Mid(Inclusao,5,2) + '-' + Mid(Inclusao,7,2)) as Inclusao,Trim(Legado) as Legado FROM [EXTRACAO$]";

        internal const string SERASA_CAIXA_NEGATIVACAO = "SELECT Trim(Bureau) as Bureau,Trim(Contrato) as Contrato,Trim(CPF) as CPF,Trim(Empresa) as Empresa,CDate(Mid(Inclusao,1,4) + '-' + Mid(Inclusao,5,2) + '-' + Mid(Inclusao,7,2)) as Inclusao,Trim(Legado) as Legado FROM [EXTRACAO$]";

    }
}
