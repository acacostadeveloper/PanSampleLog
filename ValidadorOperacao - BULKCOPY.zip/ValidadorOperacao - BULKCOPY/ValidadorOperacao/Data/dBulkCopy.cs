﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Oracle.ManagedDataAccess.Client;
using System.Data.OleDb;

namespace ValidadorOperacao.Data
{
    class dBulkCopy
    {
        internal SqlBulkCopy bulkCopy;

        public dBulkCopy(SqlConnection connectionDestino) 
        {
            bulkCopy = new SqlBulkCopy(connectionDestino);
            bulkCopy.BulkCopyTimeout = Int32.MaxValue;
        }

        public void ExecuteBulkCopy(SqlDataReader dataReaderOrigem, string tabelaDestino)
        {
            bulkCopy.DestinationTableName = tabelaDestino;

            try
            {
                bulkCopy.WriteToServer(dataReaderOrigem);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de bulk insert (ExecuteBulkCopy) - " + ex.Message);
            }
        }
        public void ExecuteBulkCopy(OracleDataReader dataReaderOrigem, string tabelaDestino)
        {
            bulkCopy.DestinationTableName = tabelaDestino;

            try
            {
                bulkCopy.WriteToServer(dataReaderOrigem);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de bulk insert (ExecuteBulkCopy) - " + ex.Message);
            }
        }

        public void ExecuteBulkCopy(OleDbDataReader dataReaderOrigem, string tabelaDestino)
        {
            bulkCopy.DestinationTableName = tabelaDestino;

            try
            {
                bulkCopy.WriteToServer(dataReaderOrigem);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de bulk insert (ExecuteBulkCopy) - " + ex.Message);
            }
        }

    }
}
