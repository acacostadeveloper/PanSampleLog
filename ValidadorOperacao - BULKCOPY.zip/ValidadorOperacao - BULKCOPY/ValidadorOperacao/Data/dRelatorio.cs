﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using ValidadorOperacao.Entity;
using System.IO;
using System.Configuration; 

namespace ValidadorOperacao.Data
{
    class dRelatorio
    {

        internal void ObterRelatorioSintetico(DateTime dataBase, DataGridView gridRelatorio)
        {
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_LOG_SINTETICO");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@DT_BASE", dataBase.Date));

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            int nColunas = dr.FieldCount;
            for (int i = 0; i < nColunas; i++)
            {
                gridRelatorio.Columns.Add(dr.GetName(i).ToString(), dr.GetName(i).ToString());
            }

            //define um array de strings com nCOlunas
            string[] linhaDados = new string[nColunas];
            //percorre o DataRead
            while (dr.Read())
            {
                //percorre cada uma das colunas
                for (int a = 0; a < nColunas; a++)
                {
                    //verifica o tipo de dados da coluna
                    if (dr.GetFieldType(a).ToString() == "System.Int32")
                    {
                        linhaDados[a] = dr.GetInt32(a).ToString();
                    }
                    if (dr.GetFieldType(a).ToString() == "System.String")
                    {
                        linhaDados[a] = dr.GetString(a).ToString();
                    }
                    if (dr.GetFieldType(a).ToString() == "System.DateTime")
                    {
                        linhaDados[a] = dr.GetDateTime(a).ToString();
                    }
                }
                //atribui a linha ao datagridview
                gridRelatorio.Rows.Add(linhaDados);
            }
        }

        internal void ObterRelatorioAnalitico(DateTime dataBase) 
        {
            dConexao conexao = new dConexao(eConexao.Dados.VO);
            SqlCommand cmd = new SqlCommand("SP_INFRA_OBTEM_LOG_ANALITICO");
            cmd.CommandType = System.Data.CommandType.StoredProcedure;

            cmd.Parameters.Add(new SqlParameter("@DT_BASE", dataBase.Date));

            SqlDataReader dr = conexao.RetornaDataReader(cmd);

            string myfilePath = ConfigurationManager.AppSettings["PATH_RELATORIO"].ToString();

            StringBuilder sb = new StringBuilder();
            StreamWriter sw = new StreamWriter(myfilePath + "relatorio_analitico_"+ dataBase.Date.ToShortDateString().Replace("/","") + ".csv");
            
            for (int i = 0; i < dr.FieldCount; i++)
            {
                string value = dr.GetName(i).ToString();

                sb.Append(value.Replace(Environment.NewLine, " ") + ";");
            }
            sb.Length--; 
            sb.AppendLine();

            sw.Write(sb.ToString());
            sb.Clear();
            
            while (dr.Read())
            {

                for (int i = 0; i < dr.FieldCount; i++)
                {
                    string value = dr[i].ToString();
                    if (value.Contains(","))
                        value = "\"" + value + "\"";

                    sb.Append(value.Replace(Environment.NewLine, " ") + ";");
                }
                sb.Length--; 
                sb.AppendLine();

                sw.Write(sb.ToString());
                sb.Clear();
            }
            
            sw.Close();
        }
    }
}
