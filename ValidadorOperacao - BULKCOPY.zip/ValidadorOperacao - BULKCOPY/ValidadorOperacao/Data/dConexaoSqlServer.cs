﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using ValidadorOperacao.Entity;

namespace ValidadorOperacao.Data
{
    public class dConexao : IDisposable
    {

        private string _strConexao = "";
        internal SqlConnection SqlConn { get; set; }

        public dConexao(eConexao.Dados banco) { 
            
            switch (banco){
                case eConexao.Dados.VO:
                    _strConexao = ConfigurationManager.ConnectionStrings["VO"].ToString();
                    break;
                case eConexao.Dados.NPV:
                    _strConexao = ConfigurationManager.ConnectionStrings["NPV"].ToString();
                    break;
                default:
                    _strConexao = ConfigurationManager.ConnectionStrings["VO"].ToString();
                    break;
            }
        }


        /// <summary>
        /// Abre a conexão com o banco de dados
        /// </summary>
        internal void AbreConexao()
        {
            try
            {
                SqlConn = new SqlConnection { ConnectionString = _strConexao };
                SqlConn.Open();
            }
            catch (Exception ex)
            {
                
            }
        }

        /// <summary>
        /// Fecha a conexao com o banco de dados
        /// </summary>
        public void FechaConexao()
        {
            if (SqlConn.State == ConnectionState.Open)
            {
                SqlConn.Close();
            }
        }

        /// <summary>
        /// Retorna um Data Reader com o resultado da pesquisa
        /// </summary>
        /// <param name="sqlComm"></param>
        /// <param name="conexao"></param>
        /// <returns></returns>
        public SqlDataReader RetornaDataReader(SqlCommand sqlComm)
        {
            try
            {
                AbreConexao();
                sqlComm.Connection = SqlConn;
                sqlComm.CommandTimeout = Int32.MaxValue;
                return sqlComm.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (AbrirConexao) - " + ex.Message);
            }
        }

        /// <summary>
        /// Retorna um Data Set com o resultado da pesquisa
        /// </summary>
        /// <param name="sqlComm"></param>
        /// <returns></returns>
        public DataSet RetornaDataSet(SqlCommand sqlComm)
        {
            try
            {
                var sqlDap = new SqlDataAdapter();
                var sqlDts = new DataSet();
                AbreConexao();
                sqlComm.CommandTimeout = 120;
                sqlComm.Connection = SqlConn;
                sqlDap.SelectCommand = sqlComm;
                sqlDap.Fill(sqlDts);
                return sqlDts;
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (AbrirConexao) - " + ex.Message);
            }
        }

        /// <summary>
        /// Executa um comando sql
        /// </summary>
        /// <param name="sqlComm"></param>
        /// <returns></returns>
        public bool ExecuteNonQuery(SqlCommand sqlComm)
        {
            try
            {
                AbreConexao();
                sqlComm.Connection = SqlConn;
                sqlComm.CommandTimeout = Int32.MaxValue;
                var iRet = sqlComm.ExecuteNonQuery();
                return !iRet.Equals(0);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (AbrirConexao) - " + ex.Message);
            }
        }

        public int ExecuteScalar(SqlCommand sqlComm)
        {
            try
            {
                AbreConexao();
                sqlComm.Connection = SqlConn;
                sqlComm.CommandTimeout = 120;
                var iRet = sqlComm.ExecuteScalar();
                return Convert.ToInt32(iRet);
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (AbrirConexao) - " + ex.Message);
            }
        }

        public void Dispose()
        {
            FechaConexao();
        }
    }
}