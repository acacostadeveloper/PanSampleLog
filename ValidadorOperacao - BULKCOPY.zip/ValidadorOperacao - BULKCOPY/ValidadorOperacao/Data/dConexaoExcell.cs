﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Configuration;
using System.Data;
using ValidadorOperacao.Entity;

namespace ValidadorOperacao.Data
{
    class dConexaoExcell
    {
        OleDbConnection excelConnection = new OleDbConnection();
        private string _strConexao = "";

        public dConexaoExcell(eConexao.Dados banco)
        {
            switch (banco)
            {
                case eConexao.Dados.SPC:
                    _strConexao = ConfigurationManager.ConnectionStrings["SPC"].ToString();
                    break;
                case eConexao.Dados.SERASA_PAN:
                    _strConexao = ConfigurationManager.ConnectionStrings["SERASA_PAN"].ToString();
                    break;
                case eConexao.Dados.SERASA_CAIXA:
                    _strConexao = ConfigurationManager.ConnectionStrings["SERASA_CAIXA"].ToString();
                    break;
            }        
        }

        internal void AbreConexao()
        {
            try
            {
                excelConnection.ConnectionString = _strConexao;
                excelConnection.Open();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (AbrirConexao) - " + ex.Message);
            }
        }

        public OleDbDataReader RetornaDataReader(OleDbCommand sqlComm)
        {
            try
            {
                AbreConexao();
                sqlComm.Connection = excelConnection;
                sqlComm.CommandTimeout = Int32.MaxValue;
                return sqlComm.ExecuteReader();
            }
            catch (Exception ex)
            {
                throw new Exception("Erro durante a tentativa de conexão com o Banco de Dados (RetornaDataReader) - " + ex.Message);
            }
        }

        public void FechaConexao()
        {
            if (excelConnection.State == ConnectionState.Open)
            {
                excelConnection.Close();
            }
        }

    }
}
