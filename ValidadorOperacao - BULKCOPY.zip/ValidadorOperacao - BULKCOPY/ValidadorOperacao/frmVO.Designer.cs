﻿namespace ValidadorOperacao
{
    partial class frmVO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdIntegra = new System.Windows.Forms.Button();
            this.grdRelatorio = new System.Windows.Forms.DataGridView();
            this.cmdRelatorio = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dpDataBase = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.cmdValidar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdRelatorio)).BeginInit();
            this.SuspendLayout();
            // 
            // cmdIntegra
            // 
            this.cmdIntegra.Location = new System.Drawing.Point(352, 12);
            this.cmdIntegra.Name = "cmdIntegra";
            this.cmdIntegra.Size = new System.Drawing.Size(127, 31);
            this.cmdIntegra.TabIndex = 0;
            this.cmdIntegra.Text = "Integrar";
            this.cmdIntegra.UseVisualStyleBackColor = true;
            this.cmdIntegra.Click += new System.EventHandler(this.cmdIntegra_Click);
            // 
            // grdRelatorio
            // 
            this.grdRelatorio.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdRelatorio.Location = new System.Drawing.Point(22, 64);
            this.grdRelatorio.Name = "grdRelatorio";
            this.grdRelatorio.Size = new System.Drawing.Size(735, 356);
            this.grdRelatorio.TabIndex = 1;
            // 
            // cmdRelatorio
            // 
            this.cmdRelatorio.Location = new System.Drawing.Point(624, 12);
            this.cmdRelatorio.Name = "cmdRelatorio";
            this.cmdRelatorio.Size = new System.Drawing.Size(133, 31);
            this.cmdRelatorio.TabIndex = 2;
            this.cmdRelatorio.Text = "Relatório";
            this.cmdRelatorio.UseVisualStyleBackColor = true;
            this.cmdRelatorio.Click += new System.EventHandler(this.cmdRelatorio_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Data Base";
            // 
            // dpDataBase
            // 
            this.dpDataBase.Location = new System.Drawing.Point(89, 18);
            this.dpDataBase.Name = "dpDataBase";
            this.dpDataBase.Size = new System.Drawing.Size(235, 20);
            this.dpDataBase.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(26, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Relatório de execução: ";
            // 
            // cmdValidar
            // 
            this.cmdValidar.Location = new System.Drawing.Point(485, 12);
            this.cmdValidar.Name = "cmdValidar";
            this.cmdValidar.Size = new System.Drawing.Size(133, 31);
            this.cmdValidar.TabIndex = 9;
            this.cmdValidar.Text = "Validar";
            this.cmdValidar.UseVisualStyleBackColor = true;
            this.cmdValidar.Click += new System.EventHandler(this.cmdValidar_Click);
            // 
            // frmVO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 439);
            this.Controls.Add(this.cmdValidar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dpDataBase);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdRelatorio);
            this.Controls.Add(this.grdRelatorio);
            this.Controls.Add(this.cmdIntegra);
            this.Name = "frmVO";
            this.Text = "Validador de Operações";
            ((System.ComponentModel.ISupportInitialize)(this.grdRelatorio)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button cmdIntegra;
        private System.Windows.Forms.DataGridView grdRelatorio;
        private System.Windows.Forms.Button cmdRelatorio;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dpDataBase;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button cmdValidar;
    }
}

