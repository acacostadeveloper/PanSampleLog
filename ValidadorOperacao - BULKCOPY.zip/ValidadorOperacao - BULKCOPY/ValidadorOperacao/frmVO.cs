﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ValidadorOperacao.Entity;
using ValidadorOperacao.Business;

namespace ValidadorOperacao
{
    public partial class frmVO : Form
    {
        public frmVO()
        {
            InitializeComponent();
        }

        private void cmdValidar_Click(object sender, EventArgs e)
        {
            grdRelatorio.Rows.Clear();
            grdRelatorio.Columns.Clear();
            
            bIntegracao integracao = new bIntegracao();
            List<eMensagem> lstMensagem = integracao.ObterListaMensagem(dpDataBase.Value);

            foreach (eMensagem oMensagem in lstMensagem)
            {
                integracao.ObterListaProcesso(oMensagem);
            }

            integracao.ExecutarFilaProcesso(lstMensagem);

            bRelatorio relatorio = new bRelatorio();

            // Relatório sintético em tela
            relatorio.ObterRelatorioSintetico(dpDataBase.Value, grdRelatorio);
        }

        private void cmdIntegra_Click(object sender, EventArgs e)
        {
            bIntegracao integracao = new bIntegracao();
            List<eMensagem> lstMensagem = integracao.ObterListaMensagem(dpDataBase.Value);

            integracao.ExecutaIntegracao(lstMensagem);
        }

        private void cmdRelatorio_Click(object sender, EventArgs e)
        {
            bRelatorio relatorio = new bRelatorio();

            grdRelatorio.Rows.Clear();
            grdRelatorio.Columns.Clear();

            // Relatório sintético em tela
            relatorio.ObterRelatorioSintetico(dpDataBase.Value, grdRelatorio);

            // Relatório analítico em excell
            relatorio.ObterDadosRelatorio(dpDataBase.Value);
        }
    }
}
