﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ValidadorOperacao.Data; 

namespace ValidadorOperacao.Business
{
    class bRelatorio
    {
        internal void ObterDadosRelatorio(DateTime dataBase) 
        {
            dRelatorio relatorio = new dRelatorio();

            relatorio.ObterRelatorioAnalitico(dataBase);
        }

        internal void ObterRelatorioSintetico(DateTime dataBase, DataGridView grdRel)
        {
            dRelatorio relatorio = new dRelatorio();

            relatorio.ObterRelatorioSintetico(dataBase, grdRel);
        }

    }
}
