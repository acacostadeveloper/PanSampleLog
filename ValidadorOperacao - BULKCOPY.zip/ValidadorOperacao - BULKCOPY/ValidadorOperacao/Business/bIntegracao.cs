﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using ValidadorOperacao.Entity;
using ValidadorOperacao.Data;

namespace ValidadorOperacao.Business
{

    class bIntegracao
    {
        internal List<eMensagem> ObterListaMensagem(DateTime dtBase) 
        {
            dIntegracao integracao = new dIntegracao();
            List<eMensagem> lstMensagem = new List<eMensagem>();
            List<eSistema> lstistema = integracao.ObterListaSistema();

            foreach(eSistema sistema in lstistema)
            {
                eMensagem mensagem = integracao.ObterMensagemIntegracao(dtBase,sistema.IdSistema);
                mensagem.Sistema = sistema; 

                lstMensagem.Add(mensagem);
            }

            return lstMensagem;
        }

        internal void ObterListaProcesso(eMensagem mensagem)
        {
            dIntegracao integracao = new dIntegracao();
            integracao.ObterListaProcesso(mensagem);
        }

        internal void ExecutaIntegracao(List<eMensagem> listaMensagem)
        {
            dIntegracao integracao = new dIntegracao();

            foreach(eMensagem msg in listaMensagem)
            {
                integracao.ImportarDadosSistema(msg);
            }
        }

        internal void ExecutarFilaProcesso(List<eMensagem> lstMensagem)
        {
            dIntegracao integracao = new dIntegracao();

            // integrador
            foreach (eMensagem msg in lstMensagem) 
            {
                foreach (eProcesso pro in msg.ListaProcesso.Where(s => s.DescricaoProcesso == "INTEGRACAO")) 
                {
                    foreach (eRegra reg in pro.ListaRegra) 
                    {
                        integracao.ExecutarRegra(msg, reg);
                    }
                }
            }

            foreach (eMensagem msg in lstMensagem)
            {
                foreach (eProcesso pro in msg.ListaProcesso.Where(s => s.DescricaoProcesso == "PRE-VALIDACAO"))
                {
                    foreach (eRegra reg in pro.ListaRegra)
                    {
                        integracao.ExecutarRegra(msg, reg);
                    }
                }
            }

            foreach (eMensagem msg in lstMensagem)
            {
                foreach (eProcesso pro in msg.ListaProcesso.Where(s => s.DescricaoProcesso == "VALIDACAO"))
                {
                    foreach (eRegra reg in pro.ListaRegra)
                    {
                        integracao.ExecutarRegra(msg, reg);
                    }
                }
            }
        }
    }
}
