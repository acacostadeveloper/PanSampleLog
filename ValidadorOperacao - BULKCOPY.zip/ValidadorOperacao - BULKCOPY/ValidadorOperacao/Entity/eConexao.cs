﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ValidadorOperacao.Entity
{
    public class eConexao
    {
        public enum Dados
        {
            VO,
            NPV,
            SPC,
            SERASA_PAN,
            SERASA_CAIXA 
        }
    }
}