﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorOperacao.Entity
{
    class eRegra
    {
        private int idRegra;

        public int IdRegra
        {
            get { return idRegra; }
            set { idRegra = value; }
        }
        private string descricaoRegra;

        public string DescricaoRegra
        {
            get { return descricaoRegra; }
            set { descricaoRegra = value; }
        }
        private string nomeProcedure;

        public string NomeProcedure
        {
            get { return nomeProcedure; }
            set { nomeProcedure = value; }
        }
        private eTipoInformacao tipoInformacao;

        internal eTipoInformacao TipoInformacao
        {
            get { return tipoInformacao; }
            set { tipoInformacao = value; }
        }
        private string indicadorLogCritico;

        public string IndicadorLogCritico
        {
            get { return indicadorLogCritico; }
            set { indicadorLogCritico = value; }
        }
        private int valorCriticidade;

        public int ValorCriticidade
        {
            get { return valorCriticidade; }
            set { valorCriticidade = value; }
        }
        private int numeroOrdem;

        public int NumeroOrdem
        {
            get { return numeroOrdem; }
            set { numeroOrdem = value; }
        } 
        
    }
}
