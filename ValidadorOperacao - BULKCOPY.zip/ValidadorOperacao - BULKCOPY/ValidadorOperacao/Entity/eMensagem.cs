﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorOperacao.Entity
{
    class eMensagem
    {
        private int idMensagem;

        public int IdMensagem
        {
            get { return idMensagem; }
            set { idMensagem = value; }
        }

        private DateTime dtBase;

        public DateTime DtBase
        {
            get { return dtBase; }
            set { dtBase = value; }
        }

        private eSistema sistema;

        internal eSistema Sistema
        {
            get { return sistema; }
            set { sistema = value; }
        }

        private List<eProcesso> listaProcesso = new List<eProcesso>();

        internal List<eProcesso> ListaProcesso
        {
            get { return listaProcesso; }
            set { listaProcesso = value; }
        }
    }
}
