﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorOperacao.Entity
{
    class eProcesso
    {
        private int idProcesso;

        public int IdProcesso
        {
            get { return idProcesso; }
            set { idProcesso = value; }
        }
        
        private string descricaoProcesso;

        public string DescricaoProcesso
        {
            get { return descricaoProcesso; }
            set { descricaoProcesso = value; }
        }
        
        private List<eRegra> listaRegra;

        internal List<eRegra> ListaRegra
        {
            get { return listaRegra; }
            set { listaRegra = value; }
        } 

    }
}
