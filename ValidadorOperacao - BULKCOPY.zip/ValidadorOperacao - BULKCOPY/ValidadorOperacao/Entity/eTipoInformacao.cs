﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorOperacao.Entity
{
    class eTipoInformacao
    {
        private int idTipoInformacao;

        public int IdTipoInformacao
        {
            get { return idTipoInformacao; }
            set { idTipoInformacao = value; }
        }
        private string descricaoTipoInformacao;

        public string DescricaoTipoInformacao
        {
            get { return descricaoTipoInformacao; }
            set { descricaoTipoInformacao = value; }
        }

        private string nomeTabelaIntegracao;

        public string NomeTabelaIntegracao
        {
            get { return nomeTabelaIntegracao; }
            set { nomeTabelaIntegracao = value; }
        }

    }
}
