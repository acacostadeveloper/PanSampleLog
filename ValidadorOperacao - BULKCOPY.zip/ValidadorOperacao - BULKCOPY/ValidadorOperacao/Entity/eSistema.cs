﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidadorOperacao.Entity
{
    class eSistema
    {
        private int idSistema;

        public int IdSistema
        {
            get { return idSistema; }
            set { idSistema = value; }
        }

        private string dsSistema;

        public string DsSistema
        {
            get { return dsSistema; }
            set { dsSistema = value; }
        }

        private string nomeConnectionString;

        public string NomeConnectionString
        {
            get { return nomeConnectionString; }
            set { nomeConnectionString = value; }
        }
        private string tipoConnectionString;

        public string TipoConnectionString
        {
            get { return tipoConnectionString; }
            set { tipoConnectionString = value; }
        }
        private string queryIntegracao;

        public string QueryIntegracao
        {
            get { return queryIntegracao; }
            set { queryIntegracao = value; }
        }

        private List<eTipoInformacao> listaTipoInformacao = new List<eTipoInformacao>();

        internal List<eTipoInformacao> ListaTipoInformacao
        {
            get { return listaTipoInformacao; }
            set { listaTipoInformacao = value; }
        }

    }
}
