import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { ModalDialogService, SimpleModalComponent } from 'ngx-modal-dialog';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { HttpErrorResponse } from '@angular/common/http';
import { PagamentosARealizar } from '../../models/AprovarReembolso/pagamentosARealizar.model';
import { HistoricoPagamentosAprovar } from '../../models/AprovarReembolso/historicoPagamentosAprovar.model';
import { AprovarPagamentos } from '../../models/AprovarReembolso/aprovarPagamentos.model';
import { PopUpModal } from '../../Helpers/popUpModal';

@Component({
  selector: 'pan-aprovar-reembolso',
  templateUrl: './aprovar-reembolso.component.html',
  styleUrls: ['./aprovar-reembolso.component.css']
})
export class AprovarReembolsoComponent implements OnInit {
  public reembolsos: PagamentosARealizar[] = [];
  reembolso = new PagamentosARealizar();
  historico = new HistoricoPagamentosAprovar();
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);
  qtdeEstonar: number;
  valorTotalEstornar: number;
  valorTotalMedio: number;
  valorMaior: number;


  //Filtros:
  filterDtInicial: IMyDateModel;
  filterDtFinal: IMyDateModel;

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };

  constructor(
    private reembolsoService: ReembolsoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef) {

  }

  ngOnInit() {
    this.qtdeEstonar = this.reembolsos.map(reembolsos => reembolsos.selecionado).length;
  }

  atualizarInformacoes() {

    this.valorTotalEstornar = 0;
    this.valorMaior = 0;
    this.valorTotalMedio = 0;

    this.qtdeEstonar = this.reembolsos.map(reembolsos => reembolsos.selecionado).filter(x => x == true).length;

    var valoresTotais = this.reembolsos.map(function (item) {
      return { valor: item.valor, selecionado: item.selecionado };
    });

    valoresTotais.forEach(element => {
      if (element.selecionado == true) {
        if (element.valor > this.valorMaior) {
          this.valorMaior = element.valor
        }
        this.valorTotalEstornar = this.valorTotalEstornar + element.valor;
      }
    });

    this.valorTotalMedio = this.valorTotalEstornar / this.qtdeEstonar;
    //this.valorMaior = Math.max.apply(null, valoresTotais.map(x => x.valor));
  }

  limparFiltros() {
    this.filterDtInicial = null;
    this.filterDtFinal = null;
  }

  validarCampos() {
    let mensagemRetorno: string = "";

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      mensagemRetorno = mensagemRetorno + "- Informe as datas para consulta.<br>";
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>";
      }
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }

  carregarPagamentosARealizar() {
    let dtInicial: string;
    let dtFinal: string;

    if (this.validarCampos()) {
      this
        .reembolsoService
        .obterPagamentosARealizar(
          FuncoesApoio.formatarDataInicial(this.filterDtInicial),
          FuncoesApoio.formatarDataFinal(this.filterDtFinal)
        )
        .subscribe(
          (data: AprovarPagamentos) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data;
              if (retorno.status == 502) {
                this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro");
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText);
              }

            }
            else {
              this.reembolsos = data.pagamentos;
              if (this.reembolsos.length == 0) {
                this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro");
              }
              else {
                this.historico = data.historicoPagamentos;
                console.log(this.historico);
                this.reembolsos.forEach(element => {
                  element.selecionado = true;
                });
                this.atualizarInformacoes();
              }

            }
          }
        ),
        error => {
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
        }
        ;
    }
  }

}
