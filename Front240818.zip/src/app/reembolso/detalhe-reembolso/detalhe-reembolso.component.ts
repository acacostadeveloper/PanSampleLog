import { Component, OnInit } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { Reembolso } from '../../models/reembolso.model';
import { HistoricoReembolso } from '../../models/HistoricoReembolso.model';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { Comunicacao } from '../../models/comunicacao.model';

@Component({
  selector: 'pan-detalhe-reembolso',
  templateUrl: './detalhe-reembolso.component.html',
  styleUrls: ['./detalhe-reembolso.component.css']
})
export class DetalheReembolsoComponent implements OnInit {
  reembolso = new Reembolso();

  constructor(
    private reembolsoService: ReembolsoService,
    private route: ActivatedRoute
  ) {

  }

  ngOnInit() {
    this.obterReembolso(this.route.snapshot.params['id']);
  }

  obterReembolso(idReembolso: number) {
    console.log(this.reembolso);
    this
      .reembolsoService
      .obterReembolso(
        idReembolso
      )
      .subscribe(
        (data: Reembolso) => {
          this.reembolso = data;
          this.preencheDados();
          console.log(this.reembolso);
        }
      )
      ;
  }

  preencheDados() {
    let historicoReembolso: HistoricoReembolso;
    this.reembolso.historicoReembolsos = [];


    historicoReembolso = new HistoricoReembolso();
    historicoReembolso.idHistoricoReembolso = 12;
    historicoReembolso.statusIni = "ok";
    historicoReembolso.statusFim = "erro";
    historicoReembolso.statusContabil = "Enviado";
    historicoReembolso.usuarioInclusao = "UserTeste";
    historicoReembolso.dataEvento = "10/10/2018";
    historicoReembolso.evento.eventoContabil = "EventoC";

    this.reembolso.historicoReembolsos.push(historicoReembolso);

    historicoReembolso = new HistoricoReembolso();
    historicoReembolso.idHistoricoReembolso = 13;
    historicoReembolso.statusIni = "erro";
    historicoReembolso.statusFim = "ok";
    historicoReembolso.statusContabil = "Negado";
    historicoReembolso.usuarioInclusao = "User2";
    historicoReembolso.dataEvento = "10/12/2018";
    historicoReembolso.evento.eventoContabil = "EventoD";

    this.reembolso.historicoReembolsos.push(historicoReembolso);

    historicoReembolso = new HistoricoReembolso();
    historicoReembolso.idHistoricoReembolso = 14;
    historicoReembolso.statusIni = "AC";
    historicoReembolso.statusFim = "OK";
    historicoReembolso.statusContabil = "Enviado";
    historicoReembolso.usuarioInclusao = "User4";
    historicoReembolso.dataEvento = "30/12/2018";
    historicoReembolso.evento.eventoContabil = "EventoC";

    this.reembolso.historicoReembolsos.push(historicoReembolso);

    let comunicacao: Comunicacao;
    this.reembolso.comunicacoes = [];

    comunicacao = new Comunicacao();
    comunicacao.mensagemComunicacao.tipoComunicacao = "SMS";
    comunicacao.dataEnvioComunicacao = "10/10/2008";
    comunicacao.mensagemComunicacao.mensagemComunicacao = "Mensagem enviada com sucesso";
    comunicacao.mensagemComunicacao.numeroVersao = "2.33.10";

    this.reembolso.comunicacoes.push(comunicacao);

    comunicacao = new Comunicacao();
    comunicacao.mensagemComunicacao.tipoComunicacao = "E-mail";
    comunicacao.dataEnvioComunicacao = "15/12/2018";
    comunicacao.mensagemComunicacao.mensagemComunicacao = "Mensagem enviada com sucesso";
    comunicacao.mensagemComunicacao.numeroVersao = "1.22.10";

    this.reembolso.comunicacoes.push(comunicacao);

    comunicacao = new Comunicacao();
    comunicacao.mensagemComunicacao.tipoComunicacao = "Celular";
    comunicacao.dataEnvioComunicacao = "25/12/2018";
    comunicacao.mensagemComunicacao.mensagemComunicacao = "Mensagem enviada com sucesso";
    comunicacao.mensagemComunicacao.numeroVersao = "4.22.21";

    this.reembolso.comunicacoes.push(comunicacao);
  }
}


