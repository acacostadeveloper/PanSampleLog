import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ReembolsoService } from '../reembolso.service';
import { Reembolso } from '../../models/reembolso.model';
import { Produto } from '../../models/produto.model';
import { ProdutoService } from '../../produto/produto.service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { ModalDialogService, SimpleModalComponent } from 'ngx-modal-dialog'; //https://github.com/Greentube/ngx-modal/blob/master/demo/src/app/app.component.ts#L30-L32
import { HttpErrorResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment'
import { ReembolsoConsulta } from '../../models/reembolsoConsulta.model';
import { FuncoesApoio } from '../../Helpers/funcoesApoio';
import { PopUpModal } from '../../Helpers/popUpModal';

@Component({
  selector: 'pan-consultar-reembolso',
  templateUrl: './consultar-reembolso.component.html',
  styleUrls: ['./consultar-reembolso.component.css']
})
export class ConsultarReembolsoComponent implements OnInit {
  public reembolsos: ReembolsoConsulta[] = [];
  reembolso = new ReembolsoConsulta();
  produtos: Produto[];
  statusReembolsos = environment.StatusReembolso;
  mensagem: PopUpModal = new PopUpModal(this.modalService, this.viewRef);

  //Filtros:
  filterIdLote: string;
  filterIdProduto: string;
  filterDtInicial: IMyDateModel;
  filterDtFinal: IMyDateModel;
  filterCpfClientes: string;
  filterStatusReembolso: string;
  statusReembolso: string[];

  //date picker
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd/mm/yyyy',
  };

  constructor(
    private reembolsoService: ReembolsoService,
    private produtoService: ProdutoService,
    private modalService: ModalDialogService,
    private viewRef: ViewContainerRef
  ) { }

  ngOnInit() {
    this.carregarProdutos();
  }

  carregarProdutos() {
    this
      .produtoService
      .obterProdutos()
      .subscribe(
        (data: Produto[]) => {
          this.produtos = data;
        }
      ),
      error => {
        console.log(error)
      }
      ;
  }

  carregarReembolsos() {
    let dtInicial: string;
    let dtFinal: string;

    if (this.validarCampos()) {
      this
        .reembolsoService
        .obterReembolsos(
          this.filterIdLote,
          this.filterIdProduto,
          FuncoesApoio.formatarDataInicial(this.filterDtInicial),
          FuncoesApoio.formatarDataFinal(this.filterDtFinal),
          this.filterCpfClientes,
          this.statusReembolso,
        )
        .subscribe(
          (data: ReembolsoConsulta[]) => {
            if (data instanceof HttpErrorResponse) {
              var retorno: HttpErrorResponse;
              retorno = data;
              if (retorno.status == 502) {
                this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro");
                this.reembolsos = [];
              }
              else {
                this.mensagem.mensagemOkModal("Ocorreu o erro: " + data.statusText);
              }

            }
            else {
              if (data.length == 0) {
                this.mensagem.mensagemOkModal("Não foram encontrados registros com este parametro");
              }
              else {
                this.reembolsos = data;
              }
            }
          }
        ),
        error => {
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error);
        }
        ;
    }
  }

  deletarReembolsos() {

    let ids = this.reembolsos;

    let loop = (id: ReembolsoConsulta) => {
      if (ids.length > 0) {
        if (id.estornar == true) {
          this.reembolsoService.deletarReembolso(id.idReembolso).subscribe(
            (data) => {
              if (data instanceof HttpErrorResponse) {
                this.mensagem.mensagemOkModal("Erro ao excluir o reembolso " + id);
              }
              loop(ids.shift())
            }),
            error => {
              if (error instanceof HttpErrorResponse) {
                this.mensagem.mensagemOkModal("Erro ao excluir o reembolso " + id);
              }
            }
        }
        else {
          loop(ids.shift())
        }
      }
      else {
        this.mensagem.mensagemOkModal("Registros excluídos com sucesso.");
        this.carregarReembolsos();
      }
    }

    loop(ids.shift());
  }

  confirmarDeletarReembolso(idReembolso: number){
    const _self = this;
    this.mensagem.mensagemOkNoModal("Deseja excluir o reembolso ?",
    function () {
      _self.deletarReembolso(idReembolso);
    });
  }

  confirmarDeletarReembolsos(){
    const _self = this;
    this.mensagem.mensagemOkNoModal("Deseja excluir os reembolsos selecionados ?",
    function () {
      _self.deletarReembolsos();
    });
  }

  public deletarReembolso(idReembolso: number) {
    console.log('cheguei' + idReembolso);
    this.reembolsoService.deletarReembolso(idReembolso).subscribe(
      data => {
        this.mensagem.mensagemOkModal("Registro excluído com sucesso.");
        this.carregarReembolsos();
      },
      error => {
        if (error instanceof HttpErrorResponse) {
          this.mensagem.mensagemOkModal("Ocorreu o erro: " + error.statusText);
        }
      },
    );

  }

  montarStatusReembolso() {
    let retorno = this.statusReembolsos.find(item => item.entrada === this.filterStatusReembolso);
    return retorno.saida.split(",");
  }

  limparFiltros() {
    this.filterIdLote = "";
    this.filterIdProduto = "";
    this.filterDtInicial = null;
    this.filterDtFinal = null;
    this.filterCpfClientes = "";
    this.filterStatusReembolso = null;
    this.statusReembolso = undefined;
  }

  validarCampos() {
    let mensagemRetorno: string = "";

    if (this.filterCpfClientes == undefined) {
      this.filterCpfClientes = "";
    }
    console.log(this.statusReembolso);
    if (this.filterStatusReembolso == undefined || this.filterStatusReembolso == null) {
      this.statusReembolso = [];
    }
    else {
      this.statusReembolso = this.montarStatusReembolso();
    }

    if (this.filterDtInicial == undefined || this.filterDtInicial == null ||
      this.filterDtFinal == undefined || this.filterDtFinal == null) {
      this.filterDtInicial = null;
      this.filterDtFinal = null;
    }
    else {
      if (FuncoesApoio.verificarDataFinalMenor(this.filterDtInicial, this.filterDtFinal)) {
        mensagemRetorno = mensagemRetorno + "- Data final deve ser maior que data inicial.<br>";
      }
    }

    if (mensagemRetorno == "") {
      return true;
    }
    else {
      this.mensagem.mensagemOkModal(mensagemRetorno);
      return false;
    }
  }
}

