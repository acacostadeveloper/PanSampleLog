export class Departamento {
    idDepartamento: number
    codigoDepartamento: string
    nomeDepartamento: string
}