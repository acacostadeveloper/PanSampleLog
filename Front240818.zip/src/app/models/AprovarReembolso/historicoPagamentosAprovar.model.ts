export class HistoricoPagamentosAprovar{
    historico10:{total:string , media: string}
    historico20:{total:string , media: string}
    historico30:{total:string , media: string}
}
