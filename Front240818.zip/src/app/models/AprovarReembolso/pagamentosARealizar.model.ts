export class PagamentosARealizar{
    cpf: string
    nomeCliente: string
    valor: number
    ids: number[]
    selecionado: boolean = true
}