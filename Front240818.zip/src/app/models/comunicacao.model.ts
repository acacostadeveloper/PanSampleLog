import { MensagemComunicacao } from "./mensagemComunicacao";

export class Comunicacao {
    mensagemComunicacao: MensagemComunicacao = new MensagemComunicacao()
    dataEnvioComunicacao: string
}