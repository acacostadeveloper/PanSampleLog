export class SistemaProduto {
    codigoSistema: string
    nomeSistema: string
}