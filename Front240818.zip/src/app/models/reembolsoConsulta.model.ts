export class ReembolsoConsulta {
    idReembolso: number
    idLote: number
    nomeProduto: string
    dtInclusao: string
    cpfCnpj: string
    codigoContrato: string
    nomeCliente: string
    valorReembolso: string
    statusReembolso: string[]=[]
    permiteEstorno: string
    estornar: boolean
}