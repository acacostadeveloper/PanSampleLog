import { Usuario } from "./usuario.model";
import { Departamento } from "./departamento.model";
import { Contrato } from "./contrato.model";
import { Sigla } from "./sigla.model";
import { ProcessoRegistro } from "./processoRegistro.model";
import { Lote } from "./lote.model";
import { HistoricoReembolso } from "./historicoReembolso.model";
import { Comunicacao } from "./comunicacao.model";

export class Reembolso {
  idReembolso: number
  pagamento: string
  usuario: Usuario = new Usuario()
  departamento: Departamento = new Departamento()
  contrato: Contrato = new Contrato()
  dataSolicitacao: string
  numeroReembolso: number
  valorReembolso: string
  mesCompetencia: number
  anoCompetencia: number
  sigla: Sigla = new Sigla()
  lote: Lote = new Lote()
  statusReembolso: string
  processoRegistro: ProcessoRegistro = new ProcessoRegistro()
  integracao: string
  mensagemErro: string
  dtInclusao: string
  permiteEstorno: boolean
  estornar: boolean
  historicoReembolsos: Array<HistoricoReembolso> = new Array<HistoricoReembolso>();
  comunicacoes: Array<Comunicacao> = new Array<Comunicacao>();
};

