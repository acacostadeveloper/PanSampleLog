import { Evento } from "./evento.model";

export class HistoricoReembolso {
    idHistoricoReembolso: number
    reembolso: number
    evento: Evento = new Evento()
    dataEvento: string
    statusIni: string
    statusFim: string
    usuarioInclusao: string
    statusContabil: string
}