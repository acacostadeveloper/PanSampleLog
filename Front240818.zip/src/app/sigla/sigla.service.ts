import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { APP_API } from '../app.api'
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SiglaService {

  constructor(private http: HttpClient) { }

  obterSiglas(): Observable<any> {

    return this.http
      .get(`${APP_API}sigla/obter`)

  }
}

