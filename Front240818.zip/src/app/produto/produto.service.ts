import { Injectable } from '@angular/core'
import { Observable } from 'rxjs'
import { APP_API } from '../app.api'
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ProdutoService {

  constructor(private http: HttpClient) { }

  obterProdutos(): Observable<any> {

    return this.http
      .get(`${APP_API}produto/obter`)
    
  }

}
