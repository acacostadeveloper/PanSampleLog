export const environment = {
  production: true,
  api: 'http://10.99.5.43:35100/api/',
  codigoDepartamento: "0000020",
  codigoColigada: "001",
  meses: [
    { id: 1, mes: "janeiro" },
    { id: 2, mes: "fevereiro" },
    { id: 3, mes: "março" },
    { id: 4, mes: "abril" },
    { id: 5, mes: "maio" },
    { id: 6, mes: "junho" },
    { id: 7, mes: "julho" },
    { id: 8, mes: "agosto" },
    { id: 9, mes: "setembro" },
    { id: 10, mes: "outubro" },
    { id: 11, mes: "novembro" },
    { id: 12, mes: "dezembro" }
  ],
  StatusReembolso: [
    { entrada: "Cancelado", saida: "Cancelado", exibicao: "Cancelado" },
    { entrada: "Rejeitado", saida: "Rejeitado", exibicao: "Rejeitado" },
    { entrada: "Reembolsado", saida: "Reembolsado", exibicao: "Reembolsado" },
    { entrada: "PagamentoLiberado", saida: "PagamentoLiberado", exibicao: "Pagamento Liberado" },
    { entrada: "AReembolsar", saida: "Bloqueado,Registrado", exibicao: "A Reembolsar" }
  ]
};
