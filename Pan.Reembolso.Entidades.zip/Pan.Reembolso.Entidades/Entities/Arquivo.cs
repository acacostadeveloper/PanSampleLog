﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Arquivo
    {
        [DataMember]
        public string nome { get; set; }

        [DataMember]
        public string descricao { get; set; }

        [DataMember]
        public DateTime created { get; set; }

        [DataMember]
        public DateTime Updated { get; set; }

        //[DataMember]
        //public List<string> ContentTypes { get; set; }
    }
}
