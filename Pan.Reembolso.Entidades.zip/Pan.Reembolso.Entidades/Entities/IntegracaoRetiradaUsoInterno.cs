﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class IntegracaoRetiradaUsoInterno
    {
        [DataMember]
        public int idIntegracao { get; set; }
        [DataMember]
        public string numeroCpfCnpj { get; set; }
        [DataMember]
        public string codigoProduto { get; set; }
        [DataMember]
        public decimal valorRetirada { get; set; }
        [DataMember]
        public Pagamento Pagamento { get; set; }
        [DataMember]
        public int codigoProcessoRegistro { get; set; }
        [DataMember]
        public int codigoLoteIntegracao { get; set; }
        [DataMember]
        public string codigoStatusIntegracao { get; set; }
        [DataMember]
        public string mensagemErro { get; set; }
        [DataMember]
        public string usuarioInclusao { get; set; }
        [DataMember]
        public DateTime dataInclusao { get; set; }
    }
}
