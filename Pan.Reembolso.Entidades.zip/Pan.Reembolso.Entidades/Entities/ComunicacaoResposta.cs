﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Entidades
{
    public class ComunicacaoResposta
    {
        public string identificador { get; set; }
        public string protocolo { get; set; }
        public ReembolsoTypes.StatusComunicacaoType situacao { get; set; }
        public string msgErro { get; set; }
        public string origem { get; set; }
    }
}
