﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    public class DevolucaoSPB
    {
        public string numeroRequisicao { get; set; }
        public string numeroOrigem { get; set; }
        public string statusRequisicao { get; set; }
    }
}
