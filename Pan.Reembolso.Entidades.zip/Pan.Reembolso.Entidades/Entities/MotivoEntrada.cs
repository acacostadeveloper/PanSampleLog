﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MotivoEntrada
    {

        [DataMember]
        public int idMotivoEntrada { get; set; }
        [DataMember]
        public string descricaoMotivoEntrada { get; set; }
        [DataMember]
        public string tipoMotivoEntrada { get; set; }
        [DataMember]
        public int? idSigla { get; set; }
        [DataMember]
        public DateTime? dtInclusao { get; set; }
        [DataMember]
        public DateTime? dtAlteracao { get; set; }
        [DataMember]
        public string indicadorAtivo { get; set; }

    }
}
