﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Favorecido
    {
        [DataMember]
        public string numeroCpfCnpj { get; set; }
        [DataMember]
        public int sequenciaCpfCnpj { get; set; }
        [DataMember]
        public string tipoPesssoa { get; set; }
        [DataMember]
        public string nome { get; set; }
        [DataMember]
        public ContaCredito contaCredito { get; set; }

        public Favorecido()
        {
            contaCredito = new ContaCredito();
        }
    }
}
