﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Pagamento
    {
        [DataMember]
        public MensagemTransferencia mensagem { get; set; }
        [DataMember]
        public DateTime? dataPagamento { get; set; }
        [DataMember]
        public DateTime dataRegistroPagamento { get; set; }
        [DataMember]
        public string tipoPagamento { get; set; }
        [DataMember]
        public decimal valorPagamento { get; set; }
        [DataMember]
        public ProcessoRegistro processoRegistro { get; set; }
        [DataMember]
        public Favorecido favorecido { get; set; }
        [DataMember]
        public List<Reembolso> listaReembolsos { get; set; }
        [DataMember]
        public long numeroPagamento { get; set; }
        [DataMember]
        public string statusPagamento { get; set; }

    }
}
