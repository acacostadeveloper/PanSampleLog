﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MensagemTransferenciaPadrao
    {
        [DataMember]
        public string codigoFinalidadeSPB { get; set; }
        [DataMember]
        public string indicadorCreditaContaCorrente { get; set; }
        [DataMember]
        public string indicadorDebitaContaCorrente { get; set; }
        [DataMember]
        public string indicadorEmiteRecebe { get; set; }
        [DataMember]
        public string indicadorMesmaTitularidade { get; set; }
        [DataMember]
        public string indicadorPrevisao { get; set; }
        [DataMember]
        public string indicadorTransitaContaCorrente { get; set; }
        [DataMember]
        public string numeroBordero { get; set; }
        [DataMember]
        public string tipoLiquidacao { get; set; }
        [DataMember]
        public string numeroVersao { get; set; }
        [DataMember]
        public Produto produto { get; set; }
    }
}
