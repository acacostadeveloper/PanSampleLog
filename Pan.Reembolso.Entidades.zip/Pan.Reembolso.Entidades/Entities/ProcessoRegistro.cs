﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class ProcessoRegistro
    {
        [DataMember]
        public int codigoProcessoRegistro { get; set; }

        [DataMember]
        public string processoRegistro { get; set; }

        [DataMember]
        public string centroCusto { get; set; }

        [DataMember]
        public string modeloContabil { get; set; }

        [DataMember]
        public string indicadorFluxo { get; set; }

        [DataMember]
        public string contaDebito { get; set; }

        [DataMember]
        public string contaCredito { get; set; }
        [DataMember]
        public string modeloContabilReversao { get; set; }

        [DataMember]
        public string contaDebitoReversao { get; set; }

        [DataMember]
        public string contaCreditoReversao { get; set; }

        [DataMember]
        public Evento evento { get; set; }

        public ProcessoRegistro()
        {
            evento = new Evento();
        }
    }
}
