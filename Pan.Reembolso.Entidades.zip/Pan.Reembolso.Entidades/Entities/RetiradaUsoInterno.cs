﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class RetiradaUsoInterno
    {
        [DataMember]
        public string cpfcnpj { get; set; }
        [DataMember]
        public string nomeCliente { get; set; }
        [DataMember]
        public decimal valor { get; set; }
        public int  processoRegistro { get; set; }
        [DataMember]
        public List<long> ids { get; set; }
        [DataMember]
        public Produto produto { get; set; }
    }
}
