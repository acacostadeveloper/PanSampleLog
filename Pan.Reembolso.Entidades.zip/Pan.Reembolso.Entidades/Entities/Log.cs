﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Log
    {
        [DataMember]
        public Guid LogId { get; set; }
        [DataMember]
        public string Application { get; set; }
        [DataMember]
        public string User { get; set; }
        [DataMember]
        public string Machine { get; set; }
        [DataMember]
        public string RequestIpAddress { get; set; }
        [DataMember]
        public dynamic RequestContentBody { get; set; }
        [DataMember]
        public string RequestUri { get; set; }
        [DataMember]
        public string RequestMethod { get; set; }
        [DataMember]
        public int? ResponseStatusCode { get; set; }
        [DataMember]
        public IDictionary<string, string> RequestHeaders { get; set; }
        [DataMember]
        public IDictionary<string, string> ResponseHeaders { get; set; }
        [DataMember]
        public dynamic ResponseContentBody { get; set; }
        [DataMember]
        public DateTime? RequestTimestamp { get; set; }
        [DataMember]
        public DateTime? ResponseTimestamp { get; set; }
    }

}
