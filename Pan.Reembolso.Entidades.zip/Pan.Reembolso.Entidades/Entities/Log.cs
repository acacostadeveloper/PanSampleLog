﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Log
    {
        [DataMember]
        public int LogId { get; set; }

        [DataMember]
        public string Application { get; set; }

        [DataMember]
        public Guid CorrelationId { get; set; }

        [DataMember]
        public string Machine { get; set; }

        [DataMember]
        public string IpAddress { get; set; }

        [DataMember]
        public string RequestUri { get; set; }

        [DataMember]
        public int? StatusCode { get; set; }

        [DataMember]
        public DateTime? RequestTimestamp { get; set; }

        [DataMember]
        public DateTime? ResponseTimestamp { get; set; }

        [DataMember]
        public int? TotalTime { get; set; }

        [DataMember]
        public dynamic JsonLog { get; set; }

        [DataMember]
        public string MessageError { get; set; }
    }

}
