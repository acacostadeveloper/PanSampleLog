﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MovimentoContabil
    {
        [DataMember]
        public MovimentoContabilPadrao movimentoPadrao { get; set; }
        //NO_REGISTRO
        public string numeroRegistro { get; set; }
        //DT_SISTEMA
        public string dataSistema { get; set; }
        //NO_REMESSA
        public string  numeroRemessa { get; set; }
        //NO_ORIGEM
        public string numeroOrigem { get; set; }
        //NO_SEQUENCIA_ORIGEM
        public string numeroSequenciaOrigem { get; set; }
        //DT_LANCAMENTO
        public string dataLancamento { get; set; }
        //VL_ENTRADA
        public decimal valorEntrada { get; set; }
        //DS_HISTORICO
        public string descricaoHistorico { get; set; }
        //DS_COMPLEMENTO1
        public string descricaoComplemento1 { get; set; }
        //NO_MODELO
        public string numeroModelo { get; set; }
        //NO_CENTRO_CUSTO_DEBITO
        public string numeroCentroCustoDebito { get; set; }
        //NO_CENTRO_CUSTO_CREDITO
        public string numeroCentroCustoCredito { get; set; }
        //DT_DOCUMENTO
        public string dataDocumento { get; set; }
        //DT_ULTIMA_ATUALIZACAO
        public string dataUltimaAtualizacao { get; set; }
        //CD_USUARIO
        public string codigoUsuario { get; set; }
        //NM_ARQUIVO_INTEGRADO
        public string nomeArquivoIntegrado { get; set; }
        //DT_INTEGRACAO
        public DateTime dataIntegracao { get; set; }
        //ID_HISTORICO_REEMBOLSO
        public int idHistoricoReembolso { get; set; }
    }
}
