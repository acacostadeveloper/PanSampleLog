﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;


namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class LogConsoleApp
    {
        [DataMember]
        public int LogId { get; set; }

        [DataMember]
        public string Application { get; set; }

        [DataMember]
        public string BatchTask { get; set; }

        [DataMember]
        public string Machine { get; set; }

        [DataMember]
        public string IpAddress { get; set; }

        [DataMember]
        public DateTime? Timestamp { get; set; }

        [DataMember]
        public string TextLog { get; set; }

        [DataMember]
        public string MessageError { get; set; }
    }
}
