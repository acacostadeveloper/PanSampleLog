﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Entidades
{
    public class RespostaSMS
    {
        public int idMensagemEntrada { get; set; }
        public int ordem { get; set; }
        public int idBroker { get; set; }
        public string descricaoBroker { get; set; }
        public int idStatus { get; set; }
        public string descricaoStatus { get; set; }
        public DateTime dataEnvio { get; set; }
        public DateTime dataStatus { get; set; }
        public string mensagem { get; set; }

    }
}
