﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Reembolso
    {
        [DataMember]
        public PagamentoReembolso pagamento {get; set;}
        [DataMember]
        public Usuario usuario { get; set; }
        [DataMember]
        public Departamento departamento { get; set; }
        [DataMember]
        public IList<Comunicacao> comunicacoes { get; set; }
        [DataMember]
        public Contrato contrato { get; set; }
        [DataMember]
        public DateTime dataSolicitacao { get; set; }
        [DataMember]
        public long numeroReembolso { get; set; }
        [DataMember]
        public decimal valorReembolso { get; set; }
        [DataMember]
        public string statusReembolso { get; set; }
        [DataMember]
        public string idLote { get; set; }


        public Reembolso()
        {
            pagamento = new PagamentoReembolso();
            usuario = new Usuario();
            departamento = new Departamento();
            comunicacoes = new List<Comunicacao>();
            contrato = new Contrato();
        }
    }
}
