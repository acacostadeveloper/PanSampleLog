﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Reembolso
    {
        [DataMember]
        public long idReembolso { get; set; }
        [DataMember]
        public Departamento departamento { get; set; }
        [DataMember]
        public IList<Comunicacao> comunicacoes { get; set; }
        [DataMember]
        public Contrato contrato { get; set; }
        [DataMember]
        public long numeroReembolso { get; set; }
        [DataMember]
        public decimal valorReembolso { get; set; }
        [DataMember]
        public string statusReembolso { get; set; }
        [DataMember]
        public string statusUsuario { get; set; }
        [DataMember]
        public int mesCompetencia { get; set; }
        [DataMember]
        public int anoCompetencia { get; set; }
        [DataMember]
        public Lote lote { get; set; }
        [DataMember]
        public Sigla sigla { get; set; }
        [DataMember]
        public ProcessoRegistro processoRegistro { get; set; }
        [DataMember]
        public int integracao{ get; set; }
        [DataMember]
        public string mensagemErro { get; set; }
        [DataMember]
        public MotivoBloqueio motivoBloqueio { get; set; }
        [DataMember]
        public DateTime dtInclusao { get; set; }
        [DataMember]
        public DateTime dataSolicitacao { get; set; }
        [DataMember]
        public Boolean permiteEstorno { get; set; }
        [DataMember]
        public List<HistoricoReembolso> historicoReembolso { get; set; }
        [DataMember]
        public string usuarioInclusao { get; set; }
        [DataMember]
        public string usuarioAlteracao { get; set; }
        [DataMember]
        public string usuarioAprovacao { get; set; }
        [DataMember]
        public string tipoPagamentoLegado { get; set; }
        [DataMember]
        public string indicadorTombado { get; set; }
        public Reembolso()
        {
            departamento = new Departamento();
            comunicacoes = new List<Comunicacao>();
            contrato = new Contrato();
            sigla = new Sigla();
            processoRegistro = new ProcessoRegistro();
            lote = new Lote();
            historicoReembolso = new List<HistoricoReembolso>();
        }
    }
}
