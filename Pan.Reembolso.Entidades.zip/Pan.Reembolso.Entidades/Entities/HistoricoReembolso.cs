﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class HistoricoReembolso
    {
        [DataMember]
        public int idHistoricoReembolso { get; set; }
        [DataMember]
        public long reembolso { get; set; }
        [DataMember]
        public Evento evento { get; set; }
        [DataMember]
        public DateTime dataEvento { get; set; }
        [DataMember]
        public string statusIni { get; set; }
        [DataMember]
        public string statusFim { get; set; }
        [DataMember]
        public string usuarioInclusao { get; set; }
        //[DataMember]
        //public string usuarioAlteracao { get; set; }
        [DataMember]
        public string statusContabil { get; set; }
        public string mensagemErro { get; set; }
    }
}
