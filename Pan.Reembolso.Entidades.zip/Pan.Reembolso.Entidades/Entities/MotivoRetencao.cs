﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MotivoRetencao
    {
        [DataMember]
        public int idMotivoRetencao { get; set; }
        [DataMember]
        public string descricaoMotivoRetencao { get; set; }
    }
}
