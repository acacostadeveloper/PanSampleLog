﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MensagemTransferencia : MensagemTransferenciaPadrao
    {
        [DataMember]
        public Reserva contaReserva { get; set; }
        [DataMember]
        public Favorecido favorecido { get; set; }
        [DataMember]
        public string numeroRequisicao { get; set; }
        [DataMember]
        public DateTime dataRegistro { get; set; }
        [DataMember]
        public DateTime? dataLiquidacao { get; set; }
        [DataMember]
        public string statusMensagem { get; set; }
        [DataMember]
        public decimal valorTransferencia { get; set; }
        [DataMember]
        public string numeroOrigem { get; set; }
        [DataMember]
        public string codigoEvento { get; set; }

    }
}
