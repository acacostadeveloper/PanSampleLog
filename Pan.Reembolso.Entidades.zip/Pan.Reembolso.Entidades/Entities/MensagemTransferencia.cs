﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MensagemTransferencia : MensagemTransferenciaPadrao
    {
        [DataMember]
        public Reserva contaReserva { get; set; }
        [DataMember]
        public string numeroRequisicao { get; set; }
        [DataMember]
        public DateTime dataRegistro { get; set; }
        [DataMember]
        public DateTime? dataLiquidacao { get; set; }
        [DataMember]
        public string statusMensagem { get; set; }
        [DataMember]
        public decimal valorTransferencia { get; set; }
        [DataMember]
        public string numeroOrigem { get; set; }
        [DataMember]
        public string codigoEvento { get; set; }
        [DataMember]
        public string nomeFavorecido { get; set; }
        [DataMember]
        public string tipoPessoaFavorecido { get; set; }
        [DataMember]
        public string numeroCpfCnpjFavorecido { get; set; }
        [DataMember]
        public int numeroSequenciaFavorecido { get; set; }
        [DataMember]
        public string tipoContaFavorecido { get; set; }
        [DataMember]
        public string numeroBancoFavorecido { get; set; }
        [DataMember]
        public string numeroAgenciaFavorecido { get; set; }
        [DataMember]
        public string digitoAgenciaFavorecido { get; set; }
        [DataMember]
        public string numeroContaFavorecido { get; set; }
        [DataMember]
        public string digitoContaFavorecido { get; set; }

    }
}
