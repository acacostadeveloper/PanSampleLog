﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Integracao
    {
        [DataMember]
        public int idIntegracao { get; set; }

        [DataMember]
        public int idReembolso { get; set; }

        [DataMember]
        public int idLote { get; set; }

        [DataMember]
        public string idCliente { get; set; }

        [DataMember]
        public string idContrato { get; set; }

        [DataMember]
        public decimal valorReembolso { get; set; }

        [DataMember]
        public string convenio { get; set; }

        [DataMember]
        public string matricula { get; set; }

        [DataMember]
        public string cpfCnpj { get; set; }

        [DataMember]
        public string mesCompetencia { get; set; }

        [DataMember]
        public string sigla { get; set; }

        [DataMember]
        public string idProcesso { get; set; }

        [DataMember]
        public string idProduto { get; set; }

        [DataMember]
        public string status { get; set; }

        [DataMember]
        public string codigoUsuarioInclusao { get; set; }

        [DataMember]
        public DateTime dataEnvio { get; set; }

        [DataMember]
        public DateTime dataIntegracao { get; set; }
    }
}
