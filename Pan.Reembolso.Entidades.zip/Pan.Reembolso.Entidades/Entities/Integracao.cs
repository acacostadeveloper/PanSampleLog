﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Integracao
    {
        [DataMember]
        public int idIntegracao { get; set; }
        [DataMember]
        public string idReembolso { get; set; }
        [DataMember]
        public string idLote { get; set; }
        [DataMember]
        public string cliente { get; set; }
        [DataMember]
        public string contrato { get; set; }
        [DataMember]
        public decimal valorReembolso { get; set; }
        [DataMember]
        public string convenio { get; set; }
        [DataMember]
        public string matricula { get; set; }
        [DataMember]
        public string cpfCnpj { get; set; }
        [DataMember]
        public string mesCompetencia { get; set; }
        [DataMember]
        public string anoCompetencia { get; set; }
        [DataMember]
        public string sigla { get; set; }
        [DataMember]
        public string processoEntrada { get; set; }
        [DataMember]
        public string produto { get; set; }
        [DataMember]
        public string status { get; set; }
        [DataMember]
        public string mensagemErro { get; set; }
        [DataMember]
        public string usuarioInclusao { get; set; }
        [DataMember]
        public DateTime dataInclusao { get; set; }
        [DataMember]
        public DateTime dataIntegracao { get; set; }
    }
}
