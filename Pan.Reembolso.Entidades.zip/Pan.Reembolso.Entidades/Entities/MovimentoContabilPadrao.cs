﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class MovimentoContabilPadrao
    {
        //CD_PROCESSO
        [DataMember]
        public string codigoProcesso { get; set; }
        //CD_LAYOUT
        [DataMember]
        public string codigoLayout { get; set; }
        //CD_COLIGADA
        [DataMember]
        public string codigoColigada { get; set; }
        //CD_SISTEMA
        [DataMember]
        public string codigoSistema { get; set; }
        //NO_SEQUENCIA_ORIGEM
        [DataMember]
        public string numeroSequenciaOrigem { get; set; }
        //CD_EMPRESA_ORIGEM
        [DataMember]
        public string codigoEmpresaOrigem { get; set; }
        //CD_AGENCIA
        [DataMember]
        public string codigoAgencia { get; set; }
        //CD_UNIDADE
        [DataMember]
        public string codigoUnidade { get; set; }
        //CD_NIVEL1
        [DataMember]
        public string codigoNivel1 { get; set; }
        //CD_NIVEL2
        [DataMember]
        public string codigoNivel2 { get; set; }
        //CD_NIVEL3
        [DataMember]
        public string codigoNivel3 { get; set; }
        //CD_NIVEL4
        [DataMember]
        public string codigoNivel4 { get; set; }
        //CD_DEBITA_CREDITA
        [DataMember]
        public string codigoCreditaDebita { get; set; }
        //CD_AGENCIA_DESTINO
        [DataMember]
        public string codigoAgenciaDestino { get; set; }
        //CD_NIVEL1_DESTINO
        [DataMember]
        public string codigoNivel1Destino { get; set; }
        //CD_NIVEL2_DESTINO
        [DataMember]
        public string codigoNivel2Destino { get; set; }
        //CD_NIVEL3_DESTINO
        [DataMember]
        public string codigoNivel3Destino { get; set; }
        //CD_NIVEL4_DESTINO
        [DataMember]
        public string codigoNivel4Destino { get; set; }
        //CD_UNIDADE_DESTINO
        [DataMember]
        public string codigoUnidadeDestino { get; set; }
        //DS_COMPLEMENTO2
        [DataMember]
        public string descricaoComplemento2 { get; set; }
        //DS_COMPLEMENTO3
        [DataMember]
        public string descricaoComplemento3 { get; set; }
        //DS_COMPLEMENTO4
        [DataMember]
        public string descricaoComplemento4 { get; set; }
        //DS_COMPLEMENTO5
        [DataMember]
        public string descricaoComplemento5 { get; set; }
        //CD_FORMA_LANCAMENTO
        [DataMember]
        public string codigoFormaLancamento { get; set; }
        //CD_TIPO_LANCAMENTO
        [DataMember]
        public string codigoTipoLancamento { get; set; }
        //CD_EVENTO
        [DataMember]
        public string codigoEvento { get; set; }
        //NO_SEQUENCIA_ITEM
        [DataMember]
        public string numeroSequenciaItem { get; set; }
        //NM_TABELA_DEBITO
        [DataMember]
        public string nomeTabelaDebito { get; set; }
        //CD_PRODUTO_DEBITO
        [DataMember]
        public string codigoProdutoDebito { get; set; }
        //CD_TIPO_CREDITO_DEBITO
        [DataMember]
        public string codigoTipoCreditoDebito { get; set; }
        //CD_ATIVIDADE_DEBITO
        [DataMember]
        public string codigoAtividadeDebito { get; set; }
        //CD_TIPO_CONTA_DEBITO
        [DataMember]
        public string codigoTipoContaDebito { get; set; }
        //NO_CONTA_DEBITO
        [DataMember]
        public string numeroContaDebito { get; set; }
        //CD_REDUZIDO_DEBITO
        [DataMember]
        public string codigoReduzidoDebito { get; set; }
        //NO_CONTA_AUXILIAR_DEBITO
        [DataMember]
        public string numeroContaAuxiliarDebito { get; set; }
        //NO_CONTA_CORRENTE_DEBITO
        [DataMember]
        public string numeroContaCorrenteDebito { get; set; }
        //NM_TABELA_CREDITO
        [DataMember]
        public string nomeTabelaCredito { get; set; }
        //CD_PRODUTO_CREDITO
        [DataMember]
        public string codigoProdutoCredito { get; set; }
        //CD_TIPO_CREDITO_CREDITO
        [DataMember]
        public string codigoTipoCreditoCredito { get; set; }
        //CD_ATIVIDADE_CREDITO
        [DataMember]
        public string codigoAtividadeCredito { get; set; }
        //CD_TIPO_CONTA_CREDITO
        [DataMember]
        public string codigoTipoContaCredito { get; set; }
        //NO_CONTA_CREDITO
        [DataMember]
        public string numeroContaCredito { get; set; }
        //CD_REDUZIDO_CREDITO
        [DataMember]
        public string codigoReduzidoCredito { get; set; }
        //NO_CONTA_AUXILIAR_CREDITO
        [DataMember]
        public string numeroContaAuxiliarCredito { get; set; }
        //NO_CONTA_CORRENTE_CREDITO
        [DataMember]
        public string numeroContaCorrenteCredito { get; set; }
        //CD_TIPO_MOEDA
        [DataMember]
        public string codigoTipoMoeda { get; set; }
        //QT_MOEDA
        [DataMember]
        public string quantidadeMoeda { get; set; }
        //VL_MOEDA
        [DataMember]
        public string valorMoeda { get; set; }
        //IC_REPROCESSAMENTO
        [DataMember]
        public string indicadorReprocessamento { get; set; }
        //CD_GERENTE
        [DataMember]
        public string codigoGerente { get; set; }
        //NO_DOCUMENTO
        [DataMember]
        public string numeroDocumento { get; set; }
        //IC_ATUALIZADO
        [DataMember]
        public string indicadorAtualizado { get; set; }
        //IC_CANCELADO
        [DataMember]
        public string indicadorCancelado { get; set; }
        //IC_ESTORNADO
        [DataMember]
        public string indicadorEstornado { get; set; }
        [DataMember]
        public int idContabilPadrao { get; set; }
    }
}
