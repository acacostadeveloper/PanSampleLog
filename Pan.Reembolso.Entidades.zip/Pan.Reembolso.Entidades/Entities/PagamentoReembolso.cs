﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class PagamentoReembolso
    {
        [DataMember]
        public MensagemTransferencia mensagem { get; set; }
        [DataMember]
        public DateTime dataPagamento { get; set; }
        [DataMember]
        public DateTime dataRegistroPagamento { get; set; }
        [DataMember]
        public string tipoPagamento { get; set; }
        [DataMember]
        public decimal valorPagamento { get; set; }

        public PagamentoReembolso()
        {
            mensagem = new MensagemTransferencia();
        }
    }
}
