﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Contrato
    {
        [DataMember]
        public Produto produto { get; set; }
        [DataMember]
        public Cliente cliente {get; set;}
        [DataMember]
        public Coligada coligada { get; set; }
        [DataMember]
        public IList<ProcessoJudicial> processoAjuizado { get; set; }
        [DataMember]
        public string numeroContrato { get; set; }

        public Contrato() 
        {
            processoAjuizado = new List<ProcessoJudicial>();
            produto = new Produto();
            cliente = new Cliente();
            coligada = new Coligada();
        }
    }
}
