﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Contrato
    {
        [DataMember]
        public Produto produto { get; set; }

        [DataMember]
        public Cliente cliente {get; set;}

        [DataMember]
        public Coligada coligada { get; set; }

        [DataMember]
        public IList<ProcessoJudicial> processoAjuizado { get; set; }

        [DataMember]
        public string numeroContrato { get; set; }

        [DataMember]
        public string convenio { get; set; }

        [DataMember]
        public StatusContratoType statusContrato { get; set; }

        [DataMember]
        public DateTime? dataStatus { get; set; }

        [DataMember]
        public HistoricoFinanceiro historicoFinanceiro { get; set; }

        public Contrato() 
        {
            processoAjuizado = new List<ProcessoJudicial>();
            produto = new Produto();
            cliente = new Cliente();
            coligada = new Coligada();
            historicoFinanceiro = new HistoricoFinanceiro();
        }
    }
}
