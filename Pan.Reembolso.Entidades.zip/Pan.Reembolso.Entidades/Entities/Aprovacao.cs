﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades
{
    [DataContract]
    public class Aprovacao
    {
        public Aprovacao()
        {
            pagamentos = new List<PagamentoAAprovar>();
            historicoPagamentos = new HistoricoPagamentos();
        }
        [DataMember]
        public List<PagamentoAAprovar> pagamentos { get; set; }
        [DataMember]
        public HistoricoPagamentos historicoPagamentos { get; set; }

        public class PagamentoAAprovar
        {
        [DataMember]
        public string numeroCpfCnpj { get; set; }
        [DataMember]
        public string nomeCliente { get; set; }
        [DataMember]
        public decimal valor { get; set; }
        [DataMember]
        public List<long> ids { get; set; }
        }

        public class HistoricoPagamentos
        {
            [DataMember]
            public HistoricoValor historico60 { get; set; }
            [DataMember]
            public HistoricoValor historico30 { get; set; }
            [DataMember]
            public HistoricoValor historico10 { get; set; }
        }

        public class HistoricoValor
        {
            public decimal total { get; set; }
            public decimal media { get; set; }
        }
    }
    
}
