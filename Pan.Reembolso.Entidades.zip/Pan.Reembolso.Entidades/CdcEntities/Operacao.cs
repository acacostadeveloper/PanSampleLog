﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.CdcEntities
{

    public class Operacao
    {
        public string contrato { get; set; }
        public string operacao { get; set; }
        public string formaLiquidacao { get; set; }
        public string origem { get; set; }
        public string codigoProduto { get; set; }
        public float valorQuitacao { get; set; }
        public int diasAtraso { get; set; }
        public string statusDaOperacao { get; set; }
        public Cliente cliente { get; set; }
        public object[] acordos { get; set; }
        public object cobradora { get; set; }
        public Garantia[] garantias { get; set; }
        public Empresa empresa { get; set; }
        public Ocorrencia[] ocorrencias { get; set; }
        public Parcela[] parcelas { get; set; }
        public object[] parcelasAtrasadas { get; set; }
        public bool habRenegocie { get; set; }
    }

    public class Cliente
    {
        public string codigo { get; set; }
        public string nome { get; set; }
        public string firstName { get; set; }
        public string pessoaTipo { get; set; }
        public long documento { get; set; }
        public string nacionalidade { get; set; }
        public string naturalidadeUF { get; set; }
        public string naturalidade { get; set; }
        public string numeroDocumento { get; set; }
        public string rg { get; set; }
        public string rgEmissor { get; set; }
        public DateTime rgData { get; set; }
        public string rguf { get; set; }
        public string sexo { get; set; }
        public string estadoCivil { get; set; }
        public string nomeMae { get; set; }
        public string nomePai { get; set; }
        public int dependentes { get; set; }
        public bool emancipado { get; set; }
        public string tipoResidencia { get; set; }
        public DateTime nascimento { get; set; }
        public Endereco endereco { get; set; }
        public IList<Telefone> telefones { get; set; }
        public string email { get; set; }
        public string nomeRecado { get; set; }
        public DateTime atualizacao { get; set; }
        public string tipoSistema { get; set; }
        public int renda { get; set; }
        public Correspondencia correspondencia { get; set; }
        public object contratos { get; set; }
    }

    public class Endereco
    {
        public string bairro { get; set; }
        public string cep { get; set; }
        public string cidade { get; set; }
        public string complemento { get; set; }
        public string enderecoCompleto { get; set; }
        public string logradouro { get; set; }
        public string numero { get; set; }
        public string uf { get; set; }
        public string tipo { get; set; }
    }

    public class Correspondencia
    {
        public string bairro { get; set; }
        public string cep { get; set; }
        public string cidade { get; set; }
        public string complemento { get; set; }
        public string enderecoCompleto { get; set; }
        public string logradouro { get; set; }
        public string numero { get; set; }
        public string uf { get; set; }
        public string tipo { get; set; }
    }

    public class Telefone
    {
        public string ddd { get; set; }
        public int numero { get; set; }
        public string tipo { get; set; }
    }

    public class Empresa
    {
        public string codigo { get; set; }
        public Atributos atributos { get; set; }
        public int documento { get; set; }
        public Endereco1 endereco { get; set; }
        public string nome { get; set; }
        public string razaoSocial { get; set; }
    }

    public class Atributos
    {
        public string códigonaorigem { get; set; }
    }

    public class Endereco1
    {
        public string bairro { get; set; }
        public string cep { get; set; }
        public string cidade { get; set; }
        public string complemento { get; set; }
        public string enderecoCompleto { get; set; }
        public string logradouro { get; set; }
        public string numero { get; set; }
        public string uf { get; set; }
        public string tipo { get; set; }
    }

    public class Garantia
    {
        public Veiculo veiculo { get; set; }
    }

    public class Veiculo
    {
        public bool alienacao { get; set; }
        public bool apreensao { get; set; }
        public object apreensaoMotivo { get; set; }
        public object apreensaoTipo { get; set; }
        public bool assistencia { get; set; }
        public object bloqueiaIL_Flag { get; set; }
        public object categoria { get; set; }
        public string chassi { get; set; }
        public bool chassiRemarcado { get; set; }
        public int codigo { get; set; }
        public int codigoTipoVeiculo { get; set; }
        public object combustivel { get; set; }
        public string cor { get; set; }
        public DateTime dataAlienacao { get; set; }
        public DateTime dataGeracaoAlienacao { get; set; }
        public DateTime dataInclusaoDUT { get; set; }
        public DateTime dataRegAssist { get; set; }
        public object envioAssistencia_Flag { get; set; }
        public int fabricacaoAno { get; set; }
        public int numeroGravame { get; set; }
        public string marca { get; set; }
        public string modelo { get; set; }
        public int modeloAno { get; set; }
        public string placa_Codigo { get; set; }
        public object placa_UF { get; set; }
        public object registroContrato_Flag { get; set; }
        public int renavam { get; set; }
        public int valorNotaFiscal { get; set; }
        public bool veiculoZero { get; set; }
        public object certificadoAtu { get; set; }
        public DateTime dataCertificadoAtu { get; set; }
        public DateTime dataInclusao { get; set; }
        public Gravame gravame { get; set; }
    }

    public class Gravame
    {
        public int codigoGravame { get; set; }
        public object criticaCetip { get; set; }
        public int statusRegistroCetip { get; set; }
        public DateTime dataRegistro { get; set; }
    }

    public class Ocorrencia
    {
        public object descricaoCodigo { get; set; }
        public object acao { get; set; }
        public bool ativo { get; set; }
        public int codigo { get; set; }
        public object codigoAcao { get; set; }
        public DateTime dataInclusao { get; set; }
        public DateTime dataParcela { get; set; }
        public DateTime dataValidade { get; set; }
        public string nome { get; set; }
    }

    public class Parcela
    {
        public bool cedida { get; set; }
        public object cessaoBanco { get; set; }
        public int cessaoCodigo { get; set; }
        public bool cessaoCoobrigacao { get; set; }
        public DateTime cessaoData { get; set; }
        public object cpPeriodicidade { get; set; }
        public int cpTaxa { get; set; }
        public object cpTipo { get; set; }
        public DateTime dataCalculo { get; set; }
        public DateTime dataPagamento { get; set; }
        public DateTime dataVencimento { get; set; }
        public int descontos { get; set; }
        public int despesas { get; set; }
        public int diasAdiantamento { get; set; }
        public string status { get; set; }
        public int diasAtraso { get; set; }
        public int encargosMoratorios { get; set; }
        public bool estorno { get; set; }
        public string formaLiquidacao { get; set; }
        public bool liquidado { get; set; }
        public object moraPeriodicidade { get; set; }
        public int moraTaxa { get; set; }
        public object moraTipo { get; set; }
        public object multaBase { get; set; }
        public int multaTaxa { get; set; }
        public int numeroParcela { get; set; }
        public bool renegociado { get; set; }
        public int saldoAcumulado { get; set; }
        public int saldoPagar { get; set; }
        public float valor { get; set; }
        public float valorAcrescimos { get; set; }
        public float valorAtual { get; set; }
        public int valorComissao { get; set; }
        public int valorCP { get; set; }
        public int valorCurva { get; set; }
        public int valorDescontoCP { get; set; }
        public int valorDescontoMora { get; set; }
        public int valorDescontoMulta { get; set; }
        public int valorDescontoParcela { get; set; }
        public float valorDescontos { get; set; }
        public int valorHonorarios { get; set; }
        public int valorJuros { get; set; }
        public int valorMora { get; set; }
        public int valorMulta { get; set; }
        public int valorPrincipal { get; set; }
        public float valorRecebido { get; set; }
        public int valorPagamentoParcial { get; set; }
        public int valorVRG { get; set; }
        public string linhaDigitavel { get; set; }
        public bool pagamentoParcial { get; set; }
        public int controle { get; set; }
        public string tipoMovimentacao { get; set; }
        public bool saldoDeParcela { get; set; }
        public int plano { get; set; }
    }
}
