﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[MENSAGEM_COMUNICACAO]")]
    [Serializable]
    public class MensagemComunicacaoDatabase
    {
        [Key]
        public int idMensagemComunicacao { get; set; }
        public string descricaoMensagemComunicacao { get; set; }
        public string tipoMensagemComunicacao { get; set; }
        public DateTime dataInclusao { get; set; }
    }
}
