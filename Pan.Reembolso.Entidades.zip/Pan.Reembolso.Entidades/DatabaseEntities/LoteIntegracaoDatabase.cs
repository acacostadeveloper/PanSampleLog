﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[LOTE_INTEGRACAO]")]
    [Serializable]
    public class LoteIntegracaoDatabase 
    {
        [Key]
        public int idLoteIntegracao { get; set; }
        public DateTime dtInclusao { get; set; }
    }
}
