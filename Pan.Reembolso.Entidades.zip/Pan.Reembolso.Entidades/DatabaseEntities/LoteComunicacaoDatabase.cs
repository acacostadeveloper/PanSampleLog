﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[LOTE_COMUNICACAO]")]
    [Serializable]
    public class LoteComunicacaoDatabase 
    {
        [Key]
        public int idLoteComunicacao { get; set; }
        public DateTime dtInclusao { get; set; }
    }
}
