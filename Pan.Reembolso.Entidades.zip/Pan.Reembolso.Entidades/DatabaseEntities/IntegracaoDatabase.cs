﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[REEMBOLSO_INTEGRACAO]")]
    [Serializable]
    public class IntegracaoDatabase
    {
        [Key]
        public int idIntegracao { get; set; }
        public long idReembolso { get; set; }
        public string idLote { get; set; }
        public string cdLoteIntegracao { get; set; }
        public string cliente { get; set; }
        public string contrato { get; set; }
        public decimal valorReembolso { get; set; }
        public string convenio { get; set; }
        public string matricula { get; set; }
        public string cpfCnpj { get; set; }
        public int mesCompetencia { get; set; }
        public int anoCompetencia { get; set; }
        public string sigla { get; set; }
        public string processoEntrada { get; set; }
        public string produto { get; set; }
        public string status { get; set; }
        public string mensagemErro { get; set; }
        public string usuarioInclusao { get; set; }
        public DateTime dataInclusao { get; set; }
        public DateTime dataIntegracao { get; set; }
    }
}
