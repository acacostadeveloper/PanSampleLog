﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[HISTORICO_REEMBOLSO]")]
    [Serializable]    
    public class HistoricoReembolsoDatabase
    {
        [Key]
        public int idHistoricoReembolso {get; set;}
        public long idReembolso { get; set; }
        public int idEvento {get; set;}
        public DateTime dataEvento { get; set; }
        public string statusIni {get; set;}
        public string statusFim { get; set; }
        public string usuario {get; set;}
        public string statusContabil { get; set; }
        public string mensagemErro { get; set; }
    }
}
