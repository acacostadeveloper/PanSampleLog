﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTA_REJEICAO]")]
    [Serializable]
    public class ContaRejeicaoDatabase : ContaDatabase
    {
        public string ativo { get; set; }
        public string erro { get; set; }
        public DateTime dataAtualizacao { get; set; }
    }
}
