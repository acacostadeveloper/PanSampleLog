﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTA]")]
    [Serializable]
    public class ContaDatabase
    {
        [Key]
        public int idConta {get; set;}
        public string tipoConta {get; set;}
        public string numeroBanco {get; set;}
        public string numeroAgencia {get; set;}
        public string digitoAgencia {get; set;}
        public string numeroConta {get; set;}
        public string digitoConta { get; set; }
    }
}
