﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[EVENTO]")]
    [Serializable]
    public class EventoDatabase : DominioDatabase
    {
        [Key]
        public int idEvento{ get; set; }
        public string codigoEvento { get; set; }
        public string eventoContabil { get; set; }
        public string fluxo { get; set; }
    }
}
