﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[ENDERECO]")]
    [Serializable]
    public class EnderecoDatabase
    {
        [Key]
        public int idEndereco {get; set;}
        public int idCliente {get; set;}
        public string nomeLogradouro {get; set;}
        public string numeroEndereco {get; set;}
        public string complemento {get; set;}
        public string cep {get; set;}
        public string bairro {get; set;}
        public string cidade {get; set;}
        public string uf {get; set;}
        public DateTime dataAtualizacao {get; set;}
    }
}
