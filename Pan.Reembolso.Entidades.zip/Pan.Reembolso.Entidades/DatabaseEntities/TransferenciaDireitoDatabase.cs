﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[TRANSFERENCIA_DIREITO]")]
    [Serializable]
    public class TransferenciaDireitoDatabase
    {
        [Key]
        public int idTransferenciaDireito { get; set; }
        public int idCliente { get; set; }
        public string numeroCpfCnpj { get; set; }
        public int sequenciaCpfCnpj { get; set; }
        public string tipoPesssoa { get; set; }
        public string nomeTerceiro { get; set; }
        public int idConta { get; set; }
        public DateTime dtInicioVigencia { get; set; }
        public DateTime? dtFimVigencia { get; set; }
        public string indicadorAtivo { get; set; }
        public string usuarioInclusao { get; set; }
        public string documento { get; set; }
    }
}
