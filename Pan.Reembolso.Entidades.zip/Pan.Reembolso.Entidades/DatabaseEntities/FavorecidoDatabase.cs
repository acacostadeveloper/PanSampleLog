﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    public class FavorecidoDatabase
    {
        [Key]
        public int idFavorecido { get; set; }
        public string numeroCpfCnpj { get; set; }
        public int sequenciaCpfCnpj { get; set; }
        public string tipoPesssoa { get; set; }
        public string nome { get; set; }
        public int idConta { get; set; }
    }
}
