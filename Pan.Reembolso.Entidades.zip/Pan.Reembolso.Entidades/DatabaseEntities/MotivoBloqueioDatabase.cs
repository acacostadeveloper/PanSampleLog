﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[MOTIVO_BLOQUEIO]")]
    [Serializable]
    public class MotivoBloqueioDatabase 
    {
        [Key]
        public int idMotivoBloqueio { get; set; }
        public string descricaoMotivoBloqueio { get; set; }
        public DateTime dtInclusao { get; set; }
    }
}
