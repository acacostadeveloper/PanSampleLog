﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTRATO]")]
    [Serializable]
    public class ContratoDatabase
    {
        [Key]
        public int idContrato {get; set;}
        public string codigoContrato {get; set;}
        public int idProduto {get; set;}
        public int idCliente {get; set;}
        public int idColigada {get; set;}
        public string statusContrato { get; set; }
        public DateTime? dataStatus { get; set; }
        public string registroObito { get; set; }
        public string obito { get; set; }
        public int? idHistoricoFinanceiro { get; set; }
    }
}
