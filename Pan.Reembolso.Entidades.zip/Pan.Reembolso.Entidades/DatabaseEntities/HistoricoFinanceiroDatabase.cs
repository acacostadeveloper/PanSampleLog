﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[HISTORICO_FINANCEIRO]")]
    [Serializable]
    public class HistoricoFinanceiroDatabase : DominioDatabase
    {
        [Key]
        public int idHistoricoFinanceiro { get; set; }

        public string motivo { get; set; }

        public string origemInformacao { get; set; }

        public int codigoHistoricoFinanceiro { get; set; }
    }
}
