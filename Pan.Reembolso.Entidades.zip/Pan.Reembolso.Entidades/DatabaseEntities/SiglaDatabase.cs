﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[SIGLA]")]
    [Serializable]
    public class SiglaDatabase : DominioDatabase
    {
        [Key]
        public int idSigla { get; set; }
        public string codigoSigla { get; set; }
        public string descricaoSigla { get; set; }
    }
}
