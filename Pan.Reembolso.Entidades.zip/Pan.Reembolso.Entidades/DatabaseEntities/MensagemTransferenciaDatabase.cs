﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[MENSAGEM]")]
    [Serializable]
    public class MensagemTransferenciaDatabase
    {
        [Key]
        public int idMensagem { get; set; }
        public int idMensagemPadrao { get; set; }
        public int idContaReserva { get; set; }
        public string numeroRequisicao { get; set; }
        public DateTime dataRegistro { get; set; }
        public DateTime? dataLiquidacao { get; set; }
        public string statusMensagem { get; set; }
        public decimal valorTransferencia { get; set; }
        public string numeroOrigem { get; set; }
        public string codigoEventoTesouraria { get; set; }
        public string nomeFavorecido { get; set; }
        public string tipoPessoaFavorecido { get; set; }
        public string numeroCpfCnpjFavorecido { get; set; }
        public int numeroSequenciaFavorecido { get; set; }
        public string tipoContaFavorecido { get; set; }
        public string numeroBancoFavorecido { get; set; }
        public string numeroAgenciaFavorecido { get; set; }
        public string digitoAgenciaFavorecido { get; set; }
        public string numeroContaFavorecido { get; set; }
        public string digitoContaFavorecido { get; set; }

    }
}
