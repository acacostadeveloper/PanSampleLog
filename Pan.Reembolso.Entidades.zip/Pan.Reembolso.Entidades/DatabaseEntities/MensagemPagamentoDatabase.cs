﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[MENSAGEM_PAGAMENTO]")]
    [Serializable]
    public class MensagemPagamentoDatabase
    {
        [Key]
        public int idMensagem { get; set; }
        [Key]
        public int idPagamento { get; set; }
    }
}
