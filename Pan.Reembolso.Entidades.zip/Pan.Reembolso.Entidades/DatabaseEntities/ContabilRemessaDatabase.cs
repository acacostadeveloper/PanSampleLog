﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTABIL_REMESSA]")]
    [Serializable]
    public class ContabilRemessaDatabase
    {
        [Key]
        public int idRemessa { get; set; }
        public DateTime dataRemessa { get; set; }
    }
}
