﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[SISTEMA]")]
    [Serializable]
    public class SistemaDatabase
    {
        [Key]
        public int idSistema {get; set;}
        public string descricaoSistema {get; set;}
        public DateTime dataInclusao {get; set;}
        public DateTime dataAlteracao {get; set;}
        public string indicadorAtivo {get; set;}
    }
}
