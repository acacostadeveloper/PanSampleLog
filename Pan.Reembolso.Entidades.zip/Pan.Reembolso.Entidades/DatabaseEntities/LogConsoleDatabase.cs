﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[dbo].[LogsReembolsoConsoleApp]")]
    [Serializable]
    public class LogConsoleDatabase
    {
        [Key]
        public int LogId { get; set; }
        public string Application { get; set; }
        public string BatchTask { get; set; }
        public string Machine { get; set; }
        public string IpAddress { get; set; }
        public DateTime? Timestamp { get; set; }
        public string TextLog { get; set; }
        public string MessageError { get; set; }
    }
}
