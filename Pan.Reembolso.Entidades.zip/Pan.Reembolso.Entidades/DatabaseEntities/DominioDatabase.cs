﻿using System;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Serializable]
    public class DominioDatabase
    {
        public DateTime dataInclusao { get; set; }
        public DateTime dataAlteracao { get; set; }
        public string indicadorAtivo { get; set; }
    }
}
