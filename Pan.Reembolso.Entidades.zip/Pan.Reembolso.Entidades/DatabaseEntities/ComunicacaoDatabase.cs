﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[COMUNICACAO]")]
    [Serializable]
    public class ComunicacaoDatabase
    {
        [Key]
        public int idComunicacao { get; set; }
        public int idMensagemComunicacao { get; set; }
        public DateTime dataEnvio { get; set; }
        public string indicadorEfetivacao { get; set; }
        public string protocolo { get; set; }
        public int idLote { get; set; }
        public string descricaoErro { get; set; }
    }
}
