﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[PRODUTO]")]
    [Serializable]
    public class ProdutoDatabase
    {
        [Key]
        public int idProduto {get; set;}
        public string codigoProduto {get; set;}
        public string nomeProduto {get; set;}
        public string codigoCarteira {get; set;}
        public int idSistema {get; set;}
        public DateTime dataInclusao {get; set;}
        public DateTime? dataAlteracao {get; set;}
        public string indicadorAtivo {get; set;}
    }
}
