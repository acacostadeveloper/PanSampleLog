﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[PROCESSO_JUDICIAL]")]
    [Serializable]
    public class ProcessoJudicialDatabase
    {
        [Key]
        public int idProcesso {get; set;}
        public int idContrato {get; set;}
        public int idProcessoOrigem {get; set;}
        public string tituloProcesso {get; set;}
    }
}
