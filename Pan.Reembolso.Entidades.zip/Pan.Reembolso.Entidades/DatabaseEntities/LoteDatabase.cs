﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{

    [Table("[gestao_reembolso].[LOTE_REEMBOLSO]")]
    [Serializable]
    public class LoteDatabase : DominioDatabase
    {
        [Key]
        public int idLote { get; set; }
        public string lote { get; set; }
    }
}
