﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Serializable]
    public class LogDatabase
    {
        [Key]
        public Guid LogId { get; set; }
        public string Application { get; set; }
        public string User { get; set; }
        public string Machine { get; set; }
        public string RequestIpAddress { get; set; }
        public dynamic RequestContentBody { get; set; }
        public string RequestUri { get; set; }
        public string RequestMethod { get; set; }
        public int? ResponseStatusCode { get; set; }
        public IDictionary<string, string> RequestHeaders { get; set; }
        public IDictionary<string, string> ResponseHeaders { get; set; }
        public dynamic ResponseContentBody { get; set; }
        public DateTime? RequestTimestamp { get; set; }
        public DateTime? ResponseTimestamp { get; set; }
    }
}
