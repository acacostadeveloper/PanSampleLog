﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[dbo].[LogsReembolsoWebAPI]")]
    [Serializable]
    public class LogDatabase
    {
        [Key]
        public int LogId { get; set; }
        public string Application { get; set; }
        public Guid CorrelationId { get; set; }
        public string Machine { get; set; }
        public string IpAddress { get; set; }
        public string RequestUri { get; set; }
        public int? StatusCode { get; set; }
        public DateTime? RequestTimestamp { get; set; }
        public DateTime? ResponseTimestamp { get; set; }
        public int? TotalTime { get; set; }
        public string JsonLog { get; set; }
        public string MessageError { get; set; }
    }
}
