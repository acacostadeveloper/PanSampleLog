﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[PROCESSO_REGISTRO]")]
    [Serializable]
    public class ProcessoRegistroDatabase : DominioDatabase
    {
        [Key]
        public int idProcessoRegistro {get; set;}
        public int codigoProcessoRegistro { get; set; }
        public string descricaoProcesso {get; set;}
        public string codigoCentroCusto {get; set;}
        public string modeloContabil {get; set;}
        public string indicadorFluxo { get; set; }
        public string codigoContaDebito { get; set; }
        public string codigoContaCredito { get; set; }
    }
}
