﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTA_RESERVA]")]
    [Serializable]
    public class ContaReservaDatabase
    {
        [Key]
        public int idConta {get; set;}
        public string cnpjSacado {get; set;}
        public string sequenciaCnpjSacado {get; set;}
        public string nomeSacado {get; set;}
        public string tipoPessoaSacado {get; set;}
    }
}
