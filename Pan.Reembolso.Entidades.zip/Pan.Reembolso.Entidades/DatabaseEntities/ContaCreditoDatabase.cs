﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTA_CREDITO]")]
    [Serializable]
    public class ContaCreditoDatabase
    {
        [Key]
        public int idConta {get; set;}
        public int idCliente {get; set;}
        public DateTime dataAtualizacao {get; set;}
    }
}
