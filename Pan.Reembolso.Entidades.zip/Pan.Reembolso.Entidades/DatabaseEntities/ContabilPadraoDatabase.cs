﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTABIL_PADRAO]")]
    [Serializable]
    public class ContabilPadraoDatabase
    {
        //ID_CONTABIL_PADRAO
        [Key]
        public int idContabilPadrao { get; set; }
        //ID_PRODUTO
        public int idProduto { get; set; }
        //CD_PROCESSO
        public string codigoProcesso { get; set; }
        //CD_LAYOUT
        public string codigoLayout { get; set; }
        //CD_COLIGADA
        public string codigoColigada { get; set; }
        //CD_SISTEMA
        public string codigoSistema { get; set; }
        //NO_SEQUENCIA_ORIGEM
        public string numeroSequenciaOrigem { get; set; }
        //CD_EMPRESA_ORIGEM
        public string codigoEmpresaOrigem { get; set; }
        //CD_AGENCIA
        public string codigoAgencia { get; set; }
        //CD_UNIDADE
        public string codigoUnidade { get; set; }
        //CD_NIVEL1
        public string codigoNivel1 { get; set; }
        //CD_NIVEL2
        public string codigoNivel2 { get; set; }
        //CD_NIVEL3
        public string codigoNivel3 { get; set; }
        //CD_NIVEL4
        public string codigoNivel4 { get; set; }
        //CD_DEBITA_CREDITA
        public string codigoCreditaDebita { get; set; }
        //CD_AGENCIA_DESTINO
        public string codigoAgenciaDestino { get; set; }
        //CD_NIVEL1_DESTINO
        public string codigoNivel1Destino { get; set; }
        //CD_NIVEL2_DESTINO
        public string codigoNivel2Destino { get; set; }
        //CD_NIVEL3_DESTINO
        public string codigoNivel3Destino { get; set; }
        //CD_NIVEL4_DESTINO
        public string codigoNivel4Destino { get; set; }
        //CD_UNIDADE_DESTINO
        public string codigoUnidadeDestino { get; set; }
        //DS_COMPLEMENTO2
        public string descricaoComplemento2 { get; set; }
        //DS_COMPLEMENTO3
        public string descricaoComplemento3 { get; set; }
        //DS_COMPLEMENTO4
        public string descricaoComplemento4 { get; set; }
        //DS_COMPLEMENTO5
        public string descricaoComplemento5 { get; set; }
        //CD_FORMA_LANCAMENTO
        public string codigoFormaLancamento { get; set; }
        //CD_TIPO_LANCAMENTO
        public string codigoTipoLancamento { get; set; }
        //CD_EVENTO
        public string codigoEvento { get; set; }
        //NO_SEQUENCIA_ITEM
        public string numeroSequenciaItem { get; set; }
        //NM_TABELA_DEBITO
        public string nomeTabelaDebito { get; set; }
        //CD_PRODUTO_DEBITO
        public string codigoProdutoDebito { get; set; }
        //CD_TIPO_CREDITO_DEBITO
        public string codigoTipoCreditoDebito { get; set; }
        //CD_ATIVIDADE_DEBITO
        public string codigoAtividadeDebito { get; set; }
        //CD_TIPO_CONTA_DEBITO
        public string codigoTipoContaDebito { get; set; }
        //NO_CONTA_DEBITO
        public string numeroContaDebito { get; set; }
        //CD_REDUZIDO_DEBITO
        public string codigoReduzidoDebito { get; set; }
        //NO_CONTA_AUXILIAR_DEBITO
        public string numeroContaAuxiliarDebito { get; set; }
        //NO_CONTA_CORRENTE_DEBITO
        public string numeroContaCorrenteDebito { get; set; }
        //NM_TABELA_CREDITO
        public string nomeTabelaCredito { get; set; }
        //CD_PRODUTO_CREDITO
        public string codigoProdutoCredito { get; set; }
        //CD_TIPO_CREDITO_CREDITO
        public string codigoTipoCreditoCredito { get; set; }
        //CD_ATIVIDADE_CREDITO
        public string codigoAtividadeCredito { get; set; }
        //CD_TIPO_CONTA_CREDITO
        public string codigoTipoContaCredito { get; set; }
        //NO_CONTA_CREDITO
        public string numeroContaCredito { get; set; }
        //CD_REDUZIDO_CREDITO
        public string codigoReduzidoCredito { get; set; }
        //NO_CONTA_AUXILIAR_CREDITO
        public string numeroContaAuxiliarCredito { get; set; }
        //NO_CONTA_CORRENTE_CREDITO
        public string numeroContaCorrenteCredito { get; set; }
        //CD_TIPO_MOEDA
        public string codigoTipoMoeda { get; set; }
        //QT_MOEDA
        public string quantidadeMoeda { get; set; }
        //VL_MOEDA
        public string valorMoeda { get; set; }
        //IC_REPROCESSAMENTO
        public string indicadorReprocessamento { get; set; }
        //CD_GERENTE
        public string codigoGerente { get; set; }
        //NO_DOCUMENTO
        public string numeroDocumento { get; set; }
        //IC_ATUALIZADO
        public string indicadorAtualizado { get; set; }
        //IC_CANCELADO
        public string indicadorCancelado { get; set; }
        //IC_ESTORNADO
        public string indicadorEstornado { get; set; }
        //DT_INCLUSAO
        public DateTime dataInclusao { get; set; }
    }
}
