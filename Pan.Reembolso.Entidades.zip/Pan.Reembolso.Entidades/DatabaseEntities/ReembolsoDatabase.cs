﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[REEMBOLSO]")]
    [Serializable]    
    public class ReembolsoDatabase
    {
        [Key]
        public long idReembolso {get; set;}
        public int idLote { get; set; }
        public string codigoUsuarioInclusao {get; set;}
        public string codigoUsuarioAlteracao {get; set;}
        public string codigoUsuarioAprovacao { get; set; }
        public int idDepartamento {get; set;}
        public int idContrato {get; set;}
        public int idSigla { get; set; }
        public int mesCompetencia { get; set; }
        public int anoCompetencia { get; set; }
        public int idProcessoRegistro { get; set; }
        public int? idMotivoBloqueio { get; set; }
        public DateTime dataSolicitacao {get; set;}
        public string statusReembolso {get; set;}
        public string statusUsuario { get; set; }
        public decimal valorReembolso {get; set;}
        public DateTime? dtInclusao { get; set; }
        public string mensagemErro { get; set; }
        public string tipoPagamentoLegado { get; set; }
        public string indicadorTombado { get; set; }
    }
}
