﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[MENSAGEM_PADRAO]")]
    [Serializable]
    public class MensagemPadraoDatabase
    {
        [Key]
        public int idMensagemPadrao {get; set;}
        public int idProduto {get; set;}
        public string finalidadeSPB {get; set;}
        public string indicadorCreditaContaCorrente {get; set;}
        public string indicadorDebitaContaCorrente {get; set;}
        public string indicadorEmiteRecebe {get; set;}
        public string indicadorMesmaTitularidade {get; set;}
        public string indicadorPrevisao {get; set;}
        public string indicadorTransitaContaCorrente {get; set;}
        public string numeroBordero {get; set;}
        public string tipoLiquidacao {get; set;}
        public DateTime dataInclusao {get; set;}
        public string codigoFinalidade { get; set; }
        public string codigoEventoTesouraria { get; set; }
        public string codigoUsuarioCadastro { get; set; }
    }
}
