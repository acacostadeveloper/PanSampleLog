﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[CONTA_ERRO]")]
    [Serializable]
    public class ContaErroDatabase
    {
        [Key]
        public int idConta {get; set;}
        public DateTime dataAtualizacao {get; set;}
        public string  ErroConta { get; set; }
    }
}
