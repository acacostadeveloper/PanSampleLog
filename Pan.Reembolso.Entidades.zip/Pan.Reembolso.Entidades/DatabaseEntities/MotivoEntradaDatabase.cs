﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[MOTIVO_ENTRADA]")]
    [Serializable]
    public class MotivoEntradaDatabase
    {

        [Key]
        public int idMotivoEntrada { get; set; }
        public string descricaoMotivoEntrada { get; set; }
        public string tipoMotivoEntrada { get; set; }
        public int? idSigla { get; set; }
        public DateTime? dtInclusao { get; set; }
        public DateTime? dtAlteracao { get; set; }
        public string indicadorAtivo { get; set; }

    }
}
