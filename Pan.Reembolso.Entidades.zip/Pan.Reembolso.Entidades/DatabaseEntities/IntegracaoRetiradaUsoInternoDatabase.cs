﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Entidades.DatabaseEntities
{
    [Table("[gestao_reembolso].[INTEGRACAO_RETIRADA_USO_INTERNO]")]
    [Serializable]
    public class IntegracaoRetiradaUsoInternoDatabase
    {
        [Key]
        public int idIntegracao { get; set; }
        public string numeroCpfCnpj { get; set; }
        public string codigoProduto { get; set; }
        public decimal valorRetirada { get; set; }
        public long? idPagamento { get; set; }
        public string codigoLoteIntegracao { get; set; }
        public string codigoStatusIntegracao { get; set; }
        public int codigoProcessoRegistro { get; set; }
        public string mensagemErro { get; set; }
        public string usuarioInclusao { get; set; }
        public DateTime dataInclusao { get; set; }
    }
}
