﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoTypes
    {
        public enum StatusReembolsoType
        {
            Solicitado = 0,
            RejeitadoContratoInexistente = 1,
            RejeitadoClienteInexistente = 2,
            Cancelado = 3
        }

        public enum StatusContratoType
        {
            Aberto = 0,
            Liquidado = 1,
            Estornado = 2
        }

        public enum StatusIntegracao
        {
            Pendente = 0,
            Integrado = 1,
            Erro = 1,
            Cancelado = 2
        }

    }
}
