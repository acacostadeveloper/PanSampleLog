﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoTypes
    {
        public enum StatusReembolsoType
        {
            //AReembolsar encapsula Registrado, Bloqueado mas não inclui PagamentoLiberado
            Undefined = -1,
            Cancelado = 0,
            Registrado = 1,
            Bloqueado = 2,
            PagamentoLiberado = 3,
            Reembolsado = 4,
            Rejeitado = 5,
            EmTransito = 6
        }

        public enum StatusContratoType
        {
            Aberto = 0,
            Liquidado = 1,
            Estornado = 2,
            NaoIntegrado = 3
        }

        public enum StatusIntegracaoType
        {
            Pendente = 0,
            Integrado = 1,
            Erro = 2,
            Cancelado = 3
        }

        public enum StatusPagamentoType
        {
            Aprovado = 0,
            EnviadoPagamento = 1,
            Reembolsado = 2
        }

        public enum StatusMensagemTransferenciaType
        {
            Integrado = 0
        }


        public enum PagamentoType
        {
            TED = 0
        }

        public enum ErroContaCreditoType
        {
            Undefined = -1,
            Fraude = 0,
            DadosInvalidos = 1
        }
    }
}
