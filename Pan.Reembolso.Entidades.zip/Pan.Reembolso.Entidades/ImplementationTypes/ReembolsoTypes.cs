﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoTypes
    {
        public enum StatusReembolsoType
        {
            //AReembolsar encapsula Registrado, Bloqueado mas não inclui PagamentoLiberado
            Undefined = -1,
            Rejeitado = 0,
            Cancelado = 1,

            // UserStatus = AReembolsar
            Registrado = 2,
            Bloqueado = 3,

            // UserStatus = PagamentoLiberado
            PagamentoLiberado = 4,
            EmTransito = 5,

            // UserStatus = Reembolsado
            Reembolsado = 6,
            RetiradaUsoInterno = 7
        }

        public enum StatusReembolsoUserType
        {
            Undefined = -1,
            Cancelado = 1,
            AReembolsar = 3,            // Registrado ; Bloqueado
            PagamentoLiberado = 5,      // PagamentoLiberado ; EmTransito
            Reembolsado = 6,             // Reembolsado ; RetiradaUsoInterno
            RetiradaUsoInterno = 7
        }


        public enum StatusContratoType
        {
            Undefined = -1,
            Aberto = 0,
            Liquidado = 1,
            Estornado = 2,
            NaoIntegrado = 3,
            ContratoNaoEncontrado = 4,
            ClienteNaoEncontrado = 5,
            DadosBancariosAusentes = 6

        }

        public enum StatusIntegracaoType
        {
            Undefined = -1,
            Pendente = 0,
            Integrado = 1,
            Erro = 2,
            Cancelado = 3
        }

        public enum StatusPagamentoType
        {
            Aprovado = 0,
            EnviadoPagamento = 1,
            Pago = 2,
            Recusado = 3,
            Devolvido = 4,
            Efetivado = 5
        }

        public enum StatusMensagemTransferenciaType
        {
            Integrada = 0,
            ErroIntegracao = 1,
            Efetivada = 2,
            Devolvida = 3
        }

        public enum MotivoBloqueioType
        {
            Undefined = -1,
            RegistroObito = 1,
            DadosBancariosAusente = 2,
            ContaFraudada = 3,
            PagamentoDevolvido = 4,
            PagamentoErroIntegracao = 5,
            FalhaManutencaoDadosBancarios = 6,
            PagamentoRecusadoTesouraria = 7,
            AprovacaoPagamentoRejeitada = 8

        }

        public enum PagamentoType
        {
            Undefined = -1,
            UsoInterno = 0,
            TED = 1
        }

        public enum ErroContaCreditoType
        {
            Undefined = -1,
            Fraude = 0,
            DadosInvalidos = 1
        }

        public enum ComunicacaoType
        {
            Undefined = -1,
            SMS = 0,
            CARTA_AR = 1
        }

        public enum StatusComunicacaoType
        {
            Undefined = -1,
            Enviado = 0,
            Efetivado = 1,
            Erro = 2
        }

        public enum StatusRespostaSMS
        {
            MensagemNaoEncontrada = 998,
            StatusInelegivel = 999,
            MensagemPendenteEnvioParaBroker = 997,
            FinalizadoSucesso = 12,
            CelularConfirmouRecebimento = 3,
            CelularNaoPertenceNenhumaOperadora = 5,
            MensagemRejeitadaCelularBlacklist = 6,
            MensagemRejeitadaExcessivasRepetições = 7,
            MensagemRejeitadaPelaOperadoraAntesTransmicao = 8,
            MensagemExpiradaSemInformacaoOperadora = 9,
            MensagemExpiradaConformeInformacaoOperadora = 10,
            MensagemRejeitadaFaltaCreditoOuContaBloqueada = 11,
            ErroProcessamento = 4,
            MensagemRecebidaFilaParaEnvioAOperadora = 1,
            MensagemEnviadaAOperadora = 2
        }

        public static StatusReembolsoUserType ObterStatusUsuario(string status)
        {
            StatusReembolsoType statusReembolso = (StatusReembolsoType)Enum.Parse(typeof(StatusReembolsoType), status);
            return ObterStatusUsuario(statusReembolso);
        }
        public static StatusReembolsoUserType ObterStatusUsuario(StatusReembolsoType statusReembolso)
        {
            StatusReembolsoUserType result = StatusReembolsoUserType.Undefined;

            switch (statusReembolso)
            {
                case StatusReembolsoType.Undefined:
                    result = StatusReembolsoUserType.Undefined;
                    break;

                case StatusReembolsoType.Rejeitado:
                case StatusReembolsoType.Cancelado:
                    result = StatusReembolsoUserType.Cancelado;
                    break;

                case StatusReembolsoType.Registrado:
                case StatusReembolsoType.Bloqueado:
                    result = StatusReembolsoUserType.AReembolsar;
                    break;

                case StatusReembolsoType.PagamentoLiberado:
                case StatusReembolsoType.EmTransito:
                    result = StatusReembolsoUserType.PagamentoLiberado;
                    break;

                case StatusReembolsoType.Reembolsado:
                    result = StatusReembolsoUserType.Reembolsado;
                    break;

                case StatusReembolsoType.RetiradaUsoInterno:
                    result = StatusReembolsoUserType.RetiradaUsoInterno;
                    break;
            }

            return result;
        }

        public static StatusComunicacaoType ObterStatusRespostaSMS(int status)
        {
            StatusRespostaSMS statusOut =  (StatusRespostaSMS)status;
            return ObterStatusRespostaSMS(statusOut);
        }
        public static StatusComunicacaoType ObterStatusRespostaSMS(StatusRespostaSMS status)
        {
            switch (status)
            {
                case StatusRespostaSMS.MensagemNaoEncontrada:
                case StatusRespostaSMS.StatusInelegivel:
                case StatusRespostaSMS.CelularNaoPertenceNenhumaOperadora:
                case StatusRespostaSMS.MensagemRejeitadaCelularBlacklist:
                case StatusRespostaSMS.MensagemRejeitadaExcessivasRepetições:
                case StatusRespostaSMS.MensagemRejeitadaPelaOperadoraAntesTransmicao:
                case StatusRespostaSMS.MensagemExpiradaSemInformacaoOperadora:
                case StatusRespostaSMS.MensagemExpiradaConformeInformacaoOperadora:
                case StatusRespostaSMS.MensagemRejeitadaFaltaCreditoOuContaBloqueada:
                case StatusRespostaSMS.ErroProcessamento:
                    return StatusComunicacaoType.Erro;
                case StatusRespostaSMS.MensagemPendenteEnvioParaBroker:
                case StatusRespostaSMS.MensagemRecebidaFilaParaEnvioAOperadora:
                case StatusRespostaSMS.MensagemEnviadaAOperadora:
                    return StatusComunicacaoType.Enviado;
                case StatusRespostaSMS.FinalizadoSucesso:
                case StatusRespostaSMS.CelularConfirmouRecebimento:
                    return StatusComunicacaoType.Efetivado;
                default:
                    return StatusComunicacaoType.Undefined;
            }
        }
    }
}
