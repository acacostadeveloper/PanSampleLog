﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoTypes
    {
        public enum StatusReembolsoType
        {
            //AReembolsar encapsula Registrado, Bloqueado mas não inclui PagamentoLiberado
            Undefined = -1,
            Cancelado = 0,
            Registrado = 1,
            Bloqueado = 2,
            PagamentoLiberado = 3,
            Reembolsado = 4,
            Rejeitado = 5,
            EmTransito = 6
        }

        public enum StatusContratoType
        {
            Undefined = -1,
            Aberto = 0,
            Liquidado = 1,
            Estornado = 2,
            NaoIntegrado = 3,
            ContratoNaoEncontrado = 4,
            ClienteNaoEncontrado = 5,
            DadosBancariosAusentes = 6

        }

        public enum StatusIntegracaoType
        {
            Pendente = 0,
            Integrado = 1,
            Erro = 2,
            Cancelado = 3
        }

        public enum StatusPagamentoType
        {
            Aprovado = 0,
            EnviadoPagamento = 1,
            Pago = 2,
            Recusado = 3,
            Devolvido = 4,
            Efetivado = 5
        }

        public enum StatusMensagemTransferenciaType
        {
            Integrada = 0,
            ErroIntegracao = 1,
            Efetivada = 2,
            Devolvida = 3 
        }


        public enum PagamentoType
        {
            Undefined = -1,
            UsoInterno = 0,
            TED = 1
        }

        public enum ErroContaCreditoType
        {
            Undefined = -1,
            Fraude = 0,
            DadosInvalidos = 1
        }
        public enum ComunicacaoType
        {
            Undefined = -1,
            SMS = 0,
            CARTA_AR = 1
        }
        public enum StatusComunicacaoType
        {
            Undefined = -1,
            Enviado = 0,
            Efetivado = 1,
            Erro = 2
        }
    }
}
