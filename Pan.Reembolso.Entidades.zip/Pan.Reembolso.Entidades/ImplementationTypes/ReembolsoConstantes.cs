﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoConstantes
    {
        public const string ID_APLICATION = "Pan.Reembolso.Api";
        public const string COLIGADA = "001";
        public const string DEPARTAMENTO = "0000020";
        public const string CONTRATO_NAO_INTEGRADO = "CTNI";
        public const string CSV_DELIMITER = ";";
        public const string INTEGRACAO_DUPLICADA = "Integracao ja existe na Base";
        public const string TABELA_INTEGRACAO = "gestao_reembolso.REEMBOLSO_INTEGRACAO";
        public const string BANCO_BULK_INSERT = "PanBulkIntegracao";
        public const string ORIGEM_PANCRED = "HF PANCRED";
        public const string FLUXO_ENTRADA = "ENTRADA";
        public const string CONTRATO_INEXISTENTE = "contrato não localizado";
        public const string CLIENTE_INEXISTENTE = "cliente não localizado";
        public const string REGISTRO_OBITO = "registro de óbito";
        public const string DADOS_BANCARIOS_AUSENTES = "dados bancários ausentes";
        public const string CONTA_FRAUDADA = "conta fraudada";
        public const string REEMBOLSO_DUPLICADO = "Reembolso ja se econtra na base";


    }
}