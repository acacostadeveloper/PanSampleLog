﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoConstantes
    {
        public const string ID_APLICATION = "Pan.Reembolso.Api";
    }
}
