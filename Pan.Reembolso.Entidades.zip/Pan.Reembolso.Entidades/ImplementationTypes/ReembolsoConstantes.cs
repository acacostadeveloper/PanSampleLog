﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public static class ReembolsoConstantes
    {
        public const string ID_APLICATION = "Pan.Reembolso.Api";

        public const string CONTRATO_NAO_INTEGRADO = "CTNI";
        public const string CSV_DELIMITER = ";";
        public const string INTEGRACAO_DUPLICADA = "Integracao ja existe na Base";
        public const string TABELA_INTEGRACAO = "gestao_reembolso.REEMBOLSO_INTEGRACAO";
    }
    
}
