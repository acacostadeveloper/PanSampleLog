﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Entidades.ImplementationTypes
{
    public class KeyValueTypes
    {
        public IDictionary<string, string> StatusRequisicaoTesouraria { get; set; }
        public IDictionary<string, ReembolsoTypes.StatusMensagemTransferenciaType> StatusIntegracaoMensagemTransferencia { get; set; }

        public KeyValueTypes()
        {
            StatusRequisicaoTesouraria = new Dictionary<string, string>
            {
                { "A", "A Receber" },
                { "B", "Pendente de 2a.Liberacao" },
                { "C", "Cancelado" },
                { "D", "A autorizar pela diretoria" },
                { "E", "Encerrada / Liquidada" },
                { "F", "Enviada para o eBank em lote -com cc" },
                { "J", "A debitar on line em conjunto" },
                { "K", "Erro no envio ao SPB - conta debitada on line" },
                { "L", "Liberada" },
                { "N", "Enviada para o eBank em lote -sem cc" },
                { "P", "Pendente" },
                { "R", "Recebida pelo SPB" },
                { "S", "Enviada ao SPB" },
                { "V", "Devolvida" }
            };

            StatusIntegracaoMensagemTransferencia = new Dictionary<string, ReembolsoTypes.StatusMensagemTransferenciaType>
            {
                { "A", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "B", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "C", ReembolsoTypes.StatusMensagemTransferenciaType.Devolvida },
                { "D", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "E", ReembolsoTypes.StatusMensagemTransferenciaType.Efetivada },
                { "F", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "J", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "K", ReembolsoTypes.StatusMensagemTransferenciaType.ErroIntegracao },
                { "L", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "N", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "P", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "R", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "S", ReembolsoTypes.StatusMensagemTransferenciaType.Integrada },
                { "V", ReembolsoTypes.StatusMensagemTransferenciaType.Devolvida }
            };
        }
    }
}
