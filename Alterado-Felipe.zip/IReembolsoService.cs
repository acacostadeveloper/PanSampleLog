﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Servico.Interface
{
    public interface IReembolsoService
    {
        Entidades.Reembolso ObterReembolso(long id);
        Entidades.Reembolso ObterReembolsoByIdContrato(string codigoContrato);
        IEnumerable<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        //Entidades.Reembolso ObterDetalhesReembolso(int idReembolso);
        IList<Entidades.Reembolso> IncluirReembolso(IEnumerable<Pan.Reembolso.Entidades.Reembolso> values);
        void ExcluirReembolso(List<long> idsEstornar);
        IEnumerable<HistoricoReembolso> ObterHistoricosReembolso(long idReembolso);
        void AprovarReembolso(List<long> ids, string status, string mensagemErro, string cpfOuCnpj);
        void AlterarStatusReembolso(List<long> ids, string status, string mensagemErro);
        Object ConsultarPagamentosPorStatus(DateTime? dtInicial, DateTime? dtFinal, string statusReembolso);
        Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        List<Object> ConsultarClientesParaManutencaoDadosBancarios();
    }
}
