﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pan.Reembolso.Api.Requests
{
    public class AtualizarReembolsosRequest
    {
        public List<long> ids { get; set; }
        public string status { get; set; }
        public string cpfOuCnpj { get; set; }
        public string mensagemErro { get; set; }
        public string usuario { get; set; }
    }
}