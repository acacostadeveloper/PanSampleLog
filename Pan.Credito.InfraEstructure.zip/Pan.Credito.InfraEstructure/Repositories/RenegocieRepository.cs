﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Runtime.Caching;
using MySql.Data.MySqlClient;
using Pan.Credito.Domain.Repository;

namespace Pan.Credito.Infrastructure.Repositories
{
    public class RenegocieRepository: IRenegocieRepository
    {
        public bool HabilitaRenegocie(string contrato)
        {
            try
            {
                var contratos = GetRenegocieCache();
                return !contratos.Contains(contrato);
            }
            catch
            {
                return false;
            }

        }

        private List<string> GetRenegocieCache()
        {
            var contratos = new List<string>();
            var cache = MemoryCache.Default;

            if (cache.Contains("renegocie_contratos"))
            {
                return (List<string>)cache.Get("renegocie_contratos");
            }
            
            const string query = " SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED ;" +
                                 " SELECT * FROM BlacklistContrato; " +
                                 " SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ ;";
            using (var comand = new MySqlCommand(query, new MySqlConnection(ConfigurationManager.ConnectionStrings["BLACK_LIST"].ConnectionString)) { CommandType = System.Data.CommandType.Text })
            {
               
                    comand.CommandType = System.Data.CommandType.Text;
                    comand.Connection.Open();
                    var reader = comand.ExecuteReader();
                    while (reader.Read())
                    {
                        contratos.Add(reader.GetString(0));
                    }
                    reader.Close();
                
            }
            var cacheItemPolicy = new CacheItemPolicy { AbsoluteExpiration = DateTime.Now.AddHours(12.0) };
            cache.Add("renegocie_contratos", contratos, cacheItemPolicy);
            return contratos;
        }
        public void Dispose()
        {
        }
    }

}