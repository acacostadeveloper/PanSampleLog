﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Pan.Credito.Domain.Entidades.Boletos.AutBank;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Protocolo;
using Pan.Credito.Domain.Repository;
using Pan.Repository.Pattern;

namespace Pan.Credito.Infrastructure.Repositories
{
    public class RcpRepository : IRcpRepository
    {
        private readonly SqlConnection _conn;

        public RcpRepository()
        {
            _conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RCP"].ConnectionString);
        }
        public bool RegistrarEnvioEmail(String p_strEmail, Int32 p_intEmailTipo, Int64 p_intDocumento, Int32 p_intIP4, Boolean p_blnAutorizar)
        {
            Boolean blnAutorizado = false;


            using (SqlConnection scConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["RCP"].ConnectionString))
            {
                try
                {
                    scConnection.Open();

                    using
                    (
                        SqlCommand command = new SqlCommand()
                        {
                            CommandText = "sp_Emails_RegistrarEnvio",
                            CommandType = CommandType.StoredProcedure,
                            Connection = scConnection
                        }
                    )
                    {
                        // Parãmetros de paginação
                        //-------------------------------------------------------------------------------------------------
                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "Email",
                            SqlDbType = SqlDbType.VarChar,
                            Size = 100,
                            Value = p_strEmail
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "EmailTipo",
                            SqlDbType = SqlDbType.Int,
                            Value = p_intEmailTipo
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "Documento",
                            SqlDbType = SqlDbType.BigInt,
                            Value = p_intDocumento
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "IP4",
                            SqlDbType = SqlDbType.Int,
                            Value = p_intIP4
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "Autorizar",
                            SqlDbType = SqlDbType.Bit,
                            Value = p_blnAutorizar
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "LimiteEmails",
                            SqlDbType = SqlDbType.TinyInt,
                            Value = 3 // hard coded a princípio
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "LimiteClientes",
                            SqlDbType = SqlDbType.TinyInt,
                            Value = 3 // hard coded a princípio
                        });

                        command.Parameters.Add(new SqlParameter()
                        {
                            ParameterName = "Autorizado",
                            SqlDbType = SqlDbType.Bit,
                            Direction = ParameterDirection.Output
                        });

                        //-------------------------------------------------------------------------------------------------





                        // Recupera valor de autorização
                        //-------------------------------------------------------------------------------------------------
                        command.ExecuteNonQuery();
                        blnAutorizado = (Boolean)command.Parameters["Autorizado"].Value;
                        //-------------------------------------------------------------------------------------------------


                        scConnection.Close();
                    }


                    return blnAutorizado;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }

        public DUT VerificarTransferenciaDUT(string p_contrato)
        {
            DUT retornoConsulta = new DUT();
            retornoConsulta.DutTransferido = false;
            retornoConsulta.DataReferencia = DateTime.Now.ToString("dd/MM/yyyy");
            try
            {
                using (SqlConnection scConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["RCP"].ConnectionString))
                {
                    using (SqlCommand cmd = scConnection.CreateCommand())
                    {
                        cmd.CommandText = "USP_CONS_SAC_DUT_NAO_TRANSFERIDOS";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("@COD_CONTRATO", p_contrato));
                        scConnection.Open();
                        using (SqlDataReader dr = cmd.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                while (dr.Read())
                                {
                                    retornoConsulta.DutTransferido = Convert.ToBoolean(dr["CONSTA_BASE"]);
                                    retornoConsulta.DataReferencia = Convert.ToDateTime(dr["DATA_REF"]).ToString("dd/MM/yyyy");
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                //Retornar como false que é a situação normal dos documentos 
            }
            return retornoConsulta;
        }

        public long? AddChamadoSpa(SAC_SDC sacSdc)
        {
            var protoloco = _conn.Insert(sacSdc);
            if (protoloco != null)
            {
                sacSdc.NR_ATENDIMENTO = Convert.ToDecimal(protoloco);
                sacSdc.NR_PROTOCOLO = Convert.ToDecimal(protoloco);
            }
            _conn.Update(sacSdc);

            return protoloco ?? 0;
        }
        
        public bool GravaBoleto(AutBank autBank)
        {
            int retorno;
            var comando = new SqlCommand("SP_GRAVABOLETO_RPC", _conn) { CommandType = CommandType.StoredProcedure };
            try
            {
                comando.Parameters.AddWithValue("@CODIGOCLIENTE", autBank.CodCliente);
                comando.Parameters.AddWithValue("@NUMEROCONTAHEADER", autBank.NumContaHeader);
                comando.Parameters.AddWithValue("@NUMEROCARTEIRA", autBank.NumCarteira);
                comando.Parameters.AddWithValue("@NOSSONUMERO", autBank.NossoNumero);
                comando.Parameters.AddWithValue("@CODIGOBANCO", autBank.CodBanco);
                comando.Parameters.AddWithValue("@CODESPECIEDOC", autBank.CodEspecieDoc);
                comando.Parameters.AddWithValue("@VALORNOMINAL", autBank.VlrNominal);
                comando.Parameters.AddWithValue("@VALORABATIMENTO", autBank.VlrAbatimento);
                comando.Parameters.AddWithValue("@DATAEMISSAO", autBank.DataEmissao);
                comando.Parameters.AddWithValue("@DATAVENCIMENTO", autBank.DataVencimento);
                comando.Parameters.AddWithValue("@SEUNUMERO", autBank.SeuNumero);
                comando.Parameters.AddWithValue("@ACEITE", autBank.Aceite);
                comando.Parameters.AddWithValue("@CPFCNPJ", autBank.CNPJCPF);
                comando.Parameters.AddWithValue("@PESSOA", autBank.TipoPessoa);
                comando.Parameters.AddWithValue("@NOME", autBank.Nome);
                comando.Parameters.AddWithValue("@MENSAGEM1", autBank.Mensagem1);
                comando.Parameters.AddWithValue("@MENSAGEM2", autBank.Mensagem2);
                comando.Parameters.AddWithValue("@MENSAGEM3", autBank.Mensagem3);
                comando.Parameters.AddWithValue("@MENSAGEM4", autBank.Mensagem4);
                comando.Parameters.AddWithValue("@MENSAGEM5", autBank.Mensagem5);
                comando.Parameters.AddWithValue("@CODIGOBARRAS", !string.IsNullOrEmpty(autBank.ResponseCip.CodBarras) ? autBank.ResponseCip.CodBarras : string.Empty);
                comando.Parameters.AddWithValue("@LINHADIGITAVEL", !string.IsNullOrEmpty(autBank.ResponseCip.LinhaDigitavel) ? autBank.ResponseCip.LinhaDigitavel : string.Empty);
                comando.Parameters.AddWithValue("@CODIGOTIPOBOLETO", autBank.TipoBoleto);
                comando.Parameters.AddWithValue("@ENDERECO", !string.IsNullOrEmpty(autBank.Endereco) ? autBank.Endereco : string.Empty);
                comando.Parameters.AddWithValue("@BAIRRO", !string.IsNullOrEmpty(autBank.Bairro) ? autBank.Bairro : string.Empty);
                comando.Parameters.AddWithValue("@CIDADE", !string.IsNullOrEmpty(autBank.Cidade) ? autBank.Cidade : string.Empty);
                comando.Parameters.AddWithValue("@UF", !string.IsNullOrEmpty(autBank.UF) ? autBank.UF : string.Empty);
                comando.Parameters.AddWithValue("@CEP", !string.IsNullOrEmpty(autBank.Cep) ? autBank.Cep : string.Empty);
                comando.Parameters.AddWithValue("@CODIGOERRO", !string.IsNullOrEmpty(autBank.ResponseCip.CodErro) ? autBank.ResponseCip.CodErro : null);
                comando.Parameters.AddWithValue("@DESCRICAOERRO", !string.IsNullOrEmpty(autBank.ResponseCip.MsgErro) ? autBank.ResponseCip.MsgErro : string.Empty);
                comando.Parameters.AddWithValue("@CODCONTRATO", autBank.CodContrato);
                comando.Parameters.AddWithValue("@BOLETOAVULSO", 0);
                comando.Parameters.AddWithValue("@DVNOSSONUMERO", autBank.DVNossoNumero);
                comando.Parameters.AddWithValue("@CD_USUARIO", autBank.IdUsuario);

                if (_conn.State == ConnectionState.Closed) _conn.Open();
                retorno = comando.ExecuteNonQuery();
            }
            finally
            {
                _conn.Close();
            }
            return retorno > 0;
        }

        public bool CancelaBoletoGerado(string contrato,DateTime dataVencimento)
        {
            var retorno = 0;
            var boletos = _conn.Find<BoletoGerado>(t => t.MENSAGEM5 == "URA_CHAT_ROBO" && t.DATAVENCIMENTO == dataVencimento && t.COD_CONTRATO == contrato && t.STATUS == "A").ToList();

            if (boletos.Any())
            {
                boletos.ForEach(boleto =>
                {
                    boleto.STATUS = "C";
                    boleto.ID_MOTIVO_CANC = 1;
                   retorno += _conn.Update(boleto);
                });
            }
            return retorno >= 1;
        }
        public BoletoGerado BuscaBoletoGerado(string contrato, DateTime dataVencimento)
        {
            var acordo = _conn.Find<BoletoGerado>(t => t.MENSAGEM5 == "URA_CHAT_ROBO" && t.DATAVENCIMENTO == dataVencimento && t.COD_CONTRATO == contrato && t.STATUS == "A").FirstOrDefault();
            return acordo;
        }


        public TipoBoleto GetConfig()
        {
            if (_conn.State == ConnectionState.Closed) _conn.Open();

            var tipoBoleto = _conn.Find<TipoBoleto>(t => t.NOMETIPO == "URA_CHAT_ROBO").FirstOrDefault();
            var configuracao = _conn.Find<TbConfiguracoes>(t => t.ID_CONFIGURACAO == 1).FirstOrDefault();

            if (tipoBoleto != null)
            {
                tipoBoleto.Configuracao = configuracao;
            }
            return tipoBoleto;
        }

        public string GetLastNossoNumero(string contrato)
        {
            const string query = "INSERT INTO [dbo].[CONTADOR_BOLETO_CIP] VALUES (@CodContrato, @Data); SELECT SCOPE_IDENTITY()";

            var comando = new SqlCommand(query, _conn);
            comando.Parameters.AddWithValue("@CodContrato", contrato);
            comando.Parameters.AddWithValue("@Data", DateTime.Now);

            if (_conn.State == ConnectionState.Closed) _conn.Open();
           
            var nossoNumero = comando.ExecuteScalar();
            return Convert.ToString(nossoNumero);
        }


        public void Dispose()
        {
            _conn.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
