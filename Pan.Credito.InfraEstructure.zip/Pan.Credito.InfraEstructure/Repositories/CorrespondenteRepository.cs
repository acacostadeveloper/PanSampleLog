﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Repository;
using Pan.Repository.Pattern;

namespace Pan.Credito.Infrastructure.Repositories
{
    public class CorrespondenteRepository : ICorrespondenteRepository
    {
        private readonly IDbConnection _conn;
        public CorrespondenteRepository()
        {
            _conn = new SqlConnection(ConfigurationManager.ConnectionStrings["RCP"].ConnectionString);
        }
       public List<Correspondente> ObterCorrespondente(string subregiao)
        {

            var query = Properties.Resources.ObterCorrespondentes;
            var correspondentes = _conn.Query<Correspondente>(query, new { @Cep = subregiao }).ToList();
            return correspondentes.Take(3).ToList();
        }

        public void Dispose()
        {
            _conn.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}