﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Pan.Credito.Domain.Entidades.Helpers;
using Pan.Repository.Pattern;

namespace Pan.Credito.Infrastructure.Repositories
{
    public class LogRepository
    {
        public static void AddLog(Logguer log)
        {
            Task.Factory.StartNew(() =>
            {
                var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["LOGS"].ConnectionString);
                const string query =
                    "INSERT INTO [dbo].[LOG_API] ([Application],[CorrelationId],[Machine],[IpAddress],[RequestUri],[StatusCode],[RequestTimestamp],[ResponseTimestamp],[TotalTime],[JsonLog])" +
                    " VALUES" +
                    " (@Application,@CorrelationId,@Machine,@IpAddress,@RequestUri,@StatusCode,@RequestTimestamp,@ResponseTimestamp,@TotalTime,@JsonLog)";


                using (var commando = new SqlCommand(query, conn))
                {
                    try
                    {
                        commando.Parameters.AddWithValue("@Application", log.Application);
                        commando.Parameters.AddWithValue("@CorrelationId", log.CorrelationId);
                        commando.Parameters.AddWithValue("@Machine", log.Machine);
                        commando.Parameters.AddWithValue("@IpAddress", log.IpAddress);
                        commando.Parameters.AddWithValue("@RequestUri", log.RequestUri);
                        commando.Parameters.AddWithValue("@StatusCode", log.ResponseStatusCode);
                        commando.Parameters.AddWithValue("@RequestTimestamp", log.RequestTimestamp);
                        commando.Parameters.AddWithValue("@ResponseTimestamp", log.ResponseTimestamp);
                        commando.Parameters.AddWithValue("@TotalTime", Convert.ToDateTime(log.TotalTime));
                        commando.Parameters.AddWithValue("@JsonLog",
                            JsonConvert.SerializeObject(log, Formatting.Indented));

                        if (conn.State == ConnectionState.Closed) conn.Open();

                        commando.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        var serialize = JsonConvert.SerializeObject(ex.StackTrace, Formatting.Indented);
                        // File.WriteAllText(@"C:\Temp\veiculos_api_log", serialize);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            });
        }
    }
}