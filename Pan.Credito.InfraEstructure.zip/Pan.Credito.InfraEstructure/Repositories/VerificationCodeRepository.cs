﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using Pan.Credito.Domain.Entidades.Helpers;
using Pan.Credito.Domain.Repository;
using Pan.Repository.Pattern;

namespace Pan.Credito.Infrastructure.Repositories
{

    public class VerificationCodeRepository : IVerificationCodeRepository
    {
        private readonly SqlConnection _conn;

        public VerificationCodeRepository()
        {
            _conn = new SqlConnection(ConfigurationManager.ConnectionStrings["LOGS"].ConnectionString);
        }
        public  bool CheckToken(string code, string documento)
        {

            var verificationCode = _conn.Find<TokenWorkFlow>(t => t.Code == code && t.Documento == documento && t.Validado == false).FirstOrDefault();

            if (verificationCode == null) return false;

            var data = verificationCode.Data.AddMinutes(5);
            if (data <= DateTime.Now) return false;

            UpdateToken(verificationCode);
            return true;
        }

        public int? InsertToken(TokenWorkFlow token)
        {
            var id = _conn.Insert(token);
            return id ?? 0;
        }

        public void UpdateToken(TokenWorkFlow value)
        {
            value.Validado = true;
            value.DataValidado = DateTime.Now;
            _conn.Update(value);
        }

        public void Dispose()
        {
            _conn.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}