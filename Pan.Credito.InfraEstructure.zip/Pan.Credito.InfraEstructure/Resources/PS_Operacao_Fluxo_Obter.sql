Select

    Eventos.COD_EVENTO_FLUXO,
    Eventos.DESC_EVENTO_FLUXO,
    Eventos.TIPO_MOVTO,

    Tipo_Liquidacao.TIPO_LIQUIDACAO,
    Tipo_Liquidacao.DESC_LIQUIDACAO,


    Fluxo.COD_EVENTO_FLUXO   ,   -- NUMBER NOT NULL,         PRIMARY KEY    REFERENCES SYSADM.BTAB_ADM_EV_FLUXO (COD_EVENTO_FLUXO)
    Fluxo.DATA_VALOR         ,   -- DATE NOT NULL,           PRIMARY KEY
    Fluxo.NUM_SEQ_FLUXO      ,   -- NUMBER NOT NULL,         PRIMARY KEY
    Fluxo.COD_ORGAO          ,   -- NUMBER,
    Fluxo.COD_SIT_ATRASO     ,   -- NUMBER,
    Fluxo.DATA_AMORTIZACAO   ,   -- DATE,
    Fluxo.DATA_CONTABILIZ    ,   -- DATE,
    Fluxo.DATA_LIBERACAO     ,   -- DATE,
    Fluxo.DATA_RET_COBRADORA ,   -- DATE,
    Fluxo.FLAG_ESTORNO       ,   -- CHAR (1),
    Fluxo.NUM_SEQ_MOVTO      ,   -- NUMBER,
    Fluxo.TIPO_ORGAO_REC     ,   -- CHAR (1),
    Fluxo.VAL_REALIZADO      ,   -- FLOAT NOT NULL,
	--clipan.liquido_recebido(Fluxo.cod_contrato_Inter,Fluxo.data_amortizacao) as VAL_REALIZADO,

    Cobradora.COD_COBRADORA        As Cobradora_Codigo,
    CobradoraCadastro.NOME_CLIENTE AS Cobradora_Nome


    -- Chaves
    --Fluxo.COD_CONTRATO_INTER ,   -- NUMBER NOT NULL,         PRIMARY KEY    REFERENCES SYSADM.ECON_EMPRESTIMOS  (COD_CONTRATO_INTER)
    --Fluxo.COD_AUTORIZADOR    ,   -- VARCHAR2 (15),           REFERENCES SYSADM.ISEG_USU_BASE     (COD_USUARIO)
    --Fluxo.COD_COBRADORA      ,   -- NUMBER (12),             REFERENCES SYSADM.VTAB_COBRADORAS   (COD_COBRADORA)
    --Fluxo.COD_SUPERVISOR     ,   -- VARCHAR2 (15),           REFERENCES SYSADM.ISEG_USU_BASE     (COD_USUARIO)
    --Fluxo.COD_USUARIO_VALID  ,   -- VARCHAR2 (15),           REFERENCES SYSADM.ISEG_USU_BASE     (COD_USUARIO)
    --Fluxo.TIPO_LIQUIDACAO    ,   -- VARCHAR2 (3) NOT NULL,   REFERENCES SYSADM.BTAB_ADM_TIPO_LIQ (TIPO_LIQUIDACAO)

    --Fluxo.BASE_CALC_MORA     ,   -- CHAR (1),
    --Fluxo.COD_AUT_CUSTAS     ,   -- NUMBER,
    --Fluxo.COD_CONT_INTER_EST ,   -- NUMBER,
    --Fluxo.COD_DESPACHANTE    ,   -- VARCHAR2 (10),
    --Fluxo.COD_EVE_FLUXO_EST  ,   -- NUMBER,
    --Fluxo.COD_EVE_INTERNO    ,   -- NUMBER (3),
    --Fluxo.COD_USU_VALID_SPB  ,   -- VARCHAR2 (15),
    --Fluxo.COD_USUARIO_INCL   ,   -- VARCHAR2 (15),
    --Fluxo.DATA_VALIDACAO     ,   -- DATE,
    --Fluxo.DATA_VALOR_EST     ,   -- DATE,
    --Fluxo.DIF_MULT_TARIFA    ,   -- NUMBER (2),
    --Fluxo.DTHORA_ENVIO_SPB   ,   -- DATE,
    --Fluxo.DTHORA_INCLUSAO    ,   -- DATE NOT NULL,
    --Fluxo.DTHORA_VALID_SPB   ,   -- DATE,
    --Fluxo.FATOR_AMTZ         ,   -- FLOAT,
    --Fluxo.FLAG_BXANT_CEDIDA  ,   -- CHAR (1),
    --Fluxo.FLAG_BXANT_LEAS    ,   -- CHAR (1),
    --Fluxo.FLAG_CALC_ANTEC    ,   -- CHAR (1),
    --Fluxo.FLAG_CALC_LEASING  ,   -- CHAR (1),
    --Fluxo.FLAG_COMP_DIV_TERC ,   -- CHAR (1),
    --Fluxo.FLAG_CONTABILIZ    ,   -- CHAR (1),
    --Fluxo.FLAG_ENVIO_SPB     ,   -- CHAR (1),
    --Fluxo.FLAG_GERA_SPB      ,   -- CHAR (1),
    --Fluxo.FLAG_PAGTO         ,   -- CHAR (1),
    --Fluxo.FLAG_RET_COBRADORA ,   -- CHAR (1),
    --Fluxo.FLAG_VALID_SPB     ,   -- CHAR (1),
    --Fluxo.HORA_PAGTO_AMORTIZ ,   -- VARCHAR2 (5),
    --Fluxo.NUM_SEQ_FLUXO_EST  ,   -- NUMBER,
    --Fluxo.PERI_TAXA_DESAGIO  ,   -- CHAR (1),
    --Fluxo.TAXA_DESAGIO       ,   -- FLOAT,
    --Fluxo.TAXA_FLUTUANTE     ,   -- FLOAT,
    --Fluxo.TAXA_MOEDA         ,   -- FLOAT,
    --Fluxo.TIPO_ENVIO_SPB     ,   -- CHAR (1),
    --Fluxo.TIPO_TAXA_DESAGIO  ,   -- CHAR (1),
    --Fluxo.TIPO_VALIDACAO     ,   -- CHAR (1),
    --Fluxo.VAL_BX_PREJ_CASH   ,   -- FLOAT,
    --Fluxo.VAL_BX_PREJ_REC_BR ,   -- FLOAT,
    --Fluxo.VAL_PG_SDMORA_GER  ,   -- FLOAT,
    --Fluxo.VAL_VRGBAL_CM_VNP  ,   -- FLOAT,
    --Fluxo.VALOR_ME,              -- FLOAT
    

FROM
               ECON_FLUXO_CAIXA  Fluxo
    INNER JOIN BTAB_ADM_TIPO_LIQ Tipo_Liquidacao   ON Fluxo.TIPO_LIQUIDACAO 		= Tipo_Liquidacao.TIPO_LIQUIDACAO
    INNER JOIN BTAB_ADM_EV_FLUXO Eventos 		   ON Fluxo.COD_EVENTO_FLUXO 		= Eventos.COD_EVENTO_FLUXO
    LEFT  JOIN VTAB_COBRADORAS   Cobradora         ON Fluxo.COD_COBRADORA   		= Cobradora.COD_COBRADORA
    LEFT  JOIN BCLI_CADASTRO     CobradoraCadastro ON CobradoraCadastro.COD_CLIENTE = Cobradora.COD_CLIENTE

WHERE 
    COD_CONTRATO_INTER = :p_intContratoInterno
ORDER BY
    Fluxo.DATA_AMORTIZACAO