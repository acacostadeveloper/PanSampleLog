
SELECT 
    PessoasFisicas.COD_CLIENTE   AS Codigo,
    Clientes.NOME_CLIENTE        AS Nome,
    'F'                          AS TipoPessoa
FROM 
    		   BCLI_FIS_BASE PessoasFisicas
    INNER JOIN BCLI_CADASTRO Clientes       ON Clientes.COD_CLIENTE = PessoasFisicas.COD_CLIENTE
WHERE 
    PessoasFisicas.NUM_CPF 		   = :p_intCPF 
    -- ANDPessoasFisicas.DATA_NASCIMENTO = :p_dtmNascimento

UNION ALL


SELECT 
    PessoasJuridicas.COD_CLIENTE AS Codigo,
    Clientes.NOME_CLIENTE        AS Nome,
    'J'                          AS TipoPessoa
FROM 
    		   BCLI_JUR_BASE PessoasJuridicas
    INNER JOIN BCLI_CADASTRO Clientes       ON Clientes.COD_CLIENTE = PessoasJuridicas.COD_CLIENTE
WHERE 
    PessoasJuridicas.NUM_CGC 	   = :p_intCNPJ 
	-- AND PessoasJuridicas.DATA_ABERTURA = :p_dtmAbertura
    

