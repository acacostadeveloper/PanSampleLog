SELECT 
    Acordos.Data_Amortizacao As Parcela_Data,
    Acordos.Val_Saldo_Parc   AS Parcela_Valor_Original,
    Acordos.Val_Recebimento  AS Parcela_Valor_Atualizado,
	ACORDOS.NOSSO_NUMERO		,
    CLIPAN.NUMBER_PARC (Operacoes.COD_CONTRATO_INTER, 
                        Operacoes.DATA_LIBERACAO, 
                        Acordos.DATA_AMORTIZACAO) AS Parcela_Numero
FROM 
    ECON_CAIXA Acordos
    INNER JOIN ECON_EMPRESTIMOS Operacoes ON Acordos.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER
WHERE 
    ACORDOS.DATA_CANCELAMENTO    IS NULL AND
    Acordos.DATA_PAGTO_EFETIVA   IS NULL AND
    Acordos.FLAG_PAGTO           = '0'