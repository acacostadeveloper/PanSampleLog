SELECT DISTINCT
    Carteira.COD_BANCO          AS Boleto_Banco,
    Carteira.COD_CARTEIRA       AS Boleto_Carteira,
    Carteira.COD_AGENCIA        AS Boleto_Agencia,
    Carteira.DIG_AGENCIA        AS Boleto_AgenciaDigito,
    Carteira.COD_CONTA          AS Boleto_Conta,
    Carteira.DIG_CONTA          AS Boleto_ContaDigito,
    Carteira.COD_EMPRESA        AS Boleto_CedenteCodigo
FROM
               ECON_EMPRESTIMOS  Operacoes
    Inner Join vtab_carteira_cor Carteira On Operacoes.COD_VEIC_LEGAL = Carteira.COD_VEIC_LEGAL
WHERE
    Operacoes.COD_CONTRATO_INTER = :intContratoInterno And
    CARTEIRA.FLAG_RENEGOCIACAO   = 'S'                 And
    ROWNUM                      <= 1 
