SELECT
    Operacoes.COD_CONTRATO_INTER   ,     --PRIMARY KEY

    Operacoes.COD_CLIENTE          ,     --FOREIGN KEY   BCLI_CADASTRO      (COD_CLIENTE)
    Operacoes.COD_FILIAL           ,     --FOREIGN KEY   BINT_FILIAL        (COD_VEIC_LEGAL COD_FILIAL)
    Operacoes.COD_OFFICER          ,     --FOREIGN KEY   BINT_OFFICER       (COD_OFFICER)
    Operacoes.COD_PRODUTO          ,     --FOREIGN KEY   BPRO_EMPREST_BASE  (COD_PRODUTO)
    Operacoes.COD_VEIC_LEGAL       ,     --FOREIGN KEY   BINT_FILIAL        (COD_VEIC_LEGAL COD_FILIAL)

    Operacoes.COD_CARTEIRA         ,
    Operacoes.COD_CESSAO           ,
    Operacoes.COD_CONTRATO         ,
    Operacoes.COD_LOJA             ,
    Operacoes.DATA_CANCELAMENTO    ,
    Operacoes.DATA_LIBERACAO       ,
    Operacoes.DATA_LIQ_CONTR       ,
    Operacoes.DATA_REPASSE         ,
    Operacoes.DATA_VENCTO_FINAL    ,
    Operacoes.DTHORA_INCLUSAO      ,
    Operacoes.FLAG_IOC_FINANC      ,
	E.TIPO_OPERACAO        ,
    Operacoes.TIPO_LIBERACAO       ,
    Operacoes.TIPO_LIQUIDACAO      ,
    Operacoes.TIPO_SITUA_ATRASO    ,
    Operacoes.VAL_CAC              ,
    Operacoes.VAL_COMPRA           ,
    Operacoes.VAL_IOC              ,
    Operacoes.VAL_SEGURO           ,

    --Operacoes.COD_SIT_ATRASO       ,     --
    --Operacoes.DATA_LIQUIDACAO      ,     --
    --Operacoes.COD_GER_MERCA        ,     --FOREIGN KEY   BINT_GERENCIA_MERC (COD_GER_MERCA)
    --Operacoes.COD_TAB_JUR          ,     --FOREIGN KEY   VPAR_TAB_JUR_GERAL (COD_TABELA)
    --Operacoes.IDX_PRINC            ,     --FOREIGN KEY   BTAB_ADM_INDEXADOR (COD_INDEXADOR)
    --Operacoes.TIPO_RENEG           ,     --FOREIGN KEY   BTAB_OFI_TP_RENEG  (COD_RENEG)
    --Operacoes.COD_LOJA_PARAM       ,     --
    --Operacoes.COD_PRODUTO_ORIGEM   ,     --
    --Operacoes.COD_REGIONAL         ,     --'C�digo da regional'
    --Operacoes.COD_USU_FORMALIZA    ,     --'Usu�rio que formalizou opera��o'
    --Operacoes.COD_USUARIO_INCL     ,     --
    --Operacoes.FLAG_COBRANCA        ,     --
    --Operacoes.FLAG_CONTABILIZ      ,     --
    --Operacoes.FLAG_GERA_FRM_LIQ    ,     --
    --Operacoes.FLAG_LIQUIDADO       ,     --
    --Operacoes.FLAG_RENEG           ,     --
    --Operacoes.FLAG_SEGURO          ,     --
    --Operacoes.PERC_COMISS_PRINC_N  ,     --'Percentual de Comissao Sobre Principal'
    --Operacoes.PRAZO_ATRASO_ATE     ,     --
    --Operacoes.PRAZO_CONTRATUAL     ,     --
    --Operacoes.QTDE_DIAS_CAREN_N    ,     --'Dias Carencia do Contrato'
    --Operacoes.QTDE_PRESTACOES_N    ,     --'Quantidade de Parcelas do Contrato'
    --Operacoes.TAXA_ENCFISC_DIA     ,     --
    --Operacoes.TAXA_ENCOPER_DIA     ,     --
    --Operacoes.TAXA_FECHAMENTO      ,     --
    --Operacoes.TAXA_JUROS_DIA       ,     --
    --Operacoes.TAXA_LIQUIDA_N       ,     --'Taxa de Liquidacao'
    --Operacoes.TAXA_PRECO_BANCO_N   ,     --'Taxa do Contrato dada pelo Banco Parceiro'
    --Operacoes.TAXA_REGISTRO_CONT_N ,     --'Taxa Registro Contrato'
    --Operacoes.VAL_CARTORIO_N       ,     --'Valor de Cartorio'
    --Operacoes.VAL_COMIS_COMPRA_N   ,     --'Comiss�o de Compra'
    --Operacoes.VAL_COMIS_OPER_CET_N ,     --'Valor de Comissao do Operador para Calculo CET'
    --Operacoes.VAL_FINANC_N         ,     --'Valor de Financiamento'
    --Operacoes.VAL_PRESTACAO_N      ,     --'Valor da Prestacao'
    --Operacoes.VAL_PRINC_OUT_CV     ,     --
    --Operacoes.VAL_TARIFA_GRAVAME_N ,     --'Valor da Tarifa para Utilizar o Servico Gravame'
    --Operacoes.VAL_TARIFA_VISTOR_N  ,     --'Valor da Tarifa Referente a Vistoria do Veiculo'
    --Operacoes.VAL_TAXA_CARTORIO_N  ,     --'Valor Taxade Cart�rio'
    --Operacoes.VAL_TAXA_CET_N       ,     --'Taxa de Custo Efetivo Total'
    --Operacoes.VAL_TAXA_N           ,     --'Taxa Usada no Calculo do Contrato'
    --Operacoes.VAL_TAXA_PACTUADA_N  ,     --'Taxa Pactuada'
    --Operacoes.VAL_TAXA_SPREAD_N    ,     --'Taxa Spread'
    --Operacoes.VENCTO_PRIM_PARC_N,        --'Vencimento Primeira Parcela Contrato'


    
    -- Par�metros do contrato
    Parametros.VAL_TAXA_CET, 
    Parametros.VAL_TAXA_PACTUADA, 
    Parametros.TAXA_JUROS_C1,
    
    
    -- Valores
    NVL(Contrato.val_entrada,                    0) As val_entrada,
    NVL(Contrato.val_financ,                     0) As val_financ,
    NVL(Contrato.val_emprestimo,                 0) As val_emprestimo,
    NVL(Contrato.val_principal,                  0) As val_principal,
    NVL(Contrato.val_cartorio,                   0) As val_cartorio,
	Contrato.num_transacao							As Num_Transacao,
	Contrato.TIPO_APROV_CRED						AS Tipo_Aprovacao,
    NVL(Contrato_Complemento.val_tarifa_gravame, 0) As val_tarifa_gravame, 
    NVL(Contrato_Complemento.val_tarifa_vistor,  0) As val_tarifa_vistor,
    


    -- Loja
    Loja.COD_LOJA              AS Loja_Codigo,
    Loja.NUM_CGC               AS Loja_CNPJ,
    Loja.DESC_BAIRRO           AS Loja_Endereco_Bairro,
    Loja.COD_CEP               AS Loja_Endereco_CEP,
    Loja.DESC_CIDADE           AS Loja_Endereco_Cidade,
    Loja.DESC_COMPL_LOGR       AS Loja_Endereco_Complemento,
    Loja.DESC_LOGRADOURO       AS Loja_Endereco_Logradouro,
    Loja.NUM_LOGRADOURO        AS Loja_Endereco_Numero,
    Loja.SIGLA_UF_END          AS Loja_Endereco_UF,
    Loja.NUM_AREA_TELEFONE     AS Loja_Telefone_Area,
    Loja.NUM_TELEFONE          AS Loja_Telefone_Numero,
    Loja.COD_RAMAL             AS Loja_Telefone_Ramal,
    Loja.DATA_INICIO_ATIV      AS Loja_InicioAtividade,
	Loja.DATA_FIM_ATIV		   AS Loja_FimAtividade,	
    Loja.DESC_LOJA             AS Loja_Nome,
    Loja.DESC_RAZAO            AS Loja_RazaoSocial,
    Loja.TIPO_LOJA             AS Loja_Tipo,
	CASE WHEN Loja.DATA_FIM_ATIV IS NULL THEN 'ATIVA'  WHEN Loja.DATA_FIM_ATIV IS NOT NULL THEN 'INATIVA' END AS Loja_Status,


    -- Officer
    Officer.COD_OFFICER        AS Officer_Codigo,
	Officer.NOME_OFFICER       AS Officer_Nome,
    Officer.NUM_CPF				AS Officer_CPF,


    -- Regional
    Regional.COD_REGIONAL      AS Regional_Codigo,
	Regional.NUM_CGC           AS Regional_CNPJ,
    Regional.DESC_REGIONAL     AS Regional_Nome, 
    Regional.DESC_BAIRRO       AS Regional_Endereco_Bairro,
    Regional.COD_CEP           AS Regional_Endereco_CEP,
    Regional.DESC_CIDADE       AS Regional_Endereco_Cidade,
    Regional.DESC_COMPL_LOGR   AS Regional_Endereco_Complemento,
    Regional.DESC_LOGRADOURO   AS Regional_Endereco_Logradouro,
    Regional.NUM_LOGRADOURO    AS Regional_Endereco_Numero,
    Regional.SIGLA_UF_END      AS Regional_Endereco_UF,
    Regional.NUM_AREA_TELEFONE AS Regional_Telefone_Area,
    Regional.NUM_TELEFONE      AS Regional_Telefone_Numero,
    Regional.COD_RAMAL         AS Regional_Telefone_Ramal,
	CASE  WHEN Regional.DATA_DESATIVACAO IS NULL THEN 'ATIVA' WHEN Regional.DATA_DESATIVACAO IS NOT NULL THEN 'INATIVA' END AS Regional_Status,

    -- Cobradora
    Cobradora.COD_COB_EXTERNA  AS Cobradora_Codigo,


    -- Cliente
    CASE
        WHEN Cliente.TIPO_CLIENTE = 'F' THEN
            Cliente_PF.NUM_CPF
        ELSE
            Cliente_PJ.NUM_CGC
    END                              AS Cliente_Documento,
    Cliente.TIPO_CLIENTE             AS Cliente_TipoPessoa,
    Cliente.NOME_CLIENTE             AS Cliente_Nome,
    Cliente_Endereco.DESC_BAIRRO     AS Cliente_Endereco_Bairro,
    Cliente_Endereco.COD_CEP         AS Cliente_Endereco_CEP,
    Cliente_Endereco.DESC_CIDADE     AS Cliente_Endereco_Cidade,
    Cliente_Endereco.DESC_COMPL_LOGR AS Cliente_Endereco_Complemento,
    Cliente_Endereco.DESC_LOGRADOURO AS Cliente_Endereco_Logradouro,
    Cliente_Endereco.NUM_LOGRADOURO  AS Cliente_Endereco_Numero,
    Cliente_Endereco.SIGLA_UF_END    AS Cliente_Endereco_UF,
	CASE
        WHEN Cliente.TIPO_CLIENTE = 'F' THEN
            Cliente_PF.desc_profissao
    END                              AS Cliente_Profissao,
		CASE
        WHEN Cliente.TIPO_CLIENTE = 'F' THEN
            Cliente_PF.val_salario_liq
    END                              AS Cliente_Salario,

    -- Empresa (ve�culo legal)
    Empresas.COD_VEIC_LEGAL          AS Empresa_Codigo,
    Empresas.NUM_CGC                 AS Empresa_CNPJ,
    Empresas.DESC_VEIC_LEGAL         AS Empresa_Nome, 
    Empresas.DESC_BAIRRO             AS Empresa_Endereco_Bairro,
    Empresas.COD_CEP                 AS Empresa_Endereco_CEP,
    Empresas.DESC_CIDADE             AS Empresa_Endereco_Cidade,
    Empresas.DESC_COMPL_LOGR         AS Empresa_Endereco_Complemento,
    Empresas.DESC_LOGRADOURO         AS Empresa_Endereco_Logradouro,
    Empresas.NUM_LOGRADOURO          AS Empresa_Endereco_Numero,
    Empresas.SIGLA_UF_END            AS Empresa_Endereco_UF,


    -- Situa��o
    Situacao.COD_SIT_ATRASO,
    Situacao.DESC_SIT_ATRASO



    -- Contrato regular
    %Contrato_Regular%




    -- Operacoes.AUTORIZO_SERASA,
    -- Operacoes.COD_BANQUEIRO,             -- FOREIGN KEY   BENT_BANQ_BASE     (COD_BANQUEIRO)
    -- Operacoes.COD_BENEFICIARIO,          -- FOREIGN KEY   BENT_BENEFICIARIO  (COD_BENEFICIARIO)
    -- Operacoes.COD_CARAC_ESPEC,           -- FOREIGN KEY   BTAB_OFI_CARAC_ESP (COD_CARAC)
    -- Operacoes.COD_CONTRATO_VINC,         -- FOREIGN KEY   ECON_EMPRESTIMOS   (COD_CONTRATO_INTER)
    -- Operacoes.COD_NEGOCIO_PF_PJ,         -- FOREIGN KEY   BCLI_CADASTRO      (COD_CLIENTE)
    -- Operacoes.COD_SETOR,                 -- FOREIGN KEY   BTAB_ADM_SETOR     (COD_SETOR)
    -- Operacoes.COD_USU_ACAO_REVIS   ,     -- FOREIGN KEY   ISEG_USU_BASE      (COD_USUARIO)   'Usu�rio da a��o revisional'
    -- Operacoes.COD_USU_APROVADOR    ,     -- FOREIGN KEY   ISEG_USU_BASE      (COD_USUARIO)
    -- Operacoes.COD_USUARIO_VALID    ,     -- FOREIGN KEY   ISEG_USU_BASE      (COD_USUARIO)
    -- Operacoes.COD_AGENCIA_EXTERN   ,     --
    -- Operacoes.COD_AGENCIA_ORIG     ,     --
    -- Operacoes.COD_ANT_ATRASO       ,     --
    -- Operacoes.COD_AQUISICAO        ,     -- 'Codigo de Carga de Aquisicao de Credito.'
    -- Operacoes.COD_BACEN_ATU        ,     --
    -- Operacoes.COD_BALANCO_ALEMAO   ,     --
    -- Operacoes.COD_BANCO_CORRESP    ,     --
    -- Operacoes.COD_BANCO_ENV        ,     --
    -- Operacoes.COD_BARCODE          ,     -- 'C�digo de Barras do Contrato.'
    -- Operacoes.COD_CAC_SEQ_CONFIS   ,     --
    -- Operacoes.COD_CAMPANHA         ,     --
    -- Operacoes.COD_CARAC_ORIG       ,     --
    -- Operacoes.COD_CARTAO_MAGLU     ,     --
    -- Operacoes.COD_CONDICAO         ,     --
    -- Operacoes.COD_CONTR_EXTERNO    ,     --
    -- Operacoes.COD_CONTR_ORIG       ,     --
    -- Operacoes.COD_COSIF_ORIG       ,     --
    -- Operacoes.COD_DRT              ,     --
    -- Operacoes.COD_GRUPO_REG        ,     --
    -- Operacoes.COD_INDEX_ORIG       ,     --
    -- Operacoes.COD_INTEGRACAO       ,     --    
    -- Operacoes.COD_MARCA_PRODUTO    ,     --
    -- Operacoes.COD_MODAL_ORIG       ,     --
    -- Operacoes.COD_MODALIDADE       ,     -- 'Modalidade de Classificacao Cont�bil BACEN'
    -- Operacoes.COD_NUM_BOLETO       ,     --
    -- Operacoes.COD_OFFICER_ANT      ,     --
    -- Operacoes.COD_ORIG_RECURSOS    ,     --
    -- Operacoes.COD_RECOR            ,
    -- Operacoes.COD_RENEG_ORIG       ,     --
    -- Operacoes.COD_SAIDA_MERCA      ,     --
    -- Operacoes.COD_SUB_MODAL_ORIG   ,     --
    -- Operacoes.COD_SUB_MODALIDADE   ,     -- 'Sub-modalidade de classifica��o cont�bil BACEN.'
    -- Operacoes.COD_TIPO_BEM         ,     --
    -- Operacoes.COD_TIPO_MERCA       ,     --
    -- Operacoes.COD_USU_VALID_SPB    ,     --
    -- Operacoes.COD_VEIC_LEGAL_ANT   ,     --
    -- Operacoes.CONTR_LIQ_ARQ        ,     --
    -- Operacoes.COTA_DEPREC_ME       ,     --
    -- Operacoes.DATA_ACAO_REVIS      ,     -- 'Data da a��o revisional'
    -- Operacoes.DATA_ASSUNCAO        ,     --
    -- Operacoes.DATA_BASE_MORAGER    ,     --
    -- Operacoes.DATA_CCL             ,     --
    -- Operacoes.DATA_CESSAO          ,     --
    -- Operacoes.DATA_CONTABILIZ      ,     --
    -- Operacoes.DATA_CONTRATACAO     ,     --
    -- Operacoes.DATA_ENVIO_ASSIST    ,     --
    -- Operacoes.DATA_ENVIO_FIDC      ,     --
    -- Operacoes.DATA_FRAUDE          ,     -- 'Data da fraude'
    -- Operacoes.DATA_INTERF_CONTR    ,     --
    -- Operacoes.DATA_IRRECUPERAB     ,     -- 'Data da irrecuperabilidade'
    -- Operacoes.DATA_LIQ_CESSAO      ,     --
    -- Operacoes.DATA_LIQ_IMOB        ,     --
    -- Operacoes.DATA_ORIGIN_AQUIS    ,     --
    -- Operacoes.DATA_PERDA_ASSIST    ,     --
    -- Operacoes.DATA_RECOMPRA        ,     --
    -- Operacoes.DATA_RETOMADA_BEM    ,     --
    -- Operacoes.DATA_TRANSF_PREJU    ,     --
    -- Operacoes.DATA_VALIDACAO       ,     --
    -- Operacoes.DATA_VENCTO_ORIG     ,     --
    -- Operacoes.DESC_OBSERVACOES     ,     --
    -- Operacoes.DESC_PROCEDIMENTOS   ,     -- 'Descri��o de Procedimento do Contrato.'
    -- Operacoes.DIR_REGRESSO         ,     --
    -- Operacoes.DTHORA_ENVIO_SPB     ,     --
    -- Operacoes.DTHORA_VALID_SPB     ,     --
    -- Operacoes.ESTACAO              ,     --
    -- Operacoes.FLAG_ACAO_REVIS      ,     -- 'S ou N - Se contrato sofreu a��o revisional' 
    -- Operacoes.FLAG_ATR_MAIS14      ,     --
    -- Operacoes.FLAG_BLOQUEIA_CESS   ,     -- 'Se [S] n�o poder� ser CEDIDO.'
    -- Operacoes.FLAG_CCB             ,     --
    -- Operacoes.FLAG_CESPARC_NOVA    ,     --
    -- Operacoes.FLAG_CLASSIF_AA      ,     --
    -- Operacoes.FLAG_CONFIS_DIV      ,     --
    -- Operacoes.FLAG_DESTR_CHEQUE    ,     --
    -- Operacoes.FLAG_ENVIO_ASSIST    ,     --
    -- Operacoes.FLAG_ENVIO_FIDC      ,     --
    -- Operacoes.FLAG_ENVIO_SPB       ,     --
    -- Operacoes.FLAG_ERRO_CONSIST    ,     --
    -- Operacoes.FLAG_GAP             ,     --
    -- Operacoes.FLAG_GERA_SPB        ,     --
    -- Operacoes.FLAG_INTERF_CONTR    ,     --
    -- Operacoes.FLAG_IOC_ISENTO      ,     --
    -- Operacoes.FLAG_LIQ_DEPREC      ,     --
    -- Operacoes.FLAG_PAGTO_JUIZO     ,     --
    -- Operacoes.FLAG_PDD_BACEN       ,     -- 'PDD BACEN: [S]im ou [N]ao.'
    -- Operacoes.FLAG_SEGUNDA_VALID   ,     -- 'S - Segunda valida��o - N ou Branco = N�o h� segunda valida��o'
    -- Operacoes.FLAG_VALID_SPB       ,     --
    -- Operacoes.FLAG_VCTO_INDET      ,     --
    -- Operacoes.NUM_BOLETO           ,     --
    -- Operacoes.NUM_CAIXA_ARQUIVO    ,     --
    -- Operacoes.NUM_CD_ARQUIVO       ,     --
    -- Operacoes.NUM_DOCUMENTO        ,     --
    -- Operacoes.NUM_LOTE_ARQUIVO     ,     --
    -- Operacoes.NUM_MESES_DEPREC     ,     --
    -- Operacoes.NUM_UNICO_CIP        ,     -- 'Numeracao enviada no arquivo retorno Central de Credito CIP'
    -- Operacoes.PERC_VRG             ,     -- 
    -- Operacoes.PORTE_CLIENTE_PF     ,     -- 
    -- Operacoes.QTD_PARCELAS_CES     ,     -- 'Quantidade de parcelas de cess�o'
    -- Operacoes.QTDE_PARC_AB_N       ,     -- 'Quantidade Parcelas em Aberto'
    -- Operacoes.SEQ_CAIXA            ,     --
    -- Operacoes.SERIE_CARTAO_MAGLU   ,     --
    -- Operacoes.STATUS               ,     --
    -- Operacoes.TAXA_ORIGIN_AQUIS    ,     --
    -- Operacoes.TAXA_PARIDADE        ,     --
    -- Operacoes.TIPO_BOLETO          ,     --
    -- Operacoes.TIPO_COBRANCA        ,     --
    -- Operacoes.TIPO_ENVIO_SPB       ,     --
    -- Operacoes.TIPO_EQUALIZACAO     ,     --
    -- Operacoes.TIPO_VALIDACAO       ,     --
    -- Operacoes.VAL_DESC_PONTUALID   ,     --
    -- Operacoes.VAL_DESCONTO         ,     --
    -- Operacoes.VAL_DESP_RESSARC     ,     --
    -- Operacoes.VAL_DESPACHANTE      ,     -- 'Valor pago ao despachante'
    -- Operacoes.VAL_FATOR_VRG        ,     --
    -- Operacoes.VAL_FIN_LIM_CRED     ,     --
    -- Operacoes.VAL_IMOBILIZADO_ME   ,     --
    -- Operacoes.VAL_IMOBILIZADO_MN   ,     --
    -- Operacoes.VAL_OPER_FINAME      ,     --
    -- Operacoes.VAL_PAGTO_ATO        ,     --
    -- Operacoes.VAL_PMT_LIM_CRED     ,     --
    -- Operacoes.VAL_PRINC_AQUIS      ,     --
    -- Operacoes.VAL_PRINCIPAL        ,     -- **************
    -- Operacoes.VAL_REBATE_FINANC_N  ,     -- 'Comissao Recebida'
    -- Operacoes.VAL_REBATE_LOJA_N    ,     -- 'Valor de Repasse do Seguro da Loja'
    -- Operacoes.VAL_RES_TARIFA       ,     -- 
    -- Operacoes.VAL_SALDO_ATUAL      ,     -- 'Valor do Saldo Atual'
    -- Operacoes.VAL_SALDO_CESSAO     ,     -- 'Valor do Saldo de Cess�o'
    -- Operacoes.VAL_SALDO_ENCARGOS   ,     -- 
    -- Operacoes.VAL_SALDO_FUTURO     ,     -- 'Valor do Saldo Futuro'
    -- Operacoes.VAL_SALDO_TOTAL      ,     -- 
    -- Operacoes.VAL_TAC_LOJA_N       ,     -- 'Valor de Repasse da Loja'
    -- Operacoes.VAL_TAXA_REBATE_N    ,     -- 'Valor de Taxa de Rebate Usado para Contrato'
    -- Operacoes.VAL_TIR_SEM_DESP_N   ,     -- 'Armazena a Taxa Tir sem Despesas Ressarciveis'
    -- Operacoes.VAL_TLA_DIA          ,     -- 
    -- Operacoes.VAL_VRG_FINAL        ,     -- 
    -- Operacoes.VAL_VRG_INICIAL      ,     -- 
    -- Operacoes.VAL_VRG_PARC         ,     -- 
    -- Operacoes.VENCTO_1_AB_N        ,     -- 'Vencimento Primeira Parcela em Aberto' 
	,CASE WHEN GM.DESC_GER_MERCA LIKE '%AUTOPAN%' THEN
          'autopan'
     ELSE
       CASE WHEN PT.desc_operacao = 'CP' THEN
            'credito'
            WHEN PT.desc_operacao = 'VEICULO' THEN
            'veiculo'
       ELSE
            PT.desc_operacao
       END
     END OPERACAO,
   CASE WHEN Cliente_Conta.COD_BANCO IS NULL THEN '' ELSE  NVL(TO_CHAR(Cliente_Conta.COD_BANCO),'-') END                 AS Cliente_Cod_Banco, 
   CASE WHEN Cliente_Conta.COD_AGENCIA IS NULL THEN '' ELSE  Cliente_Conta.COD_AGENCIA ||'-'|| Cliente_Conta.DIG_AGENCIA END       AS Cliente_Agencia, 
   CASE WHEN Cliente_Conta.COD_CONTA IS NULL THEN '' ELSE  Cliente_Conta.COD_CONTA ||'-'|| Cliente_Conta.DIG_CONTA  END        AS Cliente_Conta,
   CASE WHEN Cliente_Telefone.num_area_telefone IS NULL THEN '' ELSE    Cliente_Telefone.num_area_telefone || '-' || Cliente_Telefone.num_telefone END as Cliente_Telefone,
   CASE WHEN Cliente_Telefone.num_area_celular IS NULL THEN '' ELSE  Cliente_Telefone.num_area_celular  || '-' || Cliente_Telefone.num_celular END  as Cliente_Celular,
   CASE WHEN Comercial_Telefone.num_area_telefone IS NULL THEN '' ELSE    Comercial_Telefone.num_area_telefone || '-' || Comercial_Telefone.num_telefone END as Cliente_Comercial

   ,Emprego.desc_razao_social								Comercial_Empresa_Nome
   ,Emprego.num_cgc_empresa									Comercial_Empresa_Cnpj
   ,NaturalOcu.desc_natu_ocup								Comercial_Natureza_Ocupacao
   ,TRUNC(((SYSDATE - Emprego.DATA_ADMISSAO)/365))			Comercial_Data_Admissao_Ano
   ,TRUNC(MOD((SYSDATE - Emprego.DATA_ADMISSAO),365)/30)	Comercial_Data_Admissao_Mes
   ,Comercial_Endereco.DESC_BAIRRO     AS Comercial_Endereco_Bairro
   ,Comercial_Endereco.COD_CEP         AS Comercial_Endereco_CEP
   ,Comercial_Endereco.DESC_CIDADE     AS Comercial_Endereco_Cidade
   ,Comercial_Endereco.DESC_COMPL_LOGR AS Comercial_Endereco_Complemento
   ,Comercial_Endereco.DESC_LOGRADOURO AS Comercial_Endereco_Logradouro
   ,Comercial_Endereco.NUM_LOGRADOURO  AS Comercial_Endereco_Numero
   ,Comercial_Endereco.SIGLA_UF_END    AS Comercial_Endereco_UF
FROM
               ECON_EMPRESTIMOS   Operacoes
               
    -- Par�metro
    INNER JOIN ECON_PARAM_CALC    Parametros            ON Operacoes.COD_CONTRATO_INTER      = Parametros.COD_CONTRATO_INTER

    -- Valores
    LEFT JOIN dfen_contrato      Contrato              ON Contrato.COD_CONTRATO              = Operacoes.COD_CONTRATO
    LEFT JOIN dfen_contrato_cmpl Contrato_Complemento  ON Contrato_Complemento.cod_loja      = Contrato.cod_loja             and 
                                                          Contrato_Complemento.num_transacao = Contrato.num_transacao
    -- Empresa do Grupo Pan
    INNER JOIN BINT_VEICULO_LEGAL Empresas             ON Operacoes.COD_VEIC_LEGAL           = Empresas.COD_VEIC_LEGAL

    -- Situa��o do contrato
    Left  JOIN BTAB_ADM_SATR_EMP  Situacao             ON Operacoes.COD_VEIC_LEGAL           = Situacao.COD_VEIC_LEGAL      And
                                                          Operacoes.COD_SIT_ATRASO           = Situacao.COD_SIT_ATRASO

    -- Loja
    LEFT  JOIN BENT_LOJA_BASE     Loja                 ON Contrato.COD_LOJA                  = Loja.COD_LOJA

    -- Officer
    LEFT  JOIN BINT_OFFICER       Officer              ON Contrato.COD_OFFICER               = Officer.COD_OFFICER
    
    -- Regional
    LEFT  JOIN BINT_REGIONAL      Regional             ON Contrato.COD_REGIONAL              = Regional.COD_REGIONAL

    -- Cobradora
    LEFT JOIN  NCNT_CONTROLE      Cobradora            ON Operacoes.COD_CONTRATO_INTER       = Cobradora.COD_CONTRATO_INTER

    -- Cliente
    INNER JOIN BCLI_CADASTRO       Cliente              ON Operacoes.COD_CLIENTE              = Cliente.COD_CLIENTE
    LEFT  JOIN BCLI_ENDERECOS      Cliente_Endereco     ON Cliente.COD_CLIENTE                = Cliente_Endereco.COD_CLIENTE AND Cliente_Endereco.TIPO_ENDERECO = 'R'
	LEFT  JOIN BCLI_ENDERECOS      Comercial_Endereco     ON Cliente.COD_CLIENTE                = Comercial_Endereco.COD_CLIENTE AND Comercial_Endereco.TIPO_ENDERECO = 'C'
	LEFT  JOIN BCLI_TELEFONES      Cliente_Telefone     ON Cliente.COD_CLIENTE                = Cliente_Telefone.COD_CLIENTE AND Cliente_Telefone.tipo_cad_tel = 'R'
	LEFT  JOIN BCLI_TELEFONES      Comercial_Telefone     ON Cliente.COD_CLIENTE                = Comercial_Telefone.COD_CLIENTE AND Comercial_Telefone.tipo_cad_tel = 'C'
	LEFT  JOIN BCLI_OUTRAS_CONTAS  Cliente_Conta	    ON Cliente.COD_CLIENTE                = Cliente_Conta.COD_CLIENTE
    LEFT  JOIN BCLI_FIS_BASE       Cliente_PF           ON Cliente.COD_CLIENTE                = Cliente_PF.COD_CLIENTE        
    LEFT  JOIN BCLI_JUR_BASE       Cliente_PJ           ON Cliente.COD_CLIENTE                = Cliente_PJ.COD_CLIENTE
    LEFT  JOIN BPRO_EMPREST_BASE   E                    ON E.COD_PRODUTO                      = Operacoes.COD_PRODUTO
    LEFT  JOIN CLIPAN.TB_TIPO_PROD PT                   ON PT.TIPO_OPERACAO                   = E.TIPO_OPERACAO
    LEFT  JOIN BINT_GERENCIA_MERC  GM                   ON Operacoes.COD_GER_MERCA = GM.COD_GER_MERCA

	LEFT JOIN DMOV_FIS_EMPREGOS    Emprego				ON Emprego.cod_loja = Contrato.cod_loja and Emprego.num_transacao = Contrato.num_transacao
	LEFT JOIN BTAB_INT_NATOCUP     NaturalOcu			ON NaturalOcu.COD_NATU_OCUP    = Cliente_PF.COD_NATU_OCUP
WHERE
    Substr(Operacoes.COD_CONTRATO, 1, 3)  <> 'CES'          And
	(Cliente_Conta.NUM_SEQ_CONTA		IS NULL OR Cliente_Conta.NUM_SEQ_CONTA     = 1)               And
    