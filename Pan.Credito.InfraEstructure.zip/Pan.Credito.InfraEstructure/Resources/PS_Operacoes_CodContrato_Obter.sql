SELECT 
    COD_CONTRATO 
FROM 
    ECON_EMPRESTIMOS 
WHERE 
    dthora_inclusao Between :p_dtmInicio and :p_dtmTermino
    