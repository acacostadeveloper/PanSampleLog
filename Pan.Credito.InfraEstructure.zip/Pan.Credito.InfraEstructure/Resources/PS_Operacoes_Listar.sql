SELECT
    Operacoes.COD_CLIENTE            AS Cliente_Codigo,
    Pessoas_Fisicas.NUM_CPF            AS Cliente_Documento,
    Clientes.NOME_CLIENTE           AS Cliente_Nome,

    Cobradoras.cod_cob_externa      AS Cobradora_Codigo,

    Empresas.COD_VEIC_LEGAL         AS Empresa_Codigo,
    Empresas.DESC_VEIC_LEGAL        AS Empresa_Nome,

    Operacoes.COD_CONTRATO_INTER    AS Operacao_Codigo,
    Operacoes.COD_CONTRATO          AS Operacao_Contrato,
    Operacoes.DATA_LIBERACAO        AS Operacao_DataLiberacao,
    Operacoes.DATA_VENCTO_FINAL     AS Operacao_DataVencimento,
    CASE WHEN Operacoes.DATA_CANCELAMENTO IS NULL THEN Operacoes.FLAG_LIQUIDADO
      ELSE   'C'
      END Operacao_Liquidada,
    Operacoes.COD_LOJA              AS Operacao_Loja_Codigo,
    Contratos.QTDE_PRESTACOES       AS Operacao_Parcelas,
    (QTDE_PRESTACOES - (SELECT nvl(COUNT(*), 0) FROM ECON_AMORTIZACOES WHERE ECON_AMORTIZACOES.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER AND FLAG_LIQUIDADO='S' AND DATA_AMORTIZACAO > Operacoes.DATA_LIBERACAO ) ) AS Operacao_ParcelasAbertas,
    Operacoes.COD_PRODUTO           AS Operacao_ProdutoCodigo,
    Operacoes.COD_SIT_ATRASO        AS Operacao_Situacao,
    Atraso.DESC_SIT_ATRASO          AS Operacao_SituacaoDesc,
    Contratos.VAL_FINANC            AS Operacao_Valor, 

    GerenciaMercado.COD_GER_MERCA   As GerenciaMercado_Codigo,
    GerenciaMercado.DESC_GER_MERCA  As GerenciaMercado_Descricao,
  TP.desc_operacao        Operacao_Tipo
FROM 
               ECON_EMPRESTIMOS   Operacoes
               
       -- Clientes
    INNER JOIN BCLI_FIS_BASE    Pessoas_Fisicas    ON Pessoas_Fisicas.COD_CLIENTE   = Operacoes.COD_CLIENTE
    INNER JOIN BCLI_CADASTRO    Clientes      ON Clientes.COD_CLIENTE          = Operacoes.COD_CLIENTE

    -- Empresa (ve�culo legal)
    INNER JOIN BINT_VEICULO_LEGAL  Empresas      ON Operacoes.COD_VEIC_LEGAL      = Empresas.COD_VEIC_LEGAL
    
    -- Valores e par�metros do contrato
    LEFT  JOIN DFEN_CONTRATO    Contratos      ON Contratos.COD_CONTRATO        = Operacoes.COD_CONTRATO
    
    -- Cobradora
    LEFT  JOIN NCNT_CONTROLE    Cobradoras      ON Cobradoras.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER

    -- Ger�ncia de mercado
    Left Join BINT_GERENCIA_MERC  GerenciaMercado    On GerenciaMercado.COD_GER_MERCA = Operacoes.COD_GER_MERCA
  
  Left Join BTAB_ADM_SIT_ATRAS  Atraso        On Atraso.COD_SIT_ATRASO = Operacoes.COD_SIT_ATRASO

  Left Join BPRO_EMPREST_BASE    EB          ON EB.cod_produto = Operacoes.cod_produto AND EB.TIPO_OPERACAO <> 'E'
  Left Join CLIPAN.TB_TIPO_PROD  TP          On TP.TIPO_OPERACAO = EB.tipo_operacao
WHERE 
    Empresas.COD_VEIC_LEGAL              In ('001', '020', '023', '060', '101', '200', '201', '202','500','501') And
    Substr(Operacoes.COD_CONTRATO, 1, 3) <> 'CES'          And
    Pessoas_Fisicas.NUM_CPF = :p_intDocumento

Union All


SELECT
    Operacoes.COD_CLIENTE           AS Cliente_Codigo,
    Pessoas_Juridicas.NUM_CGC       AS Cliente_Documento,
    Clientes.NOME_CLIENTE           AS Cliente_Nome,

    Cobradoras.cod_cob_externa      AS Cobradora_Codigo,

    Empresas.COD_VEIC_LEGAL         AS Empresa_Codigo,
    Empresas.DESC_VEIC_LEGAL        AS Empresa_Nome,

    Operacoes.COD_CONTRATO_INTER    AS Operacao_Codigo,
    Operacoes.COD_CONTRATO          AS Operacao_Contrato,
	Operacoes.DATA_VENCTO_FINAL     AS Operacao_DataVencimento,
    Operacoes.DATA_LIBERACAO        AS Operacao_DataLiberacao,
    CASE WHEN Operacoes.DATA_CANCELAMENTO IS NULL THEN Operacoes.FLAG_LIQUIDADO
      ELSE   'C'
      END Operacao_Liquidada,
    Operacoes.COD_LOJA              AS Operacao_Loja_Codigo,
    Contratos.QTDE_PRESTACOES       AS Operacao_Parcelas,
    (QTDE_PRESTACOES - (SELECT nvl(COUNT(*), 0) FROM ECON_AMORTIZACOES WHERE ECON_AMORTIZACOES.COD_CONTRATO_INTER =  Operacoes.COD_CONTRATO_INTER AND FLAG_LIQUIDADO='S' AND DATA_AMORTIZACAO > Operacoes.DATA_LIBERACAO ) ) AS Operacao_ParcelasAbertas,
    Operacoes.COD_PRODUTO           AS Operacao_Produto_Codigo,
    Operacoes.COD_SIT_ATRASO        AS Operacao_Situacao,
    Atraso.DESC_SIT_ATRASO          AS Operacao_SituacaoDesc,
    Contratos.VAL_FINANC            AS Operacao_Valor,

    GerenciaMercado.COD_GER_MERCA   As GerenciaMercado_Codigo,
    GerenciaMercado.DESC_GER_MERCA  As GerenciaMercado_Descricao,
  TP.desc_operacao        Operacao_Tipo
FROM 
               ECON_EMPRESTIMOS   Operacoes
               
       -- Clientes
    INNER JOIN BCLI_JUR_BASE       Pessoas_Juridicas ON Pessoas_Juridicas.COD_CLIENTE = Operacoes.COD_CLIENTE
    INNER JOIN BCLI_CADASTRO       Clientes            ON Clientes.COD_CLIENTE          = Operacoes.COD_CLIENTE

    -- Empresa (ve�culo legal)
    INNER JOIN BINT_VEICULO_LEGAL Empresas           ON Operacoes.COD_VEIC_LEGAL      = Empresas.COD_VEIC_LEGAL
    
    -- Valores e par�metros do contrato
    LEFT  JOIN DFEN_CONTRATO      Contratos         ON Contratos.COD_CONTRATO        = Operacoes.COD_CONTRATO
    
    -- Cobradora
    LEFT  JOIN NCNT_CONTROLE      Cobradoras        ON Cobradoras.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER

    -- Ger�ncia de mercado
    Left Join BINT_GERENCIA_MERC  GerenciaMercado   On GerenciaMercado.COD_GER_MERCA = Operacoes.COD_GER_MERCA

  Left Join BTAB_ADM_SIT_ATRAS  Atraso         On Atraso.COD_SIT_ATRASO = Operacoes.COD_SIT_ATRASO
    
  Left Join BPRO_EMPREST_BASE    EB          ON EB.cod_produto = Operacoes.cod_produto AND EB.TIPO_OPERACAO <> 'E'
  Left Join CLIPAN.TB_TIPO_PROD  TP          On TP.TIPO_OPERACAO = EB.tipo_operacao

WHERE 
    Empresas.COD_VEIC_LEGAL              In ('001', '020', '023', '060', '101', '200', '201', '202','500') And
    Substr(Operacoes.COD_CONTRATO, 1, 3) <> 'CES'          And
    Pessoas_Juridicas.NUM_CGC = :p_intDocumento



Union All
    


SELECT
    Operacoes.COD_CLIENTE,
    Operacoes.NUM_CPF,
    Clientes.NOME_CLIENTE,

    0 AS Cod_Cobradora,
    
    Operacoes.COD_VEICULO_LEGAL,
    Empresas.DESC_VEIC_LEGAL        AS Empresa_Nome,

    Operacoes.COD_CONTRATO_INTER,
    Operacoes.COD_CONTRATO,
    Operacoes.DATA_LIBERACAO        AS Operacao_DataLiberacao,
    Operacoes.DATA_VENCTO_FINAL,
    'X' AS FLAG_LIQUIDADO,
    Operacoes.COD_LOJA,
    Operacoes.QTDE_PRESTACOES,
    0 AS PARC_ABERTO,
    Operacoes.COD_PRODUTO,
    Operacoes.COD_SIT_ATRASO,
    Atraso.DESC_SIT_ATRASO          AS Operacao_SituacaoDesc,
    Operacoes.VAL_PRINCIPAL,

    GerenciaMercado.COD_GER_MERCA   As GerenciaMercado_Codigo,
    GerenciaMercado.DESC_GER_MERCA  As GerenciaMercado_Descricao,
  TP.desc_operacao        Operacao_Tipo
FROM 
               SYSADM.EEXP_CONTRATOS Operacoes
    
    -- Clientes
    INNER JOIN BCLI_CADASTRO         Clientes        On Clientes.COD_CLIENTE          = Operacoes.COD_CLIENTE

    -- Empresa (ve�culo legal)
    INNER JOIN BINT_VEICULO_LEGAL    Empresas        On Operacoes.COD_VEICULO_LEGAL   = Empresas.COD_VEIC_LEGAL
                                     
    -- Ger�ncia de mercado           
    Left Join BINT_GERENCIA_MERC     GerenciaMercado On GerenciaMercado.COD_GER_MERCA = Operacoes.COD_GER_MERCA
  
  Left Join BTAB_ADM_SIT_ATRAS  Atraso         On Atraso.COD_SIT_ATRASO = Operacoes.COD_SIT_ATRASO

  Left Join BPRO_EMPREST_BASE    EB          ON EB.cod_produto = Operacoes.cod_produto AND EB.TIPO_OPERACAO <> 'E'
  Left Join CLIPAN.TB_TIPO_PROD  TP          On TP.TIPO_OPERACAO = EB.tipo_operacao
WHERE 
    Empresas.COD_VEIC_LEGAL      In ('001', '020', '023', '060', '101', '200', '201', '202','500') And
    Substr(Operacoes.COD_CONTRATO, 1, 3) <> 'CES'          And
    Operacoes.NUM_CPF                    =  :p_intDocumento

Order By
    Operacao_DataLiberacao Desc
