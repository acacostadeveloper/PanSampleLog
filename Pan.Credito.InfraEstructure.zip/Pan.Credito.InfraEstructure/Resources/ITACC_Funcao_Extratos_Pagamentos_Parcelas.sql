/*
Select
    REPLACE(Operacoes.[Codigo Origem],'-','') AS COD_CONTRATO_INTER,
    Previstos.Data            As DATA_AMORTIZACAO,
    Realizados.Data           As Liquidacao_Data,
    Previstos.Valor           As Liquidacao_ValorParcela,
    Realizados.Valor          As Liquidacao_ValorPago,
    Case
        When Previstos.Valor > Realizados.Valor Then
            Previstos.Valor - Realizados.Valor
        Else
            0.0
    End                       As Liquidacao_Descontos,
    Case
        When Realizados.Valor > Previstos.Valor Then
            Realizados.Valor - Previstos.Valor 
        Else
            0.0
    End                       As Liquidacao_Acrescimos
From 
               [vw_Operacoes]                As [Operacoes]  
    Inner Join [Pessoas]                     As [Contrapartes] On [Contrapartes].[Id]        = [Operacoes].[Contraparte Id]
    Inner Join [Operacoes Fluxos Realizados] As [Realizados]   On [Realizados].[Operacao Id] = [Operacoes].[Id]
    Left  Join [Operacoes Fluxos Previstos]  As [Previstos]    On [Previstos].[Id]           = [Realizados].[Fluxo Previsto Id]
Where
    Contrapartes.Documento = @Documento
Order By
    Operacoes.[Codigo Origem],
    Realizados.Data
	*/

with OP AS
(
Select 
    REPLACE(Operacoes.[Codigo Origem],'-','') AS COD_CONTRATO_INTER,
    Previstos.Data            As DATA_AMORTIZACAO,
    Realizados.Data           As Liquidacao_Data,
    Previstos.Valor           As Liquidacao_ValorParcela,
    Realizados.Valor          As Liquidacao_ValorPago,
    Case
        When Previstos.Valor > Realizados.Valor Then
            Previstos.Valor - Realizados.Valor
        Else
            0.0
    End                       As Liquidacao_Descontos,
    Case
        When Realizados.Valor > Previstos.Valor Then
            Realizados.Valor - Previstos.Valor 
        Else
            0.0
    End                       As Liquidacao_Acrescimos
From 
               [vw_Operacoes]                As [Operacoes]  
    Inner Join [Pessoas]                     As [Contrapartes] On [Contrapartes].[Id]        = [Operacoes].[Contraparte Id]
    Inner Join [Operacoes Fluxos Realizados] As [Realizados]   On [Realizados].[Operacao Id] = [Operacoes].[Id]
    Left  Join [Operacoes Fluxos Previstos]  As [Previstos]    On [Previstos].[Id]           = [Realizados].[Fluxo Previsto Id]
Where
    Contrapartes.Documento =  @documento
)
select	COD_CONTRATO_INTER,
		DATA_AMORTIZACAO,
		Liquidacao_Data,
		Liquidacao_ValorParcela,
		Liquidacao_ValorPago,
		Liquidacao_Descontos,
		Liquidacao_Acrescimos
from	OP
group
by		COD_CONTRATO_INTER,
		DATA_AMORTIZACAO,
		Liquidacao_Data,
		Liquidacao_ValorParcela,
		Liquidacao_ValorPago,
		Liquidacao_Descontos,
		Liquidacao_Acrescimos
Order By     COD_CONTRATO_INTER,    
			Liquidacao_Data