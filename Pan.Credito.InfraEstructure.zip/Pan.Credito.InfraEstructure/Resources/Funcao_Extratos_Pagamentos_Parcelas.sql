SELECT
    --OPNROPER                                                As COD_CONTRATO_INTER, 
	REPLACE(OPNROPER,'-','')                                As COD_CONTRATO_INTER,
    PADTVCTO                                                As DATA_AMORTIZACAO,
    PADTLIQ                                                 As Liquidacao_Data,
    Convert(decimal(18,2), PAVLRPR + PAVLRJR)               As Liquidacao_ValorParcela,
    Case
        When (PAVLRPR + PAVLRJR) > PAVLRPAGO Then
            Convert(decimal(18,2), (PAVLRPR + PAVLRJR) - PAVLRPAGO)
        Else
            0.0
    End                                                     As Liquidacao_Descontos,
    Case
        When (PAVLRPR + PAVLRJR) < PAVLRPAGO Then
            Convert(decimal(18,2), PAVLRPAGO - (PAVLRPR + PAVLRJR))
        Else
            0.0
    End                                                     As Liquidacao_Acrescimos
FROM 
               CDCPAN.SYSFUNC.COPER Operacoes  WITH (NOLOCK)
    Inner Join cdcpan.sysfunc.cparc Parcelas   WITH (NOLOCK) On panroper = opnroper
    Inner Join cdcpan.sysfunc.cclie Clientes   WITH (NOLOCK) On clcodcli = opcodcli
    Inner Join cdcpan.sysfunc.EFINA Movimento  WITH (NOLOCK) On efnroper = panroper And
                                                                efnrparc = panrparc And
                                                                efcntrl  = pacntrl
    Inner Join cdcpan.sysfunc.THFIN Finalidade WITH (NOLOCK) On efcodmov = hfcodmov
WHERE 
    Clientes.CLCGC      = @CPF                And
    Parcelas.PADTLIQ    Is Not Null           And
    Parcelas.PACODMOV   In ('03', '04', '11') And
    Finalidade.hfcodmov In ('200', '201', '204', '221', '501', '502', '503', 
                            '504', '505', '507', '601', '602', '603', '604', 
                            '605', '606', '607', '608', '609', '610', '611', 
                            '612', '613', '614', '615', '650', '701', '750')

Order By
    OPNROPER,
    PADTLIQ
