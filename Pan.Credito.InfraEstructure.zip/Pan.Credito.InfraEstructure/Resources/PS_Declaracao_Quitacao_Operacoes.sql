SELECT 
    Operacoes.COD_CONTRATO       As Operacao_Contrato,
    Operacoes.COD_CONTRATO_INTER AS Operacao_Codigo,
    Operacoes.DATA_LIBERACAO     AS Operacao_DataLiberacao,
    Empresas.NUM_CGC             AS Empresa_CNPJ,
    case
         when Empresas.NUM_CGC = 59285411000113 then
          'BANCO PAN S.A'
         else
          Empresas.DESC_VEIC_LEGAL
       END AS Empresa_NOME
FROM
    ECON_EMPRESTIMOS Operacoes
    INNER JOIN BINT_VEICULO_LEGAL Empresas ON Operacoes.COD_VEIC_LEGAL = Empresas.COD_VEIC_LEGAL
WHERE    
	Empresas.COD_VEIC_LEGAL     In ('001','023','101','200','201','500') And
    Substr(COD_CONTRATO, 1, 3)  <> 'CES'          And
    Operacoes.DATA_LIQ_CONTR    < SYSDATE - 7     And
    Operacoes.DATA_CANCELAMENTO IS NULL           And
    %WHERE%
ORDER BY
    Cod_contrato_inter