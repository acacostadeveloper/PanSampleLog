SELECT 
    NCNT_OCORRENCIA.Data_Inclusao    As DataInclusao,
    NCNT_OCORRENCIA.Data_Validade    As DataValidade,
    NCNT_OCORRENCIA.DATA_AMORTIZACAO As DataParcela,
    NCNT_OCORRENCIA.Cod_Atraso       As Codigo,
    NTAB_PARAMETROS.Desc_Atraso      As Nome,
    NCNT_OCORRENCIA.Tipo_Acao        As AcaoCodigo,
    DECODE(NCNT_OCORRENCIA.TIPO_ACAO,
            'N', 'Gera��o Normal',
            'C', 'Comandada',
            'G', 'Geral',
            'F', 'Gerado',
            'E', 'Exce��o Contrato',
            'X', 'Exce��o Atend. Pend.',
            'A', 'N�o Confirmada',
            'B', 'Confirmada',
            'D', 'Rejeitada',
            'H', 'Carga',
            'J', 'Aguardando Retorno',
            'K', 'Positivo Ar',
            'L', 'Positivo Judicial',
            'M', 'Negativo Ar',
            'O', 'Negativo Judicial',
            'Outros')                As Acao,
    Flag_Acao,
    Data_Acao
FROM 
               NCNT_OCORRENCIA
    INNER JOIN ECON_EMPRESTIMOS ON ECON_EMPRESTIMOS.COD_CONTRATO_INTER  = NCNT_OCORRENCIA.COD_CONTRATO_INTER
    INNER JOIN NTAB_PARAMETROS  ON NTAB_PARAMETROS.COD_ATRASO           = NCNT_OCORRENCIA.COD_ATRASO
WHERE 
    NCNT_OCORRENCIA.COD_ATRASO                  In (%WhereCodAtraso%) And
    NVL(NCNT_OCORRENCIA.Data_Validade, SYSDATE) >= Trunc(SYSDATE)     And
    ECON_EMPRESTIMOS.COD_CONTRATO_INTER          = :p_intContratoInterno
ORDER BY
    NCNT_OCORRENCIA.Data_inclusao