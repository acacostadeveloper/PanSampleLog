With
Saldos 
As
(
    Select
        [Valor],
        [Operacao Id]
    From
        [Operacoes Saldos]
    Where
        [Data] = @Data
)
Select
    Operacoes.[Codigo Origem] As Operacao_Contrato,
    Operacoes.[Codigo Origem] AS Operacao_Codigo,
    Operacoes.Data            AS Operacao_DataLiberacao,
    Saldos.Valor              As Operacao_Saldo,
    @Data                     As Operacao_Saldo_Data,
    Partes.CNPJ               AS Empresa_CNPJ,
    Partes.[Razao Social]     AS Empresa_NOME
From 
               [vw_Operacoes]      As [Operacoes]  
    Inner Join [Pessoas Juridicas] As [Partes]       On [Partes].[Pessoa Id] = [Operacoes].[Parte Id]
    Inner Join [Pessoas]           As [Contrapartes] On [Contrapartes].[Id]  = [Operacoes].[Contraparte Id]
    Left  Join [Saldos]                              On [Operacoes].[Id]     = [Saldos].[Operacao Id]
Where
    Contrapartes.Documento = @Documento
Order By
    Operacoes.Data
