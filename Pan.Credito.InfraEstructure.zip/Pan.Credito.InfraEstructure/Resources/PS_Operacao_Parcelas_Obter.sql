SELECT
    Parcelas.COD_CONTRATO_INTER,    --  PRIMARY KEY ,  FOREIGN KEY  ECON_EMPRESTIMOS (COD_CONTRATO_INTER)
    Parcelas.DATA_AMORTIZACAO,      --  PRIMARY KEY

    Parcelas.COD_PROMOTORA,         --  FOREIGN KEY  VTAB_PROMOTORAS    (COD_PROMOTORA)
    
    --Parcelas.DATA_LIQUIDACAO,
    -- Data da liquida��o
    (SELECT 
         Max(Data_Valor)
     FROM 
                    ECON_FLUXO_CAIXA  Fluxo 
         INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
     WHERE 
         Fluxo.COD_ORGAO                Is Not Null                    And
         Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
         Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
         Fluxo.COD_EVENTO_FLUXO         = 1                            And 
         NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
    ) AS DATA_LIQUIDACAO,

    Parcelas.FLAG_BAIXA_TOTAL,
    Parcelas.FLAG_COOBRIGADO,
    Parcelas.FLAG_EMIS_COBR,
    Parcelas.FLAG_ESTORNO_N,        --  'Se S - Ocorreu estorno Se Nulo - Sem Estorno'
    Parcelas.FLAG_LIQ_ANTEC,
    Parcelas.FLAG_LIQUIDADO,
	CASE WHEN Parcelas.FLAG_LIQUIDADO = 'S' THEN 1 ELSE 0 END Parcela_Liquidado,
    Parcelas.FLAG_TEVE_ESTORNO,
    CLIPAN.NUMBER_PARC (Operacoes.COD_CONTRATO_INTER, Operacoes.DATA_LIBERACAO, Parcelas.DATA_AMORTIZACAO) AS NUM_PARCELA,
    Parcelas.QTD_DIAS_ATRASO,
    Parcelas.TIPO_AMTZ_JUR,
    Parcelas.TIPO_AMTZ_PRINC,
    Parcelas.TIPO_LIQUIDACAO,
    Parcelas.TIPO_ORGAO_REC_N,      --  'Tipo do Orgao de Recebimento ou Estorno'
    Parcelas.VAL_AMTZ_JUR,
    Parcelas.VAL_AMTZ_PRINC,
    Parcelas.VAL_ANT_JRMN,
    Parcelas.VAL_ANT_PMN,
    Parcelas.VAL_ANTEC_CMMN,
    Parcelas.VAL_ANTEC_TOTMN,
    Parcelas.VAL_AZ_JRC1_PGMN,
    Parcelas.VAL_AZ_JRC2_PGMN,
    Parcelas.VAL_AZ_PRINC_PMNC1,
    Parcelas.VAL_AZ_PRINC_PMNC2,
    Parcelas.VAL_CALCPG_JR,
    Parcelas.VAL_CALCPG_JRC2,       --  'Valor do c�lculo de juros curva 2'
    Parcelas.VAL_CALCPG_PRINC,
    Parcelas.VAL_LIQ_JRC2,
    Parcelas.VAL_LIQ_PARCELA,
    Parcelas.VAL_SALDO_MORA,
    Parcelas.VALOR_RECEBIDO_N,      --  'Valor Pago pelo Cliente'
    NVL(df_CTT.VAL_VRG_PARC,0) VAL_VRG_PARC,

    -- Valor da parcela
    (SELECT 
          Sum(Fluxo.Val_Realizado) 
      FROM 
                     ECON_FLUXO_CAIXA  Fluxo 
          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
      WHERE 
          Fluxo.COD_ORGAO          Is Not Null                    And
          Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And
          Fluxo.Data_Amortizacao   = Parcelas.Data_Amortizacao    And 
          Fluxo.COD_EVENTO_FLUXO   = 1                            And
          Fluxo.DATA_VALOR         = (SELECT 
                                          Max(Data_Valor)
                                      FROM 
                                                     ECON_FLUXO_CAIXA  Fluxo 
                                          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
                                      WHERE 
                                          Fluxo.COD_ORGAO                Is Not Null                    And
                                          Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
                                          Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
                                          Fluxo.COD_EVENTO_FLUXO         = 1                            And 
                                          NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
                                     )
    )  AS ParcelaValor,


    -- Acr�scimos
    (SELECT 
          NVL(Sum(Fluxo.Val_Realizado), 0.0) 
     FROM 
                     ECON_FLUXO_CAIXA  Fluxo 
          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
     WHERE 
          Fluxo.COD_ORGAO          Is Not Null                    And
          Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And 
          Fluxo.Data_Amortizacao   = Parcelas.Data_Amortizacao    And
          Fluxo.COD_EVENTO_FLUXO   Not In (1, 621, 622)           And 
          Eventos.TIPO_MOVTO       = 'C'                          And
          Fluxo.DATA_VALOR         = (SELECT 
                                          Max(Data_Valor)
                                      FROM 
                                                     ECON_FLUXO_CAIXA  Fluxo 
                                          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
                                      WHERE 
                                          Fluxo.COD_ORGAO                Is Not Null                    And
                                          Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
                                          Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
                                          Fluxo.COD_EVENTO_FLUXO         = 1                            And 
                                          NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
                                     )
    ) AS ParcelaAcrescimos,


    -- Descontos
    (SELECT 
         NVL(Sum(Fluxo.Val_Realizado), 0.0)
     FROM 
                    ECON_FLUXO_CAIXA  Fluxo 
         INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
     WHERE
         Fluxo.COD_ORGAO          Is Not Null                    And
         Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And 
         Fluxo.Data_Amortizacao   = Parcelas.Data_Amortizacao    And
         Fluxo.COD_EVENTO_FLUXO   Not In (1, 621, 622)           And 
         Eventos.TIPO_MOVTO       = 'D'                          And
         Fluxo.DATA_VALOR         = (SELECT 
                                          Max(Data_Valor)
                                      FROM 
                                                     ECON_FLUXO_CAIXA  Fluxo 
                                          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
                                      WHERE 
                                          Fluxo.COD_ORGAO                Is Not Null                    And
                                          Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
                                          Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
                                          Fluxo.COD_EVENTO_FLUXO         = 1                            And 
                                          NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
                                    )
    ) AS ParcelaDescontos,



    -- Cess�o de parcela
    Cessoes.COD_CESSAO        As Cessao_Codigo,
    Cessoes.DATA_CESSAO       As Cessao_Data,
    Cessoes.FLAG_COOBRIGADO   As Cessao_Coobrigado,
    Bancos.COD_BANCO          As Cessao_Banco_Codigo,
    Bancos.NOME_BANCO         As Cessao_Banco_Nome


    --Parcelas.IDX_ADIC_PRINC     ,    --  FOREIGN KEY  BTAB_ADM_INDEXADOR (COD_INDEXADOR)
    --Parcelas.IDX_AMTZ_CA        ,    --  FOREIGN KEY  BTAB_ADM_INDEXADOR (COD_INDEXADOR)
    --Parcelas.IDX_AMTZ_OUTR_CA   ,    --  FOREIGN KEY  BTAB_ADM_INDEXADOR (COD_INDEXADOR)

    --Parcelas.BANCO_CESSAO_PARC  ,    --
    --Parcelas.COD_AQUISICAO      ,    --  'Codigo de Carga de Aquisicao de Credito.'
    --Parcelas.COD_CESSAO         ,    --  'C�digo da Cessao'
    --Parcelas.COD_LOJA           ,    --
    --Parcelas.COD_OCOR_INSS      ,    --
    --Parcelas.COD_ORGAO_N        ,    --  'Codigo do Orgao de Recebimento ou Estorno'
    --Parcelas.CONTR_LIQ_ARQ      ,    --
    --Parcelas.DATA_ANT_ALUG_CTB  ,    --  'Data do recebimento antecipado de aluguel'
    --Parcelas.DATA_APR_RENDAS    ,    --
    --Parcelas.DATA_ATU_PARC_MGER ,    --
    --Parcelas.DATA_CESSAO_PARCEL ,    --
    --Parcelas.DATA_CONTABIL      ,    --
    --Parcelas.DATA_DIF_F_CA      ,    --
    --Parcelas.DATA_DIF_F_OUTR_CA ,    --
    --Parcelas.DATA_DIF_I_CA      ,    --
    --Parcelas.DATA_DIF_I_OUTR_CA ,    --
    --Parcelas.DATA_INTEGRACAO_N  ,    --  'Data de Integracao do Pagamento para Smov'
    --Parcelas.DATA_INTERF_AVERB  ,    --  'Data de gera��o / retorno da parcela averbada'
    --Parcelas.DATA_INTERF_PARC   ,    --
    --Parcelas.DATA_INTERF_REMES  ,    --
    --Parcelas.FATOR_VRG_PARCELA  ,    --
    --Parcelas.FLAG_AMTZ_CA_SEM   ,    --
    --Parcelas.FLAG_AMTZ_OUT_SEM  ,    --
    --Parcelas.FLAG_ANT_ALUG_CTB  ,    --
    --Parcelas.FLAG_CARGA_AVERB   ,    --  'Flag de Controle para o Cobol AVERB004 incluir esses registros no processamento quando o conte�do for = 1.'
    --Parcelas.FLAG_CONTABILIZ    ,    --
    --Parcelas.FLAG_ENVIO_CACS    ,    --
    --Parcelas.FLAG_INCID_CA      ,    --
    --Parcelas.FLAG_INCID_OUTR_CA ,    --
    --Parcelas.FLAG_INTERF_AVERB  ,    --  '1 - Pendente; 2 - Gerado; 3 - Retorno; 4 - Retorno com erro; 5 - Relat�rio de inconsist�ncias'
    --Parcelas.FLAG_INTERF_CONTRL ,    --
    --Parcelas.FLAG_INTERF_PARC   ,    --
    --Parcelas.FLAG_INTERF_REMES  ,    --
    --Parcelas.MES_CARGA_AVERB    ,    --  'Data de Controle do Arquivo de Remessa Gerado.'
    --Parcelas.NUM_CAUCAO         ,    --
    --Parcelas.NUM_DOCUMENTO      ,    --
    --Parcelas.NUM_PARCELA        ,    --
    --PERI_TAXA_CA       ,    --
    --PERI_TAXA_OUTR_CA  ,    --
    --Parcelas.TIPO_AMTZ_CA       ,    --
    --Parcelas.TIPO_AMTZ_CM       ,    --
    --Parcelas.TIPO_AMTZ_CP       ,    --
    --Parcelas.TIPO_AMTZ_IR       ,    --
    --Parcelas.TIPO_AMTZ_OUTR_CA  ,    --
    --Parcelas.TIPO_AMTZ_OUTR_CP  ,    --
    --Parcelas.TIPO_AMTZ_VRG_FIM  ,    --
    --Parcelas.TIPO_CV_CA         ,    --
    --Parcelas.TIPO_CV_OCA        ,    --
    --Parcelas.TIPO_TAXA_CA       ,    --
    --Parcelas.TIPO_TAXA_OUTR_CA  ,    --
    --Parcelas.TIPO_VAL_ADIC_PRIN ,    --
    --Parcelas.TIPO_VALOR_CA      ,    --
    --Parcelas.TIPO_VALOR_OCA     ,    --
    --Parcelas.VAL_ADIC_PRINC     ,    --
    --Parcelas.VAL_ADIC_PRINC_PME ,    --
    --Parcelas.VAL_ADIC_PRINC_PMN ,    --
    --Parcelas.VAL_AMTZ_CA        ,    --
    --Parcelas.VAL_AMTZ_CA_PG     ,    --
    --Parcelas.VAL_AMTZ_CM        ,    --
    --Parcelas.VAL_AMTZ_CP        ,    --
    --Parcelas.VAL_AMTZ_CP_PG     ,    --
    --Parcelas.VAL_AMTZ_CP_PGME   ,    --
    --Parcelas.VAL_AMTZ_IR        ,    --
    --Parcelas.VAL_AMTZ_IR_PG     ,    --
    --Parcelas.VAL_AMTZ_JR_CV_TB  ,    --
    --Parcelas.VAL_AMTZ_JR_CV_TL  ,    --
    --Parcelas.VAL_AMTZ_OCP_PG    ,    --
    --Parcelas.VAL_AMTZ_OCP_PGME  ,    --
    --Parcelas.VAL_AMTZ_OUTCA_PG  ,    --
    --Parcelas.VAL_AMTZ_OUTR_CA   ,    --
    --Parcelas.VAL_AMTZ_OUTR_CP   ,    --
    --Parcelas.VAL_AMTZ_PR_CV_TB  ,    --
    --Parcelas.VAL_AMTZ_PR_CV_TL  ,    --
    --Parcelas.VAL_AMTZ_PRINC_PME ,    --
    --Parcelas.VAL_AMTZ_TAXA_FLUT ,    --
    --Parcelas.VAL_ANT_JRME       ,    --
    --Parcelas.VAL_ANT_PME        ,    --
    --Parcelas.VAL_ATU_PARC_MGER  ,    --
    --Parcelas.VAL_AZ_CMC1_PGMN   ,    --
    --Parcelas.VAL_AZ_CMC2_PGMN   ,    --
    --Parcelas.VAL_AZ_JRC1_PGME   ,    --
    --Parcelas.VAL_AZ_JRC2_PGME   ,    --
    --Parcelas.VAL_CALCPG_CM      ,    --
    --Parcelas.VAL_CALCPG_CP      ,    --
    --Parcelas.VAL_CALCPG_IR      ,    --
    --Parcelas.VAL_CALCPG_OCP     ,    --
    --Parcelas.VAL_FATOR_CORRECAO ,    --
    --Parcelas.VAL_FATOR_VRG_FIM  ,    --
    --Parcelas.VAL_JUROS_ANTEC    ,    --
    --Parcelas.VAL_LIQ_SDJUR_GER  ,    --
    --Parcelas.VAL_LIQ_SDMO_EXJUD ,    --
    --Parcelas.VAL_LIQ_SDMORA_GER ,    --
    --Parcelas.VAL_MARCADO        ,    --  'Valor pago mas n�o confirmado pelo empregador'
    --Parcelas.VAL_PARC_AQUIS     ,    --  'Valor Comprado na Aquisicao de Credito.'
    --Parcelas.VAL_PARCELA_ATUAL  ,    --  'Valor da parcela'
    --Parcelas.VAL_PARCELA_CESSAO ,    --  'Valor da parcela de cess�o'
    --Parcelas.VAL_PROVISAO_ISS   ,    --
    --Parcelas.VAL_PROVISAO_PIS   ,    --
    --Parcelas.VAL_SDJUR_GERENC   ,    --
    --Parcelas.VAL_SDMORA_EXJUDIC ,    --  'Valor de saldo de mora extrajudicial'
    --Parcelas.VAL_SDMORA_GERENC  ,    --
    --Parcelas.VAL_TAXA_CA        ,    --
    --Parcelas.VAL_TAXA_FLUT_IR   ,    --
    --Parcelas.VAL_TAXA_OUTR_CA   ,    --
    --Parcelas.VAL_TAXA_PRINC     ,    --
    --Parcelas.VAL_VRG_FIM_CALC   ,    --
    --Parcelas.VAL_VRG_FIM_LIQ    ,    --
    --Parcelas.VAL_VRG_FIM_PG     ,    --
    --Parcelas.VAL_VRG_FINAL      ,    --
    --Parcelas.VAL_VRG_INI_PG     ,    --
    --Parcelas.VAL_VRG_INICIAL    ,    --
FROM
               ECON_AMORTIZACOES Parcelas
    Inner Join ECON_EMPRESTIMOS  Operacoes On Parcelas.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And
                                              Parcelas.DATA_AMORTIZACAO   > Operacoes.DATA_LIBERACAO
    Left Join  ECON_BORD_SEL_CES Cessoes   On Parcelas.COD_CESSAO         = Cessoes.COD_CESSAO
    Left Join  BTAB_ADM_BANCOS   Bancos    On Bancos.COD_BANCO            = Cessoes.COD_BANCO
	Left join dfen_contrato      df_CTT    On df_CTT.Cod_Contrato         = Operacoes.Cod_Contrato
WHERE
    Operacoes.COD_CONTRATO_INTER = :p_intContratoInterno
ORDER BY
    Parcelas.DATA_AMORTIZACAO