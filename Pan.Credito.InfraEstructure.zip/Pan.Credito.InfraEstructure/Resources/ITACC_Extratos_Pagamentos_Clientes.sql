Select Top 1
    Id          AS Cliente_Codigo,
    Documento   AS Cliente_Documento,
    Case
        When Tipo = 0 Then  
            'F'
        Else
            'J'
    End         AS Cliente_TipoPessoa,
    Nome        AS Cliente_Nome
From 
    Pessoas WITH (NOLOCK)
Where
    Documento = @Documento


