Select
    OPNROPER                 As Operacao_Contrato,
    OPNROPER                 AS Operacao_Codigo,
    OPDTBASE                 AS Operacao_DataLiberacao,
     59285411000113          AS Empresa_CNPJ,
    'Banco Panamericano S/A' AS Empresa_NOME
From
               CDCPAN.SYSFUNC.COPER Operacoes WITH (NOLOCK)
    Inner Join CDCPAN.SYSFUNC.CCLIE Clientes  WITH (NOLOCK) On Clientes.CLCODCLI = Operacoes.OPCODCLI
Where
    Clientes.CLCGC = @CPF
ORDER BY
    Operacoes.OPDTBASE
