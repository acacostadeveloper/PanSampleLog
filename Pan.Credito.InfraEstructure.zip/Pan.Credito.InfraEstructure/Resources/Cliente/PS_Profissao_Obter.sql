select COD_GRUPO_PROFIS		Codigo_Profissao
		,DESC_GRUPO_PROFIS	Descricao_Profissao
from Btab_Int_Gr_Prof