Select
   C.DTHORA_ATUALIZ		Cliente_Atualizacao
  ,TIPO_CLIENTE			Cliente_TipoPessoa
  ,NOME_CLIENTE			Cliente_Nome
  ,C.COD_CLIENTE		Cliente_Codigo
  ,NUM_CPF				Cliente_Documento
  ,C.COD_PAIS			Cliente_Pais
  ,SIGLA_UF_NATU		Cliente_Uf_Naturalidade
  ,DATA_NASCIMENTO		Cliente_DataNascimento
  ,DESC_NATURALIDADE	Cliente_Naturalidade
  ,NUM_RG				Cliente_RG
  ,COD_ORG_EMIS			Cliente_Emissor_RG
  ,DATA_EXP_RG			Cliente_Data_Expedicao_RG
  ,SIGLA_UF_RG			Cliente_Uf_RG
  ,CASE WHEN COD_SEXO = 'M' THEN 1 ELSE 2 END				Cliente_Sexo
  ,PF.COD_ESTADO_CIVIL	Cliente_Estado_Civil
  ,NOME_PAI				Cliente_Pai
  ,NOME_MAE				Cliente_Mae
FROM BCLI_CADASTRO C
    Inner JOIN BCLI_FIS_BASE PF ON C.COD_CLIENTE = PF.COD_CLIENTE
    --LEFT JOIN btab_int_estcivil EC ON EC.COD_ESTADO_CIVIL = PF.COD_ESTADO_CIVIL
    LEFT JOIN BTAB_OFI_PAIS OP ON OP.COD_PAIS = C.COD_PAIS
WHERE
    PF.NUM_CPF = :Documento

UNION

SELECT
  C.DTHORA_ATUALIZ		Cliente_Atualizacao
  ,C.TIPO_CLIENTE		Cliente_TipoPessoa
  ,C.NOME_CLIENTE		Cliente_Nome
  ,C.COD_CLIENTE		Cliente_Codigo
  ,PJ.NUM_CGC			Cliente_Documento
  ,NULL					Cliente_Pais
  ,NULL					Cliente_Uf_Naturalidade
  ,PJ.DATA_ABERTURA		Cliente_DataNascimento
  ,NULL					Cliente_Naturalidade
  ,NULL					Cliente_RG
  ,NULL					Cliente_Emissor_RG
  ,NULL					Cliente_Data_Expedicao_RG
  ,NULL					Cliente_Uf_RG
  ,NULL					Cliente_Sexo
  ,NULL					Cliente_Estado_Civil
  ,NULL					Cliente_Pai
  ,NULL					Cliente_Mae
FROM
               BCLI_CADASTRO C
    Inner JOIN BCLI_JUR_BASE PJ ON C.COD_CLIENTE = PJ.COD_CLIENTE
WHERE
    PJ.NUM_CGC = :Documento
ORDER BY Cliente_Atualizacao desc