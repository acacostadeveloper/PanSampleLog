SELECT
    Operacoes.COD_CLIENTE			AS Cliente_Codigo,
    Pessoas_Fisicas.NUM_CPF			AS Cliente_Documento,
    Clientes.NOME_CLIENTE           AS Cliente_Nome,

    Cobradoras.cod_cob_externa      AS Cobradora_Codigo,

    Empresas.COD_VEIC_LEGAL     	AS Empresa_Codigo,
    Empresas.DESC_VEIC_LEGAL    	AS Empresa_Nome,

    Operacoes.COD_CONTRATO_INTER    AS Operacao_Codigo,
    Operacoes.COD_CONTRATO			AS Operacao_Contrato,
    Operacoes.DATA_LIBERACAO        AS Operacao_DataLiberacao,
    Operacoes.DATA_VENCTO_FINAL     AS Operacao_DataVencimento,
    Operacoes.FLAG_LIQUIDADO        AS Operacao_Liquidada,
    Operacoes.COD_LOJA              AS Operacao_Loja_Codigo,
    Contratos.QTDE_PRESTACOES       AS Operacao_Parcelas,
    (QTDE_PRESTACOES - (SELECT nvl(COUNT(*), 0) FROM ECON_AMORTIZACOES WHERE ECON_AMORTIZACOES.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER AND FLAG_LIQUIDADO='S' AND DATA_AMORTIZACAO > Operacoes.DATA_LIBERACAO ) ) AS Operacao_ParcelasAbertas,
    Operacoes.COD_PRODUTO           AS Operacao_ProdutoCodigo,
    Operacoes.COD_SIT_ATRASO        AS Operacao_Situacao,
    Contratos.VAL_FINANC            AS Operacao_Valor
FROM 
    		   ECON_EMPRESTIMOS   Operacoes
    		   
   	-- Clientes
    INNER JOIN BCLI_FIS_BASE 	  Pessoas_Fisicas   ON Pessoas_Fisicas.COD_CLIENTE   = Operacoes.COD_CLIENTE
    INNER JOIN BCLI_CADASTRO 	  Clientes		    ON Clientes.COD_CLIENTE          = Operacoes.COD_CLIENTE

    -- Empresa (ve�culo legal)
    INNER JOIN BINT_VEICULO_LEGAL Empresas   		ON Operacoes.COD_VEIC_LEGAL      = Empresas.COD_VEIC_LEGAL
    
    -- Valores e par�metros do contrato
    LEFT  JOIN DFEN_CONTRATO      Contratos         ON Contratos.COD_CONTRATO        = Operacoes.COD_CONTRATO
    
    -- Cobradora
    LEFT  JOIN NCNT_CONTROLE      Cobradoras        ON Cobradoras.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER
WHERE 
    Empresas.COD_VEIC_LEGAL              In ('001', '020', '023', '060', '101', '200', '201', '202','500') And
    Substr(Operacoes.COD_CONTRATO, 1, 3) <> 'CES'          And
    (
        Pessoas_Fisicas.NUM_CPF = :p_intDocumento Or
        Operacoes.COD_CONTRATO  = :p_strContrato
    )

Union All


SELECT
    Operacoes.COD_CLIENTE			AS Cliente_Codigo,
    Pessoas_Juridicas.NUM_CGC 		AS Cliente_Documento,
    Clientes.NOME_CLIENTE           AS Cliente_Nome,

    Cobradoras.cod_cob_externa      AS Cobradora_Codigo,

    Empresas.COD_VEIC_LEGAL     	AS Empresa_Codigo,
    Empresas.DESC_VEIC_LEGAL    	AS Empresa_Nome,

    Operacoes.COD_CONTRATO_INTER    AS Operacao_Codigo,
    Operacoes.COD_CONTRATO			AS Operacao_Contrato,
    Operacoes.DATA_VENCTO_FINAL     AS Operacao_DataVencimento,
    Operacoes.DATA_LIBERACAO        AS Operacao_DataLiberacao,
    Operacoes.FLAG_LIQUIDADO        AS Operacao_Liquidada,
    Operacoes.COD_LOJA              AS Operacao_Loja_Codigo,
    Contratos.QTDE_PRESTACOES       AS Operacao_Parcelas,
    (QTDE_PRESTACOES - (SELECT nvl(COUNT(*), 0) FROM ECON_AMORTIZACOES WHERE ECON_AMORTIZACOES.COD_CONTRATO_INTER =  Operacoes.COD_CONTRATO_INTER AND FLAG_LIQUIDADO='S' AND DATA_AMORTIZACAO > Operacoes.DATA_LIBERACAO ) ) AS Operacao_ParcelasAbertas,
    Operacoes.COD_PRODUTO           AS Operacao_Produto_Codigo,
    Operacoes.COD_SIT_ATRASO        AS Operacao_Situacao,
    Contratos.VAL_FINANC            AS Operacao_Valor
FROM 
    		   ECON_EMPRESTIMOS   Operacoes
    		   
   	-- Clientes
    INNER JOIN BCLI_JUR_BASE 	  Pessoas_Juridicas ON Pessoas_Juridicas.COD_CLIENTE = Operacoes.COD_CLIENTE
    INNER JOIN BCLI_CADASTRO 	  Clientes		    ON Clientes.COD_CLIENTE          = Operacoes.COD_CLIENTE

    -- Empresa (ve�culo legal)
    INNER JOIN BINT_VEICULO_LEGAL Empresas   		ON Operacoes.COD_VEIC_LEGAL      = Empresas.COD_VEIC_LEGAL
    
    -- Valores e par�metros do contrato
    LEFT  JOIN DFEN_CONTRATO      Contratos         ON Contratos.COD_CONTRATO        = Operacoes.COD_CONTRATO
    
    -- Cobradora
    LEFT  JOIN NCNT_CONTROLE      Cobradoras        ON Cobradoras.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER
WHERE 
    Empresas.COD_VEIC_LEGAL              In ('001', '020', '023', '060', '101', '200', '201', '202','500') And
    Substr(Operacoes.COD_CONTRATO, 1, 3) <> 'CES'          And
    Pessoas_Juridicas.NUM_CGC = :p_intDocumento



Union All
    
SELECT
    A.COD_CLIENTE,
    A.NUM_CPF,
    BCLI_CADASTRO.NOME_CLIENTE,

    0 AS Cod_Cobradora,
    
    A.COD_VEICULO_LEGAL,
    Empresas.DESC_VEIC_LEGAL    	AS Empresa_Nome,

    A.COD_CONTRATO_INTER,
    A.COD_CONTRATO,
    A.DATA_LIBERACAO,
    A.DATA_VENCTO_FINAL,
    'X' AS FLAG_LIQUIDADO,
    A.COD_LOJA,
    A.QTDE_PRESTACOES,
    0 AS PARC_ABERTO,
    A.COD_PRODUTO,
    A.COD_SIT_ATRASO,
    A.VAL_PRINCIPAL
FROM 
    SYSADM.EEXP_CONTRATOS A
    
    INNER JOIN BCLI_CADASTRO ON BCLI_CADASTRO.COD_CLIENTE = A.COD_CLIENTE

    -- Empresa (ve�culo legal)
    INNER JOIN BINT_VEICULO_LEGAL Empresas   		ON A.COD_VEICULO_LEGAL      = Empresas.COD_VEIC_LEGAL

WHERE 
    Empresas.COD_VEIC_LEGAL      In ('001', '020', '023', '060', '101', '200', '201', '202','500') And
    Substr(A.COD_CONTRATO, 1, 3) <> 'CES'          And
    A.NUM_CPF                    =  :p_intDocumento