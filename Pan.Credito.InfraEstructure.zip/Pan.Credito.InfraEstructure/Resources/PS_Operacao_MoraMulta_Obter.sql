SELECT
    PRIORIDADE,
    RN,
    COD_CONTRATO,
    MULTA, 
    JUROS_REMUNERATORIOS, 
    MORA , 
    DT_REF_TABELA , 
    DT_INC_PROPOSTA
FROM
   (SELECT 
        1                         AS PRIORIDADE,
   		ROWNUM                    AS RN,
		Operacoes.COD_CONTRATO,
		Encargos.VALOR_MULTA  	  AS MULTA, 
		Encargos.TAXA_CP 		  AS JUROS_REMUNERATORIOS, 
		Encargos.VALOR_MORA 	  AS MORA , 
		Encargos.DATA_REFERENCIA  AS DT_REF_TABELA , 
		Operacoes.DTHORA_INCLUSAO AS DT_INC_PROPOSTA
	FROM 
				   ECON_EMPRESTIMOS Operacoes 
	 	INNER JOIN VCAD_LOJA_CARAC  Loja      ON Loja.COD_PRODUTO          = Operacoes.COD_PRODUTO    AND 
	 	                                         Loja.COD_LOJA             = Operacoes.COD_LOJA_PARAM
		INNER JOIN VTAB_CARAC_MORA  Encargos  ON Encargos.cod_mora_multa   = Loja.COD_MORA_MULTA      AND 
		                                         Encargos.data_referencia <= Operacoes.DTHORA_INCLUSAO
	WHERE 
		%CONTRATO%
	ORDER BY 	
		Encargos.DATA_REFERENCIA DESC)
WHERE
	ROWNUM <= 1
	

UNION ALL

SELECT
    PRIORIDADE,
    RN,
    COD_CONTRATO,
    MULTA, 
    JUROS_REMUNERATORIOS, 
    MORA , 
    DT_REF_TABELA , 
    DT_INC_PROPOSTA
FROM
   (SELECT 
        0                         AS PRIORIDADE,
        ROWNUM                    AS RN,
        Operacoes.COD_CONTRATO,
        Encargos.VALOR_MULTA      AS MULTA, 
        Encargos.TAXA_CP          AS JUROS_REMUNERATORIOS, 
        Encargos.VALOR_MORA       AS MORA , 
        Encargos.DATA_REFERENCIA  AS DT_REF_TABELA , 
        Operacoes.DTHORA_INCLUSAO AS DT_INC_PROPOSTA
    FROM 
                   ECON_EMPRESTIMOS Operacoes 
        INNER JOIN VCAD_LOJA_CARAC  Loja      ON Loja.COD_PRODUTO          = Operacoes.COD_PRODUTO    AND 
                                                 Loja.COD_LOJA             = Operacoes.COD_LOJA_PARAM
        INNER JOIN VTAB_CARAC_MORA  Encargos  ON Encargos.cod_mora_multa   = Loja.COD_MORA_MULTA      AND 
                                                 Encargos.data_referencia <= Operacoes.DTHORA_INCLUSAO
    WHERE 
        %CONTRATO% AND
        Loja.COD_LOJA          = 99999
    ORDER BY    
        Encargos.DATA_REFERENCIA DESC)
WHERE
    ROWNUM <= 1

ORDER BY
    PRIORIDADE
