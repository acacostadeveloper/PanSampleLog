SELECT B.COD_CONTRATO   Operacao_Contrato, 
  A.NUM_CGC             Cliente_Documento,
  C.NOME_CLIENTE		Cliente_Nome,
  'J'                   Cliente_TipoPessoa,
  B.COD_LOJA, 
  B.NUM_TRANSACAO,
  B.VAL_PRINCIPAL       Operacao_Valor, 
  B.QTDE_PARCELAS_ORIG  Operacao_Parcelas, 
  B.DATA_PRIM_PARC      Operacao_PrimeiroVencimento, 
  B.COD_PRODUTO         Operacao_ProdutoCodigo, 
  B.DTHORA_ANALIS_INI   Operacao_InicioAtendimento, 
  B.TIPO_SIT_CONTRATO   Operacao_TipoSituacao,
  CASE     
    WHEN      B.tipo_sit_contrato        = '1'     
        AND  nvl(B.tipo_aprov_cred,'A') = 'A'     
        AND  t.cod_usu_aprov_exc   IS NULL                     THEN '01 - PROP. APROVADA AUTOMATICAMENTE'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_aprov_cred     = 'A'     
        AND  t.cod_usu_aprov_exc   IS NULL     
        AND  B.tipo_sit_contrato   = 'Z'                       THEN '05 - PROP. APROVADA AUT. EXPIRADA' 
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_aprov_cred     = 'A'     
        AND  B.tipo_sit_contrato   = '9'                       THEN '04 - PROP. APROVADA AUT. CANCELADA'    
    WHEN      B.tipo_sit_contrato   = '1'     
        AND  B.FLAG_INTEGRAR       = 'R'     
        AND  B.tipo_aprov_cred     = 'A'                       THEN '03 - PROP. APROVADA AUT. RECUSADO'    
    WHEN      B.tipo_sit_contrato   = '1'    
        AND  B.tipo_aprov_cred     = 'M'                       THEN '01 - PROP. APROVADA PELA ANALISE'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_sit_contrato   = '9'     
        AND  B.tipo_aprov_cred     = 'M'                       THEN '04 - PROP. APROVADA PELA ANALISE CANCELADA'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_aprov_cred     = 'M'     
        AND  B.tipo_sit_contrato   = 'Z'                       THEN '05 - PROP. APROVADA PELA ANALISE EXPIRADA'    
    WHEN      B.tipo_sit_contrato   = '1'     
        AND  B.tipo_aprov_cred     = 'R'                       THEN '01 - PROP. APROVADA PELA REANALISE'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_sit_contrato   = 'Z'     
        AND  B.tipo_aprov_cred     = 'R'                       THEN '05 - PROP. APROVADA PELA REANALISE EXPIRADA'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_sit_contrato   = '9'     
        AND  B.tipo_aprov_cred     = 'R'                       THEN '04 - PROP. APROVADA PELA REANALISE CANCELADA '    
    WHEN ((   B.TIPO_SIT_CONTRATO   = '2'      
        AND  B.TIPO_APROV_CRED      IN ('A','B'))     
        OR (B.TIPO_SIT_CONTRATO    IN ('Z','9')      
        AND  B.TIPO_APROV_CRED      IN ('A','B')      
        AND  B.TIPO_SIT_CONTR_ANT   = '2'))                    THEN '03 - PROP. REPROVADA AUTOMATICAMENTE'    
    WHEN ((   B.tipo_sit_contrato = '2' AND B.tipo_aprov_cred = 'M')    
        OR (    B.tipo_sit_contrato IN ('Z', '9')                         
        AND B.tipo_aprov_cred = 'M'                                          
        AND B.tipo_sit_contr_ant = '2' ) )                     THEN '03 - PROP. REPROVADA PELA ANALISE'    
    WHEN      B.TIPO_SIT_CONTRATO    = '3'                      THEN '02 - PROP. EM ANALISE'    
    WHEN      B.TIPO_SIT_CONTRATO    = '1'     
        AND  B.FLAG_INTEGRAR        IN ('S','N')    
        AND  t.COD_USU_APROV_EXC    IS NOT NULL                THEN '01 - PROP. APROVADA POR EXCE�AO'    
    WHEN      B.TIPO_SIT_CONTR_ANT   = '3'     
        AND  B.TIPO_SIT_CONTRATO    = 'Z'     
        AND  B.TIPO_APROV_CRED      = 'M'                      THEN '05 - PROP. EXPIRADA AGUARDANDO ANALISE'    
    WHEN      B.TIPO_SIT_CONTRATO    = '9'                      THEN '04 - PROPOSTA CANCELADA'                   
    WHEN      B.TIPO_SIT_CONTRATO    = 'Z'                      THEN '05 - PROPOSTA EXPIRADA' 
    END AS                             Operacao_Status 
FROM Dfen_Juridico A
JOIN BCLI_JUR_BASE PJ ON A.NUM_CGC = PJ.NUM_CGC
JOIN BCLI_CADASTRO C ON C.COD_CLIENTE = PJ.COD_CLIENTE
JOIN DFEN_CONTRATO B ON B.COD_LOJA      = A.COD_LOJA AND B.NUM_TRANSACAO = A.num_transacao
JOIN dfen_contrato_Cmpl T ON T.COD_LOJA      = B.COD_LOJA AND T.NUM_TRANSACAO = B.num_transacao
WHERE A.NUM_CGC = :DOCUMENTO

UNION ALL

SELECT B.COD_CONTRATO   Operacao_Contrato,  
  A.NUM_CPF             Cliente_Documento, 
  C.NOME_CLIENTE        Cliente_Nome,
  'F'                   Cliente_TipoPessoa,
  B.COD_LOJA,
  B.NUM_TRANSACAO,
  B.VAL_PRINCIPAL       Operacao_Valor, 
  B.QTDE_PARCELAS_ORIG  Operacao_Parcelas, 
  B.DATA_PRIM_PARC      Operacao_PrimeiroVencimento, 
  B.COD_PRODUTO         Operacao_ProdutoCodigo, 
  B.DTHORA_ANALIS_INI   Operacao_InicioAtendimento, 
  B.TIPO_SIT_CONTRATO   Operacao_TipoSituacao,
  CASE     
    WHEN      B.tipo_sit_contrato        = '1'     
        AND  nvl(B.tipo_aprov_cred,'A') = 'A'     
        AND  t.cod_usu_aprov_exc   IS NULL                     THEN '01 - PROP. APROVADA AUTOMATICAMENTE'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_aprov_cred     = 'A'     
        AND  t.cod_usu_aprov_exc   IS NULL     
        AND  B.tipo_sit_contrato   = 'Z'                       THEN '05 - PROP. APROVADA AUT. EXPIRADA' 
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_aprov_cred     = 'A'     
        AND  B.tipo_sit_contrato   = '9'                       THEN '04 - PROP. APROVADA AUT. CANCELADA'    
    WHEN      B.tipo_sit_contrato   = '1'     
        AND  B.FLAG_INTEGRAR       = 'R'     
        AND  B.tipo_aprov_cred     = 'A'                       THEN '03 - PROP. APROVADA AUT. RECUSADO'    
    WHEN      B.tipo_sit_contrato   = '1'    
        AND  B.tipo_aprov_cred     = 'M'                       THEN '01 - PROP. APROVADA PELA ANALISE'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_sit_contrato   = '9'     
        AND  B.tipo_aprov_cred     = 'M'                       THEN '04 - PROP. APROVADA PELA ANALISE CANCELADA'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_aprov_cred     = 'M'     
        AND  B.tipo_sit_contrato   = 'Z'                       THEN '05 - PROP. APROVADA PELA ANALISE EXPIRADA'    
    WHEN      B.tipo_sit_contrato   = '1'     
        AND  B.tipo_aprov_cred     = 'R'                       THEN '01 - PROP. APROVADA PELA REANALISE'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_sit_contrato   = 'Z'     
        AND  B.tipo_aprov_cred     = 'R'                       THEN '05 - PROP. APROVADA PELA REANALISE EXPIRADA'    
    WHEN      B.tipo_sit_contr_ant  = '1'     
        AND  B.tipo_sit_contrato   = '9'     
        AND  B.tipo_aprov_cred     = 'R'                       THEN '04 - PROP. APROVADA PELA REANALISE CANCELADA '    
    WHEN ((   B.TIPO_SIT_CONTRATO   = '2'      
        AND  B.TIPO_APROV_CRED      IN ('A','B'))     
        OR (B.TIPO_SIT_CONTRATO    IN ('Z','9')      
        AND  B.TIPO_APROV_CRED      IN ('A','B')      
        AND  B.TIPO_SIT_CONTR_ANT   = '2'))                    THEN '03 - PROP. REPROVADA AUTOMATICAMENTE'    
    WHEN ((   B.tipo_sit_contrato = '2' AND B.tipo_aprov_cred = 'M')    
        OR (    B.tipo_sit_contrato IN ('Z', '9')                         
        AND B.tipo_aprov_cred = 'M'                                          
        AND B.tipo_sit_contr_ant = '2' ) )                     THEN '03 - PROP. REPROVADA PELA ANALISE'    
    WHEN      B.TIPO_SIT_CONTRATO    = '3'                      THEN '02 - PROP. EM ANALISE'    
    WHEN      B.TIPO_SIT_CONTRATO    = '1'     
        AND  B.FLAG_INTEGRAR        IN ('S','N')    
        AND  t.COD_USU_APROV_EXC    IS NOT NULL                THEN '01 - PROP. APROVADA POR EXCE�AO'    
    WHEN      B.TIPO_SIT_CONTR_ANT   = '3'     
        AND  B.TIPO_SIT_CONTRATO    = 'Z'     
        AND  B.TIPO_APROV_CRED      = 'M'                      THEN '05 - PROP. EXPIRADA AGUARDANDO ANALISE'    
    WHEN      B.TIPO_SIT_CONTRATO    = '9'                      THEN '04 - PROPOSTA CANCELADA'                   
    WHEN      B.TIPO_SIT_CONTRATO    = 'Z'                      THEN '05 - PROPOSTA EXPIRADA' 
    END AS                      Operacao_Status
FROM dmov_cli_fis_base A
JOIN BCLI_FIS_BASE PF ON A.NUM_CPF = PF.NUM_CPF
JOIN BCLI_CADASTRO C ON C.COD_CLIENTE = PF.COD_CLIENTE
JOIN DFEN_CONTRATO B ON B.COD_LOJA      = A.COD_LOJA AND B.NUM_TRANSACAO = A.num_transacao
JOIN dfen_contrato_Cmpl T ON T.COD_LOJA      = B.COD_LOJA AND T.NUM_TRANSACAO = B.num_transacao
WHERE A.NUM_CPF = :DOCUMENTO