SELECT  A.NUM_SEQ_CONTRATO  Quantidade
        ,B.NOME_FAVORECIDO  Favorecido
        ,B.NUM_CGC_CPF    Documento
        ,CASE  WHEN INSTR ('E,C,D,R,L,T,D', B.TIPO_LIB_LOTE) = 0 THEN 'REMUNERA��O ' ELSE 'PRINCIPAL' END AS Tipo_Liberacao
        ,A.DATA_REPASSE    Data_Repasse
        ,B.COD_BANCO    Banco_Codigo
        ,B.COD_AGENCIA    Agencia
        ,CASE WHEN rtrim(ltrim(B.DIG_AGENCIA)) = '' OR rtrim(ltrim(B.DIG_AGENCIA)) is null THEN '0' ELSE B.DIG_AGENCIA   END Agencia_Digito
        ,B.COD_CONTA    Conta
        ,CASE WHEN rtrim(ltrim(B.DIG_CONTA)) = '' or rtrim(ltrim(B.DIG_CONTA)) is null  THEN '0' ELSE B.DIG_CONTA   END Conta_Digito
        ,CASE   WHEN INSTR ('E,C,D,R,L,T,D', B.TIPO_LIB_LOTE) = 0 THEN A.VAL_REBATE_LOJA ELSE A.VAL_REPASSE END AS Valor
        ,B.TIPO_GERACAO    Tipo_Geracao
FROM SLIB_CONTRATOS A 
INNER JOIN SLIB_DOC_PAGTO B ON A.COD_DOC_PAGTO = B.COD_DOC_PAGTO
WHERE A.COD_CONTRATO = :CONTRATO
ORDER BY A.NUM_SEQ_CONTRATO ASC 