SELECT w.cod_contrato						Operacao_Contrato,
	data_liberacao							Operacao_DataLiberacao,
	w.cod_contrato_inter					Operacao_Contrato_Interno,
	TRUNC(SYSDATE)							Operacao_Data_Referencia,
	CLIPAN.F_TXANO(d.taxa_juros_c1)			Operacao_Juros_Ano,
	TRUNC(D.val_taxa_pactuada, 4)			Operacao_Pactuada_Ano,
	DECODE(w.idx_princ, 'PREF', 'PRE FIXADO', 'POS', 'POS FIXADO')	AS Operacao_Tipo,
	DECODE(R.tipo_base_calc_pmt, 'P', 'PRICE', 'D', 'DECRESCENTE')	AS Operacao_Regime_Amortizacao,
	DECODE(R.tipo_liq_ctb, '3', 'NORMAL', 'IRREGULAR')				AS Operacao_Fluxo_Pagamento, 
	w.cod_produto													Produto_Codigo, 
	C.val_taxa_cet													Operacao_CET
FROM econ_emprestimos w
	left join BPRO_EMPREST_BASE R
	on R.COD_PRODUTO = W.COD_PRODUTO
	INNER JOIN econ_param_calc d
	on d.cod_contrato_inter = w.cod_contrato_inter 
	INNER JOIN dfen_contrato F 
	on F.COD_CONTRATO = w.Cod_Contrato     
	INNER JOIN dfen_contrato_cmpl C 
	on C.COD_LOJA = F.COD_LOJA AND C.NUM_TRANSACAO = F.NUM_TRANSACAO 
WHERE w.cod_contrato = :Contrato