SELECT 
		CASE     
		WHEN      a.tipo_sit_contrato        = '1'     
				AND  nvl(a.tipo_aprov_cred,'A') = 'A'     
				AND  t.cod_usu_aprov_exc   IS NULL                     THEN '01 - PROP. APROVADA AUTOMATICAMENTE'    
		WHEN      a.tipo_sit_contr_ant  = '1'     
				AND  a.tipo_aprov_cred     = 'A'     
				AND  t.cod_usu_aprov_exc   IS NULL     
				AND  a.tipo_sit_contrato   = 'Z'                       THEN '05 - PROP. APROVADA AUT. EXPIRADA' 
		WHEN      a.tipo_sit_contr_ant  = '1'     
				AND  a.tipo_aprov_cred     = 'A'     
				AND  a.tipo_sit_contrato   = '9'                       THEN '04 - PROP. APROVADA AUT. CANCELADA'    
		WHEN      a.tipo_sit_contrato   = '1'     
				AND  a.FLAG_INTEGRAR       = 'R'     
				AND  a.tipo_aprov_cred     = 'A'                       THEN '03 - PROP. APROVADA AUT. RECUSADO'    
		WHEN      a.tipo_sit_contrato   = '1'    
				AND  a.tipo_aprov_cred     = 'M'                       THEN '01 - PROP. APROVADA PELA ANALISE'    
		WHEN      a.tipo_sit_contr_ant  = '1'     
				AND  a.tipo_sit_contrato   = '9'     
				AND  a.tipo_aprov_cred     = 'M'                       THEN '04 - PROP. APROVADA PELA ANALISE CANCELADA'    
		WHEN      a.tipo_sit_contr_ant  = '1'     
				AND  a.tipo_aprov_cred     = 'M'     
				AND  a.tipo_sit_contrato   = 'Z'                       THEN '05 - PROP. APROVADA PELA ANALISE EXPIRADA'    
		WHEN      a.tipo_sit_contrato   = '1'     
				AND  a.tipo_aprov_cred     = 'R'                       THEN '01 - PROP. APROVADA PELA REANALISE'    
		WHEN      a.tipo_sit_contr_ant  = '1'     
				AND  a.tipo_sit_contrato   = 'Z'     
				AND  a.tipo_aprov_cred     = 'R'                       THEN '05 - PROP. APROVADA PELA REANALISE EXPIRADA'    
		WHEN      a.tipo_sit_contr_ant  = '1'     
				AND  a.tipo_sit_contrato   = '9'     
				AND  a.tipo_aprov_cred     = 'R'                       THEN '04 - PROP. APROVADA PELA REANALISE CANCELADA '    
		WHEN ((   A.TIPO_SIT_CONTRATO   = '2'      
				AND  A.TIPO_APROV_CRED      IN ('A','B'))     
				OR (A.TIPO_SIT_CONTRATO    IN ('Z','9')      
				AND  A.TIPO_APROV_CRED      IN ('A','B')      
				AND  A.TIPO_SIT_CONTR_ANT   = '2'))                    THEN '03 - PROP. REPROVADA AUTOMATICAMENTE'    
		WHEN ((   a.tipo_sit_contrato = '2' AND a.tipo_aprov_cred = 'M')    
				OR (    a.tipo_sit_contrato IN ('Z', '9')                         
				AND a.tipo_aprov_cred = 'M'                                          
				AND a.tipo_sit_contr_ant = '2' ) )                     THEN '03 - PROP. REPROVADA PELA ANALISE'    
		WHEN      A.TIPO_SIT_CONTRATO    = '3'                      THEN '02 - PROP. EM ANALISE'    
		WHEN      A.TIPO_SIT_CONTRATO    = '1'     
				AND  A.FLAG_INTEGRAR        IN ('S','N')    
				AND  t.COD_USU_APROV_EXC    IS NOT NULL                THEN '01 - PROP. APROVADA POR EXCE�AO'    
		WHEN      A.TIPO_SIT_CONTR_ANT   = '3'     
				AND  A.TIPO_SIT_CONTRATO    = 'Z'     
				AND  A.TIPO_APROV_CRED      = 'M'                      THEN '05 - PROP. EXPIRADA AGUARDANDO ANALISE'    
		WHEN      A.TIPO_SIT_CONTRATO    = '9'                      THEN '04 - PROPOSTA CANCELADA'                   
		WHEN      A.TIPO_SIT_CONTRATO    = 'Z'                      THEN '05 - PROPOSTA EXPIRADA' 
		END AS STATUS 
FROM	dfen_contrato      a
		JOIN dmov_cli_cadastro  b ON b.cod_loja = a.cod_loja AND b.num_transacao = a.num_transacao 
		JOIN dmov_cli_fis_base  c ON c.cod_loja = a.cod_loja AND c.num_transacao = a.num_transacao 
		JOIN dfen_contrato_Cmpl t ON t.cod_loja = a.cod_loja AND t.num_transacao = a.num_transacao
WHERE  A.COD_CONTRATO = :Contrato