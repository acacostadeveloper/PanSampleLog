SELECT 
	cod_cartao_cred ID, 
	desc_cart_cred	Nome
FROM BTAB_INT_CART_CRED