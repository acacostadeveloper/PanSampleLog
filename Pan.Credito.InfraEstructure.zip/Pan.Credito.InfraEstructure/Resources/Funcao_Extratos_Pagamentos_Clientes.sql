Select Top 1
    --CLCODCLI   AS Cliente_Codigo,
	CASE WHEN ISNUMERIC(CLCODCLI) = 1 THEN CLCODCLI ELSE REPLACE(REPLACE(CLCGC,'.',''),'-','') END  AS Cliente_Codigo,
    --CLCGC      AS Cliente_Documento,
	REPLACE(REPLACE(CLCGC,'.',''),'-','') AS Cliente_Documento,
    'F'        AS Cliente_TipoPessoa,
    CLNOMECLI  AS Cliente_Nome
From 
    cdcpan.sysfunc.cclie WITH (NOLOCK)
Where
    CLCGC = @CPF
Order By
    CLDTCAD Desc


