Select

    Acordos.COD_CONTRATO_INTER  ,   --  
    Acordos.DATA_AMORTIZACAO    ,   --  
    Acordos.DATA_PAGTO          ,   --  
    Acordos.NUM_SEQ_PAGTO       ,   --  
    Acordos.COD_USU_CANCEL      ,   --  'C�digo do usu�rio que efetuou cancelamento'
    Acordos.DATA_CANCELAMENTO   ,   --  'Data de cancelamento'
    Acordos.DATA_INCL_ACORDO    ,   --  
    Acordos.DATA_PAGTO_EFETIVA  ,   --  
    Acordos.FLAG_PAGTO          ,   --  
    Acordos.NOSSO_NUMERO        ,   --  
    Acordos.VAL_COMISS_HONOR    ,   --  
    Acordos.VAL_COMISS_PERM     ,   --  
    Acordos.VAL_COMISSAO_COB    ,   --  
    Acordos.VAL_DESC_ANTECIP    ,   --  
    Acordos.VAL_DESCONTO_CONC   ,   --  
    Acordos.VAL_DESPESAS        ,   --  
    Acordos.VAL_HONORARIOS      ,   --  
    Acordos.VAL_MORA            ,   --  
    Acordos.VAL_MULTA           ,   --  
    Acordos.VAL_RECEBIMENTO     ,   --  
    Acordos.VAL_SALDO_PARC         --  


--    Acordos.COD_ANALISTA_PEND   ,   --  
--    Acordos.COD_ATRASO          ,   --  FK NTAB_PARAMETROS   (COD_ATRASO)
--    Acordos.COD_CAIXA           ,   --  
--    Acordos.COD_OPER_AUTORIZ    ,   --  FK BINT_OPER_VARE    (COD_OPER_VAREJO)
--    Acordos.COD_OPER_INCLUSAO   ,   --  
--    Acordos.COD_ORGAO_REC       ,   --  'C�digo do �rg�o Recebedor.'
--    Acordos.COD_POL_DESC        ,   --  FK NTAB_POLITICA_DESC(COD_POL_DESC)
--    Acordos.COD_PREST_AUTORIZ   ,   --  FK VTAB_COBRADORAS   (COD_COBRADORA)
--    Acordos.COD_RECUSA_DEBITO   ,   --  FK VTAB_RECUSA_DEBITO(COD_RECUSA)
--    Acordos.COD_REGIONAL_DEVOL  ,   --  
--    Acordos.COD_REGUA           ,   --  FK NTAB_CE_PADRAO_GER(COD_REGUA)
--    Acordos.COD_RETORNO         ,   --  'C�digo referente a situa��o/status do consignado.'
--    Acordos.COD_USU_AUTORIZ     ,   --                                                    
--    Acordos.COD_USU_PARC_ANTEC  ,   --  FK ISEG_USU_BASE     (COD_USUARIO)
--    Acordos.COD_USU_SUPERV      ,   --  FK ISEG_USU_BASE     (COD_USUARIO)
--    Acordos.DATA_ABERTURA       ,   --  
--    Acordos.DATA_DEBITO         ,   --  
--    Acordos.DATA_EMISSAO        ,   --  
--    Acordos.DATA_ENVIO_DEBITO   ,   --  
--    Acordos.DATA_GERA_INTERF    ,   --  
--    Acordos.DATA_INTEGRACAO     ,   --  
--    Acordos.DATA_INTERF_COMIS   ,   --  
--    Acordos.DATA_RET_DEBITO     ,   --  
--    Acordos.DTHORA_INCL_FILA    ,   --  
--    Acordos.DTHORA_MOVIMENTO    ,   --  
--    Acordos.FLAG_DEBITO_CC      ,   --  
--    Acordos.FLAG_EMISSAO        ,   --  
--    Acordos.FLAG_GERA_INTERF    ,   --  
--    Acordos.FLAG_INTEGRACAO     ,   --  
--    Acordos.FLAG_INTERF_COMIS   ,   --  
--    Acordos.FLAG_INTERV         ,   --  
--    Acordos.FLAG_JUDICIAL       ,   --  
--    Acordos.FLAG_ORIG_BUREAU    ,   --  
--    Acordos.FLAG_PROC_CANCELA   ,   --  
--    Acordos.FLAG_USU_AUTORIZ    ,   --  
--    Acordos.MES_REF_FRACIONA    ,   --  
--    Acordos.NUM_ACORDO          ,   --  
--    Acordos.NUM_DEP_IDENTIFIC   ,   --  
--    Acordos.NUM_SEQ_ABERTURA    ,   --  
--    Acordos.PERC_DESC_ANTECIP   ,   --  
--    Acordos.SEQ_CAIXA           ,   --  
--    Acordos.TIPO_ACORDO         ,   --  
--    Acordos.TIPO_ATENDIMENTO    ,   --  
--    Acordos.TP_ORIG_ACORDO      ,   --  
--    Acordos.VAL_DEP_ID_DIF      ,   --  
--    Acordos.VAL_DESC_ENC_PARC   ,   --  
--    Acordos.VAL_DESC_JRS_PARC   ,   --  
--    Acordos.VAL_DESC_MAX_PERM   ,   --  
--    Acordos.VAL_DESC_PMT        ,   --  
--    Acordos.VAL_DESC_PRINC      ,   --  'Desconto sobre o principal'
--    Acordos.VAL_DESC_PRINC_PAR  ,   --  
--    Acordos.VAL_DESP_DEP_IDENT  ,   --  
--    Acordos.VAL_DESP_NOTIFIC    ,   --  
--    Acordos.VAL_DESP_TELEFONIA  ,   --  
--    Acordos.VAL_MAX_DESC_PRINC  ,   --  'Desconto m�ximo permitido sobre o principal da parcela'
--    Acordos.VAL_NOMINAL_COMISS  ,   --  
--    Acordos.VAL_PAGAMENTOS      ,   --  
--    Acordos.VAL_RESTIT_N_SEGURO ,   --  'VALOR DA RESTITUICAO DO SEGURO QUANDO O MESMO FOI BANCADO PELO BANCO E NAO PELO CLIENTE QUANDO E PAGO PELO CLIENTE O VALOR ESTA NO ATRIBUTO VAL_RESTIT_SEGURO'
--    Acordos.VAL_RESTIT_SEGURO   ,   --  
--    Acordos.VAL_TAR_TROCA_CHQ   ,   --  
--    Acordos.VAL_TARIFA          ,   --  
--    Acordos.VAL_TAXA_FLUT       ,   --  
--    Acordos.VAL_TLA             ,   --  
    
--    TiposAtraso.DESC_ATRASO     ,
    
--    Cobradoras.COD_CLIENTE      ,
    
--    MotivosRecusa.DESC_RECUSA

From
               ECON_CAIXA         Acordos
--    Left  Join NTAB_PARAMETROS    TiposAtraso   On Acordos.COD_ATRASO        = TiposAtraso.COD_ATRASO
--    Left  Join VTAB_COBRADORAS    Cobradoras    On Acordos.COD_PREST_AUTORIZ = Cobradoras.COD_COBRADORA
--    Left  Join VTAB_RECUSA_DEBITO MotivosRecusa On Acordos.COD_RECUSA_DEBITO = MotivosRecusa.COD_RECUSA

Where
    COD_CONTRATO_INTER = :p_intContratoInterno
ORDER BY
    Acordos.NOSSO_NUMERO,
    Acordos.DATA_INCL_ACORDO,
    Acordos.DATA_AMORTIZACAO
    --Acordos.COD_CONTRATO_INTER,
    --Acordos.DATA_PAGTO,
    --Acordos.NUM_SEQ_PAGTO,
    --Acordos.DATA_AMORTIZACAO