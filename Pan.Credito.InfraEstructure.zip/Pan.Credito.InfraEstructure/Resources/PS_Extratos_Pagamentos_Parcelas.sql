SELECT 
    Operacoes.COD_CONTRATO_INTER,
    Parcelas.DATA_AMORTIZACAO,

    -- Data da liquida��o
    (SELECT 
         Max(Data_Valor)
     FROM 
                    ECON_FLUXO_CAIXA  Fluxo 
         INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
     WHERE 
         Fluxo.COD_ORGAO                Is Not Null                    And
         Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
         Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
         Fluxo.COD_EVENTO_FLUXO         = 1                            And 
         NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
    ) AS Liquidacao_Data,


    -- Valor pago
    (SELECT 
          Sum(Fluxo.Val_Realizado) 
      FROM 
                     ECON_FLUXO_CAIXA  Fluxo 
          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
      WHERE 
          Fluxo.COD_ORGAO          Is Not Null                    And
          Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And
          Fluxo.Data_Amortizacao   = Parcelas.Data_Amortizacao    And 
          Fluxo.COD_EVENTO_FLUXO   = 1                            And
          Fluxo.DATA_VALOR         = (SELECT 
                                          Max(Data_Valor)
                                      FROM 
                                                     ECON_FLUXO_CAIXA  Fluxo 
                                          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
                                      WHERE 
                                          Fluxo.COD_ORGAO                Is Not Null                    And
                                          Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
                                          Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
                                          Fluxo.COD_EVENTO_FLUXO         = 1                            And 
                                          NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
                                     )
    )  AS Liquidacao_ValorParcela,


    -- Acr�scimos
    (SELECT 
          NVL(Sum(Fluxo.Val_Realizado), 0.0) 
     FROM 
                     ECON_FLUXO_CAIXA  Fluxo 
          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
     WHERE 
          Fluxo.COD_ORGAO          Is Not Null                    And
          Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And 
          Fluxo.Data_Amortizacao   = Parcelas.Data_Amortizacao    And
          Fluxo.COD_EVENTO_FLUXO   <> 1                           And 
          Eventos.TIPO_MOVTO       = 'C'                          And
          Fluxo.DATA_VALOR         = (SELECT 
                                          Max(Data_Valor)
                                      FROM 
                                                     ECON_FLUXO_CAIXA  Fluxo 
                                          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
                                      WHERE 
                                          Fluxo.COD_ORGAO                Is Not Null                    And
                                          Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
                                          Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
                                          Fluxo.COD_EVENTO_FLUXO         = 1                            And 
                                          NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
                                     )
    ) AS Liquidacao_Acrescimos,


    -- Descontos
    (SELECT 
         NVL(Sum(Fluxo.Val_Realizado), 0.0)
     FROM 
                    ECON_FLUXO_CAIXA  Fluxo 
         INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
     WHERE
         Fluxo.COD_ORGAO          Is Not Null                    And
         Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And 
         Fluxo.Data_Amortizacao   = Parcelas.Data_Amortizacao    And
         Fluxo.COD_EVENTO_FLUXO   <> 1                           And 
         Eventos.TIPO_MOVTO       = 'D'                          And
         Fluxo.DATA_VALOR         = (SELECT 
                                          Max(Data_Valor)
                                      FROM 
                                                     ECON_FLUXO_CAIXA  Fluxo 
                                          INNER JOIN BTAB_ADM_EV_FLUXO Eventos ON Fluxo.COD_EVENTO_FLUXO = Eventos.COD_EVENTO_FLUXO
                                      WHERE 
                                          Fluxo.COD_ORGAO                Is Not Null                    And
                                          Fluxo.COD_CONTRATO_INTER       = Operacoes.COD_CONTRATO_INTER And 
                                          Fluxo.Data_Amortizacao         = Parcelas.Data_Amortizacao    And 
                                          Fluxo.COD_EVENTO_FLUXO         = 1                            And 
                                          NVL(Fluxo.FLAG_ESTORNO, 'N')   = 'N'
                                    )
    ) AS Liquidacao_Descontos

FROM
    ECON_EMPRESTIMOS Operacoes
    INNER JOIN ECON_AMORTIZACOES Parcelas ON Parcelas.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER

WHERE
    Parcelas.DATA_AMORTIZACAO > Operacoes.DATA_LIBERACAO AND
    Parcelas.FLAG_LIQUIDADO   = 'S'                      AND
    Operacoes.Cod_cliente In 
    (
        SELECT
            CADASTRO.COD_CLIENTE      AS Cliente_Codigo
        FROM
                       BCLI_CADASTRO CADASTRO
            Inner JOIN BCLI_FIS_BASE CLIENTEPF ON CADASTRO.COD_CLIENTE = CLIENTEPF.COD_CLIENTE
        WHERE
            CLIENTEPF.NUM_CPF = :p_intCPF

        UNION

        SELECT
            CADASTRO.COD_CLIENTE  AS Cliente_Codigo
        FROM
                       BCLI_CADASTRO CADASTRO
            Inner JOIN BCLI_JUR_BASE CLIENTEPJ ON CADASTRO.COD_CLIENTE = CLIENTEPJ.COD_CLIENTE
        WHERE
            CLIENTEPJ.NUM_CGC = :p_intCNPJ
    )

ORDER BY
    Operacoes.COD_CONTRATO_INTER,
    Parcelas.DATA_AMORTIZACAO