SELECT 
    Operacoes.COD_CONTRATO       As Operacao_Contrato,
    Operacoes.COD_CONTRATO_INTER AS Operacao_Codigo,
    Operacoes.DATA_LIBERACAO     AS Operacao_DataLiberacao,
    Empresas.NUM_CGC             AS Empresa_CNPJ,
    Empresas.DESC_VEIC_LEGAL     AS Empresa_NOME
FROM
    ECON_EMPRESTIMOS Operacoes
    INNER JOIN BINT_VEICULO_LEGAL Empresas ON Operacoes.COD_VEIC_LEGAL = Empresas.COD_VEIC_LEGAL
WHERE
    Empresas.COD_VEIC_LEGAL In('001', '020', '023', '060', '101', '200', '201', '202','500') And
    Substr(COD_CONTRATO, 1, 3) <> 'CES'       And
    Cod_cliente In 
    (
        SELECT
            CADASTRO.COD_CLIENTE      AS Cliente_Codigo
        FROM
                       BCLI_CADASTRO CADASTRO
            Inner JOIN BCLI_FIS_BASE CLIENTEPF ON CADASTRO.COD_CLIENTE = CLIENTEPF.COD_CLIENTE
        WHERE
            CLIENTEPF.NUM_CPF = :p_intCPF

        UNION

        SELECT
            CADASTRO.COD_CLIENTE  AS Cliente_Codigo
        FROM
                       BCLI_CADASTRO CADASTRO
            Inner JOIN BCLI_JUR_BASE CLIENTEPJ ON CADASTRO.COD_CLIENTE = CLIENTEPJ.COD_CLIENTE
        WHERE
            CLIENTEPJ.NUM_CGC = :p_intCNPJ
    )
ORDER BY
    Cod_contrato_inter