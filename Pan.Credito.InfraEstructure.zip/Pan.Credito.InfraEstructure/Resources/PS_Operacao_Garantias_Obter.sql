Select

	Garantias.COD_GARANTIA       ,   -- PRIMARY KEY
    
	Garantias.COD_CLASSE_GAR     ,   -- REFERENCES SYSADM.BTAB_ADM_GARANTIA  (COD_CLASSE_GAR)
	--Garantias.COD_INDEX_TAXA     ,   -- REFERENCES SYSADM.BTAB_ADM_INDEXADOR (COD_INDEXADOR)
	Garantias.COD_GAR_SUBSTITUT  ,   -- REFERENCES SYSADM.GCAD_GARANTIAS     (COD_GARANTIA)
	Garantias.COD_MOEDA_GAR      ,   -- REFERENCES SYSADM.BTAB_ADM_INDEXADOR (COD_INDEXADOR)
	--Garantias.COD_PAIS           ,   -- REFERENCES SYSADM.BTAB_OFI_PAIS      (COD_PAIS)
	--Garantias.COD_USU_VALID_BAI  ,   -- REFERENCES SYSADM.ISEG_USU_BASE      (COD_USUARIO)

	--Garantias.COD_CONTRATO_VINC  ,   -- 'Codigo do Contrato BNDU a qual a Garantia esta Vinculada'
	--Garantias.COD_RISCO_GAR      ,   -- 'Risco de garantias'
	--Garantias.COD_USUARIO        ,   -- 
	--Garantias.COD_USUARIO_BAIXA  ,   -- 
	--Garantias.COD_USUARIO_VALID  ,   -- 
	Garantias.DATA_CONTAB_BAIXA  ,   -- 
	Garantias.DATA_CONTAB_EFETIV ,   -- 
	Garantias.DATA_CONTABILIZ    ,   -- 
	Garantias.DATA_DESATIVACAO   ,   -- 
	Garantias.DATA_INIC_VALORIZ  ,   -- 
	--Garantias.DATA_VALIDACAO     ,   -- 
	Garantias.DATA_VENCIMENTO    ,   -- 
	--Garantias.DESC_GARANTIA      ,   -- 
	--Garantias.FLAG_CALC_BAIXA    ,   -- 
	--Garantias.FLAG_CTB           ,   -- 
	--Garantias.FLAG_ENV_BANCO     ,   -- 
	--Garantias.FLAG_PENDENCIA     ,   -- 
	Garantias.FLAG_VEICULO       ,   -- 
	--Garantias.FLAG_VENC_INDET    ,   -- 
	Garantias.NUM_SEQ_GAR        ,   -- 
	--Garantias.PERC_EXIG_TIPO     ,   -- 
	--Garantias.PERC_EXIGIVEL      ,   -- 
	--Garantias.PERC_GARANTIA      ,   -- 'Percentual da Garantia sobre Todas as Garantias do Contrato'
	--Garantias.PERC_SALDO_DEV     ,   -- 
	--Garantias.PERI_TAXA          ,   -- 
	--Garantias.TAXA_VALORIZ       ,   -- 
	--Garantias.TIPO_BACEN         ,   -- 'Tipo BACEN'
	Garantias.TIPO_BAIXA         ,   -- 
	--Garantias.TIPO_INDEX_TAXA    ,   -- 
	--Garantias.TIPO_MOEDA         ,   -- 
	--Garantias.TIPO_MOT_BXMANUAL  ,   -- 
	--Garantias.TIPO_TAB_RELAC     ,   -- 
	--Garantias.TIPO_TAXA          ,   -- 
	--Garantias.TIPO_VALIDACAO     ,   -- 
	Garantias.TIPO_VALORIZACAO   ,   -- 
	--Garantias.VAL_HIST_USD       ,   -- 
	Garantias.VAL_HISTORICO      ,   -- 
	Garantias.VALOR_GARANTIA     ,   -- 

    

	--Garantias_Veiculos.COD_GARANTIA            ,   -- PRIMARY KEY

	--Garantias_Veiculos.COD_BLOQUEIO            ,   -- REFERENCES SYSADM.GTAB_MOTIV_BLOQ_IL (COD_BLOQUEIO)    
	--Garantias_Veiculos.COD_DESPACHANTE         ,   -- REFERENCES SYSADM.GTAB_DESPACHANTES (COD_DESPACHANTE),
	--Garantias_Veiculos.COD_NATU_OCUP           ,   -- REFERENCES SYSADM.BTAB_INT_NATOCUP (COD_NATU_OCUP)
	--Garantias_Veiculos.SIGLA_UF_END            ,   -- REFERENCES SYSADM.BTAB_ADM_UF (SIGLA_UF)
	--Garantias_Veiculos.SIGLA_UF_PLACA_ANT      ,   -- REFERENCES SYSADM.BTAB_ADM_UF (SIGLA_UF)
	Garantias_Veiculos.SIGLA_UF_PLACA_ATU      ,   -- REFERENCES SYSADM.BTAB_ADM_UF (SIGLA_UF),
	--Garantias_Veiculos.SIGLA_UF_VEIC           ,   -- REFERENCES SYSADM.BTAB_ADM_UF (SIGLA_UF),

	Garantias_Veiculos.ANO_FABRIC              ,   -- 
	Garantias_Veiculos.ANO_MODELO              ,   -- 
	--Garantias_Veiculos.COD_AGE_PROPANT         ,   -- 
	--Garantias_Veiculos.COD_BAN_PROPANT         ,   -- 
	--Garantias_Veiculos.COD_CARROCERIA          ,   -- 
	--Garantias_Veiculos.COD_CEP                 ,   -- 
	--Garantias_Veiculos.COD_COMP_PROPANT        ,   -- 
	--Garantias_Veiculos.COD_CONTA_PROPANT       ,   -- 
	--Garantias_Veiculos.COD_CORRETORA           ,   -- 
	--Garantias_Veiculos.COD_RAMAL               ,   -- 
	Garantias_Veiculos.COD_RENAVAN             ,   -- 
	--Garantias_Veiculos.COD_RESP_VISTORIA       ,   -- 
	--Garantias_Veiculos.COD_SEGURADORA          ,   -- 
	Garantias_Veiculos.COD_TP_VEIC             ,   -- 
	--Garantias_Veiculos.COD_USU_AGEND           ,   --     'Codigo Usuario de Agendamento do Gravame'
	--Garantias_Veiculos.COD_USU_AUTORIZA        ,   --     'Codigo do Usuario Autorizador do Agendamento'
	--Garantias_Veiculos.COD_USU_BAI_DUT         ,   -- 
	--Garantias_Veiculos.COD_USUAR_BLOQUEIO      ,   -- 
	Garantias_Veiculos.COD_VEICULO             ,   -- 
	--Garantias_Veiculos.DATA_AGEND_GRAVAME      ,   --     'Data de Agendamento para Envio ao Gravame'
	--Garantias_Veiculos.DATA_ALIEN_DET_BA       ,   -- 
	Garantias_Veiculos.DATA_ALIENACAO          ,   -- 
	--Garantias_Veiculos.DATA_BLOQUEIO           ,   -- 
	--Garantias_Veiculos.DATA_CERTIFIC_ANT       ,   -- 
	Garantias_Veiculos.DATA_CERTIFIC_ATU       ,   -- 
	--Garantias_Veiculos.DATA_DETRAN             ,   -- 
	--Garantias_Veiculos.DATA_EMISSAO_NF         ,   -- 
	Garantias_Veiculos.DATA_GERA_ALIENAC       ,   -- 
	--Garantias_Veiculos.DATA_PERDA_ASSIST       ,   -- 
	Garantias_Veiculos.DATA_REG_ASSIST         ,   -- 
	--Garantias_Veiculos.DATA_VENC_SEGURO        ,   -- 
	--Garantias_Veiculos.DATA_VISTORIA           ,   -- 
	--Garantias_Veiculos.DESC_BAIRRO             ,   -- 
	--Garantias_Veiculos.DESC_CIDADE             ,   -- 
	--Garantias_Veiculos.DESC_COMPL_LOGR         ,   -- 
	Garantias_Veiculos.DESC_COR_VEIC           ,   -- 
	--Garantias_Veiculos.DESC_LOGRADOURO         ,   -- 
	--Garantias_Veiculos.DESC_VISTORIA           ,   -- 
	--Garantias_Veiculos.DIG_AGE_PROPANT         ,   -- 
	--Garantias_Veiculos.DIG_CON_PROPANT         ,   -- 
	--Garantias_Veiculos.DT_BAIXA_DUT            ,   -- 
	--Garantias_Veiculos.DT_DUT_ARQ_GERACAO      ,   -- 
	--Garantias_Veiculos.DT_DUT_ARQ_RETORNO      ,   -- 
	Garantias_Veiculos.DT_INCL_DUT             ,   -- 
	--Garantias_Veiculos.DTHORA_AUTORIZA         ,   --     'Data/Hora da Autorizacao do Agendamento de Gravame'
	Garantias_Veiculos.DTHORA_INCLUSAO         ,   --     'Data/Hora da Inclusao do Agendamento'
	--Garantias_Veiculos.DUT_ARQ_GERACAO         ,   -- 
	--Garantias_Veiculos.DUT_ARQ_RETORNO         ,   -- 
	--Garantias_Veiculos.DUT_COD_AGENTE          ,   -- 
	--Garantias_Veiculos.DUT_CPF_AGENTE          ,   -- 
	--Garantias_Veiculos.DUT_DATA_EMISSAO        ,   -- 
	--Garantias_Veiculos.DUT_NOME_AGENTE         ,   -- 
	--Garantias_Veiculos.EMAIL_EMITENTE          ,   -- 
	--Garantias_Veiculos.FLAG_ALIEN_DET_BA       ,   -- 
	Garantias_Veiculos.FLAG_ALIENACAO          ,   -- 
	Garantias_Veiculos.FLAG_ASSISTENCIA        ,   -- 
	Garantias_Veiculos.FLAG_BLOQUEIA_IL        ,   -- 
	Garantias_Veiculos.FLAG_CHASSI_REMARC      ,   -- 
	Garantias_Veiculos.FLAG_ENVIO_ASSIST       ,   -- 
	Garantias_Veiculos.FLAG_GAR_PRINCIPAL      ,   -- 
	--Garantias_Veiculos.FLAG_GAR_VEIC           ,   -- 
	--Garantias_Veiculos.FLAG_INTER_VEIC         ,   -- 
	--Garantias_Veiculos.FLAG_LIBERA_PAGTO       ,   --     'S/N Liberar Pagamento'
	--Garantias_Veiculos.FLAG_POSSUI_DPVAT       ,   -- 
	--Garantias_Veiculos.FLAG_POSSUI_IPVA        ,   -- 
	--Garantias_Veiculos.FLAG_POSSUI_MULTA       ,   -- 
	--Garantias_Veiculos.FLAG_POSSUI_TRIB        ,   -- 
	--Garantias_Veiculos.FLAG_REG_CONTR_UF       ,   --     'Registro de Contrato UF.'
	Garantias_Veiculos.FLAG_REG_CONTRATO       ,   -- 
	--Garantias_Veiculos.FLAG_STATUS_DETRAN      ,   -- 
	--Garantias_Veiculos.FLAG_TAXI               ,   -- 
	--Garantias_Veiculos.FLAG_TAXI_ISENTO        ,   -- 
	--Garantias_Veiculos.FLAG_TRANSF_PROP        ,   -- 
	Garantias_Veiculos.FLAG_VEIC_ZERO          ,   -- 
	--Garantias_Veiculos.FLAG_VISTORIA_REALIZADA ,   -- 
	--Garantias_Veiculos.NOME_EMITENTE           ,   -- 
	--Garantias_Veiculos.NOME_SEGURADO           ,   -- 
	--Garantias_Veiculos.NOME_VENDEDOR           ,   -- 
	--Garantias_Veiculos.NOME_VISTORIADOR        ,   -- 
	--Garantias_Veiculos.NUM_APOLICE             ,   -- 
	--Garantias_Veiculos.NUM_AREA_TELEFONE       ,   -- 
	--Garantias_Veiculos.NUM_CERTIFIC_ANT        ,   -- 
	Garantias_Veiculos.NUM_CERTIFIC_ATU        ,   -- 
	--Garantias_Veiculos.NUM_CGC_CPF             ,   -- 
	Garantias_Veiculos.NUM_CHASSI              ,   -- 
	--Garantias_Veiculos.NUM_FAX                 ,   -- 
	Garantias_Veiculos.NUM_GRAVAME             ,   -- 
	--Garantias_Veiculos.NUM_LOGRADOURO          ,   -- 
	--Garantias_Veiculos.NUM_NF                  ,   -- 
	--Garantias_Veiculos.NUM_PLACA_ANT           ,   -- 
	Garantias_Veiculos.NUM_PLACA_ATU           ,   -- 
	--Garantias_Veiculos.NUM_SEQ_ARQ_DUT         ,   -- 
	--Garantias_Veiculos.NUM_TELEFONE            ,   -- 
	--Garantias_Veiculos.NUM_VISTORIA            ,   -- 
	--Garantias_Veiculos.OBS_AGENDA_GRAVAME      ,   --     'Observacao Quando Ocorrer Agendamento para Envio ao Gravame'
	--Garantias_Veiculos.SERIE_NF                ,   -- 
	--Garantias_Veiculos.SIGLA_UF_EMITENTE       ,   -- 
	--Garantias_Veiculos.STATUS_GRAVAME          ,   --     '1 - Ativos para pr�pria institui��o; 2 - Ativos para outra institui��o; 3 - N�o ativos para a pr�pria institui��o; 4 - N�o ativos para outra institui��o; 5 - Chassi errado; E - Registro enviado'
	--Garantias_Veiculos.VAL_AVALIACAO           ,   -- 
	--Garantias_Veiculos.VAL_TRIBUTOS            ,   -- 
	Garantias_Veiculos.VALOR_NF,                    -- 


	
	-- Ve�culos
	Veiculos.DESC_VEICULO,
	Veiculos.TIPO_COMBUSTIVEL,
	Veiculos.TIPO_CATEGORIA,
	Veiculos_Marcas.DESC_MARCA,



	-- Ve�culos apreendidos
	Veiculos_Apreendidos.TIPO_APREENSAO,
	Motivos_Apreensao.DESC_MOT_APR_QUIT

FROM
			   GCAD_GAR_CONTR     Garantias_Contrato
	INNER JOIN GCAD_GARANTIAS     Garantias            ON Garantias_Contrato.COD_GARANTIA       = Garantias.COD_GARANTIA
	INNER JOIN GCAD_GAR_VEIC      Garantias_Veiculos   ON Garantias_Contrato.COD_GARANTIA       = Garantias_Veiculos.COD_GARANTIA
	INNER JOIN BTAB_ADM_VEICULO   Veiculos             ON Garantias_Veiculos.COD_VEICULO        = Veiculos.COD_VEICULO
	INNER JOIN BTAB_MARCA_VEICULO Veiculos_Marcas      ON Veiculos.COD_MARCA                    = Veiculos_Marcas.COD_MARCA
	LEFT  JOIN GCAD_VEIC_APREEN   Veiculos_Apreendidos ON Garantias_Contrato.COD_GARANTIA       = Veiculos_Apreendidos.COD_GARANTIA
	LEFT  JOIN GTAB_MOT_APR_QUIT  Motivos_Apreensao    ON Veiculos_Apreendidos.COD_MOT_APR_QUIT = Motivos_Apreensao.COD_MOT_APR_QUIT

WHERE
	