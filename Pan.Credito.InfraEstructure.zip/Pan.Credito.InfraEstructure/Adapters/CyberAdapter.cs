﻿using System;
using System.Configuration;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Pan.Credito.CrossCutting;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Infrastructure.WS_Cyber_AssessoriaAtual;

namespace Pan.Credito.Infrastructure.Adapters
{

    public class CyberAdapter : ICyberAdapter
    {
        private readonly WSConsultaAssessoriaAtual _cyberService;
        public CyberAdapter()
        {
            _cyberService = new WSConsultaAssessoriaAtualClient();
        }
        public Cobradora Assessoria_Obter(long  p_intDocumento,string p_strContrato,string p_strGrupo)
        {
                var  objAssessoria = new getAssessoriaAtual();
                var objClient     = new WSConsultaAssessoriaAtualClient();
                objAssessoria.CPF_CNPJ          = p_intDocumento.ToString();
                objAssessoria.CONTRATO_PESQUISA = p_strContrato;
                objAssessoria.GRUPO             = p_strGrupo;
                var resposta = objClient.getAssessoriaAtual(objAssessoria);



                if (resposta.@return.COD_ERRO_PESQUISA != 5 && resposta.@return.COD_ERRO_PESQUISA != 0)
                    throw new Exception(string.Format("ERRO AO CONSULTAR CYBER [{0}]", resposta.@return.DESC_ERRO_PESQUISA));

                if (resposta.@return.COD_ERRO_PESQUISA == 5) return null;

                var objRetorno = new Cobradora
                    (
                    Convert.ToInt64(resposta.@return.COD_ASSESSORIA),
                    DateTime.ParseExact(resposta.@return.DT_DISTRIBUICAO, "MMddyyyy", null),
                    resposta.@return.EMAIL_ASSESSORIA,

                    new Endereco
                        (
                        resposta.@return.ENDERECO_ASSESSORIA,
                        resposta.@return.NUMERO_END_ASSESSORIA,
                        "",
                        resposta.@return.BAIRRO_END_ASSESSORIA,
                        resposta.@return.CEP_END_ASSESSORIA,
                        resposta.@return.CIDADE_END_ASSESSORIA,
                        resposta.@return.ESTADO_END_ASSESSORIA
                        ),
                    resposta.@return.NOME_FANTASIA_ASSESSORIA,
                    Format.Telefone(resposta.@return.DDD_TELEF_ASSESSORIA, resposta.@return.TELEF_ASSESSORIA));

                if (!string.IsNullOrEmpty(resposta.@return.TELEF_ASSESSORIA) && resposta.@return.TELEF_ASSESSORIA.Substring(0, 4) == "0800")
                {
                    objRetorno.Telefone = resposta.@return.TELEF_ASSESSORIA;
                }
            return objRetorno;
        }
        public static bool ValidateServerCertificate(object  sender,X509Certificate certificate,X509Chain chain,SslPolicyErrors sslPolicyErrors)
        {

            if (sslPolicyErrors == SslPolicyErrors.RemoteCertificateChainErrors)
            {
                return false;
            }
            else if (sslPolicyErrors == SslPolicyErrors.RemoteCertificateNameMismatch)
            {
                System.Security.Policy.Zone z = System.Security.Policy.Zone.CreateFromUrl(((HttpWebRequest)sender).RequestUri.ToString());
                if (z.SecurityZone == System.Security.SecurityZone.Intranet ||
                    z.SecurityZone == System.Security.SecurityZone.MyComputer)
                {
                    return true;
                }
                return false;
            }
            return true;
        }
      
       
        public class MyPolicy : ICertificatePolicy
        {
            public bool CheckValidationResult(ServicePoint    srvPoint, X509Certificate certificate, WebRequest      request, int   certificateProblem)
            {
                return true;
            }
        }

        public void Dispose()
        {
        }
    }
}
