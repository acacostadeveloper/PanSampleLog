﻿using System;
using Pan.Credito.Domain.Common;
using Pan.Credito.Infrastructure.PublishSms;

namespace Pan.Credito.Infrastructure.Adapters
{

    public class SmsDispatcher : ISmsDispatcher
    {
        private readonly BN_PUBLISHwebservicepublishcfcPortType _publishService;
        public SmsDispatcher()
        {
            _publishService = new BN_PUBLISHwebservicepublishcfcPortTypeClient(); ;
        }

        public bool EnviarSms(int DDD, int celular, string linhaDigitavel,string cpf)
        {
            var publishService = new BN_PUBLISHwebservicepublishcfcPortTypeClient();

            var dadosMensagem = new TDadosMensagem
            {
                Cartao = string.Empty,
                CodigoCampanha = 0,
                CodigoCampanhaSpecified = true,
                Conta = string.Empty,
                CPF = cpf,
                DataAdesaoPacote = DateTime.Now,
                DataAdesaoPacoteSpecified = true,
                DataEnvio = DateTime.Now,
                DataEnvioSpecified = true,
                DDD = DDD,
                DDDSpecified = true,
                Logo = "0",
                NumeroPacote = 0,
                NumeroPacoteSpecified = true,
                Org = "0",
                Telefone = celular,
                TelefoneSpecified = true,
                TipoCliente = 1,
                TipoClienteSpecified = true,
                TipoDaCampanha = new ArrayOfTipoDeCampanha { Midia = "1" },
                TipoTelefone = 2,
                TipoTelefoneSpecified = true
            };

            var dadosSMS = new TDadosSMS
            {
                BarCode = linhaDigitavel,
                CodigoSMS = 450,
                CodigoSMSSpecified = true,
                Nome = string.Empty,
                CodMoeda = string.Empty,
                CodPais = string.Empty
            };
            var envio = new TMensagensEnvioLote
            {
                MensagemEnvio = new ArrayOfTMensagemEnvio { TMensagemEnvio = new TMensagemEnvio[1] }
            };
            envio.MensagemEnvio.TMensagemEnvio[0] = new TMensagemEnvio
            {
                DadosMensagem = dadosMensagem,
                DadosSMS = dadosSMS
            };
            var retornoEnvio = publishService.fncEnviarMensagem(new fncEnviarMensagemRequest { MensagensEnvioLote  = envio}).@return;
            return retornoEnvio.Codigo == 0;
        }

        public bool EnviarSmsCode(int DDD, int celular, string body, string cpf)
        {
            var publishService = new BN_PUBLISHwebservicepublishcfcPortTypeClient();

            var dadosMensagem = new TDadosMensagem
            {
                Cartao = string.Empty,
                CodigoCampanha = 0,
                CodigoCampanhaSpecified = true,
                Conta = string.Empty,
                CPF = cpf,
                DataAdesaoPacote = DateTime.Now,
                DataAdesaoPacoteSpecified = true,
                DataEnvio = DateTime.Now,
                DataEnvioSpecified = true,
                DDD = DDD,
                DDDSpecified = true,
                Logo = "0",
                NumeroPacote = 0,
                NumeroPacoteSpecified = true,
                Org = "0",
                Telefone = celular,
                TelefoneSpecified = true,
                TipoCliente = 1,
                TipoClienteSpecified = true,
                TipoDaCampanha = new ArrayOfTipoDeCampanha { Midia = "1" },
                TipoTelefone = 2,
                TipoTelefoneSpecified = true
            };

            var dadosSMS = new TDadosSMS
            {
                BarCode = string.Format("CODIGO DE VERIFICACAO BANCO PAN: {0}", body),
                CodigoSMS = 452,
                CodigoSMSSpecified = true,
                Nome = string.Empty,
                CodMoeda = string.Empty,
                CodPais = string.Empty
            };
            var envio = new TMensagensEnvioLote
            {
                MensagemEnvio = new ArrayOfTMensagemEnvio { TMensagemEnvio = new TMensagemEnvio[1] }
            };
            envio.MensagemEnvio.TMensagemEnvio[0] = new TMensagemEnvio
            {
                DadosMensagem = dadosMensagem,
                DadosSMS = dadosSMS
            };
            var retornoEnvio = publishService.fncEnviarMensagem(new fncEnviarMensagemRequest { MensagensEnvioLote = envio }).@return;
            return retornoEnvio.Codigo == 0;
        }



        public bool EnviarSms(int DDD, int celular, string linhaDigitavel, string cpf,DateTime DataVenc,decimal valorFatura)
        {
            var publishService = new BN_PUBLISHwebservicepublishcfcPortTypeClient();

            var dadosMensagem = new TDadosMensagem
            {
                Cartao = string.Empty,
                CodigoCampanha = 0,
                CodigoCampanhaSpecified = true,
                Conta = string.Empty,
                CPF = cpf,
                DataAdesaoPacote = DateTime.Now,
                DataAdesaoPacoteSpecified = true,
                DataEnvio = DateTime.Now,
                DataEnvioSpecified = true,
                DDD = DDD,
                DDDSpecified = true,
                Logo = "0",
                NumeroPacote = 0,
                NumeroPacoteSpecified = true,
                Org = "0",
                Telefone = celular,
                TelefoneSpecified = true,
                TipoCliente = 1,
                TipoClienteSpecified = true,
                TipoDaCampanha = new ArrayOfTipoDeCampanha { Midia = "1" },
                TipoTelefone = 2,
                TipoTelefoneSpecified = true
            };

            var dadosSMS = new TDadosSMS
            {
                BarCode = linhaDigitavel,
                CodigoSMS = 451,
                CodigoSMSSpecified = true,
                Nome = string.Empty,
                CodMoeda = string.Empty,
                CodPais = string.Empty,
                ValorFatura = (double)valorFatura,
                ValorFaturaSpecified = true,
                VencCms = DataVenc,
                VencCmsSpecified = true
            };
            var envio = new TMensagensEnvioLote
            {
                MensagemEnvio = new ArrayOfTMensagemEnvio { TMensagemEnvio = new TMensagemEnvio[1] }
            };
            envio.MensagemEnvio.TMensagemEnvio[0] = new TMensagemEnvio
            {
                DadosMensagem = dadosMensagem,
                DadosSMS = dadosSMS
            };
            var retornoEnvio = publishService.fncEnviarMensagem(new fncEnviarMensagemRequest { MensagensEnvioLote = envio }).@return;
            return retornoEnvio.Codigo == 0;
        }
        
        public void Dispose()
        {
            var disposable = _publishService as IDisposable;
            if (disposable != null) disposable.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}