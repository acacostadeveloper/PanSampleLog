﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Oracle.ManagedDataAccess.Client;
using Pan.Credito.CrossCutting;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Boletos;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Helpers;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Repository;

namespace Pan.Credito.Infrastructure.Adapters
{
    public class PansolutionAdapter : IPansolutionAdapter
    {
        private readonly IRcpRepository _rcpRepository;
        private readonly ICyberAdapter _cyberAdapter;

        public PansolutionAdapter(IRcpRepository rcpRepository, ICyberAdapter cyberAdapter)
        {
            _rcpRepository = rcpRepository;
            _cyberAdapter = cyberAdapter;
        }

        public ClienteExtrato ObterCliente(long Documento)
        {
            if (Documento <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();

            if (Documento > 0)
            {
                oHelp.AddParameter("Documento", DbType.Int64, Documento);
            }

            var cliente = oHelp.ExecuteEntityText<ClienteExtrato>(Properties.Resources.PS_Cliente_Dados);


            if (cliente.Count == 0) throw new Exception("Operação não encontrada");

            return cliente.First();
        }
        public Cliente ObterCliente2(long Documento)
        {
            if (Documento <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("Documento", DbType.Int64, Documento);

            var cliente = oHelp.ExecuteEntityText<Cliente>(Properties.Resources.PS_Cliente_Dados);

            if (cliente.Count == 0) return null;

            var firstOrDefault = cliente.FirstOrDefault();
            if (firstOrDefault != null) firstOrDefault.TipoSistema = TipoSistema.Pansolution;

            return cliente.FirstOrDefault();
        }
        public List<Endereco> ObterClienteEndereco(long codCliente)
        {
            var oHelp = new OracleHelper();
            oHelp.AddParameter("COD_CLIENTE", DbType.Int64, codCliente);
            var data = oHelp.ExecuteEntityText<Endereco>(Properties.Resources.PS_Cliente_Endereco);
            return data;
        }
        public List<Telefone> ObterClienteTelefone(long codCliente)
        {
            var oHelp = new OracleHelper();
            oHelp.AddParameter("COD_CLIENTE", DbType.Int64, codCliente);
            var data = oHelp.ExecuteEntityText<Telefone>(Properties.Resources.PS_Cliente_Telefone);
            return data;
        }
        public List<Referencia> ObterClienteReferencia(long CodigoLoja, long NumeroTransacao)
        {
            var oHelp = new OracleHelper();
            oHelp.AddParameter("LOJA_CODIGO", DbType.Int64, CodigoLoja);
            oHelp.AddParameter("NUM_TRANSACAO", DbType.Int64, NumeroTransacao);
            var data = oHelp.ExecuteEntityText<Referencia>(Properties.Resources.PS_Cliente_Referencia);
            return data;
        }
        public int ObterCodigoProfissaoCliente(string profissao)
        {
            if (string.IsNullOrEmpty(profissao)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("profissao", DbType.String, profissao);
            var data = oHelp.ExecuteScalar<int>(Properties.Resources.PS_Codigo_Profissao_Obter);
            return data;
        }
        public DataSet ObterContratosCliente(long p_intDocumento)
        {
            if (p_intDocumento <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCPF",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCNPJ",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });

                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Cliente_Operacoes;

                    objConexao.Open();

                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();

                    if (objDS.Tables.Count == 0 || objDS.Tables[0].Rows.Count == 0)
                        return null;
                }
            }

            return objDS;
        }
        public DateTime ObterDataNascimentoCliente(long cpf)
        {
            if (cpf <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("cpf", DbType.Int64, cpf);
            var data = oHelp.ExecuteScalar<DateTime>(Properties.Resources.PS_Data_Nascimento_Obter);
            return data;
        }
        public DataSet ValidarCliente(long p_intDocumento)
        {
            if (p_intDocumento <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCPF",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });

                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCNPJ",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Cliente_Validar;
                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();
                    objDA.Fill(objDS);
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();

                    if (objDS.Tables.Count == 0 || objDS.Tables[0].Rows.Count == 0) return null;
                }
            }

            return objDS;
        }
        public List<TipoVeiculo> ObterTipoVeiculo()
        {
            var oHelp = new OracleHelper();
            var data = oHelp.ExecuteEntityText<TipoVeiculo>(Properties.Resources.PS_Tipo_Veiculo_Obter);
            return data;
        }
        public List<VeiculoCliente> ObterVeiculoCliente(string placa, string chassi)
        {
            var oHelp = new OracleHelper();
            var sb = new StringBuilder();
            if (!string.IsNullOrEmpty(placa)) sb.Append(" AND GAR_VEIC.NUM_PLACA_ATU = '" + placa + "' ");

            if (!string.IsNullOrEmpty(chassi)) sb.Append(" AND GAR_VEIC.NUM_CHASSI = '" + chassi + "' ");

             return oHelp.ExecuteEntityText<VeiculoCliente>(Properties.Resources.PS_Veiculo_Cliente.Replace("@WHERE", sb.ToString()));
        }
        public decimal ObterCodigoContratoInterno(string codContrato)
        {
            if (string.IsNullOrEmpty(codContrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper(); 
            oHelp.AddParameter("codContrato", DbType.String, codContrato);
            var operacao = oHelp.ExecuteScalar<decimal>(Properties.Resources.PS_Contrato_Interno_Obter);
            return operacao;
        }
        public XElement ObterDeclaracaoQuitacao(long p_intDocumento, string p_strContrato = "")
        {
            if (p_intDocumento <= 0 && String.IsNullOrWhiteSpace(p_strContrato))
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            XElement objXML;
            var strWhere = string.Empty;
            var strWhere1 = string.Empty;
            var strWhere2 = string.Empty;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objConexao.Open();
                    if (p_intDocumento > 0)
                    {
                        strWhere1 = " CLIENTEPF.NUM_CPF = :p_intCPF ";
                        strWhere2 = " CLIENTEPJ.NUM_CGC = :p_intCNPJ ";
                    }
                    if (!String.IsNullOrWhiteSpace(p_strContrato))
                    {
                        if (p_intDocumento > 0)
                        {
                            strWhere1 += " And ";
                            strWhere2 += " And ";
                        }

                        strWhere1 += @"CADASTRO.COD_CLIENTE = (Select COD_CLIENTE From ECON_EMPRESTIMOS Where COD_CONTRATO = :p_strContrato)";
                        strWhere2 += @"CADASTRO.COD_CLIENTE = (Select COD_CLIENTE From ECON_EMPRESTIMOS Where COD_CONTRATO = :p_strContrato)";
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Declaracao_Quitacao_Clientes.Replace("%WHERE1%", strWhere1).Replace("%WHERE2%", strWhere2);
                    if (p_intDocumento > 0)
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intCPF",
                            DbType = DbType.Int64,
                            Value = p_intDocumento
                        });
                    }

                    if (!string.IsNullOrWhiteSpace(p_strContrato))
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Value = p_strContrato
                        });

                    }

                    if (p_intDocumento > 0)
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intCNPJ",
                            DbType = DbType.Int64,
                            Value = p_intDocumento
                        });
                    }
                    var objDA = new OracleDataAdapter(objCommand);
                    var objDSCliente = new DataSet();

                    objDA.Fill(objDSCliente);
                    if (objDSCliente.Tables.Count == 0 || objDSCliente.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    objXML = XElement.Parse("<Extrato tipo=\"Quitacao\" />");
                    objXML.Add(new XElement("Cliente",
                        new XElement("Nome", objDSCliente.Tables[0].Rows[0]["Cliente_Nome"]),
                        new XElement("TipoPessoa", objDSCliente.Tables[0].Rows[0]["Cliente_TipoPessoa"]),
                        new XElement("Documento",
                            objDSCliente.Tables[0].Rows[0]["Cliente_TipoPessoa"].ToString().Equals("F") ?
                                objDSCliente.Tables[0].Rows[0]["Cliente_Documento"].ToString().PadLeft(11, '0') : objDSCliente.Tables[0].Rows[0]["Cliente_Documento"].ToString().PadLeft(14, '0'))
                        ));
                    if (p_intDocumento > 0)
                    {
                        strWhere = @"Cod_cliente In 
                                    (
                                        SELECT
                                            CADASTRO.COD_CLIENTE      AS Cliente_Codigo
                                        FROM
                                                       BCLI_CADASTRO CADASTRO
                                            Inner JOIN BCLI_FIS_BASE CLIENTEPF ON CADASTRO.COD_CLIENTE = CLIENTEPF.COD_CLIENTE
                                        WHERE
                                            CLIENTEPF.NUM_CPF = :p_intCPF

                                        UNION

                                        SELECT
                                            CADASTRO.COD_CLIENTE  AS Cliente_Codigo
                                        FROM
                                                       BCLI_CADASTRO CADASTRO
                                            Inner JOIN BCLI_JUR_BASE CLIENTEPJ ON CADASTRO.COD_CLIENTE = CLIENTEPJ.COD_CLIENTE
                                        WHERE
                                            CLIENTEPJ.NUM_CGC = :p_intCNPJ
                                    )";
                    }
                    if (!string.IsNullOrWhiteSpace(p_strContrato))
                    {
                        if (p_intDocumento > 0)
                        {
                            strWhere += " And ";
                        }

                        strWhere += "Operacoes.COD_CONTRATO = :p_strContrato";
                    }
                    var strSQLQuitacaoAnormal = p_OrgaosRecebedoresQuitacaoAnormal();

                    if (!String.IsNullOrWhiteSpace(strSQLQuitacaoAnormal))
                    {
                        strWhere += " And Not Exists (" + strSQLQuitacaoAnormal + ") ";
                    }
                    objCommand.CommandText = Properties.Resources.PS_Declaracao_Quitacao_Operacoes.Replace("%WHERE%", strWhere);
                    objCommand.Parameters.Clear();

                    if (p_intDocumento > 0)
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intCPF",
                            DbType = DbType.Int64,
                            Value = p_intDocumento
                        });

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intCNPJ",
                            DbType = DbType.Int64,
                            Value = p_intDocumento
                        });

                    }

                    if (!string.IsNullOrWhiteSpace(p_strContrato))
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Value = p_strContrato
                        });

                    }
                    var objDSOperacoes = new DataSet();
                    objDA.Fill(objDSOperacoes);
                    if (objDSOperacoes.Tables.Count == 0 || objDSOperacoes.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    foreach (var objOperacao in from DataRow objRow in objDSOperacoes.Tables[0].Rows select new XElement("Operacao",
                        new XElement("Empresa_Nome", objRow["Empresa_Nome"]),
                        new XElement("Empresa_CNPJ", objRow["Empresa_CNPJ"]),
                        new XElement("Data_Contrato", objRow["Operacao_DataLiberacao"]),
                        new XElement("Codigo", objRow["Operacao_Codigo"]),
                        new XElement("Contrato", objRow["Operacao_Contrato"])))
                    {
                        objXML.Add(objOperacao);
                    }
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objXML;
        }
        public ClienteExtrato ObterDeclaracaoQuitacaoCliente(long Documento, string Contrato)
        {
            if (Documento <= 0 && string.IsNullOrEmpty(Contrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var sb = new StringBuilder();
            var sb2 = new StringBuilder();

            var oHelp = new OracleHelper();

            if (Documento > 0)
            {
                sb.Append(" CLIENTEPF.NUM_CPF = :p_intCPF ");
                sb2.Append(" CLIENTEPJ.NUM_CGC = :p_intCNPJ ");
            }

            if (!string.IsNullOrWhiteSpace(Contrato))
            {
                if (Documento > 0)
                {
                    sb.Append(" And ");
                    sb2.Append(" And ");
                }

                sb.Append(@"CADASTRO.COD_CLIENTE = (Select COD_CLIENTE From ECON_EMPRESTIMOS Where COD_CONTRATO = :p_strContrato)");
                sb2.Append(@"CADASTRO.COD_CLIENTE = (Select COD_CLIENTE From ECON_EMPRESTIMOS Where COD_CONTRATO = :p_strContrato)");
            }

            if (Documento > 0)
            {
                oHelp.AddParameter("p_intCPF", DbType.Int64, Documento);
                oHelp.AddParameter("p_intCNPJ", DbType.Int64, Documento);

            }

            if (!string.IsNullOrWhiteSpace(Contrato)) oHelp.AddParameter("p_strContrato", DbType.String, Contrato);


            var cliente = oHelp.ExecuteEntityText<ClienteExtrato>(Properties.Resources.PS_Declaracao_Quitacao_Clientes.Replace("%WHERE1%", sb.ToString()).Replace("%WHERE2%", sb2.ToString()));


            if (cliente.Count == 0) throw new Exception("Operação não encontrada");

            sb.Clear();

            if (Documento > 0)
            {
                sb.Append(@"Cod_cliente In 
                                    (
                                        SELECT
                                            CADASTRO.COD_CLIENTE      AS Cliente_Codigo
                                        FROM
                                                       BCLI_CADASTRO CADASTRO
                                            Inner JOIN BCLI_FIS_BASE CLIENTEPF ON CADASTRO.COD_CLIENTE = CLIENTEPF.COD_CLIENTE
                                        WHERE
                                            CLIENTEPF.NUM_CPF = :p_intCPF

                                        UNION

                                        SELECT
                                            CADASTRO.COD_CLIENTE  AS Cliente_Codigo
                                        FROM
                                                       BCLI_CADASTRO CADASTRO
                                            Inner JOIN BCLI_JUR_BASE CLIENTEPJ ON CADASTRO.COD_CLIENTE = CLIENTEPJ.COD_CLIENTE
                                        WHERE
                                            CLIENTEPJ.NUM_CGC = :p_intCNPJ
                                    )");
            }

            if (!string.IsNullOrWhiteSpace(Contrato))
            {
                if (Documento > 0) sb.Append(" And ");

                sb.Append("Operacoes.COD_CONTRATO = :p_strContrato");
            }

            var SQLQuitacaoAnormal = p_OrgaosRecebedoresQuitacaoAnormal();

            if (!string.IsNullOrWhiteSpace(SQLQuitacaoAnormal)) sb.Append(" And Not Exists (" + SQLQuitacaoAnormal + ") ");

            var oHelp2 = new OracleHelper();

            if (Documento > 0)
            {
                oHelp2.AddParameter("p_intCPF", DbType.Int64, Documento);
                oHelp2.AddParameter("p_intCNPJ", DbType.Int64, Documento);

            }
            if (!string.IsNullOrWhiteSpace(Contrato))
                oHelp2.AddParameter("p_strContrato", DbType.String, Contrato);

            var operacao = oHelp2.ExecuteEntityText<Operacao>(Properties.Resources.PS_Declaracao_Quitacao_Operacoes.Replace("%WHERE%", sb.ToString()));

            if (operacao.Count == 0) throw new Exception("Operação não encontrada");

            cliente.First().Operacoes = operacao;
            return cliente.First();
        }
        public XElement ObterExtratoPagamentos(long p_intDocumento, DateTime p_dtmInicio, DateTime p_dtmFim)
        {
            if (p_intDocumento <= 0 || DateTime.MinValue.Equals(p_dtmInicio) || DateTime.MinValue.Equals(p_dtmFim))
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            XElement objXML;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCPF",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCNPJ",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Extratos_Pagamentos_Clientes;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    var objDSCliente = new DataSet();

                    objDA.Fill(objDSCliente);
                    if (objDSCliente.Tables.Count == 0 || objDSCliente.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    objXML = XElement.Parse("<Extrato tipo=\"Pagamentos\" />");

                    objXML.Add(new XElement("Cliente",
                        new XElement("Nome", objDSCliente.Tables[0].Rows[0]["Cliente_Nome"]),
                        new XElement("TipoPessoa", objDSCliente.Tables[0].Rows[0]["Cliente_TipoPessoa"]),
                        new XElement("Documento", objDSCliente.Tables[0].Rows[0]["Cliente_Documento"])
                        ));
                    objCommand.CommandText = Properties.Resources.PS_Extratos_Pagamentos_Operacoes;
                    var objDSOperacoes = new DataSet();
                    objDA.Fill(objDSOperacoes);
                    if (objDSOperacoes.Tables.Count == 0 || objDSOperacoes.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    objCommand.CommandText = Properties.Resources.PS_Extratos_Pagamentos_Parcelas;
                    var objDSParcelas = new DataSet();
                    objDA.Fill(objDSParcelas);
                    if (objDSParcelas.Tables.Count == 0 || objDSParcelas.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    foreach (DataRow objRow in objDSOperacoes.Tables[0].Rows)
                    {
                        var decValorAcrescimos = 0.0m;
                        var decValorDescontos = 0.0m;
                        var decValorParcelas = 0.0m;
                        var intCodigoOperacao = Convert.ToInt64(objRow["Operacao_Codigo"]);
                        var objOperacao = new XElement("Operacao",
                            new XElement("Empresa_Nome", objRow["Empresa_Nome"]),
                            new XElement("Empresa_CNPJ", objRow["Empresa_CNPJ"]),
                            new XElement("Data_Contrato", objRow["Operacao_DataLiberacao"]),
                            new XElement("Codigo", objRow["Operacao_Codigo"]),
                            new XElement("Contrato", objRow["Operacao_Contrato"]));
                        var objParcelas = new XElement("Parcelas");
                        var arrParcelas = objDSParcelas.Tables[0].Select("COD_CONTRATO_INTER = " + intCodigoOperacao.ToString(), "LIQUIDACAO_DATA Asc, DATA_AMORTIZACAO Asc");
                        foreach (var objParcela in arrParcelas)
                        {
                            if (objParcela["Liquidacao_Data"] == DBNull.Value)
                            {
                                continue;
                            }
                            var dtmPagamento = Convert.ToDateTime(objParcela["Liquidacao_Data"]);

                            if (dtmPagamento < p_dtmInicio)
                            {
                                decValorAcrescimos += Convert.ToDecimal(objParcela["Liquidacao_Acrescimos"]);
                                decValorDescontos += Convert.ToDecimal(objParcela["Liquidacao_Descontos"]);
                                decValorParcelas += Convert.ToDecimal(objParcela["Liquidacao_ValorParcela"]);
                            }
                            else if (dtmPagamento <= p_dtmFim)
                            {
                                objParcelas.Add(new XElement("Parcela",
                                    new XElement("Data_Amortizacao", Convert.ToDateTime(objParcela["DATA_AMORTIZACAO"]).ToString("yyyy-MM-dd")),
                                    new XElement("Data_Liquidacao", Convert.ToDateTime(objParcela["Liquidacao_Data"]).ToString("yyyy-MM-dd")),
                                    new XElement("Valor_Parcela", Convert.ToDecimal(objParcela["Liquidacao_ValorParcela"]).ToString("0.00", CultureInfo.InvariantCulture)),
                                    new XElement("Valor_Acrescimo", Convert.ToDecimal(objParcela["Liquidacao_Acrescimos"]).ToString("0.00", CultureInfo.InvariantCulture)),
                                    new XElement("Valor_Desconto", Convert.ToDecimal(objParcela["Liquidacao_Descontos"]).ToString("0.00", CultureInfo.InvariantCulture)),
                                    new XElement("Valor_Pago", (Convert.ToDecimal(objParcela["Liquidacao_ValorParcela"]) + Convert.ToDecimal(objParcela["Liquidacao_Acrescimos"]) - Convert.ToDecimal(objParcela["Liquidacao_Descontos"])).ToString("0.00", CultureInfo.InvariantCulture))));
                            }
                            else
                            {
                                break;
                            }
                        }

                        if (objParcelas.HasElements)
                        {
                            objOperacao.Add(new XElement("ValorParcelas", decValorParcelas.ToString("0.00", CultureInfo.InvariantCulture)));
                            objOperacao.Add(new XElement("ValorAcrescimos", decValorAcrescimos.ToString("0.00", CultureInfo.InvariantCulture)));
                            objOperacao.Add(new XElement("ValorDescontos", decValorDescontos.ToString("0.00", CultureInfo.InvariantCulture)));
                            objOperacao.Add(new XElement("ValorExtras", "0.00"));
                            objOperacao.Add(objParcelas);

                            objXML.Add(objOperacao);
                        }
                    }
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objXML;

        }
        public ClienteExtrato ObterExtratoPagamentosCliente(long p_intDocumento, DateTime p_dtmInicio, DateTime p_dtmFim)
        {
            if (p_intDocumento <= 0 || DateTime.MinValue.Equals(p_dtmInicio) || DateTime.MinValue.Equals(p_dtmFim))
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            decimal decValorParcelas;
            decimal decValorAcrescimos;
            decimal decValorDescontos;

            var oHelp = new OracleHelper();

            if (p_intDocumento > 0)
            {
                oHelp.AddParameter("p_intCPF", DbType.Int64, p_intDocumento);
                oHelp.AddParameter("p_intCNPJ", DbType.Int64, p_intDocumento);

            }

            var cliente = oHelp.ExecuteEntityText<ClienteExtrato>(Properties.Resources.PS_Extratos_Pagamentos_Clientes);

            if (cliente.Count == 0)
                throw new Exception("Operação não encontrada");

           var operacoes = oHelp.ExecuteEntityText<Operacao>(Properties.Resources.PS_Extratos_Pagamentos_Operacoes);
           var parcelas = oHelp.ExecuteEntityText<ParcelasExtrato>(Properties.Resources.PS_Extratos_Pagamentos_Parcelas);

            parcelas = parcelas.Where(p => p.DataLiquidacao != DateTime.MinValue).ToList();

            operacoes.ForEach(o =>
            {
                decValorAcrescimos = 0.0m;
                decValorDescontos = 0.0m;
                decValorParcelas = 0.0m;

                parcelas.Where(p => p.ContratoInter.ToString() == o.Codigo).ToList().ForEach(p =>
                {
                    if (p.DataLiquidacao < p_dtmInicio)
                    {
                        decValorAcrescimos += p.Acrescimos;
                        decValorDescontos += p.Descontos;
                        decValorParcelas += p.Valor;

                    }
                    else if (p.DataLiquidacao <= p_dtmFim)
                    {
                        if (o.Parcelas == null)
                            o.Parcelas = new List<ParcelasExtrato>();

                        o.Parcelas.Add(p);
                    }
                });

                if (o.Parcelas != null && o.Parcelas.Count > 0)
                {
                    o.ValorParcelas = decValorParcelas;
                    o.ValorAcrescimos = decValorAcrescimos;
                    o.ValorDescontos = decValorDescontos;

                }
            });

            cliente.First().Operacoes = operacoes;

            return cliente.First();
        }
        public ClienteExtrato ObterExtratoTaxas(long Documento, int Ano)
        {
            if (Ano < 2013m) return null;
            
            var oHelp = new OracleHelper();

            oHelp.AddParameter("Documento", DbType.Int64, Documento);

            var clientes = oHelp.ExecuteEntityText<ClienteExtrato>(Properties.Resources.PS_Cliente_Dados);

            if (clientes.Count == 0)
                throw new Exception("Operação não encontrada");

            oHelp.AddParameter("DATA_INICIAL", DbType.DateTime, Convert.ToDateTime(Ano + "-01-01"));
            oHelp.AddParameter("DATA_FINAL", DbType.DateTime, Convert.ToDateTime(Ano + "-12-31"));

            var tarifas = oHelp.ExecuteEntityText<TarifasExtrato>(Properties.Resources.PS_Operacao_Tarifas);

            var cliente = clientes.First();

            cliente.Tarifas = tarifas;
            return cliente;
        }
        public List<Liberacao> ObterOperacoesRealizadas(string Contrato)
        {
            var oHelp = new OracleHelper();
            oHelp.AddParameter("CONTRATO", DbType.String, Contrato);
            var data = oHelp.ExecuteEntityText<Liberacao>(Properties.Resources.PS_Operacao_Realizadas);
            return data;
        }
        public List<Contrato> CalcularQuitacao(string documento)
        {
            var objMsg = Mensagem.CriarMensagem("isisfpes", "UPE"
                , new KeyValuePair<String, String>("CODIGO1", "002")
                , new KeyValuePair<String, String>("CODIGO2", "PU")
                , new KeyValuePair<String, String>("DOCUMENTO", documento)
                , new KeyValuePair<String, String>("OPCAO", "1"));
            objMsg.Executar();

            var contratos = new List<Contrato>();

            if (objMsg.ErroNumero == 0)
            {
                objMsg.ItensRetorno["CONTRATO"].Itens.ToList().ForEach(c =>
                {
                    var contrato = new Contrato {NumeroContrato = c.Itens["COD_CONTRATO"].ValorTexto};

                    if (contrato.NumeroContrato.Contains("CES")) return;

                    contrato.Assessoria = c.Itens["FLAG_ASSESSORIA"].ValorTexto;
                    contrato.QuitacaoD0 = Convert.ToDecimal(c.Itens["VAL_QUITACAO_D0"].ValorTexto) / 100;
                    contrato.QuitacaoD1 = Convert.ToDecimal(c.Itens["VAL_QUITACAO_D1"].ValorTexto) / 100;
                    contrato.StringCyber = c.Itens["STRING_CYBER"].ValorTexto;
                    contratos.Add(contrato);
                });
            }

            return contratos;
        }
        public DataSet ListarOperacoes(long p_intDocumento, string p_strTipoPessoa)
        {
            if (p_intDocumento <= 0 || String.IsNullOrWhiteSpace(p_strTipoPessoa))
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intDocumento",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Operacoes_Listar;
                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0 || objDS.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public DataSet ObterAcordos(long p_intContratoInterno)
        {
            if (p_intContratoInterno <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intContratoInterno",
                        DbType = DbType.Int64,
                        Value = p_intContratoInterno
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Acordos_Obter;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0)
                    {
                        throw new Exception("Não foi possível recuperar os valores solicitados.");
                    }
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public List<BandeiraCartao> ObterBandeiraCartao()
        {
            var oHelp = new OracleHelper();
            var data = oHelp.ExecuteEntityText<BandeiraCartao>(Properties.Resources.PS_Operacao_Bandeira_Cartao_Obter);
            return data;
        }
        public List<Boleto> ObterBoletos(string p_strContrato, int p_intProximos, DateTime? p_dtmInicio, DateTime? p_dtmTermino, bool p_blnIncluirLiquidados)
        {
            if ("" == p_strContrato) return null;

            List<Boleto> lstBoletos;
            var decJurosRemuneratorios = 0.0m;
            var decMora = 0.0m;
            var decMulta = 0.0m;
            var decValorJurosRemuneratorios = 0.0m;

            var objDSMoraMulta = ObterTaxasEncargos(p_strContrato, 0);
            if (objDSMoraMulta.Tables[0].Rows.Count > 0)
            {
                decMulta = Convert.ToDecimal(objDSMoraMulta.Tables[0].Rows[0]["MULTA"]);
                decMora = Convert.ToDecimal(objDSMoraMulta.Tables[0].Rows[0]["MORA"]);
                decJurosRemuneratorios = Convert.ToDecimal(objDSMoraMulta.Tables[0].Rows[0]["JUROS_REMUNERATORIOS"]);
            }
            var intPrazoBancario = ObterPrazoBancario(p_strContrato, 0);
            var intQtdeParcelas = ObterQuantidadeParcelas(p_strContrato, 0);
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();

                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(Properties.Resources.PS_Boletos_Obter);

                    if (string.Empty != p_strContrato)
                    {
                        objSB.AppendLine(" AND OPERACAO.COD_CONTRATO = :p_strContrato ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });

                    }

                    if (null != p_dtmInicio)
                    {
                        objSB.AppendLine(" AND BOLETO.DATA_AMORTIZACAO >= :p_dtmInicio ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_dtmInicio",
                            DbType = DbType.DateTime,
                            Value = p_dtmInicio
                        });
                    }

                    if (null != p_dtmTermino)
                    {
                        objSB.AppendLine(" AND BOLETO.DATA_AMORTIZACAO <= :p_dtmTermino ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_dtmTermino",
                            DbType = DbType.DateTime,
                            Value = p_dtmTermino
                        });
                    }

                    if (!p_blnIncluirLiquidados)
                    {
                        objSB.AppendLine(" AND AMORT.FLAG_LIQUIDADO = 'N' ");


                        objSB.AppendLine(" AND BOLETO.DATA_AMORTIZACAO >= :p_dtmAtual ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_dtmAtual",
                            DbType = DbType.DateTime,
                            Value = new DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day).AddDays(-intPrazoBancario)
                        });
                    }

                    objSB.AppendLine(" ORDER BY BOLETO.DATA_AMORTIZACAO ");
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();

                    using (var sdr = objCommand.ExecuteReader())
                    {
                        lstBoletos = new List<Boleto>();

                        while (sdr.Read())
                        {
                            var objBoleto = new Boleto()
                            {
                                Sacado = new Sacado()
                                {
                                    Nome = sdr.GetString(sdr.GetOrdinal("SACADO_NOME")).Trim(),
                                    CPFCNPJ = sdr.GetValue(sdr.GetOrdinal("SACADO_DOCUMENTO")).ToString(),
                                    TipoPessoa = sdr.GetString(sdr.GetOrdinal("SACADO_TIPOPESSOA")),
                                    Endereco = new Endereco()
                                    {
                                        Bairro = sdr.GetString(sdr.GetOrdinal("SACADO_ENDERECO_BAIRRO")).Trim(),
                                        CEP = sdr.GetDecimal(sdr.GetOrdinal("SACADO_ENDERECO_CEP")).ToString("00000-000"),
                                        Cidade = sdr.GetString(sdr.GetOrdinal("SACADO_ENDERECO_CIDADE")).Trim(),
                                        Complemento = !sdr.IsDBNull(sdr.GetOrdinal("SACADO_ENDERECO_COMPLEMENTO")) ? sdr.GetString(sdr.GetOrdinal("SACADO_ENDERECO_COMPLEMENTO")).Trim() : "",
                                        Logradouro = sdr.GetString(sdr.GetOrdinal("SACADO_ENDERECO_LOGRADOURO")).Trim(),
                                        Numero = sdr.GetString(sdr.GetOrdinal("SACADO_ENDERECO_NUMERO")).Trim(),
                                        UF = sdr.GetString(sdr.GetOrdinal("SACADO_ENDERECO_UF")).Trim()
                                    }
                                },
                                Cedente = new Cedente()
                                {
                                    Codigo = 0,
                                    CPFCNPJ = sdr.GetDecimal(sdr.GetOrdinal("CEDENTE_CNPJ")).ToString(),
                                    Nome = sdr.GetString(sdr.GetOrdinal("CEDENTE_NOME")).Trim(),
                                    ContaBancaria = new ContaBancaria()
                                    {
                                        Agencia = sdr.GetDecimal(sdr.GetOrdinal("CEDENTE_AGENCIA")).ToString(),
                                        DigitoAgencia = sdr.GetString(sdr.GetOrdinal("CEDENTE_AGENCIA_DIGITO")).Trim(),
                                        Conta = sdr.GetDecimal(sdr.GetOrdinal("CEDENTE_CONTA")).ToString(),
                                        DigitoConta = sdr.GetString(sdr.GetOrdinal("CEDENTE_CONTA_DIGITO")).Trim()
                                    },
                                    Endereco = new Endereco()
                                    {
                                        Bairro = sdr.GetString(sdr.GetOrdinal("CEDENTE_ENDERECO_BAIRRO")).Trim(),
                                        CEP = sdr.GetDecimal(sdr.GetOrdinal("CEDENTE_ENDERECO_CEP")).ToString("00000-000"),
                                        Cidade = sdr.GetString(sdr.GetOrdinal("CEDENTE_ENDERECO_CIDADE")).Trim(),
                                        Complemento = !sdr.IsDBNull(sdr.GetOrdinal("CEDENTE_ENDERECO_COMPLEMENTO")) ? sdr.GetString(sdr.GetOrdinal("CEDENTE_ENDERECO_COMPLEMENTO")).Trim() : "",
                                        Logradouro = sdr.GetString(sdr.GetOrdinal("CEDENTE_ENDERECO_LOGRADOURO")).Trim(),
                                        Numero = sdr.GetString(sdr.GetOrdinal("CEDENTE_ENDERECO_NUMERO")).Trim(),
                                        UF = sdr.GetString(sdr.GetOrdinal("CEDENTE_ENDERECO_UF")).Trim()
                                    }
                                },
                                Banco = new Banco()
                                {
                                    Codigo = Convert.ToInt32(sdr.GetDecimal(sdr.GetOrdinal("BOLETO_BANCO")))
                                },
                                NumeroParcelas = intQtdeParcelas,
                                NumeroParcela = Convert.ToInt32(sdr.GetDecimal(sdr.GetOrdinal("BOLETO_NUM_PARCELA"))),
                                DataVencimento = sdr.GetDateTime(sdr.GetOrdinal("BOLETO_AMORTIZACAO")),
                                Carteira = sdr.GetDecimal(sdr.GetOrdinal("BOLETO_CARTEIRA")).ToString(),
                                NumeroDocumento = sdr.GetString(sdr.GetOrdinal("BOLETO_NUMERO_TITULO")).Trim(),
                                NossoNumero = sdr.GetString(sdr.GetOrdinal("BOLETO_NOSSO_NUMERO")).Trim(),
                                ValorBoleto = sdr.GetDecimal(sdr.GetOrdinal("BOLETO_VALOR"))
                            };
                            const bool blnRegistro = false;
                            var blnRegraNova = (String.Compare(ConfigurationManager.AppSettings["Pansolution_Boleto_DataRegraMoraMulta_1"], sdr.GetDateTime(sdr.GetOrdinal("OPERACAO_DATA")).ToString("yyyy-MM-dd")) == -1);
                            var objCulture = new CultureInfo("pt-BR");


                            if (!blnRegraNova)
                            {
                                objBoleto.ValorMoraDiária = (((decMora + decJurosRemuneratorios) / 100.0m) / 30.0m) * sdr.GetDecimal(sdr.GetOrdinal("BOLETO_VALOR"));
                                objBoleto.ValorMultaAtraso = decMulta;
                            }
                            else
                            {
                                objBoleto.ValorMoraDiária = ((decMora / 100.0m) / 30.0m) * sdr.GetDecimal(sdr.GetOrdinal("BOLETO_VALOR"));
                                objBoleto.ValorMultaAtraso = ((decMulta / 100.0m) * sdr.GetDecimal(sdr.GetOrdinal("BOLETO_VALOR")));
                                decValorJurosRemuneratorios = ((decJurosRemuneratorios / 100.0m) / 30.0m) * sdr.GetDecimal(sdr.GetOrdinal("BOLETO_VALOR"));
                            }
                            if (!blnRegistro && !blnRegraNova)
                                objBoleto.Instrucoes.Add(String.Format("Cobrar comissão de permanência de R$ {0} por dia de atraso.", objBoleto.ValorMoraDiária.ToString("#,##0.00", objCulture)));

                            if (blnRegraNova)
                            {
                                objBoleto.Instrucoes.Add("* * Valores expressos em reais * *");
                                objBoleto.Instrucoes.Add("Valores calculados automaticamente.");
                                objBoleto.Instrucoes.Add(String.Format("Após o vencimento e em atraso de até {0} dias, pagável somente nas agências {1}.", intPrazoBancario, objBoleto.Banco.NomeAbreviado));

                                if (!blnRegistro)
                                {
                                    if (decMulta > 0.0m)
                                        objBoleto.Instrucoes.Add(String.Format("Serão acrescidos ao valor original da parcela: multa de {0}% totalizando R$ {1}.", decMulta.ToString("#,##0.00", objCulture), objBoleto.ValorMultaAtraso.ToString("#,##0.00", objCulture)));

                                    if (decMora > 0.0m && decJurosRemuneratorios > 0.0m)
                                        objBoleto.Instrucoes.Add(String.Format("Mora R$ {0} por dia de atraso e Juros remuneratórios de R$ {1} por dia de atraso.", objBoleto.ValorMoraDiária.ToString("#,##0.00", objCulture), decValorJurosRemuneratorios.ToString("#,##0.00", objCulture)));
                                    else if (decMora > 0.0m)
                                        objBoleto.Instrucoes.Add(String.Format("Mora R$ {0} por dia de atraso.", objBoleto.ValorMoraDiária.ToString("#,##0.00", objCulture)));
                                    else if (decJurosRemuneratorios > 0.0m)
                                        objBoleto.Instrucoes.Add(String.Format("Juros remuneratórios de R$ {0} por dia de atraso.", decValorJurosRemuneratorios.ToString("#,##0.00", objCulture)));
                                }

                                objBoleto.Instrucoes.Add("O pagamento desta parcela não quita débitos anteriores.");
                                objBoleto.Instrucoes.Add("Após o vencimento consulte Serviços em <A HREF='www.bancopan.com.br'>www.bancopan.com.br</A> ou ligue para a Central de Atendimento");
                                objBoleto.Instrucoes.Add("CAC – Capitais e regiões metropolitanas – 4002 1687 ou 0800 775 8686 Demais localidades");
                                objBoleto.Instrucoes.Add("SAC – 0800 776 8000");
                                objBoleto.Instrucoes.Add("Ouvidoria – 0800 776 9595");
                            }
                            else
                            {
                                objBoleto.Instrucoes.Add(String.Format("Pagável em qualquer agência " + objBoleto.Banco.NomeAbreviado + " até <b>{0}</b> dias após o vencimento.", intPrazoBancario));
                                objBoleto.Instrucoes.Add(String.Format("Após {0} dias do vencimento, consultar o site <A HREF='www.bancopan.com.br'>www.bancopan.com.br</A>, acessar a opção <b>Acessar meus serviços</b>, depois acessar <b>Consultar Cobradora.</b>", intPrazoBancario));
                                objBoleto.Instrucoes.Add("O pagamento deste não quita outros débitos.");
                                objBoleto.Instrucoes.Add("Em caso de dúvida, entrar em contato com a central de atendimento nos telefones:");
                                objBoleto.Instrucoes.Add("Capitais e regiões metropolitanas 4002-1687, demais localidades 0800-775-8686");
                            }
                            lstBoletos.Add(objBoleto);
                            if (0 < p_intProximos)
                            {
                                if (lstBoletos.Count >= p_intProximos)
                                {
                                    break;
                                }
                            }
                        }
                    }

                    objConexao.Close();
                }
            }

            return lstBoletos;
        }
        public List<Boleto> ObterBoletosAcordo(string p_strContrato, long p_intContratoInterno = 0, DateTime? p_dtmPagamento = null, int p_intNumeroSequencia = 0)
        {
            if (string.Empty == p_strContrato && 0 >= p_intContratoInterno)
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para obtenção de boleto de acordo");

            List<Boleto> lstBoletos;
            if (p_intContratoInterno <= 0)
                p_intContratoInterno = ObterContratoInterno(p_strContrato);

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    var objSBBoleto = new StringBuilder();
                    var objSBParcelas = new StringBuilder();

                    objSBBoleto.Append(Properties.Resources.PS_BoletosAcordo_Obter);
                    objSBParcelas.Append(Properties.Resources.PS_BoletosAcordoParcelas_Obter);

                    if (0 < p_intContratoInterno)
                    {
                        objSBBoleto.AppendLine(" AND OPERACAO.COD_CONTRATO_INTER  = :intContratoInterno ");
                        objSBParcelas.AppendLine(" AND Operacoes.COD_CONTRATO_INTER = :intContratoInterno ");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "intContratoInterno",
                            DbType = DbType.Int64,
                            Value = p_intContratoInterno
                        });
                    }
                    else if ("" != p_strContrato)
                    {
                        objSBBoleto.AppendLine(" AND OPERACAO.COD_CONTRATO  = :strContrato ");
                        objSBParcelas.AppendLine(" AND Operacoes.COD_CONTRATO = :strContrato ");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "strContratoz'",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });
                    }

                    if (null != p_dtmPagamento)
                    {
                        objSBBoleto.AppendLine(" AND Acordos.DATA_PAGTO = :dtmPagamento ");
                        objSBParcelas.AppendLine(" AND Acordos.DATA_PAGTO = :dtmPagamento ");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "dtmPagamento",
                            DbType = DbType.DateTime,
                            Value = p_dtmPagamento
                        });
                    }

                    if (0 < p_intNumeroSequencia)
                    {
                        objSBBoleto.AppendLine(" AND Acordos.NUM_SEQ_PAGTO = :intNumSequencia ");
                        objSBParcelas.AppendLine(" AND Acordos.NUM_SEQ_PAGTO = :intNumSequencia ");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "intNumSequencia",
                            DbType = DbType.Int32,
                            Value = p_intNumeroSequencia
                        });
                    }

                    objSBBoleto.AppendLine(" ORDER BY	BOLETO_DATA_INCLUSAO Desc ");
                    objSBParcelas.AppendLine(" ORDER BY Acordos.DATA_AMORTIZACAO ");
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;

                    objConexao.Open();

                    objCommand.CommandText = objSBParcelas.ToString();

                    var objDA = new OracleDataAdapter(objCommand);
                    var objDSParcelas = new DataSet();

                    objDA.Fill(objDSParcelas);

                    objCommand.CommandText = objSBBoleto.ToString();

                    using (var sdr = objCommand.ExecuteReader())
                    {
                        lstBoletos = new List<Boleto>();

                        if (sdr.Read())
                        {
                            var objBoleto = new Boleto()
                            {
                                Sacado = new Sacado()
                                {
                                    Nome = sdr.GetValue<string>("SACADO_NOME"),
                                    CPFCNPJ = sdr.GetValue<string>("SACADO_DOCUMENTO"),
                                    TipoPessoa = sdr.GetValue<string>("SACADO_TIPOPESSOA"),
                                    Endereco = new Endereco()
                                    {
                                        Bairro = sdr.GetValue<string>("SACADO_ENDERECO_BAIRRO"),
                                        CEP = sdr.GetValue<Int64>("SACADO_ENDERECO_CEP").ToString("00000-000"),
                                        Cidade = sdr.GetValue<string>("SACADO_ENDERECO_CIDADE"),
                                        Complemento = sdr.GetValue<string>("SACADO_ENDERECO_COMPLEMENTO"),
                                        Logradouro = sdr.GetValue<string>("SACADO_ENDERECO_LOGRADOURO"),
                                        Numero = sdr.GetValue<string>("SACADO_ENDERECO_NUMERO"),
                                        UF = sdr.GetValue<string>("SACADO_ENDERECO_UF")
                                    }
                                },

                                Cedente = new Cedente()
                                {
                                    Codigo = sdr.GetValue<int>("Boleto_CedenteCodigo"),
                                    CPFCNPJ = sdr.GetValue<string>("CEDENTE_CNPJ"),
                                    Nome = sdr.GetValue<string>("CEDENTE_NOME"),
                                    ContaBancaria = new ContaBancaria()
                                    {
                                        Agencia = sdr.GetValue<string>("Boleto_Agencia"),
                                        DigitoAgencia = sdr.GetValue<string>("Boleto_AgenciaDigito"),
                                        Conta = sdr.GetValue<string>("Boleto_Conta"),
                                        DigitoConta = sdr.GetValue<string>("Boleto_ContaDigito")
                                    },
                                    Endereco = new Endereco()
                                    {
                                        Bairro = sdr.GetValue<string>("CEDENTE_ENDERECO_BAIRRO"),
                                        CEP = sdr.GetValue<Int64>("CEDENTE_ENDERECO_CEP").ToString("00000-000"),
                                        Cidade = sdr.GetValue<string>("CEDENTE_ENDERECO_CIDADE"),
                                        Complemento = sdr.GetValue<string>("CEDENTE_ENDERECO_COMPLEMENTO"),
                                        Logradouro = sdr.GetValue<string>("CEDENTE_ENDERECO_LOGRADOURO"),
                                        Numero = sdr.GetValue<string>("CEDENTE_ENDERECO_NUMERO"),
                                        UF = sdr.GetValue<string>("CEDENTE_ENDERECO_UF")
                                    }

                                },

                                Banco = new Banco()
                                {
                                    Codigo = sdr.GetValue<int>("Boleto_Banco")
                                },

                                NumeroParcelas = 0,
                                NumeroParcela = 0,

                                DataVencimento = sdr.GetValue<DateTime>("BOLETO_AMORTIZACAO"),
                                Carteira = sdr.GetValue<string>("Boleto_Carteira"),
                                NumeroDocumento = sdr.GetValue<string>("BOLETO_NUMERO_TITULO") + sdr.GetValue<string>("BOLETO_NUM_PARCELA").PadLeft(2, '0'),
                                NossoNumero = sdr.GetValue<string>("BOLETO_NOSSO_NUMERO"),
                                ValorBoleto = sdr.GetValue<decimal>("BOLETO_VALOR"),
                                ValorMoraDiária = sdr.GetValue<decimal>("BOLETO_MORA_DIA"),
                                ValorMultaAtraso = sdr.GetValue<decimal>("BOLETO_MORA_MULTA")
                            };

                            var strInstrucaoParcelas = "O pagamento deste boleto quita a(s) parcela(s) <b>";

                            var parcelas = objDSParcelas.Tables[0].DefaultView;
                            parcelas.RowFilter = "NOSSO_NUMERO = '" + objBoleto.NossoNumero + "'";

                            if (parcelas.Count > 0)
                            {
                                for (var i = 0; i < parcelas.Count; i++)
                                {
                                    strInstrucaoParcelas += parcelas[i]["Parcela_Numero"];

                                    if (i == parcelas.Count - 2)
                                        strInstrucaoParcelas += " e ";
                                    else if (i < parcelas.Count - 2)
                                        strInstrucaoParcelas += ", ";
                                }
                            }

                            strInstrucaoParcelas += "</b> do contrato </b>" + sdr.GetValue<string>("BOLETO_NUMERO_TITULO") + "</b>.";
                            objBoleto.Instrucoes.Add("Sr. CAIXA, não receber após o vencimento.");
                            objBoleto.Instrucoes.Add("Para maiores informações, consulte o site <A HREF='www.bancopan.com.br'>www.bancopan.com.br</A>.");
                            objBoleto.Instrucoes.Add("Em caso de dúvida, entrar em contato com a central de atendimento nos telefones:");
                            objBoleto.Instrucoes.Add("Capitais e regiões metropolitanas 4002-1687, demais localidades 0800-775-8686");
                            objBoleto.Instrucoes.Add("");
                            objBoleto.Instrucoes.Add(strInstrucaoParcelas);
                            lstBoletos.Add(objBoleto);
                        }
                        else
                        {
                            throw new Exception("Acordo Nao Encontrado");
                        }
                    }
                    objConexao.Close();
                }
            }

            if (lstBoletos.Count == 0)
                throw new Exception("Acordo Nao Encontrado");

            return lstBoletos;
        }
        public DataSet ObterCobradora(long p_intCodigo)
        {
            if (p_intCodigo <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }

            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();


                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(@"SELECT 
                                       Cobradora.COD_COBRADORA             AS Cobradora_Codigo,
                                       Cobradora.COD_CLIENTE               AS Cobradora_CodigoCliente,
                                       CobradoraCadastro.NOME_CLIENTE      AS Cobradora_RazaoSocial,
                                       CobradoraCadastro.TIPO_CLIENTE      AS Cobradora_TipoPessoa,
                                       CobradoraCadastro.NOME_FANTASIA     AS Cobradora_NomeFantasia,
                                       CobradoraEndereco.NUM_SEQ_ENDERECO  AS Cobradora_Endereco_Sequencia,
                                       CobradoraEndereco.COD_CEP           AS Cobradora_Endereco_CEP,
                                       CobradoraEndereco.NUM_LOGRADOURO    AS Cobradora_Endereco_Numero,
                                       CobradoraEndereco.DESC_CIDADE       AS Cobradora_Endereco_Cidade,
                                       CobradoraEndereco.SIGLA_UF_END      AS Cobradora_Endereco_UF,
                                       CobradoraEndereco.DESC_BAIRRO       AS Cobradora_Endereco_Bairro,
                                       CobradoraEndereco.DESC_COMPL_LOGR   AS Cobradora_Endereco_Complemento,
                                       CobradoraEndereco.DESC_LOGRADOURO   AS Cobradora_Endereco_Logradouro
                                   FROM
                                                  VTAB_COBRADORAS Cobradora
                                       INNER JOIN BCLI_CADASTRO   CobradoraCadastro ON Cobradora.COD_CLIENTE = CobradoraCadastro.COD_CLIENTE
                                       INNER JOIN BCLI_ENDERECOS  CobradoraEndereco ON Cobradora.COD_CLIENTE = CobradoraEndereco.COD_CLIENTE
                                   WHERE    
                                       Cobradora.COD_COBRADORA = :p_intCodigo");

                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intCodigo",
                        DbType = DbType.Int64,
                        Value = p_intCodigo
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0)
                    {
                        throw new Exception("Não foi possível recuperar os valores solicitados.");
                    }
                    objDA.Dispose();
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public long ObterCodigoCliente(long p_intDocumento)
        {
            if (p_intDocumento <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            long intRetorno;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();


                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(@"Select 
                                        PessoaFisica.COD_CLIENTE 
                                    From 
                                        BCLI_FIS_BASE PessoaFisica 
                                    Where
                                        NUM_CPF = :p_intDocumento
                                    UNION
                                    Select 
                                        PessoaJuridica.COD_CLIENTE 
                                    From 
                                        BCLI_JUR_BASE PessoaJuridica
                                    Where
                                        NUM_CGC = :p_intDocumento");

                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intDocumento",
                        DbType = DbType.Int64,
                        Value = p_intDocumento
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    intRetorno = Convert.ToInt64(objCommand.ExecuteScalar());

                    objConexao.Close();
                }
            }

            return intRetorno;
        }
        public long ObterCodigoClientePorContrato(string p_strContrato, long p_intCodigoContratoInterno = 0)
        {
            if (p_strContrato == "" && p_intCodigoContratoInterno <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            long intRetorno;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();


                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(@"Select 
                                       Operacoes.COD_CLIENTE 
                                   From 
                                       ECON_EMPRESTIMOS Operacoes
                                   Where ");

                    if (p_intCodigoContratoInterno > 0)
                    {
                        objSB.AppendLine(" COD_CONTRATO_INTER = :p_intContratoInterno");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno",
                            DbType = DbType.Int64,
                            Value = p_intCodigoContratoInterno
                        });
                    }
                    else if (p_strContrato != string.Empty)
                    {
                        objSB.AppendLine(" COD_CONTRATO = :p_strContrato");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    intRetorno = Convert.ToInt64(objCommand.ExecuteScalar());
                    objConexao.Close();
                }
            }
            return intRetorno;
        }
        public long ObterCodigoLojaPorContrato(string p_strContrato, long p_intContratoInterno)
        {
            if (string.Empty == p_strContrato && p_intContratoInterno <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            long intRetorno;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();

                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(@"Select
                                       Contrato.COD_LOJA
                                   From
                                                  ECON_EMPRESTIMOS   Operacoes
                                       INNER JOIN DFEN_CONTRATO      Contrato  ON Contrato.COD_CONTRATO = Operacoes.COD_CONTRATO
                                   Where ");

                    if (string.Empty != p_strContrato)
                    {
                        objSB.AppendLine(" Operacoes.COD_CONTRATO = :p_strContrato ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });
                    }
                    else if (0 < p_intContratoInterno)
                    {
                        objSB.AppendLine(" Operacoes.COD_CONTRATO_INTER = :p_intContratoInterno ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno",
                            DbType = DbType.Int64,
                            Value = p_intContratoInterno
                        });
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    intRetorno = Convert.ToInt64(objCommand.ExecuteScalar());
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return intRetorno;
        }
        public string ObterCodigoProdutoPorContrato(string p_strContrato, long p_intContratoInterno)
        {
            if (string.Empty == p_strContrato && p_intContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            string strRetorno;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();

                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(Properties.Resources.PS_Operacoes_CodProduto_Obter);
                    if (string.Empty != p_strContrato)
                    {
                        objSB.AppendLine(" OPERACOES.COD_CONTRATO = :p_strContrato ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });
                    }
                    else if (0 < p_intContratoInterno)
                    {
                        objSB.AppendLine(" OPERACOES.COD_CONTRATO_INTER = :p_intContratoInterno ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno",
                            DbType = DbType.Int64,
                            Value = p_intContratoInterno
                        });
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    strRetorno = Convert.ToString(objCommand.ExecuteScalar());
                    objConexao.Close();
                }
            }
            return strRetorno;
        }
        public DataSet ObterContaAcordo(long p_intContratoInterno)
        {
            if (0 >= p_intContratoInterno) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "intContratoInterno",
                        DbType = DbType.Int64,
                        Value = p_intContratoInterno
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Acordos_Conta_Obter;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0) throw new Exception("Não foi possível recuperar informações de conta bancária para boleto de acordo.");
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                    objConexao.Close();
                }
            }
            return objDS;
        }
        public long ObterContratoInterno(string p_strContrato)
        {
            if (string.Empty == p_strContrato) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            long intRetorno;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();
                using (var objCommand = new OracleCommand())
                {
                     objSB.Append(@"Select 
                                       COD_CONTRATO_INTER
                                   From
                                       ECON_EMPRESTIMOS
                                   Where
                                       COD_CONTRATO = :p_strContrato");
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_strContrato",
                        DbType = DbType.String,
                        Size = 12,
                        Value = p_strContrato
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    intRetorno = Convert.ToInt64(objCommand.ExecuteScalar());
                    objConexao.Close();
                }
            }
            return intRetorno;
        }
        public List<Contrato> ObterContratos(long documento)
        {
            if (documento <= 0)
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("p_intDocumento", DbType.Int64, documento);
            var data = oHelp.ExecuteEntityText<Contrato>(Properties.Resources.PS_Operacoes_Listar);
            return data;
        }
        public List<OperacaoCredito> ObterDadosFinanceiro(string Contrato)
        {
            if (string.IsNullOrEmpty(Contrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("Contrato", DbType.String, Contrato);
            var data = oHelp.ExecuteEntityText<OperacaoCredito>(Properties.Resources.PS_Operacao_Dados_Financeiro);
            return data;
        }
        public List<Debito> ObterDebitos(string contrato)
        {
            var oHelp = new OracleHelper();
            oHelp.AddParameter("Contrato", DbType.String, contrato);
            var data = oHelp.ExecuteEntityText<Debito>(Properties.Resources.PS_Operacao_Debitos);
            return data;
        }
        public long ObterDocumento(string Contrato)
        {
            if (string.IsNullOrEmpty(Contrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("Contrato", DbType.String, Contrato);
            var documento = oHelp.ExecuteScalar<Int64>(Properties.Resources.PS_Operacao_CPF);
            return documento;
        }
        public DataSet ObterFluxoPorContrato(long p_intContratoInterno)
        {
            if (p_intContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intContratoInterno",
                        DbType = DbType.Int64,
                        Value = p_intContratoInterno
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Operacao_Fluxo_Obter;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0)
                    {
                        throw new Exception("Não foi possível recuperar os valores solicitados.");
                    }
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public DataSet ObterGarantias(long p_intContratoInterno) 
        {
            if (p_intContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();

                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(Properties.Resources.PS_Operacao_Garantias_Obter);
                    objSB.Append("Garantias_Contrato.COD_CONTRATO_INTER = :p_intContratoInterno ORDER BY DATA_DESATIVACAO desc");
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intContratoInterno",
                        DbType = DbType.Int64,
                        Value = p_intContratoInterno
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0) throw new Exception("Não foi possível recuperar valores de mora e multa para o contrato solicitado.");
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public List<Loja> ObterLoja(int regional)
        {
            if (regional <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            var sb = new StringBuilder();

            sb.Append(Properties.Resources.PS_Loja_Obter);
            sb.Append(" where COD_REGIONAL = :COD_REGIONAL");

            oHelp.AddParameter("COD_REGIONAL", DbType.Int32, regional);
            var data = oHelp.ExecuteEntityText<Loja>(sb.ToString());
            return data;
        }
        public DataSet ObterLojaDS(long p_intLoja)
        {
            if (p_intLoja <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();
                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(@"Select   
                                       Loja.COD_LOJA          AS Loja_Codigo,
                                       Loja.NUM_CGC           AS Loja_CNPJ,
                                       Loja.DESC_BAIRRO       AS Loja_Endereco_Bairro,
                                       Loja.COD_CEP           AS Loja_Endereco_CEP,
                                       Loja.DESC_CIDADE       AS Loja_Endereco_Cidade,
                                       Loja.DESC_COMPL_LOGR   AS Loja_Endereco_Complemento,
                                       Loja.DESC_LOGRADOURO   AS Loja_Endereco_Logradouro,
                                       Loja.NUM_LOGRADOURO    AS Loja_Endereco_Numero,
                                       Loja.SIGLA_UF_END      AS Loja_Endereco_UF,
                                       Loja.NUM_AREA_TELEFONE AS Loja_Telefone_Area,
                                       Loja.NUM_TELEFONE      AS Loja_Telefone_Numero,
                                       Loja.COD_RAMAL         AS Loja_Telefone_Ramal,
                                       Loja.DATA_INICIO_ATIV  AS Loja_InicioAtividade,
                                       Loja.DESC_LOJA         AS Loja_Nome,
                                       Loja.DESC_RAZAO        AS Loja_RazaoSocial,
                                       Loja.TIPO_LOJA         AS Loja_Tipo
                                   From
                                       BENT_LOJA_BASE Loja
                                   Where
                                       Loja.COD_LOJA = :p_intLoja ");

                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intLoja",
                        DbType = DbType.Int64,
                        Value = p_intLoja
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0)
                        throw new Exception("Não foi possível recuperar os valores solicitados.");
                    objDA.Dispose();
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public DataSet ObterLojaPorContrato(string p_strContrato, long p_intContratoInterno)
        {
            return ObterLojaDS(this.ObterCodigoLojaPorContrato(p_strContrato,p_intContratoInterno));
        }
        public DataSet ObterOcorrenciasPorContrato(long p_intContratoInterno)
        {
            if (p_intContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                new StringBuilder();


                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intContratoInterno",
                        DbType = DbType.Int64,
                        Value = p_intContratoInterno
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Operacao_Ocorrencias_Obter;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public DataSet ObterOperacao(string p_strContrato, long p_intContratoInterno)
        {
            if (string.Empty == p_strContrato && p_intContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;
            var strSQLContratoIrregular = string.Empty;

            try
            {
                using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
                {
                    var objSB = new StringBuilder();

                    using (var objCommand = new OracleCommand())
                    {
                        objSB.Append(Properties.Resources.PS_Operacao_Obter);

                        if (string.Empty != p_strContrato)
                        {
                            objSB.Append("Operacoes.COD_CONTRATO = :p_strContrato");

                            objCommand.Parameters.Add(new OracleParameter()
                            {
                                ParameterName = "p_strContrato",
                                DbType = DbType.String,
                                Size = 12,
                                Value = p_strContrato
                            });
                        }
                        else if (0 < p_intContratoInterno)
                        {
                            objSB.Append("Operacoes.COD_CONTRATO_INTER = :p_intContratoInterno");

                            objCommand.Parameters.Add(new OracleParameter()
                            {
                                ParameterName = "p_intContratoInterno",
                                DbType = DbType.Int64,
                                Value = p_intContratoInterno
                            });
                        }
                        var strSQLQuitacaoAnormal = p_OrgaosRecebedoresQuitacaoAnormal();

                        if (!string.IsNullOrWhiteSpace(strSQLQuitacaoAnormal))
                        {
                            strSQLContratoIrregular = @"Case
                                                        When Exists (" + strSQLQuitacaoAnormal + @") Then
                                                            0
                                                        Else
                                                            1
                                                    End AS Contrato_Regular ";
                        }
                        objSB = objSB.Replace("%Contrato_Regular%", ", " + strSQLContratoIrregular);
                        objCommand.Connection = objConexao;
                        objCommand.CommandType = CommandType.Text;
                        objCommand.CommandText = objSB.ToString();

                        objConexao.Open();
                        var objDA = new OracleDataAdapter(objCommand);
                        objDS = new DataSet();

                        objDA.Fill(objDS);

                        if (objDS.Tables.Count == 0) throw new Exception("Não foi possível recuperar informações para o contrato solicitado.");
                        objConexao.Close();
                    }
                }
            }
            catch (OracleException ex)
            {
                var errorMessage = "Code: " + ex.ErrorCode + "\n" + "Message: " + ex.Message;
                throw new Exception(errorMessage);
            }
            return objDS;
        }
        public OperacaoCredito ObterOperacaoDevolucao(string Contrato)
        {
            if (string.IsNullOrEmpty(Contrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("Contrato", DbType.String, Contrato);
            var ret = oHelp.ExecuteEntityText<OperacaoCredito>(Properties.Resources.PS_Operacao_Devolucao);
            return ret.FirstOrDefault();
        }
        public List<String> ObterOperacoesPorPeriodo(DateTime p_dtmInicio, DateTime p_dtmTermino)
        {
            List<String> lstContratos;

            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    if (null != p_dtmInicio)
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_dtmInicio",
                            DbType = DbType.DateTime,
                            Value = p_dtmInicio
                        });
                    }
                    if (null != p_dtmTermino)
                    {
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_dtmTermino",
                            DbType = DbType.DateTime,
                            Value = p_dtmTermino
                        });
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Operacoes_CodContrato_Obter;

                    objConexao.Open();
                    using (var sdr = objCommand.ExecuteReader())
                    {
                        lstContratos = new List<String>();

                        while (sdr.Read())
                        {
                            lstContratos.Add(sdr.GetString(sdr.GetOrdinal("COD_CONTRATO")).Trim());
                        }
                    }
                    objConexao.Close();
                }
            }
            return lstContratos;
        }
        public DataSet ObterParcelas(long p_intContratoInterno)
        {
            if (p_intContratoInterno <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }

            DataSet objDS;


            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intContratoInterno",
                        DbType = DbType.Int64,
                        Value = p_intContratoInterno
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Operacao_Parcelas_Obter;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0)
                    {
                        throw new Exception("Não foi possível recuperar valores de mora e multa para o contrato solicitado.");
                    }
                    objConexao.Close();
                }
            }

            return objDS;
        }
        public List<Parcela> ObterParcelasN(long ContratoInterno)
        {
            if (ContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("p_intContratoInterno", DbType.String, ContratoInterno);
            var ret = oHelp.ExecuteEntityText<Parcela>(Properties.Resources.PS_Operacao_Parcelas_Obter);
            return ret.ToList();
        }
        public byte ObterPrazoBancario(string p_strContrato, long p_intContratoInterno)
        {
            if (string.Empty == p_strContrato && p_intContratoInterno <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            Byte intRetorno;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();
                using (var objCommand = new OracleCommand())
                {
                   objSB.Append(Properties.Resources.PS_Operacao_PrazoBancario_Obter);

                    if (string.Empty != p_strContrato)
                    {
                        objSB.AppendLine(" AND OPERACOES.COD_CONTRATO = :p_strContrato ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });
                    }
                    else if (0 < p_intContratoInterno)
                    {
                        objSB.AppendLine(" AND OPERACOES.COD_CONTRATO_INTER = :p_intContratoInterno ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno",
                            DbType = DbType.Int64,
                            Value = p_intContratoInterno
                        });
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    intRetorno = Convert.ToByte(objCommand.ExecuteScalar());
                    objConexao.Close();
                }
            }

            return intRetorno;
        }
        public List<Profissao> ObterProfissao()
        {
            var oHelp = new OracleHelper();
            var data = oHelp.ExecuteEntityText<Profissao>(Properties.Resources.PS_Profissao_Obter);
            return data;
        }
        public List<Contrato> ObterPropostas(long documento)
        {
            if (documento <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("DOCUMENTO", DbType.Int64, documento);

            var data = oHelp.ExecuteEntityText<Contrato>(Properties.Resources.PS_Operacao_Proposta);

            if (data.Count == 0) return null;
            return data;
        }
        public int ObterQuantidadeParcelas(string p_strContrato, int p_intContratoInterno)
        {
            if (string.Empty == p_strContrato && p_intContratoInterno <= 0)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            var intRetorno = 0;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();
                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(Properties.Resources.PS_Operacao_QtdeParcelas_Obter);
                    if (string.Empty != p_strContrato)
                    {
                        objSB.AppendLine(" OPERACOES.COD_CONTRATO = :p_strContrato ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });
                    }
                    else if (0 < p_intContratoInterno)
                    {
                        objSB.AppendLine(" OPERACOES.COD_CONTRATO_INTER = :p_intContratoInterno ");
                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno",
                            DbType = DbType.Int32,
                            Value = p_intContratoInterno
                        });
                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    try
                    {
                        intRetorno = Convert.ToInt32(objCommand.ExecuteScalar());
                    }
                    catch (Exception)
                    {
                        // ignored
                    }
                    objConexao.Close();
                }
            }

            return intRetorno;
        }
        public decimal ObterSaldoDevedor(long ContratoInterno)
        {
            if (ContratoInterno == 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("ContratoInterno", DbType.Int64, ContratoInterno);
            var documento = oHelp.ExecuteScalar<Decimal>(Properties.Resources.PS_Operacao_Saldo_Devedor);
            return documento;
        }
        public Proposta ObterSituacaoProposta(string contrato)
        {
            if (string.IsNullOrEmpty(contrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("Contrato", DbType.String, contrato);
            var data = oHelp.ExecuteEntityText<Proposta>(Properties.Resources.PS_Operacao_Proposta_Situacao);

            return data.Count == 0 ? null : data.First();
        }
        public DataSet ObterTaxasEncargos(string p_strContrato, int p_intContratoInterno)
        {
            if (string.Empty == p_strContrato && p_intContratoInterno <= 0) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            DataSet objDS;
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                var objSB = new StringBuilder();


                using (var objCommand = new OracleCommand())
                {
                    objSB.Append(Properties.Resources.PS_Operacao_MoraMulta_Obter);
                    if (string.Empty != p_strContrato)
                    {
                        objSB.Replace("%CONTRATO%", "OPERACOES.COD_CONTRATO = :p_strContrato2");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato1",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_strContrato2",
                            DbType = DbType.String,
                            Size = 12,
                            Value = p_strContrato
                        });

                    }
                    else if (0 < p_intContratoInterno)
                    {
                        objSB.Replace("%CONTRATO%", "OPERACOES.COD_CONTRATO_INTER = :p_intContratoInterno2");

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno1",
                            DbType = DbType.Int32,
                            Value = p_intContratoInterno
                        });

                        objCommand.Parameters.Add(new OracleParameter()
                        {
                            ParameterName = "p_intContratoInterno2",
                            DbType = DbType.Int32,
                            Value = p_intContratoInterno
                        });

                    }
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = objSB.ToString();

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0)
                    {
                        throw new Exception("Não foi possível recuperar valores de mora e multa para o contrato solicitado.");
                    }
                    objConexao.Close();
                }
            }
            return objDS;
        }
        public DataSet ProcurarOperacoes(string p_strBusca)
        {
            if (string.IsNullOrWhiteSpace(p_strBusca))
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");
            }
            DataSet objDS;
            long intDocumento;

            long.TryParse(p_strBusca, out intDocumento);
            using (var objConexao = new OracleConnection(ConfigurationManager.ConnectionStrings["PanSolution"].ConnectionString))
            {
                using (var objCommand = new OracleCommand())
                {
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_intDocumento",
                        DbType = DbType.Int64,
                        Value = intDocumento
                    });
                    objCommand.Parameters.Add(new OracleParameter()
                    {
                        ParameterName = "p_strContrato",
                        DbType = DbType.String,
                        Value = p_strBusca.PadLeft(12, '0')
                    });
                    objCommand.Connection = objConexao;
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = Properties.Resources.PS_Operacoes_Procurar;

                    objConexao.Open();
                    var objDA = new OracleDataAdapter(objCommand);
                    objDS = new DataSet();

                    objDA.Fill(objDS);
                    if (objDS.Tables.Count == 0 || objDS.Tables[0].Rows.Count == 0)
                    {
                        return null;
                    }
                    objCommand.Dispose();
                    objConexao.Close();
                    objConexao.Dispose();
                }
            }
            return objDS;
        }
        public Pricing SimularPricing(string Contrato)
        {
            if (string.IsNullOrEmpty(Contrato)) throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            var oHelp = new OracleHelper();
            oHelp.AddParameter("Contrato", DbType.String, Contrato);
            var pricing = oHelp.ExecuteEntityText<Pricing>(Properties.Resources.PS_Operacao_Simula_Pricing);
            return pricing.FirstOrDefault();
        }
        private string p_OrgaosRecebedoresQuitacaoAnormal()
        {
            var strWhere = string.Empty;

            const string strOrgaoRecebedores = "O:1,2,3,4,5,6,8;R:30;8:868;N:1,3,4,5,6,7,9";

            if (string.IsNullOrWhiteSpace(strOrgaoRecebedores)) return strWhere;
            strWhere += " Select COD_CONTRATO_INTER From ECON_FLUXO_CAIXA Fluxo Where Fluxo.COD_CONTRATO_INTER = Operacoes.COD_CONTRATO_INTER And (";

            var arrTiposOrgaos = strOrgaoRecebedores.Split(';');

            for (var intA = 0; intA < arrTiposOrgaos.Length; intA++)
            {
                var arrOrgaos = arrTiposOrgaos[intA].Split(':');
                if (intA > 0)
                {
                    strWhere += " Or ";
                }
                strWhere += "(Fluxo.TIPO_ORGAO_REC = '" + arrOrgaos[0] + "' And Fluxo.COD_ORGAO In (" + arrOrgaos[1] + ")) ";
            }
            strWhere += ")";
            return strWhere;
        }
        public Mensagem CobolObterContratos(long documento)
        {
            var objMsg = Mensagem.CriarMensagem("isisff01", "UF1", new KeyValuePair<String, String>("DOCUMENTO", documento.ToString()));
            objMsg.Executar();
            return objMsg;
        }
        public Mensagem CobolObterContratos(long p_intCodigoCliente, long p_intCodigoContrato = 0)
        {
            var objMsg = Mensagem.CriarMensagem("isisfa08","U18",
                new KeyValuePair<String, String>("CODIGO DO CLIENTE", p_intCodigoCliente.ToString()),
                new KeyValuePair<String, String>("CODIGO DO CONTRATO", p_intCodigoContrato.ToString()));

            objMsg.Executar();
            return objMsg;
        }
        public Mensagem CobolObterOperacoes(long p_intCodigoContratoInterno, DateTime? p_dtmPagamento = null)
        {
            var strCodigoProduto = ObterCodigoProdutoPorContrato("", p_intCodigoContratoInterno);
            var strDataPagamento = null != p_dtmPagamento ? Convert.ToDateTime(p_dtmPagamento).ToString("yyyyMMdd") : DateTime.Now.ToString("yyyyMMdd");
            var objMsg = Mensagem.CriarMensagem("aate300a",
                "U30",
                new KeyValuePair<String, String>("CODIGO CONTRATO INTERNO", p_intCodigoContratoInterno.ToString()),
                new KeyValuePair<String, String>("CODIGO DO PRODUTO", strCodigoProduto),
                new KeyValuePair<String, String>("DATA DO PAGAMENTO", strDataPagamento),
                new KeyValuePair<String, String>("TIPO DA PESSOA", "F"));
            objMsg.Executar();
            return objMsg;
        }
        public String CobolCancelarAcordo(Acordo p_objAcordo)
        {
            var objMsg = Mensagem.CriarMensagem("aate300d","30F",
                new KeyValuePair<String, String>("CODIGO CONTRATO INTERNO", p_objAcordo.ContratoInterno.ToString()));
            var objParcelas = objMsg.ItensEnvio["PARCELAS"];

            foreach (var objParcela in p_objAcordo.Parcelas)
                objParcelas.InserirItem(objParcela.DataVencimento.ToString("yyyyMMdd"), "");

            objMsg.ItensEnvio["QUANTIDADE DE PARCELAS"].ValorTexto = p_objAcordo.Parcelas.Count.ToString();

            objMsg.Executar();
            return objMsg.ErroNumero > 0 ? objMsg.ErroMensagem : "true";
        }
        public string CobolEfetuarAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento, decimal p_decValor, bool p_blnOrdemInversa = false)
        {
            return CobolEfetuarAcordo(this.CobolSimularAcordo(p_strContrato,
                p_intContratoInterno,
                p_dtmPagamento,
                p_decValor,
                p_blnOrdemInversa));
        }
        public string CobolEfetuarAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento, bool p_blnConsolidarAtrasadas, int p_intParcelas = 0, bool p_blnOrdemInversa = false)
        {
            return CobolEfetuarAcordo(this.CobolSimularAcordo(p_strContrato,
                p_intContratoInterno,
                p_dtmPagamento,
                p_blnConsolidarAtrasadas,
                p_intParcelas,
                p_blnOrdemInversa));
        }
        public string CobolEfetuarAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento, bool desconto, params DateTime[] p_arrAmortizacoes)
        {
            return CobolEfetuarAcordo(this.CobolSimularAcordo(p_strContrato, p_intContratoInterno, p_dtmPagamento, p_arrAmortizacoes), desconto);
        }
        public string CobolEfetuarAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento)
        {
            return CobolEfetuarAcordo(this.CobolSimularAcordo(p_strContrato,p_intContratoInterno,p_dtmPagamento));
        }
        public Acordo CobolSimularAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento, decimal p_decValor, bool p_blnOrdemInversa = false)
        {
            if (string.Empty == p_strContrato && 0 >= p_intContratoInterno)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para identificação do contrato.");
            }
            if (0.0m >= p_decValor)
            {
                throw new ArgumentException("Não foram fornecidos parâmetros para geração de um acordo.");
            }
            var intA = 0;
            if (p_intContratoInterno <= 0)
            {
                p_intContratoInterno = ObterContratoInterno(p_strContrato);
            }
            var objAcordo = CobolSimularAcordo(p_strContrato,p_intContratoInterno,p_dtmPagamento);
            while (objAcordo.Valor > p_decValor)
            {
                if (!p_blnOrdemInversa)
                {
                    intA = objAcordo.Parcelas.Count - 1;
                }
                objAcordo.Parcelas.RemoveAt(intA);

            }
            if (0 == objAcordo.Parcelas.Count)
            {
                throw new Exception("Não foi possível gerar um acordo, porque o valor solicitado não permite o pagamento de nenhuma parcela");
            }
            return objAcordo;
        }
        public Acordo CobolSimularAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento, bool p_blnConsolidarAtrasadas, int p_intParcelas = 0, bool p_blnOrdemInversa = false)
        {
            if (string.Empty == p_strContrato && 0 >= p_intContratoInterno)
            {
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para identificação do contrato.");
            }
            if (!p_blnConsolidarAtrasadas && 0 >= p_intParcelas)
            {
                throw new ArgumentException("Não foram fornecidos parâmetros para geração de um acordo.");
            }

            var intA = 0;
            var intParcelas = 0;
            var blnAtraso = false;
            var lstAmortizacoes = new List<DateTime>();
            if (p_intContratoInterno <= 0)
            {
                p_intContratoInterno = ObterContratoInterno(p_strContrato);
            }
            var objMsgOperacao = CobolSimularAcordoObterParcelas(p_intContratoInterno,
                p_dtmPagamento);
            var objOperacaoParcelas = objMsgOperacao.ItensRetorno["PARCELAS"];
            intParcelas = objOperacaoParcelas.Itens.Count;
            blnAtraso = objOperacaoParcelas.Itens.Count > 0 && (Convert.ToInt32(objOperacaoParcelas[0]["QUANTIDADE DE DIAS EM ATRASO"].Valor) > 0);
            if (p_blnConsolidarAtrasadas)
            {
                if (!blnAtraso)
                {
                    throw new Exception("Não há parcelas atrasadas para consolidação.");
                }
                while (objOperacaoParcelas.Itens.Count > 0 && Convert.ToInt32(objOperacaoParcelas[intA]["QUANTIDADE DE DIAS EM ATRASO"].Valor) > 0)
                {
                    lstAmortizacoes.Add(Convert.ToDateTime(objOperacaoParcelas[intA]["DATA DA AMORTIZACAO"].Valor));
                    intA++;

                    if (intA == objOperacaoParcelas.Itens.Count)
                    {
                        break;
                    }
                }
            }
            else
            {
                while (intA < p_intParcelas)
                {
                    var intB = 0;
                    if (!p_blnOrdemInversa)
                    {
                        intB = intA;
                    }
                    else
                    {
                        intB = intParcelas - intA - 1;
                    }
                    lstAmortizacoes.Add(Convert.ToDateTime(objOperacaoParcelas[intB]["DATA DA AMORTIZACAO"].Valor));
                    intA++;
                }
            }
            return CobolSimularAcordo(p_intContratoInterno,p_dtmPagamento,objMsgOperacao,lstAmortizacoes.ToArray<DateTime>());
        }
        public Acordo CobolSimularAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento, params DateTime[] p_arrAmortizacoes)
        {
            if (p_intContratoInterno <= 0)p_intContratoInterno = ObterContratoInterno(p_strContrato);

            var objMsgOperacao = CobolSimularAcordoObterParcelas(p_intContratoInterno,p_dtmPagamento);

            return CobolSimularAcordo(p_intContratoInterno,p_dtmPagamento,objMsgOperacao,p_arrAmortizacoes);
        }
        public Acordo CobolSimularAcordo(string p_strContrato, long p_intContratoInterno, DateTime p_dtmPagamento)
        {
            if (p_intContratoInterno <= 0)
            {
                p_intContratoInterno = ObterContratoInterno(p_strContrato);
            }
            var objMsgOperacao = CobolSimularAcordoObterParcelas(p_intContratoInterno,p_dtmPagamento);
            var objOperacaoParcelas = objMsgOperacao.ItensRetorno["PARCELAS"];

            var strFormaLiquidacao = objMsgOperacao.ItensRetorno["Tipo Liquidação"].Valor.ToString();
            var intFormaLiquidacao = (OperacaoLiquidacaoTipos)Common.Escolher(strFormaLiquidacao,
                "A", OperacaoLiquidacaoTipos.BoletoECheque,
                "B", OperacaoLiquidacaoTipos.Boleto,
                "C", OperacaoLiquidacaoTipos.Cheque,
                "D", OperacaoLiquidacaoTipos.DebitoConta,
                "F", OperacaoLiquidacaoTipos.ChequeEDebito,
                "G", OperacaoLiquidacaoTipos.BoletoEDebito,
                "I", OperacaoLiquidacaoTipos.Interface,
                "", OperacaoLiquidacaoTipos.Indefinido,
                OperacaoLiquidacaoTipos.Indefinido);
            var objAcordo = new Acordo(p_intContratoInterno.ToString(),
                DateTime.MinValue,
                DateTime.MinValue,
                DateTime.MinValue,
                p_dtmPagamento,
                "",
                0,
                "0");
            foreach (var objParcela in objOperacaoParcelas.Itens)
            {
                objAcordo.Parcelas.Add(CobolGerarParcelaAcordo(p_dtmPagamento,intFormaLiquidacao,objParcela));
            }
            return objAcordo;
        }
        private string CobolEfetuarAcordo(Acordo p_objAcordo, bool desconto = false)
        {
            var objDSConta = this.ObterContaAcordo(Convert.ToInt64(p_objAcordo.ContratoInterno));
            var strAcordoBanco = objDSConta.Tables[0].Rows[0]["Boleto_Banco"].ToString();

            var objMsgAcordo = Mensagem.CriarMensagem("aate30bb","3BB",
                new KeyValuePair<String, String>("CODIGO CONTRATO INTERNO", p_objAcordo.ContratoInterno.ToString()),
                new KeyValuePair<String, String>("DATA_PAGAMENTO", p_objAcordo.DataVencimento.ToString("yyyyMMdd")),
                new KeyValuePair<String, String>("CD_DO_BANCO", strAcordoBanco));
            var objAcordoParcelas = objMsgAcordo.ItensEnvio["PARCELAS"];

            foreach (var objParcela in p_objAcordo.Parcelas)
            {
                var totalJuros = (objParcela.ValorCP + objParcela.ValorMora + objParcela.ValorMulta);

                objAcordoParcelas.InserirItem(objParcela.DataVencimento.ToString("yyyyMMdd"),
                    objParcela.Valor.ToString("0.00").Replace(".", "").Replace(",", ""),
                    objParcela.ValorCP.ToString("0.00").Replace(".", "").Replace(",", ""),
                    objParcela.ValorMora.ToString("0.00").Replace(".", "").Replace(",", ""),
                    objParcela.ValorMulta.ToString("0.00").Replace(".", "").Replace(",", ""),
                    "0",
                    desconto && totalJuros > 0 ? totalJuros.ToString("0.00").Replace(".", "").Replace(",", "") : objParcela.ValorDescontoParcela.ToString("0.00").Replace(".", "").Replace(",", ""),
                    "0");
            }

            objMsgAcordo.ItensEnvio["QUANTIDADE DE PARCELAS"].Valor = p_objAcordo.Parcelas.Count;
            objMsgAcordo.Executar();

            return objMsgAcordo.ErroNumero.ToString() + ";" + objMsgAcordo.ErroMensagem;
        }
        private Parcela CobolGerarParcelaAcordo(DateTime p_dtmPagamento, OperacaoLiquidacaoTipos p_intFormaLiquidacao, MensagemItem p_objMensagem)
        {
            var intDiasVencimento = Convert.ToInt16(p_objMensagem["QUANTIDADE DE DIAS EM ATRASO"].Valor);
            var intDiasAdiantamento = 0;
            var intDiasAtraso = 0;
            var decAcrescimos = 0.0m;
            var decDescontos = 0.0m;
            if (intDiasVencimento < 0)
            {
                intDiasAdiantamento = Math.Abs(intDiasVencimento);
                decAcrescimos = 0.0m;
                decDescontos = Convert.ToDecimal(p_objMensagem["VALOR DA PARCELA"].Valor) - Convert.ToDecimal(p_objMensagem["VALOR DA PARCELA NA CURVA"].Valor);
            }
            else
            {
                intDiasAtraso = intDiasVencimento;
                decAcrescimos = Convert.ToDecimal(p_objMensagem["VALOR DA COMISSAO DE PERMANENCIA"].Valor)
                                + Convert.ToDecimal(p_objMensagem["VALOR DA MORA"].Valor)
                                + Convert.ToDecimal(p_objMensagem["VALOR DA MULTA"].Valor);
                decDescontos = 0.0m;
            }
            return new Parcela()
            {
                DataCalculo = p_dtmPagamento,
                DataVencimento = Convert.ToDateTime(p_objMensagem["DATA DA AMORTIZACAO"].Valor),
                DiasAdiantamento = (Int16)intDiasAdiantamento,
                DiasAtraso = (Int16)intDiasAtraso,
                FormaLiquidacao = p_intFormaLiquidacao,
                NumeroParcela = Convert.ToInt32(p_objMensagem["NUMERO DA PARCELA"].Valor),
                ValorDescontoParcela = Convert.ToDecimal(p_objMensagem["VALOR DA PARCELA"].Valor)
                                       - Convert.ToDecimal(p_objMensagem["VALOR DA PARCELA NA CURVA"].Valor),
                ValorCP = Convert.ToDecimal(p_objMensagem["VALOR DA COMISSAO DE PERMANENCIA"].Valor),
                ValorMora = Convert.ToDecimal(p_objMensagem["VALOR DA MORA"].Valor),
                ValorMulta = Convert.ToDecimal(p_objMensagem["VALOR DA MULTA"].Valor),
                Valor = Convert.ToDecimal(p_objMensagem["VALOR DA PARCELA"].Valor),

                ValorDescontos = decDescontos,
                ValorAcrescimos = decAcrescimos
            };
        }
        private Acordo CobolSimularAcordo(long p_intContratoInterno, DateTime p_dtmPagamento, Mensagem p_objMsgOperacao, params DateTime[] p_arrAmortizacoes)
        {
            var intB = 0;
            var objOperacaoParcelas = p_objMsgOperacao.ItensRetorno["PARCELAS"];
            var strFormaLiquidacao = p_objMsgOperacao.ItensRetorno["Tipo Liquidação"].Valor.ToString();
            var intFormaLiquidacao = (OperacaoLiquidacaoTipos)Common.Escolher(strFormaLiquidacao,
                "A", OperacaoLiquidacaoTipos.BoletoECheque,
                "B", OperacaoLiquidacaoTipos.Boleto,
                "C", OperacaoLiquidacaoTipos.Cheque,
                "D", OperacaoLiquidacaoTipos.DebitoConta,
                "F", OperacaoLiquidacaoTipos.ChequeEDebito,
                "G", OperacaoLiquidacaoTipos.BoletoEDebito,
                "I", OperacaoLiquidacaoTipos.Interface,
                "", OperacaoLiquidacaoTipos.Indefinido,
                OperacaoLiquidacaoTipos.Indefinido);
            var objAcordo = new Acordo(p_intContratoInterno.ToString(),
                DateTime.MinValue,
                DateTime.MinValue,
                DateTime.MinValue,
                p_dtmPagamento,
                "",
                0,
                "0");
            p_arrAmortizacoes = p_arrAmortizacoes.OrderBy(a => a.Ticks).ToArray<DateTime>();

            foreach (var dtmAmortizacao in p_arrAmortizacoes)
            {
                while (true)
                {
                    if (intB >= objOperacaoParcelas.Itens.Count || Convert.ToDateTime(objOperacaoParcelas[intB]["DATA DA AMORTIZACAO"].Valor) > dtmAmortizacao)
                        break;
                    if (Convert.ToDateTime(objOperacaoParcelas[intB]["DATA DA AMORTIZACAO"].Valor) == dtmAmortizacao)
                    {
                        objAcordo.Parcelas.Add(CobolGerarParcelaAcordo(p_dtmPagamento, intFormaLiquidacao, objOperacaoParcelas[intB]));
                        intB++;
                        break;
                    }
                    intB++;
                }
            }
            return objAcordo;
        }
        private Mensagem CobolSimularAcordoObterParcelas(long p_intContratoInterno, DateTime p_dtmPagamento)
        {
            var objRetorno = CobolObterOperacoes(p_intContratoInterno,p_dtmPagamento);
            return objRetorno;
        }
        public List<Despesas> ObterDespesas()
        {
            var oHelp = new OracleHelper("PanSolution");
            var data = oHelp.ExecuteEntityText<Despesas>(Properties.Resources.Pan_NegocieDivida_ObterDespesas);
            return data;
        }
        public List<ProdutoVeiculos> ObterProdutosVeiculos(string pTipoProduto)
        {
            var oHelp = new OracleHelper("PanSolution");
            oHelp.AddParameter("pTipoProduto", DbType.String, pTipoProduto);
            var data = oHelp.ExecuteEntityText<ProdutoVeiculos>(Properties.Resources.Pan_NegocieDivida_ObterProdutosVeiculos);
            return data;
        }

        public OperacaoCredito ObterOperacaoPansolution(string Contrato, long ContratoInterno = 0)
        {
            if (string.IsNullOrWhiteSpace(Contrato) && ContratoInterno <= 0) throw new ArgumentException("numero de contrato invalido");

            OperacaoCredito objOperacao = null;

            MensagemItem objMsgParcela = null;
            var intA = 0;

            var objDS = ObterOperacao(Contrato.PadLeft(12, '0'), ContratoInterno);

            if (objDS.Tables[0].Rows.Count <= 0) return null;

            try
            {
                var objRow = objDS.Tables[0].Rows[0];

                Contrato = Convert.ToString(objRow["COD_CONTRATO"]);
                ContratoInterno = Convert.ToInt64(objRow["COD_CONTRATO_INTER"]);

                var objCliente = new Cliente
                {
                    Nome = objRow["Cliente_Nome"].ToString(),
                    Documento = Convert.ToInt64(objRow["Cliente_Documento"].ToString()),
                    PessoaTipo = objRow["Cliente_TipoPessoa"].ToString(),
                    Endereco = new Endereco
                    {
                        Logradouro = objRow["Cliente_Endereco_Logradouro"].ToString(),
                        Numero = objRow["Cliente_Endereco_Numero"].ToString(),
                        Complemento = objRow["Cliente_Endereco_Complemento"].ToString(),
                        Bairro = objRow["Cliente_Endereco_Bairro"].ToString(),
                        CEP = objRow["Cliente_Endereco_CEP"].ToString(),
                        Cidade = objRow["Cliente_Endereco_Cidade"].ToString(),
                        UF = objRow["Cliente_Endereco_UF"].ToString()
                    },
                    Telefones = new List<Telefone>()
                };

                if (objRow["Cliente_Telefone"] != DBNull.Value)
                {

                    var telefone = objRow["Cliente_Telefone"].ToString();
                    var divide = telefone.IndexOf('-');

                    if (divide > 0 && telefone.Length > 10)
                    {
                        objCliente.Telefones.Add(new Telefone
                        {
                            DDD = Common.IsNull(telefone.Substring(0, divide), ""),
                            Numero = Common.IsNull(telefone.Substring(divide + 1, telefone.Length - (divide + 1)), 0),
                            Tipo = TipoTelefone.Telefone
                        });
                    }
                }

                if (objRow["Cliente_Celular"] != DBNull.Value)
                {
                    var telefone = objRow["Cliente_Celular"].ToString();
                    var divide = telefone.IndexOf('-');

                    if (divide > 0 && telefone.Length > 10)
                    {
                        objCliente.Telefones.Add(new Telefone
                        {
                            DDD = Common.IsNull(telefone.Substring(0, divide), ""),
                            Numero = Common.IsNull(telefone.Substring(divide + 1, telefone.Length - (divide + 1)), 0),
                            Tipo = TipoTelefone.Celular
                        });
                    }
                }

                if (objRow["Cliente_Comercial"] != DBNull.Value)
                {
                    var telefone = objRow["Cliente_Comercial"].ToString();
                    var divide = telefone.IndexOf('-');

                    if (divide > 0 && telefone.Length > 10)
                    {
                        objCliente.Telefones.Add(new Telefone
                        {
                            DDD = Common.IsNull(telefone.Substring(0, divide), ""),
                            Numero =
                                Common.IsNull(telefone.Substring(divide + 1, telefone.Length - (divide + 1)), (long)0),
                            Tipo = TipoTelefone.Comercial
                        });
                    }
                }

                if (objRow["Cliente_Cod_Banco"] != DBNull.Value)
                {

                    objCliente.Conta = new Conta
                    {
                        Agencia = Common.IsNull(objRow["Cliente_Agencia"].ToString(), ""),
                        Numero = Common.IsNull(objRow["Cliente_Conta"].ToString(), "")
                    };

                    int result;
                    if (int.TryParse(objRow["Cliente_Cod_Banco"].ToString(), out result))
                    {
                        objCliente.Conta.Banco = result;
                    }
                }
                var strEmpresaCodigo = Common.IsNull(objRow["Empresa_Codigo"], "").Trim();
                var objEmpresa = new Empresa(Common.IsNull(objRow["Empresa_CNPJ"], 0L),
                    Common.IsNull(objRow["Empresa_Nome"], ""),
                    Common.IsNull(objRow["Empresa_Nome"], ""),
                    new Endereco
                        (
                        Common.IsNull(objRow["Empresa_Endereco_Logradouro"], ""),
                        Common.IsNull(objRow["Empresa_Endereco_Numero"], ""),
                        Common.IsNull(objRow["Empresa_Endereco_Complemento"], ""),
                        Common.IsNull(objRow["Empresa_Endereco_Bairro"], ""),
                        Common.IsNull(objRow["Empresa_Endereco_CEP"], ""),
                        Common.IsNull(objRow["Empresa_Endereco_Cidade"], ""),
                        Common.IsNull(objRow["Empresa_Endereco_UF"], "")
                        )) { Codigo = strEmpresaCodigo };

                objEmpresa.Atributos.Add("Código na origem", strEmpresaCodigo);
                var objLoja = new Loja(Common.IsNull(objRow["Loja_CNPJ"], 0L),
                    Common.IsNull(objRow["Cod_Loja"], ""),
                    new Endereco
                        (
                        Common.IsNull(objRow["Loja_Endereco_Logradouro"], ""),
                        Common.IsNull(objRow["Loja_Endereco_Numero"], ""),
                        Common.IsNull(objRow["Loja_Endereco_Complemento"], ""),
                        Common.IsNull(objRow["Loja_Endereco_Bairro"], ""),
                        Common.IsNull(objRow["Loja_Endereco_CEP"], ""),
                        Common.IsNull(objRow["Loja_Endereco_Cidade"], ""),
                        Common.IsNull(objRow["Loja_Endereco_UF"], "")
                        ),
                    Common.IsNull(objRow["Loja_InicioAtividade"], DateTime.MinValue),
                    Common.IsNull(objRow["Loja_Nome"], ""),
                    new Officer
                        (
                        Common.IsNull(objRow["Officer_Codigo"], 0L),
                        Common.IsNull(objRow["Officer_Nome"], "")
                        ),
                    Common.IsNull(objRow["Loja_RazaoSocial"], ""),
                    new Regional
                        (
                        Common.IsNull(objRow["Regional_Codigo"], 0L),
                        Common.IsNull(objRow["Regional_Nome"], ""),
                        new Endereco
                            (
                            Common.IsNull(objRow["Regional_Endereco_Logradouro"], ""),
                            Common.IsNull(objRow["Regional_Endereco_Numero"], ""),
                            Common.IsNull(objRow["Regional_Endereco_Complemento"], ""),
                            Common.IsNull(objRow["Regional_Endereco_Bairro"], ""),
                            Common.IsNull(objRow["Regional_Endereco_CEP"], ""),
                            Common.IsNull(objRow["Regional_Endereco_Cidade"], ""),
                            Common.IsNull(objRow["Regional_Endereco_UF"], "")
                            ),
                        "(" + Common.IsNull(objRow["Regional_Telefone_Area"], "") + ") " +
                        Common.IsNull(objRow["Regional_Telefone_Numero"], "")
                        ),
                    "(" + Common.IsNull(objRow["Loja_Telefone_Area"], "") + ") " +
                    Common.IsNull(objRow["Loja_Telefone_Numero"], ""),
                    Common.IsNull(objRow["Loja_Tipo"], "")
                    )
                {
                    Officer = { CPF = Common.IsNull(objRow["Officer_CPF"], 0L) },
                    Status = Common.IsNull(objRow["Loja_Status"], ""),
                    Regional =
                    {
                        CNPJ = Common.IsNull(objRow["Regional_CNPJ"], 0L),
                        Status = Common.IsNull(objRow["Regional_Status"], "")
                    },
                    FimAtividade = Common.IsNull(objRow["Loja_FimAtividade"], DateTime.MinValue)
                };
                var objGarantias = this.ObterGarantias(Contrato, ContratoInterno);
                var objDut = _rcpRepository.VerificarTransferenciaDUT(Contrato);
                foreach (var t in objGarantias)
                {
                    t.Transferencia = objDut;
                }

                var objDSFluxo = ObterFluxoPorContrato(ContratoInterno);
                var objFluxo = (from DataRow objRowFluxo in objDSFluxo.Tables[0].Rows
                                select new FluxoItem()
                                {
                                    CodigoAtraso = Common.IsNull(objRowFluxo["COD_SIT_ATRASO"], 0),
                                    CodigoEvento = Common.IsNull(objRowFluxo["COD_EVENTO_FLUXO"], 0L),
                                    CodigoOrgaoRecebedor = Common.IsNull(objRowFluxo["COD_ORGAO"], 0),
                                    DataAmortizacao = Common.IsNull(objRowFluxo["DATA_AMORTIZACAO"], Common.IsNull(objRowFluxo["DATA_LIBERACAO"], DateTime.MinValue)),
                                    DataContabilizacao = Common.IsNull(objRowFluxo["DATA_CONTABILIZ"], DateTime.MinValue),
                                    DataLiberacao = Common.IsNull(objRowFluxo["DATA_LIBERACAO"], DateTime.MinValue),
                                    DataRetCobradora = Common.IsNull(objRowFluxo["DATA_RET_COBRADORA"], DateTime.MinValue),
                                    DataValor = Common.IsNull(objRowFluxo["DATA_VALOR"], DateTime.MinValue),
                                    Descricao = Common.IsNull(objRowFluxo["DESC_EVENTO_FLUXO"], ""),
                                    Estorno = (Common.IsNull(objRowFluxo["FLAG_ESTORNO"], "") == "S"),
                                    NumeroSequencia = Common.IsNull(objRowFluxo["NUM_SEQ_FLUXO"], 0),
                                    NumeroSequenciaMovimento = Common.IsNull(objRowFluxo["NUM_SEQ_MOVTO"], 0L),
                                    TipoLiquidacao = Common.IsNull(objRowFluxo["DESC_LIQUIDACAO"], ""),
                                    TipoMovimento = Common.IsNull(objRowFluxo["TIPO_MOVTO"], ""),
                                    TipoOrgaoRecebedor = Common.IsNull(objRowFluxo["TIPO_ORGAO_REC"], ""),
                                    Valor = ((Common.IsNull(objRowFluxo["TIPO_MOVTO"], "") == "D") || (Common.IsNull(objRowFluxo["FLAG_ESTORNO"], "") == "S") ? -1.0m : 1.0m) * Common.IsNull(objRowFluxo["VAL_REALIZADO"], 0.0m)
                                }).ToList();

                var objDSParcelas = ObterParcelas(ContratoInterno);
                var objParcelas = new List<Parcela>();
                var objMsg = CobolObterOperacoes(ContratoInterno);
                var objMsgParcelas = objMsg.ItensRetorno["PARCELAS"];
                if (objMsgParcelas.Itens.Count > 0)
                    objMsgParcela = objMsgParcelas[intA];

                //foreach (DataRow objRowParcela in objDSParcelas.Tables[0].Rows)
                //{
                //    var objParcela = new Parcela
                //    {
                //        CessaoCodigo = Common.IsNull(objRowParcela["Cessao_Codigo"], 0L),
                //        DataVencimento =
                //            Common.IsNull(objRowParcela["DATA_AMORTIZACAO"], DateTime.MinValue),
                //        DataPagamento = Common.IsNull(objRowParcela["DATA_LIQUIDACAO"], DateTime.MinValue),
                //        DiasAtraso = Common.IsNull(objRowParcela["QTD_DIAS_ATRASO"], (Int16)0),
                //        Estorno = (Common.IsNull(objRowParcela["FLAG_ESTORNO_N"], "") == "S"),
                //        Liquidado = (Common.IsNull(objRowParcela["FLAG_LIQUIDADO"], "") == "S"),
                //        NumeroParcela = Common.IsNull(objRowParcela["NUM_PARCELA"], 0),
                //        ValorJuros = Common.IsNull(objRowParcela["VAL_AMTZ_JUR"], 0.0m),
                //        ValorPrincipal = Common.IsNull(objRowParcela["VAL_AMTZ_PRINC"], 0.0m),
                //        Valor = Common.IsNull(objRowParcela["ParcelaValor"], 0.0m),
                //        ValorAcrescimos = Common.IsNull(objRowParcela["ParcelaAcrescimos"], 0.0m),
                //        ValorDescontos = Common.IsNull(objRowParcela["ParcelaDescontos"], 0.0m),
                //        ValorVRG = Common.IsNull(objRowParcela["VAL_VRG_PARC"], 0.0m),
                //        FormaLiquidacao = (OperacaoLiquidacaoTipos)
                //            Common.Escolher(
                //                Common.IsNull(objRowParcela["TIPO_LIQUIDACAO"], ""),
                //                "A", OperacaoLiquidacaoTipos.BoletoECheque,
                //                "B", OperacaoLiquidacaoTipos.Boleto,
                //                "C", OperacaoLiquidacaoTipos.Cheque,
                //                "D", OperacaoLiquidacaoTipos.DebitoConta,
                //                "F", OperacaoLiquidacaoTipos.ChequeEDebito,
                //                "G", OperacaoLiquidacaoTipos.BoletoEDebito,
                //                "I", OperacaoLiquidacaoTipos.Interface,
                //                "", OperacaoLiquidacaoTipos.Indefinido,
                //                OperacaoLiquidacaoTipos.Indefinido)
                //    };

                //    if (objParcela.CessaoCodigo != 0)
                //    {
                //        objParcela.CessaoData = Common.IsNull(objRowParcela["Cessao_Data"], DateTime.MinValue);
                //        objParcela.CessaoCoobrigacao = (Common.IsNull(objRowParcela["Cessao_Coobrigado"], "") == "S");
                //        objParcela.CessaoBanco = new Banco(Common.IsNull(objRowParcela["Cessao_Banco_Codigo"], 0), 0);
                //    }

                //    if (objMsgParcela != null && Convert.ToDateTime(objMsgParcela["DATA DA AMORTIZACAO"].Valor) == objParcela.DataVencimento)
                //    {
                //        objParcela.Renegociado = Convert.ToString(objMsgParcela["FLAG PARCELA FAZ PARTE DA RENEG."].Valor) == "S";
                //        objParcela.Valor = Convert.ToDecimal(objMsgParcela["VALOR DA PARCELA"].Valor);
                //        objParcela.ValorCurva = Convert.ToDecimal(objMsgParcela["VALOR DA PARCELA NA CURVA"].Valor);
                //        objParcela.ValorMora = Convert.ToDecimal(objMsgParcela["VALOR DA MORA"].Valor);
                //        objParcela.ValorCP = Convert.ToDecimal(objMsgParcela["VALOR DA COMISSAO DE PERMANENCIA"].Valor);
                //        objParcela.ValorMulta = Convert.ToDecimal(objMsgParcela["VALOR DA MULTA"].Valor);
                //        objParcela.MoraTaxa = Convert.ToDecimal(objMsgParcela["TAXA DA MORA"].Valor);
                //        objParcela.MoraTipo = Convert.ToString(objMsgParcela["TIPO DA TAXA MORA"].Valor);
                //        objParcela.MoraPeriodicidade = Convert.ToString(objMsgParcela["PERIODICIDADE DA TAXA MORA"].Valor);
                //        objParcela.MultaTaxa = Convert.ToDecimal(objMsgParcela["PERCENTUAL DA MULTA"].Valor);
                //        objParcela.MultaBase = Convert.ToString(objMsgParcela["BASE MULTA"].Valor);
                //        objParcela.CPTaxa = Convert.ToDecimal(objMsgParcela["TAXA DE CP"].Valor);
                //        objParcela.CPTipo = Convert.ToString(objMsgParcela["TIPO DA TAXA CP"].Valor);
                //        objParcela.CPPeriodicidade = Convert.ToString(objMsgParcela["PERIODICIDADE DA TAXA CP"].Valor);
                //        objParcela.ValorDescontoMora = Convert.ToDecimal(objMsgParcela["VALOR DO DESCONTO SOBRE MORA"].Valor);
                //        objParcela.ValorDescontoCP = Convert.ToDecimal(objMsgParcela["VALOR DO DESCONTO SOBRE CP"].Valor);
                //        objParcela.ValorDescontoMulta = Convert.ToDecimal(objMsgParcela["VALOR DO DESCONTO SOBRE MULTA"].Valor);
                //        objParcela.ValorDescontoParcela = Convert.ToDecimal(objMsgParcela["VALOR DO DESCONTO SOBRE PARCELA"].Valor);
                //        objParcela.ValorHonorarios = Convert.ToDecimal(objMsgParcela["VALOR DOS HONORARIOS"].Valor);
                //        objParcela.ValorComissao = Convert.ToDecimal(objMsgParcela["VALOR DA COMISSAO"].Valor);

                //        var intDiasVencimento = Convert.ToInt16(objMsgParcela["QUANTIDADE DE DIAS EM ATRASO"].Valor);

                //        if (intDiasVencimento < 0)
                //        {
                //            objParcela.DiasAdiantamento = Math.Abs(intDiasVencimento);
                //            objParcela.ValorDescontos = objParcela.Valor - objParcela.ValorCurva;
                //        }
                //        else
                //        {
                //            objParcela.DiasAtraso = intDiasVencimento;
                //            objParcela.ValorAcrescimos = objParcela.ValorMora + objParcela.ValorMulta + objParcela.ValorCP;
                //        }

                //        if (intA < objMsgParcelas.Itens.Count - 1)
                //        {
                //            objMsgParcela = objMsgParcelas[++intA];
                //        }
                //    }
                //    objParcelas.Add(objParcela);
                //}
                objOperacao = new OperacaoCredito
                {
                    Cliente = objCliente,
                    Empresa = objEmpresa,
                    Loja = objLoja,
                    Fluxo = objFluxo,
                    Parcelas = objParcelas,
                    Garantias = objGarantias,
                    Acordos = ObterAcordosPansolution(ContratoInterno),
                    Ocorrencias = ObterOcorrencias(ContratoInterno),
                    CodigoProduto = Common.IsNull(objRow["COD_PRODUTO"], ""),
                    Contrato = Common.IsNull(objRow["COD_CONTRATO"], ""),
                    ContratoInterno = Common.IsNull(objRow["COD_CONTRATO_INTER"], 0L),
                    Regular = Convert.ToBoolean(Common.IsNull(objRow["Contrato_Regular"], 0)),
                    SituacaoCodigo = Common.IsNull(objRow["COD_SIT_ATRASO"], 0),
                    Operacao = Common.IsNull(objRow["OPERACAO"], ""),
                    Origem = Origens.PanSolution,
                    FormaLiquidacao = (OperacaoLiquidacaoTipos)
                        Common.Escolher(Common.IsNull(objRow["TIPO_LIQUIDACAO"], ""),
                            "A", OperacaoLiquidacaoTipos.BoletoECheque,
                            "B", OperacaoLiquidacaoTipos.Boleto,
                            "C", OperacaoLiquidacaoTipos.Cheque,
                            "D", OperacaoLiquidacaoTipos.DebitoConta,
                            "F", OperacaoLiquidacaoTipos.ChequeEDebito,
                            "G", OperacaoLiquidacaoTipos.BoletoEDebito,
                            "I", OperacaoLiquidacaoTipos.Interface,
                            "M", OperacaoLiquidacaoTipos.Misto,
                            "", OperacaoLiquidacaoTipos.Indefinido,
                            OperacaoLiquidacaoTipos.Indefinido),
                    BuscaApreensao = (bool)Common.Escolher(Common.IsNull(objRow["COD_SIT_ATRASO"], 0), 11, true, false),
                    Prejuizo =
                        (bool)
                            Common.Escolher(Common.IsNull(objRow["COD_SIT_ATRASO"], 0), 10, true, 12, true, 13, true,
                                false)
                };
                objOperacao.Cliente.Comercial = new Comercial
                {
                    EmpresaNome = Common.IsNull(objRow["Comercial_Empresa_Nome"], "").Trim(),
                    EmpresaCnpj = Common.IsNull(objRow["Comercial_Empresa_Cnpj"], "").Trim(),
                    Profissao = Common.IsNull(objRow["Cliente_Profissao"], "").Trim(),
                    Salario = Common.IsNull(objRow["Comercial_Data_Admissao_Ano"], 0),
                    NaturezaOcupacao = Common.IsNull(objRow["Comercial_Natureza_Ocupacao"], "").Trim(),
                    TempoAtividadeAno = (Int16)Common.IsNull(objRow["Comercial_Data_Admissao_Ano"], 0),
                    TempoAtividadeMeses = (Int16)Common.IsNull(objRow["Comercial_Data_Admissao_Mes"], 0),
                    Endereco = new Endereco
                    {
                        Logradouro = objRow["Comercial_Endereco_Logradouro"].ToString(),
                        Numero = objRow["Comercial_Endereco_Numero"].ToString(),
                        Complemento = objRow["Comercial_Endereco_Complemento"].ToString(),
                        Bairro = objRow["Comercial_Endereco_Bairro"].ToString(),
                        CEP = objRow["Comercial_Endereco_CEP"].ToString(),
                        Cidade = objRow["Comercial_Endereco_Cidade"].ToString(),
                        UF = objRow["Comercial_Endereco_UF"].ToString()
                    }
                };
                if (0 < Common.IsNull(objRow["Cobradora_Codigo"], 0L))
                {
                    objOperacao.Cobradora = ObterCobradora(objCliente.Documento, Contrato);
                }
                PreencherConfiguracoes(objOperacao);
                return objOperacao;
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        private List<Garantia> ObterGarantias(string p_strContrato, long p_intContratoInterno = 0)
        {
            if (String.IsNullOrWhiteSpace(p_strContrato) && p_intContratoInterno <= 0)
            {
                throw new ArgumentException("O valor do parâmetro fornecido não é válido. Deve ser informado o código do contrato ou o identificador interno da operação para o qual se quer cancelar o acordo. Não devem ser informados valores para mais de um parâmetro numa mesma requisição; a identificação do contrato é feita apenas por um deles.");
            }

            if (p_intContratoInterno <= 0)
            {
                p_intContratoInterno = ObterContratoInterno(p_strContrato);
            }
            var objDS = ObterGarantias(p_intContratoInterno);


            return (from DataRow objRowGarantia in objDS.Tables[0].Rows
                select new Garantia()
                {
                    Codigo = Common.IsNull(objRowGarantia["COD_GARANTIA"], 0L),
                    CodigoClasseGarantia = Common.IsNull(objRowGarantia["COD_CLASSE_GAR"], 0L),
                    CodigoGarantiaSubstituida = Common.IsNull(objRowGarantia["COD_GAR_SUBSTITUT"], 0L),
                    CodigoMoeda = Common.IsNull(objRowGarantia["COD_MOEDA_GAR"], ""),
                    DataContabilizacao = Common.IsNull(objRowGarantia["DATA_CONTABILIZ"], DateTime.MinValue),
                    DataContabilizacaoBaixa = Common.IsNull(objRowGarantia["DATA_CONTAB_BAIXA"], DateTime.MinValue),
                    DataContabilizacaoEfetiva = Common.IsNull(objRowGarantia["DATA_CONTAB_EFETIV"], DateTime.MinValue),
                    DataDesativacao = Common.IsNull(objRowGarantia["DATA_DESATIVACAO"], DateTime.MinValue),
                    DataInicioValorizacao = Common.IsNull(objRowGarantia["DATA_INIC_VALORIZ"], DateTime.MinValue),
                    DataVencimento = Common.IsNull(objRowGarantia["DATA_VENCIMENTO"], DateTime.MinValue),
                    GarantiaPrincipal = (Common.IsNull(objRowGarantia["FLAG_GAR_PRINCIPAL"], "") == "S"),
                    NumeroSequencia = Common.IsNull(objRowGarantia["NUM_SEQ_GAR"], 0),
                    TipoBaixa = Common.IsNull(objRowGarantia["TIPO_BAIXA"], ""),
                    TipoValorizacao = Common.IsNull(objRowGarantia["TIPO_VALORIZACAO"], ""),
                    ValorHistorico = Common.IsNull(objRowGarantia["VAL_HISTORICO"], 0.0m),
                    Valor = Common.IsNull(objRowGarantia["VALOR_GARANTIA"], 0.0m),
                    NumeroCertificadoAtu = Common.IsNull(objRowGarantia["NUM_CERTIFIC_ATU"], ""),
                    DataCertificadoAtu = Common.IsNull(objRowGarantia["DATA_CERTIFIC_ATU"], DateTime.MinValue),
                    DataInclusao = Common.IsNull(objRowGarantia["DTHORA_INCLUSAO"], DateTime.MinValue),
                    Veiculo = new Veiculo()
                    {
                        Codigo = Common.IsNull(objRowGarantia["COD_VEICULO"], 0L), Alienacao = (Common.IsNull(objRowGarantia["FLAG_ALIENACAO"], "") == "C"), Assistencia = (Common.IsNull(objRowGarantia["FLAG_ASSISTENCIA"], "") == "1"), Apreensao = (Common.IsNull(objRowGarantia["TIPO_APREENSAO"], "") != ""), ApreensaoMotivo = Common.IsNull(objRowGarantia["DESC_MOT_APR_QUIT"], ""), ApreensaoTipo = Common.IsNull(objRowGarantia["TIPO_APREENSAO"], ""), BloqueiaIL_Flag = Common.IsNull(objRowGarantia["FLAG_BLOQUEIA_IL"], ""), Categoria = Common.IsNull(objRowGarantia["TIPO_CATEGORIA"], ""), Chassi = Common.IsNull(objRowGarantia["NUM_CHASSI"], ""), ChassiRemarcado = (Common.IsNull(objRowGarantia["FLAG_CHASSI_REMARC"], "") == "S"), CodigoTipoVeiculo = Common.IsNull(objRowGarantia["COD_TP_VEIC"], 0L), Combustivel = Common.Escolher(Common.IsNull(objRowGarantia["TIPO_COMBUSTIVEL"], ""), "1", "Gasolina", "2", "Álcool", "3", "Diesel", "4", "Gás natural", "5", "Bi-combustível", "").ToString(), Cor = Common.IsNull(objRowGarantia["DESC_COR_VEIC"], ""), DataAlienacao = Common.IsNull(objRowGarantia["DATA_ALIENACAO"], DateTime.MinValue), DataGeracaoAlienacao = Common.IsNull(objRowGarantia["DATA_GERA_ALIENAC"], DateTime.MinValue), DataRegAssist = Common.IsNull(objRowGarantia["DATA_REG_ASSIST"], DateTime.MinValue), EnvioAssistencia_Flag = Common.IsNull(objRowGarantia["FLAG_ENVIO_ASSIST"], ""), FabricacaoAno = Common.IsNull(objRowGarantia["ANO_FABRIC"], (Int16) 0), NumeroGravame = Common.IsNull(objRowGarantia["NUM_GRAVAME"], 0L), Marca = Common.IsNull(objRowGarantia["DESC_MARCA"], ""), Modelo = Common.IsNull(objRowGarantia["DESC_VEICULO"], ""), ModeloAno = Common.IsNull(objRowGarantia["ANO_MODELO"], (Int16) 0), Placa_Codigo = Common.IsNull(objRowGarantia["NUM_PLACA_ATU"], ""), Placa_UF = Common.IsNull(objRowGarantia["SIGLA_UF_PLACA_ATU"], ""), RegistroContrato_Flag = Common.IsNull(objRowGarantia["FLAG_REG_CONTRATO"], ""), Renavam = Common.IsNull(objRowGarantia["COD_RENAVAN"], 0L), ValorNotaFiscal = Common.IsNull(objRowGarantia["VALOR_NF"], 0.0m), VeiculoZero = (Common.IsNull(objRowGarantia["FLAG_VEIC_ZERO"], "") == "1"), CertificadoAtu = Common.IsNull(objRowGarantia["NUM_CERTIFIC_ATU"], ""), DataInclusao = Common.IsNull(objRowGarantia["DTHORA_INCLUSAO"], DateTime.MinValue), DataCertificadoAtu = Common.IsNull(objRowGarantia["DATA_CERTIFIC_ATU"], DateTime.MinValue)
                    }
                }).ToList();
        }
        private List<Ocorrencia> ObterOcorrencias(long p_intContratoInterno)
        {
            if (p_intContratoInterno <= 0)
            {
                throw new Exception("Nenhum parâmetro foi fornecido para recuperação de informações.");
            }
            var objDS = ObterOcorrenciasPorContrato(p_intContratoInterno);
            var objRetorno = (from DataRow objRow in objDS.Tables[0].Rows select new Ocorrencia(Common.IsNull(objRow["Codigo"], 0L), Common.IsNull(objRow["Nome"], ""), Common.IsNull(objRow["AcaoCodigo"], ""), Common.IsNull(objRow["Acao"], ""), Common.IsNull(objRow["DataInclusao"], DateTime.MinValue), Common.IsNull(objRow["DataValidade"], DateTime.MaxValue), Common.IsNull(objRow["DataParcela"], DateTime.MinValue), (Common.IsNull(objRow["DataValidade"], DateTime.MaxValue) >= DateTime.Now))).ToList();

            var arrOcorrenciasAtivas = objRetorno.Select(o => o.Codigo).Distinct().ToArray();

            var arrOcorrenciasPares = ConfigurationManager.AppSettings["Pansolution_Operacao_OcorrenciasInibidorasFuncao"].Split(';');

            foreach (var strOcorrenciaPar in arrOcorrenciasPares)
            {
                var arrOcorrenciasPar = strOcorrenciaPar.Split('|');
                var arrOcorrenciasParesAtivadoras = arrOcorrenciasPar[0].Split(',');
                var arrOcorrenciasParesDesativadoras = arrOcorrenciasPar[1].Split(',');



                for (var intA = 0; intA < arrOcorrenciasAtivas.Length; intA++)
                {
                    if (!arrOcorrenciasParesAtivadoras.Contains(arrOcorrenciasAtivas[intA].ToString())) continue;
                    for (var intB = intA; intB < arrOcorrenciasAtivas.Length; intB++)
                    {
                        if (!arrOcorrenciasParesDesativadoras.Contains(arrOcorrenciasAtivas[intB].ToString())) continue;
                        arrOcorrenciasAtivas[intA] = -1;
                        arrOcorrenciasAtivas[intB] = -1;
                        break;
                    }
                }
            }

            arrOcorrenciasAtivas = Array.FindAll(arrOcorrenciasAtivas, i => i != -1);

            foreach (var objOcorrencia in objRetorno)
            {
                objOcorrencia.Ativo = (arrOcorrenciasAtivas.Contains(objOcorrencia.Codigo)) && (objOcorrencia.DataValidade >= DateTime.Today);
            }
            objDS.Dispose();
            return objRetorno;
        }
        private void PreencherConfiguracoes(OperacaoCredito p_objOperacao)
        {
            var blnContratoInibido = false;
            var arrOcorrenciasAtivas = p_objOperacao.Ocorrencias.Where(o => o.Ativo).Select(o => o.Codigo).Distinct().ToArray();
            var arrOcorrenciasInibidoras = ConfigurationManager.AppSettings["Pansolution_Operacao_OcorrenciasInibidoras"].Split(';');

            foreach (var strRegistro in arrOcorrenciasInibidoras)
            {
                var arrOcorrenciasInibidorasItens = strRegistro.Split('|');
                var arrOcorrenciasInibidorasOcorrencias = arrOcorrenciasInibidorasItens[0].Split(',');

                if (arrOcorrenciasInibidorasOcorrencias.Any(strOcorrencia => arrOcorrenciasAtivas.Contains(Convert.ToInt64(strOcorrencia))))
                {
                    blnContratoInibido = true;
                }
                if (blnContratoInibido)
                {
                    break;
                }
            }
        }
        public List<Acordo> ObterAcordosPansolution(long contrato)
        {
            if (contrato <= 0) throw new Exception("Nenhum parâmetro foi fornecido para recuperação de informações.");

            Acordo objAcordo = null;
            var strNossoNumero = string.Empty;
            var dtmInclusao = DateTime.MinValue;
            var objDS = ObterAcordos(contrato);
            var objRetorno = new List<Acordo>();

            foreach (DataRow objRow in objDS.Tables[0].Rows)
            {
                if (Common.IsNull(objRow["NOSSO_NUMERO"], "") != strNossoNumero || Common.IsNull(objRow["DATA_INCL_ACORDO"], DateTime.MinValue) != dtmInclusao)
                {
                    strNossoNumero = Common.IsNull(objRow["NOSSO_NUMERO"], "");
                    dtmInclusao = Common.IsNull(objRow["DATA_INCL_ACORDO"], DateTime.MinValue);

                    objAcordo = new Acordo(Common.IsNull(objRow["COD_CONTRATO_INTER"], ""),
                        Common.IsNull(objRow["DATA_CANCELAMENTO"], DateTime.MinValue),
                        Common.IsNull(objRow["DATA_INCL_ACORDO"], DateTime.MinValue),
                        Common.IsNull(objRow["DATA_PAGTO_EFETIVA"], DateTime.MinValue),
                        Common.IsNull(objRow["DATA_PAGTO"], DateTime.MinValue),
                        Common.IsNull(objRow["NOSSO_NUMERO"], ""),
                        Common.IsNull(objRow["NUM_SEQ_PAGTO"], 0),
                        Common.IsNull(objRow["FLAG_PAGTO"], ""));
                    objRetorno.Add(objAcordo);
                }
                var decDescontos = Common.IsNull(objRow["VAL_DESCONTO_CONC"], 0.0m) +
                                   Common.IsNull(objRow["VAL_DESC_ANTECIP"], 0.0m);
                var decAcrescimos = Common.IsNull(objRow["VAL_MORA"], 0.0m) + Common.IsNull(objRow["VAL_COMISS_PERM"], 0.0m)
                                    + Common.IsNull(objRow["VAL_MULTA"], 0.0m)
                                    + Common.IsNull(objRow["VAL_COMISS_HONOR"], 0.0m)
                                    + Common.IsNull(objRow["VAL_COMISSAO_COB"], 0.0m);

                const decimal decValorVRG = 0M;
                if (objAcordo != null)
                    objAcordo.Parcelas.Add(new Parcela(0,
                        Common.IsNull(objRow["DATA_PAGTO"], DateTime.MinValue),
                        Common.IsNull(objRow["DATA_AMORTIZACAO"], DateTime.MinValue),
                        Common.IsNull(objRow["DATA_PAGTO_EFETIVA"], DateTime.MinValue),
                        0,
                        0,
                        false,
                        OperacaoLiquidacaoTipos.Indefinido,
                        Common.IsNull(objRow["DATA_PAGTO_EFETIVA"], DateTime.MinValue) != DateTime.MinValue,
                        false,
                        Common.IsNull(objRow["VAL_SALDO_PARC"], 0.0m),
                        Common.IsNull(objRow["VAL_SALDO_PARC"], 0.0m) - CrossCutting.Common.IsNull(objRow["VAL_DESC_ANTECIP"], 0.0m),
                        0.0m,
                        0.0m,
                        Common.IsNull(objRow["VAL_RECEBIMENTO"], 0.0m),
                        Common.IsNull(objRow["VAL_MORA"], 0.0m),
                        Common.IsNull(objRow["VAL_COMISS_PERM"], 0.0m),
                        Common.IsNull(objRow["VAL_MULTA"], 0.0m),
                        0.0m,
                        0.0m,
                        0.0m,
                        Common.IsNull(objRow["VAL_DESCONTO_CONC"], 0.0m) + CrossCutting.Common.IsNull(objRow["VAL_DESC_ANTECIP"], 0.0m),
                        Common.IsNull(objRow["VAL_COMISS_HONOR"], 0.0m),
                        Common.IsNull(objRow["VAL_COMISSAO_COB"], 0.0m),
                        0.0m,
                        "",
                        "",
                        0.0m,
                        "",
                        0.0m,
                        "",
                        "",
                        0.0m,
                        0.0m,
                        0.0m,
                        0.0m,
                        0.0m,
                        decDescontos,
                        decAcrescimos,
                        decValorVRG,
                        string.Empty));
            }
            objDS.Dispose();
            return objRetorno;
        }
        private Cobradora ObterCobradora(Int64 p_intDocumento, String p_strContrato)
        {
            if (p_intDocumento <= 0 || string.IsNullOrWhiteSpace(p_strContrato))
            {
                return null;
            }
            try
            {
                return _cyberAdapter.Assessoria_Obter(p_intDocumento, p_strContrato, "1");
            }
            catch
            {
                return null;
            }
        }
        public void Dispose()
        {
        }
    }
}