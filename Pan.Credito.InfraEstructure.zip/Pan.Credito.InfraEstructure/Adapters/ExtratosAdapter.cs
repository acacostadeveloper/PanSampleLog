﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Threading.Tasks;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Common;
using RestSharp;

namespace Pan.Credito.Infrastructure.Adapters
{
    public class ExtratosAdapter : IExtratosAdapter
    {
        private readonly IEmailDispatcher _emailDispatcher;
        
        public ExtratosAdapter(IEmailDispatcher emailDispatcher)
        {
            _emailDispatcher = emailDispatcher;
        }

        public byte[] ObterExtratoDepagamentos(int ano, string documento, string email, bool enviarEmail)
        {
            var client = new RestClient(ConfigurationManager.AppSettings["EXTRATOS_DOMAIN"]);
            var request = new RestRequest("WebBanking/Extrato.aspx?req={req}&documento={documento}&ano={ano}&gerar={gerar}", Method.GET);
            request.AddHeader("Content-Type", "application/pdf");
            request.AddUrlSegment("req", "pagamentos");
            request.AddUrlSegment("documento", documento);
            request.AddUrlSegment("ano", Convert.ToString(ano));
            request.AddUrlSegment("gerar", "true");
            var response = client.Execute(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) throw new Exception("SEM CONTEUDO");
            var rawBytes = response.RawBytes;
            if (rawBytes.Length == 17240) throw new Exception("SEM CONTEUDO");
            if (!enviarEmail) return rawBytes;
            var anexos = new Dictionary<string, byte[]>
            {
                {string.Format("demonstrativo_de_pagamento_{0}.pdf", documento),rawBytes }
            };
            _emailDispatcher.EnviarEmail(email, "Banco Pan Demonstrativo de pagamentos", Properties.Resources.demonstrativo_pagamento_msg_body, ref anexos);
            return null;
        }

        public byte[] ObterExtratoTarifas(int ano, string documento, string email, bool enviarEmail)
        {
            var client = new RestClient(ConfigurationManager.AppSettings["EXTRATOS_DOMAIN"]);
            var request = new RestRequest("WebBanking/Extrato.aspx?req={req}&documento={documento}&ano={ano}&gerar={gerar}", Method.GET);
            request.AddHeader("Content-Type", "application/pdf");
            request.AddUrlSegment("req", "tarifas");
            request.AddUrlSegment("documento", documento);
            request.AddUrlSegment("ano", Convert.ToString(ano));
            request.AddUrlSegment("gerar", "true");
            var response = client.Execute(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) throw new Exception("SEM CONTEUDO");
            var rawBytes = response.RawBytes;
            if (rawBytes.Length == 17240) throw new Exception("SEM CONTEUDO");
            if (!enviarEmail) return rawBytes;
            var anexos = new Dictionary<string, byte[]>
            {
                {string.Format("extrato_de_tarifas_{0}.pdf", documento),rawBytes }
            };
            _emailDispatcher.EnviarEmail(email, "Banco Pan Extrato Anual de Tarifas", Properties.Resources.guia_extrato_tarifa_msg_corpo, ref anexos);

            return null;
        }

        public byte[] ObterInformeDeRedimentos(int ano, string documento, string email, bool enviarEmail)
        {
            var client = new RestClient(ConfigurationManager.AppSettings["EXTRATOS_DOMAIN"]);
            var request = new RestRequest("WebBanking/Extrato.aspx?req={req}&documento={documento}&ano={ano}&gerar={gerar}", Method.GET);
            request.AddHeader("Content-Type", "application/pdf");
            request.AddUrlSegment("req", "rendimentos");
            request.AddUrlSegment("documento", documento);
            request.AddUrlSegment("ano", Convert.ToString(ano));
            request.AddUrlSegment("gerar", "true");
            var response = client.Execute(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) throw new Exception("SEM CONTEUDO");
            var rawBytes = response.RawBytes;
            if (rawBytes.Length == 17240) throw new Exception("SEM CONTEUDO");
            if (!enviarEmail) return rawBytes;
            var anexos = new Dictionary<string, byte[]>
            {
                {string.Format("informe_de_rendimento_{0}.pdf", documento),rawBytes }
            };
            if (response.ContentLength == 17210) return null;
            _emailDispatcher.EnviarEmail(email, "Banco Pan Demonstrativo de rendimentos", Properties.Resources.demonstrativo_rendimento_msg_body, ref anexos);

            return null;
        }

        public byte[] DeclaracaoContratoQuitado(string contrato, string email, bool enviarEmail)
        {
            var client = new RestClient(ConfigurationManager.AppSettings["EXTRATOS_DOMAIN"]);
            var request = new RestRequest("WebBanking/Extrato.aspx?req={req}&contrato={contrato}&gerar={gerar}", Method.GET);
            request.AddHeader("Content-Type", "application/pdf");
            request.AddUrlSegment("req", "quitacao");
            request.AddUrlSegment("contrato", contrato);
            request.AddUrlSegment("gerar", "true");
            var response = client.Execute(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) throw new Exception("ERRO NO LEGADO");
            var rawBytes = response.RawBytes;
            if (rawBytes.Length == 17240) throw new Exception("SEM CONTEUDO");
            if (!enviarEmail) return rawBytes;
            var anexos = new Dictionary<string, byte[]>
            {
                {string.Format("declaracao_contrato_quitado_{0}.pdf", contrato),rawBytes }
            };
            _emailDispatcher.EnviarEmail(email, "Banco Pan Declaração de contrato quitado", Properties.Resources.guia_declaracao_contrato_quitado_msg_corpo, ref anexos);

            return null;
        }

        public byte[] ObterCartaResumo(string documento, string contrato, string email, bool enviarEmail)
        {
            var client = new RestClient(ConfigurationManager.AppSettings["EXTRATOS_DOMAIN"]);
            var request = new RestRequest("RCP_NET/CartaResumo/CartaVeiculos.aspx?cpf={documento}&contrato={contrato}", Method.GET);
            request.AddHeader("Content-Type", "application/pdf");
            request.AddUrlSegment("contrato", contrato);
            request.AddUrlSegment("cpf", documento);
            var response = client.Execute(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) throw new Exception("SEM CONTEUDO");
            var rawBytes = response.RawBytes;
            if (rawBytes.Length == 17240) throw new Exception("SEM CONTEUDO");
            if (!enviarEmail) return rawBytes;
            var anexos = new Dictionary<string, byte[]>
            {
                {string.Format("carta_resumo_contrato_{0}.pdf", contrato),rawBytes }
            };
            _emailDispatcher.EnviarEmail(email, "Banco Pan Carta Resumo", Properties.Resources.guia_carta_resumo_msg_corpo, ref anexos);

            return null;
        }

        public Dictionary<string, byte[]> GuiaTransferenciaDivida(string email, bool enviarEmail)
        {
            var anexos = new Dictionary<string, byte[]>
            {
                {"Guia_Transf_Divida.pdf", Properties.Resources.Guia_Transf_Divida}
            };
            if (!enviarEmail) return anexos;
            _emailDispatcher.EnviarEmail(email, "Financiamentos - Guia de Transferência de dívida",Properties.Resources.guia_transf_divida_corpo_msg, ref anexos);
            return anexos;
        }

        public Dictionary<string, byte[]> GuiaSubstituicaoDeGarantia(string email, bool enviarEmail)
        {
            var anexos = new Dictionary<string, byte[]>
            {
                {"Guia_Sub_Garantia.pdf", Properties.Resources.Guia_Sub_Garantia}
            };
            if (!enviarEmail) return anexos;
            _emailDispatcher.EnviarEmail(email, "Financiamentos - Guia de Substituição de Garantia", Properties.Resources.guia_sub_garantia_msg_corpo, ref anexos);
            return anexos;
        }
        
        public void Dispose()
        {
            
        }
    }
}