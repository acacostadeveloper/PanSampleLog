﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Pan.Credito.CrossCutting;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Exceptions;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Domain.Repository;
using Pan.Credito.Infrastructure.wsFuncaoAutorizador;
using Pan.Credito.Infrastructure.wsFuncaoGV;
using Pan.Credito.Infrastructure.wsFuncaoVeiculos;
using Cobradora = Pan.Credito.Domain.Entidades.Credito.Cobradora;
using Endereco = Pan.Credito.Domain.Entidades.Credito.Endereco;
using Garantia = Pan.Credito.Domain.Entidades.Credito.Garantia;
using Ocorrencia = Pan.Credito.Domain.Entidades.Credito.Ocorrencia;
using Telefone = Pan.Credito.Domain.Entidades.Credito.Telefone;
using TipoEstadoCivil = Pan.Credito.Domain.Entidades.Types.TipoEstadoCivil;
using TipoNacionalidade = Pan.Credito.Domain.Entidades.Types.TipoNacionalidade;
using TipoResidencia = Pan.Credito.Domain.Entidades.Types.TipoResidencia;
using TipoSexo = Pan.Credito.Domain.Entidades.Types.TipoSexo;
using TipoSistema = Pan.Credito.Domain.Entidades.Types.TipoSistema;
using TipoStatus = Pan.Credito.Infrastructure.wsFuncaoVeiculos.TipoStatus;
using TipoTelefone = Pan.Credito.Domain.Entidades.Types.TipoTelefone;

namespace Pan.Credito.Infrastructure.Adapters
{
    public class FuncaoAdapter : IFuncaoAdapter
    {

        public const string backOffice = "01";
        private const string CodigoChaveFuncao = "1";
        private const int DiasCarenciaQuitado = 7;
        public readonly string mesa = ConfigurationManager.AppSettings["MESA_FUNCAO"];
        private readonly string SenhaFuncao = ConfigurationManager.AppSettings["SENHA_FUNCAO"] ;
        private readonly string UsuarioFuncao = ConfigurationManager.AppSettings["USUARIO_FUNCAO"];
        private readonly WsGVSoap _wsGv;
        private readonly WsCDCSoap _wsCDC;
        private readonly WSAutorizadorSoap _wsAutorizador;
        private readonly wsFuncaoAutorizadorAcordos.WSAutorizadorSoap _wsAutorizadorAcordos;
        private readonly IRenegocieRepository _renegocieRepository;
        private readonly ICobrancaAdapter _cobrancaAdapter;
        public FuncaoAdapter(IRenegocieRepository renegocieRepository, ICobrancaAdapter cobrancaAdapter)
        {
            _renegocieRepository = renegocieRepository;
            _cobrancaAdapter = cobrancaAdapter;

            _wsGv = new WsGVSoapClient();
            _wsCDC = new WsCDCSoapClient();
            _wsAutorizador = new WSAutorizadorSoapClient();
            _wsAutorizadorAcordos = new wsFuncaoAutorizadorAcordos.WSAutorizadorSoapClient();
        }

        #region EXTRATOS
        public ClienteExtrato Extrato_Pagamentos(Int64 p_intDocumento, DateTime p_dtmInicio, DateTime p_dtmFim)
        {
            if (p_intDocumento <= 0 || DateTime.MinValue.Equals(p_dtmInicio) || DateTime.MinValue.Equals(p_dtmFim))
                throw new ArgumentException("Não foi fornecido nenhum parâmetro para busca.");

            // Variáveis
            decimal decValorParcelas = 0.0m;
            decimal decValorAcrescimos = 0.0m;
            decimal decValorDescontos = 0.0m;

            var oHelp = new SQLHelper("Funcao");
            oHelp.AddParameter("CPF", DbType.String, p_intDocumento.ToString("000'.'000'.'000'-'00"));

            var cliente = oHelp.ExecuteEntityText<ClienteExtrato>(Properties.Resources.Funcao_Extratos_Pagamentos_Clientes);

            if (cliente.Count == 0)
                return null;

            oHelp = new SQLHelper("Funcao");
            oHelp.AddParameter("CPF", DbType.String, p_intDocumento.ToString("000'.'000'.'000'-'00"));

            var operacoes = oHelp.ExecuteEntityText<Operacao>(Properties.Resources.Funcao_Extratos_Pagamentos_Operacoes);

            if (operacoes.Count == 0) return null;

            oHelp = new SQLHelper("Funcao");
            oHelp.AddParameter("CPF", DbType.String, p_intDocumento.ToString("000'.'000'.'000'-'00"));

            var parcelas = oHelp.ExecuteEntityText<ParcelasExtrato>(Properties.Resources.Funcao_Extratos_Pagamentos_Parcelas);

            if (parcelas.Count == 0) return null;

            parcelas = parcelas.Where(p => p.DataLiquidacao != DateTime.MinValue).ToList();

            operacoes.ForEach(o =>
            {
                decValorAcrescimos = 0.0m;
                decValorDescontos = 0.0m;
                decValorParcelas = 0.0m;

                parcelas.Where(p => p.ContratoInter.ToString() == o.Codigo.Replace("-", string.Empty)).ToList().ForEach(p =>
                {
                    if (p.DataLiquidacao < p_dtmInicio)
                    {
                        decValorAcrescimos += p.Acrescimos;
                        decValorDescontos += p.Descontos;
                        decValorParcelas += p.Valor;
                    }
                    else if (p.DataLiquidacao <= p_dtmFim)
                    {
                        if (o.Parcelas == null)
                            o.Parcelas = new List<ParcelasExtrato>();

                        o.Parcelas.Add(p);
                    }
                    else
                    {
                        return;
                    }
                });

                if (o.Parcelas != null && o.Parcelas.Count > 0)
                {
                    o.ValorParcelas = decValorParcelas;
                    o.ValorAcrescimos = decValorAcrescimos;
                    o.ValorDescontos = decValorDescontos;
                }
            });
            var clienteRetorno = cliente.FirstOrDefault();
            clienteRetorno.Operacoes = operacoes;

            return cliente.Count > 0 ? cliente.First() : null;
        }
        public ClienteExtrato ObterDeclaracaoQuitacao(Int64 Documento, string Contrato)
        {
            ClienteExtrato cliente = null;
            cliente = ConsultaContratoQuitado(Contrato, Documento);

            if (cliente == null)
                return null;

            if (Documento == 0)
            {
                var quitado = cliente.Operacoes.FirstOrDefault(o => o.Quitado && Common.DataReferencia < o.DataLiquidacao.AddDays(DiasCarenciaQuitado));

                if (quitado != null)
                    return null;
            }
            cliente.Operacoes = cliente.Operacoes.Where(o => o.Quitado && Common.DataReferencia > o.DataLiquidacao.AddDays(DiasCarenciaQuitado)).ToList();

            return cliente;
        }
        public ClienteExtrato ObterExtratoPagamentosCliente(Int64 Documento, DateTime Inicio, DateTime Fim)
        {
            var parcelas = new InConsultaPagamentos
            {
                CPF_CNPJ_CLIENTE = FormataDocumento(Documento),
                DATA_INICIAL = Inicio,
                DATA_FINAL = Fim
            };

            var aut = AutenticarCDC();

            var ret = _wsCDC.ConsultaPagamentos(new ConsultaPagamentosRequest { Autenticacao = aut, CONSULTA_PAGAMENTOS = parcelas }).CONSULTA_PAGAMENTOS;

            if (ret.STATUS.CODIGO == TipoStatus.ERRO) return null;

            var cliente = new ClienteExtrato { Operacoes = new List<Operacao>() };
            var op = new Operacao();
            ret.PAGAMENTOS_OPERACAO.ToList().ForEach(p =>
                {
                    op = new Operacao { Contrato = p.NUMERO_OPERACAO };

                    var parcela = new ParcelasExtrato();
                    op.Parcelas = new List<ParcelasExtrato>();

                    p.FLUXO_PARCELAS.ToList().
                        ForEach(pa =>
                        {
                            parcela = new ParcelasExtrato
                            {
                                DataAmortizacao = pa.DATA_VENCIMENTO,
                                DataLiquidacao = pa.DATA_LIQUIDACAO,
                                Acrescimos = (decimal)pa.LIQUIDACAO_ACRESCIMO,
                                Descontos = (decimal)pa.LIQUIDACAO_DESCONTO,
                                Valor = (decimal)pa.VALOR_ORIGINAL
                            };
                            op.Parcelas.Add(parcela);
                        });

                    cliente.Operacoes.Add(op);
                });

            return cliente;
        }
        public ClienteExtrato ObterExtratoTaxas(Int64 Documento, int Ano)
        {
            var cliente = ObterOperacoes(Documento);

            if (cliente == null) throw new Exception("cliente não encontrado");

            //  var funcao = new WsCDCSoapClient();

            var extrato = new InConsultaExtratoTarifas
            {
                DATA_INICIAL = Convert.ToDateTime(Ano + "-01-01"),
                DATA_FINAL = Convert.ToDateTime(Ano + "-12-31")
            };

            cliente.Operacoes.ForEach(o =>
            {
                extrato.NUMERO_OPERACAO = o.Contrato;

                var ret = _wsCDC.ConsultaExtratoTarifas(new ConsultaExtratoTarifasRequest
                {
                    Autenticacao = AutenticarCDC(),
                    CONSULTA_EXTRATO_TARIFAS = extrato
                }).CONSULTA_EXTRATO_TARIFAS;

                if (ret.STATUS.CODIGO == TipoStatus.ERRO)
                    return;

                if (cliente.Documento == 0)
                {
                    cliente.Documento = Documento;
                    cliente.Nascimento = ret.DADOS_CLIENTE.DATA_NASCIMENTO;
                    cliente.Nome = ret.DADOS_CLIENTE.NOME_CLIENTE;
                }

                if (cliente.Tarifas == null) cliente.Tarifas = new List<TarifasExtrato>();

                if (ret.FLUXO_EVENTOS != null)
                {
                    ret.FLUXO_EVENTOS.ToList().ForEach(fe =>
                    {
                        var tarifa = new TarifasExtrato();

                        switch (fe.TIPO_COBRANCA)
                        {
                            case TiposCobrancaTarifa.NAO_DEFINIDO:
                                break;
                            case TiposCobrancaTarifa.IOF:
                                tarifa.CobrancaGenerico = "IOF";
                                break;
                            case TiposCobrancaTarifa.JUROS:
                                tarifa.CobrancaGenerico = "Juros";
                                break;
                        }

                        tarifa.MesCobranca = Convert.ToDateTime(fe.DATA_COBRANCA, new CultureInfo("pt-BR")).Month;
                        tarifa.OperacaoLote = fe.NUMERO_OPERACAO;
                        tarifa.ProdutoNome = fe.DESCRICAO_PRODUTO;
                        tarifa.Valor = Convert.ToDecimal(fe.VALOR_COBRANCA);
                        cliente.Tarifas.Add(tarifa);

                    });
                }
            });
            return cliente;
        }
        public ClienteExtrato ConsultaContratoQuitado(string Contrato, Int64 Documento)
        {
            Cliente cliente = null;

            if (Documento > 0)
                cliente = ObterCliente(Documento.ToString());
            else if (!string.IsNullOrEmpty(Contrato))
                cliente = ObterCliente(Contrato);

            if (cliente == null) return null;

            var In = new wsFuncaoVeiculos.InConsultaOperacao();
            if (Documento == 0)
            {
                In.NUMERO_OPERACAO = Contrato;
                In.TIPO_BUSCA = wsFuncaoVeiculos.TipoBusca.OPERACAO;
            }
            else
            {
                In.CPF_CNPJ_CLIENTE = FormataDocumento(Documento);
                In.TIPO_BUSCA = wsFuncaoVeiculos.TipoBusca.CPF_CNPJ;
            }
            var ret = _wsCDC.ConsultarOperacoes(new ConsultarOperacoesRequest { Autenticacao = AutenticarCDC(), CONSULTA_OPERACAO = In }).RETORNO_CONSULTA_OPERACOES;

            if (ret.STATUS.CODIGO != wsFuncaoVeiculos.TipoStatus.SUCESSO)
                return null;

            var cliente2 = new ClienteExtrato();
            var operacao = new Operacao();

            cliente2.Nome = ret.OPERACOES[0].CLIENTE_NOME;
            cliente2.Documento = cliente.Documento;
            cliente2.Tipo_Pessoa = cliente.Documento.ToString().Length <= 11 ? 'F' : 'J';

            operacao.Contrato = ret.OPERACOES[0].NUMERO_OPERACAO;
            operacao.DataLiquidacao = ret.OPERACOES[0].DATA_LIQUIDACAO;
            operacao.Quitado = ret.OPERACOES[0].SITUACAO_CONTRATO == "L";

            operacao.Data_Contrato = ret.OPERACOES[0].DATABASE;
            operacao.CNPJ = 59285411000113;
            operacao.CodigoProduto = ret.OPERACOES[0].CODIGO_PRODUTO;

            cliente2.Operacoes = new List<Operacao> { operacao };
            return cliente2;
        }
        #endregion EXTRATOS

        #region CLIENTE
        public string GravarCliente(Cliente cliente)
        {
            var In = new wsFuncaoAutorizadorAcordos.InDadoCadastral
            {
                CODIGO_CLIENTE =
                    cliente.PessoaTipo == "F"
                        ? cliente.Documento.ToString().PadLeft(11, '0')
                        : cliente.Documento.ToString().PadLeft(14, '0'),
                NOME = cliente.Nome,
                TIPO_PESSOA = wsFuncaoAutorizadorAcordos.TipoPessoa.FISICA,
                CPF_CNPJ = FormataDocumento(cliente.Documento)
            };

            switch (cliente.Nacionalidade)
            {
                case TipoNacionalidade.BRASILEIRA:
                    In.CODIGO_NACIONALIDADE = "01";
                    break;

                case TipoNacionalidade.ESTRANGEIRA:
                    In.CODIGO_NACIONALIDADE = "05";
                    break;
            }

            In.NATURALIDADE_UF = cliente.NaturalidadeUF;
            if (cliente.Nascimento.HasValue)
                In.DATA_NASCIMENTO_OU_FUNDACAO = cliente.Nascimento.Value;
            In.NATURALIDADE = cliente.Naturalidade;
            In.RG_OU_IE = cliente.RG;
            In.RG_ORGAO_EMISSOR = cliente.RGEmissor;
            In.RG_OU_IE_UF = cliente.RGUF;

            if (cliente.Sexo != TipoSexo.NAO_DEFINIDO)
                In.SEXO = cliente.Sexo == TipoSexo.MASCULINO ? wsFuncaoAutorizadorAcordos.TipoSexo.MASCULINO : wsFuncaoAutorizadorAcordos.TipoSexo.FEMININO;

            switch (cliente.EstadoCivil)
            {
                case TipoEstadoCivil.NAO_DEFINIDO:
                    In.ESTADO_CIVIL = wsFuncaoAutorizadorAcordos.TipoEstadoCivil.NAO_DEFINIDO;
                    break;

                case TipoEstadoCivil.SOLTEIRO:
                    In.ESTADO_CIVIL = wsFuncaoAutorizadorAcordos.TipoEstadoCivil.SOLTEIRO;
                    break;

                case TipoEstadoCivil.CASADO:
                    In.ESTADO_CIVIL = wsFuncaoAutorizadorAcordos.TipoEstadoCivil.CASADO;
                    break;

                case TipoEstadoCivil.DIVORCIADO:
                    In.ESTADO_CIVIL = wsFuncaoAutorizadorAcordos.TipoEstadoCivil.DIVORCIADO;
                    break;

                case TipoEstadoCivil.VIUVO:
                    In.ESTADO_CIVIL = wsFuncaoAutorizadorAcordos.TipoEstadoCivil.VIUVO;
                    break;

                default:
                    In.ESTADO_CIVIL = wsFuncaoAutorizadorAcordos.TipoEstadoCivil.NAO_DEFINIDO;
                    break;
            }

            In.NOME_MAE = cliente.NomeMae;
            In.NOME_PAI = cliente.NomePai;

            In.TIPO_RESIDENCIA = (wsFuncaoAutorizadorAcordos.TipoResidencia)(int)cliente.TipoResidencia;

            var end = new wsFuncaoAutorizadorAcordos.InDadoEnderecoTipo();
            end.CEP = cliente.Endereco.CEP;
            end.LOGRADOURO = cliente.Endereco.Logradouro;
            end.NUMERO = cliente.Endereco.Numero;
            end.COMPLEMENTO = cliente.Endereco.Complemento;
            end.BAIRRO = cliente.Endereco.Bairro;
            end.CIDADE = cliente.Endereco.Cidade;
            end.UF = cliente.Endereco.UF;
            end.TIPO = wsFuncaoAutorizadorAcordos.TipoEndereco.RESIDENCIAL;

            var endCor = new wsFuncaoAutorizadorAcordos.InDadoEnderecoTipo();
            if (!string.IsNullOrEmpty(cliente.Correspondencia.CEP))
            {
                endCor.CEP = cliente.Correspondencia.CEP;
                endCor.LOGRADOURO = cliente.Correspondencia.Logradouro;
                endCor.NUMERO = cliente.Correspondencia.Numero;
                endCor.COMPLEMENTO = cliente.Correspondencia.Complemento;
                endCor.BAIRRO = cliente.Correspondencia.Bairro;
                endCor.CIDADE = cliente.Correspondencia.Cidade;
                endCor.UF = cliente.Correspondencia.UF;
                endCor.TIPO = wsFuncaoAutorizadorAcordos.TipoEndereco.CORRESPONDENCIA;
            }

            In.DADOS_ENDERECOS = new wsFuncaoAutorizadorAcordos.InDadosEnderecosTipo();

            if (cliente.Comercial.Endereco != null)
            {
                In.DADOS_ENDERECOS.DADO_ENDERECO = new wsFuncaoAutorizadorAcordos.InDadoEnderecoTipo[3];
                In.DADOS_ENDERECOS.DADO_ENDERECO[0] = end;

                if (endCor != null)
                    In.DADOS_ENDERECOS.DADO_ENDERECO[1] = endCor;

                var endComPJ = cliente.Comercial.Endereco;
                var endComercial = new wsFuncaoAutorizadorAcordos.InDadoEnderecoTipo();

                if (!string.IsNullOrEmpty(endComPJ.CEP.Trim()))
                {
                    endComercial.CEP = endComPJ.CEP;
                    endComercial.LOGRADOURO = endComPJ.Logradouro;
                    endComercial.NUMERO = endComPJ.Numero;
                    endComercial.COMPLEMENTO = endComPJ.Complemento;
                    endComercial.BAIRRO = endComPJ.Bairro;
                    endComercial.CIDADE = endComPJ.Cidade;
                    endComercial.UF = endComPJ.UF;
                    endComercial.TIPO = wsFuncaoAutorizadorAcordos.TipoEndereco.COMERCIAL;
                    In.DADOS_ENDERECOS.DADO_ENDERECO[2] = endComercial;
                }
            }
            else
            {
                In.DADOS_ENDERECOS.DADO_ENDERECO = new wsFuncaoAutorizadorAcordos.InDadoEnderecoTipo[endCor == null ? 1 : 2];
                In.DADOS_ENDERECOS.DADO_ENDERECO[0] = end;
                if (endCor != null)
                    In.DADOS_ENDERECOS.DADO_ENDERECO[1] = endCor;
            }

            In.TELEFONES = new wsFuncaoAutorizadorAcordos.InTelefonesTipo();
            In.TELEFONES.TELEFONE = new wsFuncaoAutorizadorAcordos.InTelefoneTipo[cliente.Telefones.Count];

            for (int i = 0; i < cliente.Telefones.Count; i++)
            {
                var tel = new wsFuncaoAutorizadorAcordos.InTelefoneTipo();
                tel.DDD = cliente.Telefones[i].DDD.ToString();
                tel.NUMERO = cliente.Telefones[i].Numero.ToString();
                switch (cliente.Telefones[i].Tipo)
                {
                    case TipoTelefone.Telefone:
                        tel.TIPO = wsFuncaoAutorizadorAcordos.TipoTelefone.FONE_RESIDENCIAL;
                        In.CATEGORIA_TELEFONE_RESIDENCIAL = wsFuncaoAutorizadorAcordos.CategoriaTelefoneResidencial.PROPRIO;
                        break;

                    case TipoTelefone.Celular:
                        tel.TIPO = wsFuncaoAutorizadorAcordos.TipoTelefone.CELULAR;
                        break;

                    case TipoTelefone.Recado:
                        tel.TIPO = wsFuncaoAutorizadorAcordos.TipoTelefone.FONE_RECADO;
                        break;
                    case TipoTelefone.Comercial:
                        tel.TIPO = wsFuncaoAutorizadorAcordos.TipoTelefone.FONE_COMERCIAL1;
                        break;
                    default:
                        break;
                }
                In.TELEFONES.TELEFONE[i] = tel;
            }

            In.VALOR_RENDA = (double)cliente.Renda;
            In.EMAIL = cliente.Email;

            var retorno = _wsGv.ConsultarDadosConsolidados(new ConsultarDadosConsolidadosRequest
                {
                    Autenticacao = AutenticarGV(),
                    CodBackoffice = backOffice,
                    CpfCnpj = In.CPF_CNPJ,
                    NumeroContrato = string.Empty
                }).ConsultarDadosConsolidadosResult;

            if (!retorno.DadosConsolidados.Any()) return null;

            var operacao = retorno.DadosConsolidados[0];
            var retCli = operacao.DadosCadastral;

            In.RG_ORGAO_EMISSOR = retCli.RG_ORGAO_EMISSOR;

            In.GRUPO = retCli.GRUPO;
            In.PERMITE_CONSULTASCR = retCli.AUTORIZACAO_CONSULTAS_SCR.ToLower().Contains("sim") ? wsFuncaoAutorizadorAcordos.TipoSimNao.SIM : wsFuncaoAutorizadorAcordos.TipoSimNao.NAO;
            In.PPE = retCli.PEP.ToLower().Contains("sim") ? wsFuncaoAutorizadorAcordos.TipoSimNao.SIM : wsFuncaoAutorizadorAcordos.TipoSimNao.NAO;
            In.QTD_DEPENDENTES = retCli.QTD_DEPENDENTES_OU_QTD_SOCIOS;
            In.RESIDENCIA_ANTERIOR_ANOS = retCli.RESIDENCIA_ANTERIOR_ANOS;
            In.RESIDENCIA_ANTERIOR_MESES = retCli.RESIDENCIA_ANTERIOR_MESES;
            In.RESIDENCIA_ATUAL_ANOS = retCli.RESIDENCIA_ATUAL_ANOS;
            In.RESIDENCIA_ATUAL_MESES = retCli.RESIDENCIA_ATUAL_MESES;
            In.TIPO_CLIENTE = wsFuncaoAutorizadorAcordos.TipoCadastro.CLIENTE;
            In.TIPO_ESCOLARIDADE = (wsFuncaoAutorizadorAcordos.TipoEscolaridade)Enum.Parse(typeof(wsFuncaoAutorizadorAcordos.TipoEscolaridade), retCli.TIPO_ESCOLARIDADE.ToString());
            In.VALOR_ALUGUEL = retCli.VALOR_ALUGUEL;
            In.VALOR_RENDA = retCli.VALOR_RENDA;
            In.VALOR_OUTRAS_RENDAS = retCli.VALOR_RENDA_OUTROS;

            In.CONJUGE = PreencherConjuge(retCli);
            In.DADO_PROFISSIONAL = PreencherDadosProfissionais(retCli);
            In.DADOS_BANCARIOS = PreencherDadosBancarios(retCli);
            In.DADOS_EXPERIENCIA_FINANCEIRA = PreecherDadosFinanceiros(retCli);
            In.DADOS_REF_PESSOAIS = PreencherDadosRerenciais(retCli);

            var ret = _wsAutorizadorAcordos.AlterarCliente(new wsFuncaoAutorizadorAcordos.AlterarClienteRequest { Autenticacao = AutenticarAutorizadorAcordos(), DADO_CADASTRAL = In }).CLIENTE;

            return ret.STATUS.CODIGO == wsFuncaoAutorizadorAcordos.TipoStatus.ERRO ? ret.STATUS.ERROS.ERRO[0].MENSAGEM : "";
        }
        public Cliente ObterCliente(string Contrato)
        {

            var ret = _wsAutorizador.ConsultarClienteCodigo(new ConsultarClienteCodigoRequest
            {
                Autenticacao = AutenticarAutorizador(),
                pCodigo = Contrato
            }).DADO_CADASTRAL;

            if (ret.STATUS_CONSULTA.CODIGO == wsFuncaoAutorizador.TipoStatus.ERRO) return null;

            var cli = new Cliente();
            cli.Codigo = ret.CODIGO_CLIENTE;
            cli.PessoaTipo = ret.TIPO_PESSOA == wsFuncaoAutorizador.TipoPessoa.FISICA ? "F" : "J";
            cli.TipoSistema = TipoSistema.Funcao;
            cli.Documento = Common.ObterNumeros(ret.CPF_CNPJ);
            cli.Nome = ret.NOME;
            cli.Nacionalidade = (TipoNacionalidade)ret.CODIGO_NACIONALIDADE;
            cli.NaturalidadeUF = ret.NATURALIDADE_UF;
            cli.Nascimento = ret.DATA_NASCIMENTO_OU_FUNDACAO;
            cli.Naturalidade = ret.NATURALIDADE;
            cli.RG = ret.RG_OU_IE;
            cli.RGEmissor = ret.RG_ORGAO_EMISSOR;
            if (DateTime.MinValue != ret.RG_OU_IE_DATA_EMISSAO)
                cli.RGData = ret.RG_OU_IE_DATA_EMISSAO;
            cli.RGUF = ret.RG_OU_IE_UF;
            cli.Sexo = (TipoSexo)ret.SEXO;
            cli.EstadoCivil = (TipoEstadoCivil)ret.ESTADO_CIVIL;
            cli.NomeMae = ret.NOME_MAE;
            cli.NomePai = ret.NOME_PAI;

            cli.Dependentes = (short)ret.QTD_DEPENDENTES_OU_QTD_SOCIOS;
            cli.TipoResidencia = (TipoResidencia)ret.TIPO_IMOVEL;
            cli.Conta = new Conta
            {
                Agencia = ret.DADOS_BANCARIOS.DADO_BANCARIO[0].AGENCIA.NUMERO,
                Banco = string.IsNullOrEmpty(ret.DADOS_BANCARIOS.DADO_BANCARIO[0].BANCO.NUMERO)? int.MinValue: Convert.ToInt32(ret.DADOS_BANCARIOS.DADO_BANCARIO[0].BANCO.NUMERO),
                Numero = ret.DADOS_BANCARIOS.DADO_BANCARIO[0].CONTA.NUMERO
            };
            cli.Email = ret.EMAIL;
            cli.NomeRecado = ret.NOME_RECADO;
            cli.Renda = (decimal)ret.VALOR_RENDA;
            cli.Comercial = new Comercial();
            cli.Comercial.RendaMensal = (decimal)ret.VALOR_RENDA;
            cli.Comercial.Profissao = ret.DADO_REFERENCIAL.PROFISSAO;
            cli.Comercial.EmpresaNome = ret.DADO_REFERENCIAL.EMPRESA_TRABALHO_NOME;
            cli.Comercial.EmpresaCnpj = ret.DADO_REFERENCIAL.EMPRESA_TRABALHO_CNPJ;
            cli.Comercial.NaturezaOcupacao = ret.DADO_REFERENCIAL.CODIGO_NATUREZA_OCUPACAO;

            var dataAdmissao = ret.DADO_REFERENCIAL.DATA_ADMISSAO;
            dataAdmissao = Common.DataReferencia.AddDays(-400);

            if (dataAdmissao > DateTime.MinValue)
            {
                var tempoEmprego = Common.DataReferencia.Subtract(dataAdmissao);
                cli.Comercial.TempoAtividadeAno = Convert.ToSByte(tempoEmprego.Days / 365);
                cli.Comercial.TempoAtividadeMeses = Convert.ToSByte((tempoEmprego.Days / 30) - (12 * cli.Comercial.TempoAtividadeAno));
            }
            var end = ret.DADOS_ENDERECOS.DADO_ENDERECO.FirstOrDefault(f => f.TIPO == wsFuncaoAutorizador.TipoEndereco.RESIDENCIAL);

            cli.Endereco = new Endereco();
            cli.Endereco.CEP = end.CEP;
            cli.Endereco.Logradouro = end.LOGRADOURO;
            cli.Endereco.Numero = end.NUMERO;
            cli.Endereco.Complemento = end.COMPLEMENTO;
            cli.Endereco.Bairro = end.BAIRRO;
            cli.Endereco.Cidade = end.CIDADE;
            cli.Endereco.UF = end.UF;

            var endCom = ret.DADOS_ENDERECOS.DADO_ENDERECO.FirstOrDefault(f => f.TIPO == wsFuncaoAutorizador.TipoEndereco.COMERCIAL);

            if (endCom != null && !string.IsNullOrEmpty(endCom.CEP))
            {
                cli.Comercial.Endereco = new Endereco();
                cli.Comercial.Endereco.CEP = endCom.CEP;
                cli.Comercial.Endereco.Logradouro = endCom.LOGRADOURO;
                cli.Comercial.Endereco.Numero = endCom.NUMERO;
                cli.Comercial.Endereco.Complemento = endCom.COMPLEMENTO;
                cli.Comercial.Endereco.Bairro = endCom.BAIRRO;
                cli.Comercial.Endereco.Cidade = endCom.CIDADE;
                cli.Comercial.Endereco.UF = endCom.UF;

            }

            var endCor = ret.DADOS_ENDERECOS.DADO_ENDERECO.FirstOrDefault(f => f.TIPO == wsFuncaoAutorizador.TipoEndereco.CORRESPONDENCIA);

            if (endCor != null && !string.IsNullOrEmpty(endCor.CEP))
            {
                cli.Correspondencia = new Endereco();
                cli.Correspondencia.CEP = endCor.CEP;
                cli.Correspondencia.Logradouro = endCor.LOGRADOURO;
                cli.Correspondencia.Numero = endCor.NUMERO;
                cli.Correspondencia.Complemento = endCor.COMPLEMENTO;
                cli.Correspondencia.Bairro = endCor.BAIRRO;
                cli.Correspondencia.Cidade = endCor.CIDADE;
                cli.Correspondencia.UF = endCor.UF;

            }

            cli.Telefones = new List<Telefone>();

            var tel = ret.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoAutorizador.TipoTelefone.FONE_RESIDENCIAL);

            if (tel != null && !string.IsNullOrEmpty(tel.NUMERO))
            {
                cli.Telefones.Add(new Telefone
                {
                    DDD = tel.DDD,
                    Numero = (int)Common.ObterNumeros(tel.NUMERO),
                    Tipo = TipoTelefone.Telefone
                });
            }

            var cel = ret.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoAutorizador.TipoTelefone.CELULAR);
            if (cel != null && !string.IsNullOrEmpty(cel.NUMERO))
            {
                cli.Telefones.Add(new Telefone
                {
                    DDD = cel.DDD,
                    Numero = (int)Common.ObterNumeros(cel.NUMERO),
                    Tipo = TipoTelefone.Celular
                });
            }

            var com = ret.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoAutorizador.TipoTelefone.FONE_COMERCIAL1);
            if (com != null && !string.IsNullOrEmpty(com.NUMERO))
            {
                cli.Telefones.Add(new Telefone
                {
                    DDD = com.DDD,
                    Numero = (int)Common.ObterNumeros(com.NUMERO),
                    Tipo = TipoTelefone.Comercial
                });
            }

            var rec = ret.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoAutorizador.TipoTelefone.FONE_RECADO);
            if (rec != null && rec.NUMERO != null)
            {
                cli.Telefones.Add(new Telefone
                {
                    DDD = rec.DDD,
                    Numero = (int)Common.ObterNumeros(rec.NUMERO),
                    Tipo = TipoTelefone.Recado
                });
            }
            return cli;
        }
        public Cliente ConsultarCliente(string Contrato)
        {
            wsFuncaoAutorizador.WSAutorizadorSoapClient funcao = new wsFuncaoAutorizador.WSAutorizadorSoapClient();

            wsFuncaoAutorizador.Autenticacao aut = AutenticarAutorizador();

            wsFuncaoAutorizador.OutDadoCadastral ret = funcao.ConsultarClienteNumeroContrato(aut, Contrato);

            if (ret.STATUS_CONSULTA.CODIGO == wsFuncaoAutorizador.TipoStatus.ERRO)
            {
                //return null;
            }

            var cliente = new Cliente
            {
                Nome = ret.NOME,
                Documento = Common.ObterNumeros(ret.CPF_CNPJ),
                PessoaTipo = ret.TIPO_PESSOA == wsFuncaoAutorizador.TipoPessoa.FISICA ? "F" : "J"
            };
            return cliente;
        }
        #endregion CLIENTE

        #region OPERAÇÃO
        public List<OperacaoCredito> ObterOperacoes(string contrato, Int64 documento)
        {
            var operacoes = new List<OperacaoCredito>();
            var cpf = Common.FormataDocumento(documento);

            var retorno = _wsGv.ConsultarDadosConsolidados(new ConsultarDadosConsolidadosRequest
            {
                Autenticacao = AutenticarGV(),
                CodBackoffice = backOffice,
                CpfCnpj = cpf,
                NumeroContrato = contrato
            }).ConsultarDadosConsolidadosResult;

           // System.IO.File.WriteAllText(@"C:\Temp\operacao", JsonConvert.SerializeObject(retorno, Formatting.Indented));


           Parallel.ForEach(retorno.DadosConsolidados.ToList(), (operacao) =>
           {
               operacoes.Add(MontaOperacao(operacao));
           });

            Parallel.ForEach(operacoes, (operacao) =>
            {

                if (operacao.StatusDaOperacao == OperacaoCreditoStatus.EmDia || operacao.StatusDaOperacao == OperacaoCreditoStatus.Atrasada || operacao.StatusDaOperacao == OperacaoCreditoStatus.Quitada) return;
                var Cobradora = ObterCobradoraCyber(Convert.ToInt64(operacao.Cliente.Documento), operacao.Contrato);
                if (Cobradora != null)
                {
                    operacao.Cobradora = Cobradora;
                }
                operacao.HabRenegocie = _renegocieRepository.HabilitaRenegocie(operacao.Contrato);
            });
            return operacoes;
        }

        public OperacaoCredito ObterOperacao(string contrato, Int64 documento)
        {
            var operacaoServico = new OperacaoCredito();

            var retorno = _wsGv.ConsultarDadosConsolidados(new ConsultarDadosConsolidadosRequest
            {
                Autenticacao = AutenticarGV(),
                CodBackoffice = backOffice,
                CpfCnpj = string.Empty,
                NumeroContrato = contrato
            }).ConsultarDadosConsolidadosResult;

          //  System.IO.File.WriteAllText(@"C:\Temp\operacao", JsonConvert.SerializeObject(retorno, Formatting.Indented));

            var operacao = retorno.DadosConsolidados[0];

            if (operacao != null)
            {
                if (retorno.MensagemErro != null && retorno.MensagemErro.Contains("Input string"))
                {
                    retorno.MensagemErro = string.Empty;
                }

                if (operacao.DadosCadastral.MensagemErro != null && operacao.DadosCadastral.MensagemErro.ToUpper().Contains("CLIENTE NÃO ENCONTRADO"))
                {
                    return null;
                }
                else
                {
                    if (!string.IsNullOrEmpty(retorno.MensagemErro))
                    {
                        throw new FuncaoServiceException(string.Format("{0}", retorno.MensagemErro));
                    }
                }

                operacaoServico.Cliente = ObterClienteConsolidado(operacao); // CHAMADA

                var retOp = operacao.DadosDaOperacao;

                if (retOp != null)
                {
                    operacaoServico.Origem = Origens.Funcao;
                    operacaoServico.Contrato = retOp.NUMERO_OPERACAO;
                    operacaoServico.CodigoProduto = retOp.DADOS_OPERACAO.CODIGO_PRODUTO;
                    operacaoServico.QuantidadeParcelas = retOp.DADOS_OPERACAO.PLANO;
                    operacaoServico.StatusContrato = operacao.DadosConsultaContratoParcelas.CONTRATO.Situacao;

                    if (retOp.DADOS_OPERACAO.FORMA_PGTO == "B") operacaoServico.FormaLiquidacao = OperacaoLiquidacaoTipos.Boleto;



                    var parcelasCtt = ObterParcelasConsolidado(operacao);
                    if (parcelasCtt != null)
                    {
                        parcelasCtt.ToList().ForEach(r => r.Plano = operacaoServico.QuantidadeParcelas);
                        operacaoServico.Parcelas = parcelasCtt;
                    }

                    if (operacao.DadosConsultaContratoParcelas != null)
                    {
                        if (operacao.DadosConsultaContratoParcelas.BEM != null)
                            operacaoServico.BuscaApreensao = (operacao.DadosConsultaContratoParcelas.BEM.FirstOrDefault().FlagApreencao == "S");
                    }

                    if (operacao.DadosConsultarBloqueioOperacao.Any(t => t.CodMotivoBloqueio == 674 && t.StatusBloqueio == "A"))
                    {
                        operacaoServico.BuscaApreensao = true;
                    }


                    operacaoServico.Garantias = ObterGarantiasConsolidado(operacao, operacaoServico.BuscaApreensao);

                    operacaoServico.Loja = ObterLojaConsolidado(operacao);
                    if (operacaoServico.Loja != null)
                    {
                        operacaoServico.Loja.Regional = new Regional() { Nome = retOp.DADOS_OPERACAO.PROMOTORA.Remove(0, retOp.DADOS_OPERACAO.PROMOTORA.IndexOf(':') + 2) };
                    }

                    operacaoServico.ValorQuitacao = operacaoServico.Parcelas.Where(p => !p.Liquidado && !p.PagamentoParcial)
                    .Sum(p => p.ValorPrincipal + p.ValorAcrescimos - p.ValorDescontos);
                    operacaoServico.Acordos = ObterAcordosConsolidado(operacao);
                    operacaoServico.Fluxo = ObterFluxo(operacaoServico.Parcelas);
                    operacaoServico.Ocorrencias = ObterOcorrenciasConsolidado(operacao);
                    var bloqueios = ConsultarBloqueioConsolidado(operacao);

                    if (bloqueios != null)
                    {
                        if (operacaoServico.Ocorrencias == null)
                            operacaoServico.Ocorrencias = bloqueios;
                        else
                            operacaoServico.Ocorrencias.AddRange(bloqueios.ToList());
                    }
                    operacaoServico.Operacao = "veiculo";

                    operacaoServico.Cobradora = ObterCobradoraCyber(Convert.ToInt64(operacaoServico.Cliente.Documento), operacaoServico.Contrato);

                    operacaoServico.Empresa = new Empresa { Codigo = "001" };
                    operacaoServico.Empresa.Atributos.Add("Código na origem", "001");
                }
            }
            operacaoServico.HabRenegocie =_renegocieRepository.HabilitaRenegocie(operacaoServico.Contrato);
            return operacaoServico;
        }

        public OperacaoCredito ObterParcelasAcordo(string Contrato)
        {
            var ret = _wsCDC.ConsultaContratoParcelas(new ConsultaContratoParcelasRequest
            {
                Autenticacao = AutenticarCDC(),
                pInConsultaContratoParcelas = new wsFuncaoVeiculos.InConsultaContratoParcelas { NUMERO_OPERACAO = Contrato }
            }).ConsultaContratoParcelasResult;


            if (ret.STATUS.CODIGO == wsFuncaoVeiculos.TipoStatus.ERRO) return null;

            var contrato = new OperacaoCredito();
            var parcelas = new List<Parcela>();

            ret.PARCELAS.OrderBy(p => p.NumeroParcela).ToList().ForEach(o =>
            {
                var parcela = new Parcela();

                parcela.DataPagamento = o.DataPagamento;
                parcela.Liquidado = o.SituacaoParcela == "L";
                parcela.DataVencimento = o.Vencimento;
                parcela.NumeroParcela = Convert.ToInt32(o.NumeroParcela);
                if (o.ValodCurva > o.ValorPMT)
                    parcela.ValorAcrescimos = (decimal)(o.ValodCurva - o.ValorPMT);
                else if (o.ValorPago > o.ValorPMT)
                    parcela.ValorAcrescimos = (decimal)(o.ValorPago - o.ValorPMT);

                if (!parcela.Liquidado && o.ValorPMT > o.ValodCurva)
                    parcela.ValorDescontos = (decimal)(o.ValorPMT - o.ValodCurva);
                else if (parcela.Liquidado && o.ValorPMT > o.ValorPago)
                    parcela.ValorDescontos = (decimal)(o.ValorPMT - o.ValorPago);

                parcela.Valor = (decimal)o.ValorPMT;

                parcelas.Add(parcela);
            });

            contrato.Parcelas = parcelas;

            return contrato;
        }
        #endregion

        #region CONTRATOS
        public List<Contrato> ObterContratos(Int64 Documento)
        {
            var In = new wsFuncaoVeiculos.InObterContratosCPF
            {
                CPF_CNPJ_CLIENTE = Common.FormataDocumento(Documento),
                DATA_REFERENCIA = Common.DataReferencia
            };
            var ret =
                _wsCDC.ObterContratosCPF(new ObterContratosCPFRequest
                {
                    Autenticacao = AutenticarCDC(),
                    OBTER_CONTRATOS_CPF = In
                }).RETORNO_OBTER_CONTRATOS_CPF;


            if (ret.STATUS.CODIGO == wsFuncaoVeiculos.TipoStatus.ERRO)
            {
                In.CPF_CNPJ_CLIENTE = Common.FormataDocumento(Documento);
                In.DATA_REFERENCIA = Common.DataReferencia;
            }

            var contratos = new List<Contrato>();

            ret.CONTRATOS.ToList().ForEach(o =>
            {
                var contrato = new Contrato
                {
                    Origem = Origens.Funcao,
                    InicioAtendimento = o.DATA_INCLUSAO,
                    EmpresaNome = o.NOME_EMPRESA,
                    NumeroContrato = o.NUMERO_OPERACAO,
                    Parcelas = o.QTD_PARCELAS
                };

                var operacao = ObterParcelasAcordo(contrato.NumeroContrato);

                if (operacao != null)
                {
                    if (operacao.Parcelas != null)
                        contrato.ParcelasAbertas = (operacao.Parcelas.Count - operacao.Parcelas.Count(t => t.Liquidado));
                    contrato.SaldoDevedor = operacao.ValorQuitacao;
                }
                contrato.Vencimento = o.DATA_VCTO_CONTRATO;
                contrato.ClienteNome = o.NOME_CLIENTE;
                contrato.Documento = Documento;
                contrato.InicioAtendimento = o.DATA_INCLUSAO;
                contrato.Liquidada = o.SITUACAO_CONTRATO[0];
                contrato.Atraso = o.SITUACAO_CONTRATO[0] == 'A' ? "ABERTO" : "S";
                contrato.ProdutoCodigo = o.CODIGO_PRODUTO;
                contrato.TipoOperacao = "VEICULO";

                contratos.Add(contrato);
            });

            return contratos;
        }
        #endregion

        #region BOLETOS
        public byte[] GerarBoletoAcordo(string acordo, string contrato, int parcelaIni, int parcelaFim)
        {

            var protocolo = IniciarProtocoloAtendimento(mesa, backOffice, contrato);
            var In = new wsFuncaoGV.EntradaEmitirBoletosAcordo
            {
                NumeroAcordo = acordo,
                IdProtocolo = protocolo,
                ParcelaIni = parcelaIni,
                ParcelaFim = parcelaFim
            };


            var ret = _wsGv.EmitirBoletosAcordo(new EmitirBoletosAcordoRequest
            {
                Autenticacao = AutenticarGV(),
                pEntradaEmitirBoletosAcordo = In
            }).EmitirBoletosAcordoResult;

            FecharProtocoloAtendimento(protocolo);

            return ret.Arquivo;
        }

        public byte[] GerarBoletoParcela(string Contrato, int parcela)
        {
            byte[] boletoBase64 = null;
            var objectRequest = new wsFuncaoVeiculos.InGerar2ViaBoleto
            {
                NUMERO_OPERACAO = Contrato,
                NUMERO_PARCELA = parcela.ToString().PadLeft(3, '0')
            };

            var boleto = _wsCDC.Gerar2ViaBoleto(new Gerar2ViaBoletoRequest
            {
                Autenticacao = AutenticarCDC(),
                GERAR_2VIA_BOLETO = objectRequest
            }).RETORNO_2VIA_BOLETOS;
            if (string.IsNullOrEmpty(boleto.BOLETO)) return null;

            boletoBase64 = Convert.FromBase64String(boleto.BOLETO);
            return boletoBase64;
        }

        public byte[] GerarBoletoParcela(string Contrato, int parcelaInicial, int parcelaFinal)
        {
            var objectRequest = new wsFuncaoVeiculos.InGerar2ViaCarne
            {
                NUMERO_OPERACAO = Contrato,
                PARCELA_INICIAL = parcelaInicial.ToString().PadLeft(3, '0'),
                PARCELA_FINAL = parcelaFinal.ToString().PadLeft(3, '0')
            };
            var boleto = _wsCDC.Gerar2ViaCarne(new Gerar2ViaCarneRequest
            {
                Autenticacao = AutenticarCDC(),
                GERAR_2VIA_CARNE = objectRequest
            }).RETORNO_2VIA_CARNE;
            if (!string.IsNullOrEmpty(boleto.MENSAGEM_ERRO)) throw new FuncaoServiceException(string.Format("ERRO EM Gerar2ViaCarne {0}", boleto.MENSAGEM_ERRO));
            var boletoBase64 = Convert.FromBase64String(boleto.BOLETO);
            return boletoBase64;
        }
        #endregion

        #region PARCELAS

        public List<Parcela> ObterParcelas(string Contrato, DateTime? Data = null)
        {
            var In = new InConsultarSaldoParcelas
            {
                NUMERO_CONTRATO = Contrato,
                DATA_REFERENCIA = Data.HasValue ? Data.Value : Common.DataReferencia
            };

            var ret = _wsCDC.ConsultarSaldoParcelas(new ConsultarSaldoParcelasRequest
            {
                Autenticacao = AutenticarCDC(),
                CONSULTAR_PARCELAS = In
            }).RETORNO_CONSULTA_PARCELAS;

            if (ret.STATUS.CODIGO == TipoStatus.ERRO) return null;

            var parcelas = new List<Parcela>();
            
            ret.PARCELAS.ToList().ForEach(o =>
            {
                var parcela = new Parcela
                {
                    NumeroParcela = Convert.ToInt32(o.NUMERO_PARCELA),
                    DataPagamento = o.DATA_BAIXA
                };
                parcela.Liquidado = parcela.DataPagamento > DateTime.MinValue;
                parcela.DataVencimento = o.DATA_VENCIMENTO;
                parcela.SaldoPagar = (decimal)o.SALDO_LIQUIDACAO;
                parcela.Despesas = (decimal)o.VALOR_DESPESAS;
                parcela.ValorJuros = (decimal)o.VALOR_JUROS;
                parcela.ValorMora = (decimal)o.VALOR_MORA;
                parcela.ValorMulta = (decimal)o.VALOR_MULTA;
                parcela.Valor = (decimal)o.VALOR_PARCELA;
                parcela.ValorPrincipal = (decimal)o.VALOR_PARCELA;
                parcela.ValorAcrescimos = parcela.ValorMora + parcela.ValorMulta + (decimal)o.VALOR_IOC + (decimal)o.VALOR_DESPESAS;

                if (!parcela.Liquidado && parcela.DiasAtraso == 0)
                {
                    parcela.ValorDescontos = parcela.Valor - (decimal)o.SALDO_LIQUIDACAO;
                    if (parcela.ValorAcrescimos > 0)
                    {
                        parcela.ValorDescontos = parcela.Valor - (Convert.ToDecimal(o.SALDO_LIQUIDACAO) - parcela.ValorAcrescimos);
                    }
                }


                if (!parcela.Liquidado && parcela.DiasAtraso == 0 && Data.HasValue)
                {
                    DateTime dt = Data.GetValueOrDefault();
                    if (dt > parcela.DataVencimento)
                        parcela.ValorDescontos = decimal.Zero;
                }
                parcelas.Add(parcela);
            });
            return parcelas;
        }
        #endregion

        #region ACORDOS
        public string CancelarAcordo(string Acordo, string contrato)
        {

            var protocolo = IniciarProtocoloAtendimento(mesa, backOffice, contrato);
            var funcao = new WsGVSoapClient();

            var aut = AutenticarGV();


            var ret = funcao.CancelarAcordos(aut, protocolo, Acordo, "", "");

            FecharProtocoloAtendimento(protocolo);

            return ret.CodErro > 0 ? ret.MensagemErro : "true";
        }

        //EFETUA CADASTRARACORDO
        public string EfetuarAcordo(string Contrato, DateTime Pagamento, List<Parcela> parcelas, bool desconto)
        {
            var operacaoIn = new wsFuncaoAutorizadorAcordos.InDadosAcordo
            {
                DATABASE = DateTime.Now,
                DATA_1_VENCIMENTO = Pagamento,
                QTDPARCELAS = 1,
                CODIGOPRODUTO = "000002",
                VALORPROPOSTO = (double)parcelas.Sum(p => p.Valor - p.ValorDescontos + p.ValorAcrescimos),
                FLUXOPARCELAS = new wsFuncaoAutorizadorAcordos.InParcelaAcordo[1]
            };

            var parcelasAcordadas = new wsFuncaoAutorizadorAcordos.InParcelaAcordada[parcelas.Count];

            for (var i = 0; i < parcelas.Count; i++)
            {
                var fluxo = new wsFuncaoAutorizadorAcordos.InParcelaAcordo
                {
                    VALORPARCELA = (double)(parcelas[i].Valor - parcelas[i].ValorDescontos + parcelas[i].ValorAcrescimos),
                    NRPARCELA = parcelas[i].NumeroParcela,
                    VENCIMENTO = Pagamento
                };
                var parcelasAcordada = new wsFuncaoAutorizadorAcordos.InParcelaAcordada
                {
                    NRPARCELA = fluxo.NRPARCELA.ToString()
                };
                parcelasAcordadas[i] = parcelasAcordada;
            }

            operacaoIn.OPERACOESACORDADAS = new wsFuncaoAutorizadorAcordos.InOperacoesAcordadas()
            {
                OPERACAO = new wsFuncaoAutorizadorAcordos.InOperacaoAcordada[]
                {
                    new wsFuncaoAutorizadorAcordos.InOperacaoAcordada(){
                        CODIGOBACKOFFICE = backOffice,
                        CODIGOINSTALACAO = 2,
                        NUMEROOPERACAO = Contrato,
                        PARCELAS = new wsFuncaoAutorizadorAcordos.InParcelasAcordadas() { PARCELA = parcelasAcordadas }                        
                    }
                }
            };
            operacaoIn.VALIDARPOLITICA = wsFuncaoAutorizadorAcordos.TipoSimNao.SIM;
            operacaoIn.TIPO_SISTEMA = wsFuncaoAutorizadorAcordos.TipoSistema.VEICULO;
           
            var ret = _wsAutorizadorAcordos.CadastrarAcordo(new wsFuncaoAutorizadorAcordos.CadastrarAcordoRequest
            {
                Autenticacao = AutenticarAutorizadorAcordos(),
                DADOSACORDO = operacaoIn
            }).PROPOSTA;

            if (string.IsNullOrEmpty(ret.NUMERO_PROPOSTA))
            {
                throw new FuncaoServiceException(string.Format("ERRO AO CADASTRAR ACORDO {0}", ret.MENSAGEMERRO));
            } 

            return ret.NUMERO_PROPOSTA;
        }

        public string EfetuarAcordoRenegocie(string Contrato, DateTime Pagamento, List<Parcela> parcelas, string codProduto, int qtdeParcelas = 1)
        {
            var operacaoIn = new wsFuncaoAutorizadorAcordos.InDadosAcordo
            {
                DATABASE = DateTime.Now,
                DATA_1_VENCIMENTO = Pagamento,
                QTDPARCELAS = qtdeParcelas,
                CODIGOPRODUTO = codProduto,
                VALORPROPOSTO = (double)parcelas.Sum(p => p.Valor),
                FLUXOPARCELAS = new wsFuncaoAutorizadorAcordos.InParcelaAcordo[1]
            };

            var parcelasAcordadas = new wsFuncaoAutorizadorAcordos.InParcelaAcordada[parcelas.Count];

            for (var i = 0; i < parcelas.Count; i++)
            {
                var fluxo = new wsFuncaoAutorizadorAcordos.InParcelaAcordo
                {
                    VALORPARCELA = (double)parcelas[i].Valor,
                    NRPARCELA = parcelas[i].NumeroParcela,
                    VENCIMENTO = Pagamento
                };
                var parcelasAcordada = new wsFuncaoAutorizadorAcordos.InParcelaAcordada
                {
                    NRPARCELA = fluxo.NRPARCELA.ToString()
                };
                parcelasAcordadas[i] = parcelasAcordada;
            }

            operacaoIn.OPERACOESACORDADAS = new wsFuncaoAutorizadorAcordos.InOperacoesAcordadas()
            {
                OPERACAO = new wsFuncaoAutorizadorAcordos.InOperacaoAcordada[]
                {
                    new wsFuncaoAutorizadorAcordos.InOperacaoAcordada(){
                        CODIGOBACKOFFICE = backOffice,
                        CODIGOINSTALACAO = 2,
                        NUMEROOPERACAO = Contrato,
                        PARCELAS = new wsFuncaoAutorizadorAcordos.InParcelasAcordadas() { PARCELA = parcelasAcordadas }                        
                    }
                }
            };
            operacaoIn.VALIDARPOLITICA = wsFuncaoAutorizadorAcordos.TipoSimNao.SIM;
            operacaoIn.TIPO_SISTEMA = wsFuncaoAutorizadorAcordos.TipoSistema.VEICULO;

            var ret = _wsAutorizadorAcordos.CadastrarAcordo(new wsFuncaoAutorizadorAcordos.CadastrarAcordoRequest
            {
                Autenticacao = AutenticarAutorizadorAcordos(),
                DADOSACORDO = operacaoIn
            }).PROPOSTA;

            if (!string.IsNullOrEmpty(ret.MENSAGEMERRO)) throw new FuncaoServiceException(string.Format("ERRO AO CADASTRAR ACORDO {0}", ret.MENSAGEMERRO));

            return ret.NUMERO_PROPOSTA;
        }

        public Acordo SimularAcordo(String Contrato, DateTime Pagamento, List<DateTime> DatasVencimento)
        {
            var acordo = new Acordo {DataVencimento = Pagamento};
            
            var parcelasTemp = ObterParcelas(Contrato, Pagamento);

            if (parcelasTemp == null) return null;

            var parcelas = parcelasTemp.Where(p => !p.Liquidado).ToList();

            parcelas.ForEach(parcela =>
            {
                DatasVencimento.ForEach(data =>
                {
                    if (data == parcela.DataVencimento)
                    {
                        acordo.Parcelas.Add(parcela);
                    }
                });
            });
            acordo.FlagPagamento = "2";
            return acordo;
        }
        
        public Acordo SimularAcordoRenegocie(AcordoRenegocie acordoRenegocie)
        {
            var acordo = new Acordo { DataVencimento = acordoRenegocie.DataPagamento };

            var parcelasTemp = ObterParcelas(acordoRenegocie.Contrato, acordoRenegocie.DataPagamento);

            if (parcelasTemp == null) return null;

            var parcelas = parcelasTemp.Where(p => !p.Liquidado).ToList();

            var parcelasCobranca = parcelas.Where(t => t.Status == ParcelaStatus.Atrasado && acordoRenegocie.DatasVencimento.Contains(t.DataVencimento)).ToList();
            if (parcelasCobranca.Count > 0)
            {
                var beforeSet2017 = parcelasTemp.Any(t => t.NumeroParcela == 1 && t.DataVencimento < new DateTime(2017, 09, 01));
                var maxDias = parcelasCobranca.Max(t => t.DiasAtraso);
                var regras = _cobrancaAdapter.ObterRegras(acordoRenegocie.CodigoProduto, parcelasCobranca.Count, maxDias, beforeSet2017);
                parcelasCobranca.ForEach(parcelaCob =>
                {
                    var valor = parcelaCob.ValorAtual;
                    valor -= (regras[0].ValorPercMaximoDescontoMora / 100) * parcelaCob.ValorMora;
                    valor -= (regras[0].ValorPercMaximoDescontoMulta / 100) * parcelaCob.ValorMulta;
                    valor -= (regras[0].ValorPercMaximoDescontoParcela / 100) * parcelaCob.Valor;
                    valor += 1.0m;
                    parcelaCob.ValorDescontos = Math.Round(parcelaCob.ValorAtual - valor, 2);
                });
            }
            parcelas.ForEach(parcela =>
            {
                acordoRenegocie.DatasVencimento.ForEach(data =>
                {
                    if (data == parcela.DataVencimento)
                    {
                        acordo.Parcelas.Add(parcela);
                    }
                });
            });
            acordo.FlagPagamento = "2";
            return acordo;
        }

        public List<Acordo> ConsultarAcordo(string Contrato)
        {
            var ret = _wsGv.ObterAcordos(new ObterAcordosRequest
            {
                Autenticacao = AutenticarGV(),
                pNrContrato = Contrato,
                pSituacao = wsFuncaoGV.SituacaoContrato.Todos
            }).ObterAcordosResult;
            if (!string.IsNullOrEmpty(ret[0].MensagemErro))
                return null;

            var acordos = new List<Acordo>();
            ret.ToList().ForEach(f =>
            {
                if (f.ObjAcordo.NumeroAcordo == null)
                    return;


                var acordo = new Acordo();
                acordo.ContratoInterno = f.ObjAcordo.NumeroAcordo;
                acordo.DataInclusao = Convert.ToDateTime(f.ObjAcordo.DataBase, new CultureInfo("pt-BR"));

                acordo.DataPagamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")) == new DateTime(2079, 2, 2).Date ? DateTime.MinValue : Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));

                acordo.FlagPagamento = "2";
                acordo.DataVencimento = Convert.ToDateTime(f.ObjAcordo.objParcelasAcordo[0].DtVencimento, new CultureInfo("pt-BR"));

                var parcelas = ObterParcelas(Contrato, acordo.DataInclusao);

                f.ObjAcordo.objContratosNegociados.ToList().ForEach(p =>
                {
                    var parcela = new Parcela { NumeroParcela = Convert.ToInt32(p.NumeroParcela) };

                    var pa = parcelas.FirstOrDefault(fd => fd.NumeroParcela == parcela.NumeroParcela);

                    var valorAcordo = Convert.ToDecimal(pa.ValorAtual, new CultureInfo("pt-BR"));
                    var valor = Convert.ToDecimal(pa.Valor, new CultureInfo("pt-BR"));

                    parcela.DataVencimento = Convert.ToDateTime(pa.DataVencimento, new CultureInfo("pt-BR"));
                    parcela.Valor = valor;
                    if (valorAcordo > valor)
                        parcela.ValorAcrescimos = valorAcordo - valor;

                    parcela.ValorCP = parcela.ValorAcrescimos;

                    if (valor > valorAcordo)
                    {
                        parcela.ValorDescontos = valor - valorAcordo;
                        parcela.ValorDescontoParcela = parcela.ValorDescontos;
                    }
                    acordo.Parcelas.Add(parcela);
                });

                switch (f.ObjAcordo.Situacao[0])
                {
                    case 'A':
                        break;

                    case 'L':
                        acordo.Liquidado = true;
                        break;

                    case 'C':
                        acordo.DataCancelamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));
                        break;
                }

                acordos.Add(acordo);
            });

            return acordos;
        }

        public List<string> ObterLinhaDigitavelAcordo(string Contrato, bool apenasAcordosAtivos)
        {
            var acordos = _wsGv.ObterAcordos(new ObterAcordosRequest
           {
               Autenticacao = AutenticarGV(),
               pNrContrato = Contrato,
               pSituacao = wsFuncaoGV.SituacaoContrato.Andamento
           }).ObterAcordosResult;

            if (!string.IsNullOrEmpty(acordos[0].MensagemErro)) return null;


            var linhas = new List<string>();
            acordos.ToList().ForEach(acordo =>
            {
                acordo.ObjAcordo.objParcelasAcordo.ToList().ForEach(parcela =>
                {
                    linhas.Add(parcela.LinhaDigitavel);
                });
            });
            return linhas;
        }

        public List<string> ObterAcordoSms(string Contrato, bool apenasAcordosAtivos)
        {

            var acordos = _wsGv.ObterAcordos(new ObterAcordosRequest
            {
                Autenticacao = AutenticarGV(),
                pNrContrato = Contrato,
                pSituacao = wsFuncaoGV.SituacaoContrato.Andamento
            }).ObterAcordosResult;

            if (!string.IsNullOrEmpty(acordos[0].MensagemErro)) return null;


            var linhas = new List<string>();
            acordos.ToList().ForEach(acordo =>
            {
                acordo.ObjAcordo.objParcelasAcordo.ToList().ForEach(parcela =>
                {
                    linhas.Add(parcela.LinhaDigitavel);
                });
            });
            return linhas;
        }

        public List<Acordo> ConsultarAcordo(string Contrato,List<Parcela> parcelas, bool apenasAcordosAtivos)
        {
            var ret = _wsGv.ObterAcordos(new ObterAcordosRequest
            {
                Autenticacao = AutenticarGV(),
                pNrContrato = Contrato,
                pSituacao = wsFuncaoGV.SituacaoContrato.Andamento
            }).ObterAcordosResult;
            

            if (!string.IsNullOrEmpty(ret[0].MensagemErro)) throw new Exception("[ERRO AO CONSULTAR ACORDO FUNÇÃO]" + ret[0].MensagemErro);

            var acordos = new List<Acordo>();
            ret.ToList().ForEach(f =>
            {
                if (f.ObjAcordo.NumeroAcordo == null) throw new Exception("[ERRO AO CONSULTAR ACORDO FUNÇÃO PROPRIEDADE NumeroAcordo ESTA NULL]");

                if (f.ObjAcordo.PDFBoleto == null)
                {
                    var firstOrDefault = f.ObjAcordo.objParcelasAcordo.FirstOrDefault();
                    if (firstOrDefault != null)
                    {
                        var erroRegistro = firstOrDefault.ErroRegistro;
                        throw new Exception(string.Format("[ERRO AO CONSULTAR ACORDO FUNÇÃO PROPRIEDADE PDFBoleto ESTA NULL] {0}", erroRegistro));
                    }
                }

                var acordo = new Acordo
                {
                    ContratoInterno = f.ObjAcordo.NumeroAcordo,
                    DataInclusao = Convert.ToDateTime(f.ObjAcordo.DataBase, new CultureInfo("pt-BR")),
                    DataPagamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")) ==
                                    new DateTime(2079, 2, 2).Date
                        ? DateTime.MinValue
                        : Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")),
                    FlagPagamento = "2",
                    DataVencimento = Convert.ToDateTime(f.ObjAcordo.objParcelasAcordo[0].DtVencimento, new CultureInfo("pt-BR")),
                    PDF = f.ObjAcordo.PDFBoleto!=null? Convert.ToBase64String(f.ObjAcordo.PDFBoleto):null
                };

               // var parcelas = ObterParcelas(Contrato, acordo.DataInclusao);

                f.ObjAcordo.objParcelasAcordo.ToList().ForEach(r =>
                {
                    if (r.LinhaDigitavel != null) acordo.LinhaDigitavel = r.LinhaDigitavel;
                });


                f.ObjAcordo.objContratosNegociados.ToList().ForEach(p =>
                {

                    var parcela = new Parcela { NumeroParcela = Convert.ToInt32(p.NumeroParcela) };
                    var pa = parcelas.FirstOrDefault(fd => fd.NumeroParcela == parcela.NumeroParcela);


                    var valorAcordo = Convert.ToDecimal(pa.ValorAtual, new CultureInfo("pt-BR"));
                    var valor = Convert.ToDecimal(pa.Valor, new CultureInfo("pt-BR"));

                    parcela.DataVencimento = Convert.ToDateTime(pa.DataVencimento, new CultureInfo("pt-BR"));
                    parcela.Valor = valor;
                    if (valorAcordo > valor)
                        parcela.ValorAcrescimos = valorAcordo - valor;

                    parcela.ValorCP = parcela.ValorAcrescimos;

                    if (valor > valorAcordo)
                    {
                        parcela.ValorDescontos = valor - valorAcordo;
                        parcela.ValorDescontoParcela = parcela.ValorDescontos;
                    }
                    acordo.Parcelas.Add(parcela);
                });

                switch (f.ObjAcordo.Situacao[0])
                {
                    case 'A':
                        break;

                    case 'L':
                        acordo.Liquidado = true;
                        break;

                    case 'C':
                        acordo.DataCancelamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));
                        break;
                }

                acordos.Add(acordo);
            });
            return acordos;
        }

        // OBTER ACORDOS EM ANDAMENTO 
        public Acordo ConsultarAcordo(string Contrato,string NumAcordo, List<Parcela> parcelas, bool WithPDF)
        {
            var ret = _wsGv.ObterAcordos(new ObterAcordosRequest
            {
                Autenticacao = AutenticarGV(),
                pNrContrato = Contrato,
                pSituacao = wsFuncaoGV.SituacaoContrato.Andamento
            }).ObterAcordosResult;

            var acordoFuncao = ret.ToList().FirstOrDefault(t => t.ObjAcordo.NumeroAcordo == NumAcordo);

            if (acordoFuncao == null) return null;
            
                if (!string.IsNullOrEmpty(acordoFuncao.MensagemErro)) throw new Exception("[ERRO AO CONSULTAR ACORDO FUNÇÃO]" + acordoFuncao.MensagemErro);
                if (acordoFuncao.ObjAcordo.NumeroAcordo == null) throw new Exception("[ERRO AO CONSULTAR ACORDO FUNÇÃO PROPRIEDADE NumeroAcordo ESTA NULL]");

            var acordo = new Acordo
                {
                    ContratoInterno = acordoFuncao.ObjAcordo.NumeroAcordo,
                    DataInclusao = Convert.ToDateTime(acordoFuncao.ObjAcordo.DataBase, new CultureInfo("pt-BR")),
                    DataPagamento = Convert.ToDateTime(acordoFuncao.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")) ==
                                    new DateTime(2079, 2, 2).Date
                        ? DateTime.MinValue
                        : Convert.ToDateTime(acordoFuncao.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")),
                    FlagPagamento = "2",
                    DataVencimento = Convert.ToDateTime(acordoFuncao.ObjAcordo.objParcelasAcordo[0].DtVencimento, new CultureInfo("pt-BR")),
                    PDF = acordoFuncao.ObjAcordo.PDFBoleto != null ? Convert.ToBase64String(acordoFuncao.ObjAcordo.PDFBoleto) : null
                };
                acordoFuncao.ObjAcordo.objParcelasAcordo.ToList().ForEach(r =>
                {
                    if (r.LinhaDigitavel != null) acordo.LinhaDigitavel = r.LinhaDigitavel;
                });

                acordoFuncao.ObjAcordo.objContratosNegociados.ToList().ForEach(p =>
                {

                    var parcela = new Parcela { NumeroParcela = Convert.ToInt32(p.NumeroParcela) };
                    var pa = parcelas.FirstOrDefault(fd => fd.NumeroParcela == parcela.NumeroParcela);


                    var valorAcordo = Convert.ToDecimal(pa.ValorAtual, new CultureInfo("pt-BR"));
                    var valor = Convert.ToDecimal(pa.Valor, new CultureInfo("pt-BR"));

                    parcela.DataVencimento = Convert.ToDateTime(pa.DataVencimento, new CultureInfo("pt-BR"));
                    parcela.Valor = valor;
                    if (valorAcordo > valor)
                        parcela.ValorAcrescimos = valorAcordo - valor;

                    parcela.ValorCP = parcela.ValorAcrescimos;

                    if (valor > valorAcordo)
                    {
                        parcela.ValorDescontos = valor - valorAcordo;
                        parcela.ValorDescontoParcela = parcela.ValorDescontos;
                    }
                    acordo.Parcelas.Add(parcela);
                });
                switch (acordoFuncao.ObjAcordo.Situacao[0])
                {
                    case 'A':
                        break;

                    case 'L':
                        acordo.Liquidado = true;
                        break;

                    case 'C':
                        acordo.DataCancelamento = Convert.ToDateTime(acordoFuncao.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));
                        break;
                }

                if (WithPDF)
                {
                    if (acordoFuncao.ObjAcordo.PDFBoleto == null)
                    {
                        var firstOrDefault = acordoFuncao.ObjAcordo.objParcelasAcordo.FirstOrDefault();
                        if (firstOrDefault != null)
                        {
                            var erroRegistro = firstOrDefault.ErroRegistro;
                            throw new Exception(string.Format("[ERRO AO CONSULTAR ACORDO FUNÇÃO PROPRIEDADE PDFBoleto ESTA NULL] {0}",erroRegistro));
                        }
                    }
                    acordo.PDF = acordoFuncao.ObjAcordo.PDFBoleto != null ? Convert.ToBase64String(acordoFuncao.ObjAcordo.PDFBoleto) : null;
                }
                return acordo;
        }


        public List<Acordo> ConsultarAcordo(string Contrato, bool apenasAcordosAtivos)
        {
            var ret = _wsGv.ObterAcordos(new ObterAcordosRequest
            {
                Autenticacao = AutenticarGV(),
                pNrContrato = Contrato,
                pSituacao = wsFuncaoGV.SituacaoContrato.Andamento
            }).ObterAcordosResult;

            if (!string.IsNullOrEmpty(ret[0].MensagemErro)) throw new Exception("[ERRO AO CONSULTAR ACORDO FUNÇÃO]" + ret[0].MensagemErro);

            var acordos = new List<Acordo>();
            ret.ToList().ForEach(f =>
            {
                if (f.ObjAcordo.NumeroAcordo == null) throw new Exception("[ERRO AO CONSULTAR ACORDO FUNÇÃO PROPRIEDADE NumeroAcordo ESTA NULL]");

                if (f.ObjAcordo.PDFBoleto == null)
                {
                    var firstOrDefault = f.ObjAcordo.objParcelasAcordo.FirstOrDefault();
                    if (firstOrDefault != null)
                    {
                        var erroRegistro = firstOrDefault.ErroRegistro;
                        throw new Exception(string.Format("[ERRO AO CONSULTAR ACORDO FUNÇÃO PROPRIEDADE PDFBoleto ESTA NULL] {0}", erroRegistro));
                    }
                }

                var acordo = new Acordo
                {
                    ContratoInterno = f.ObjAcordo.NumeroAcordo,
                    DataInclusao = Convert.ToDateTime(f.ObjAcordo.DataBase, new CultureInfo("pt-BR")),
                    DataPagamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")) ==
                                    new DateTime(2079, 2, 2).Date
                        ? DateTime.MinValue
                        : Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")),
                    FlagPagamento = "2",
                    DataVencimento = Convert.ToDateTime(f.ObjAcordo.objParcelasAcordo[0].DtVencimento, new CultureInfo("pt-BR")),
                    PDF = Convert.ToBase64String(f.ObjAcordo.PDFBoleto)
                };

                var parcelas = ObterParcelas(Contrato, acordo.DataInclusao);

                f.ObjAcordo.objParcelasAcordo.ToList().ForEach(r =>
                {
                    if (r.LinhaDigitavel != null) acordo.LinhaDigitavel = r.LinhaDigitavel;
                });


                f.ObjAcordo.objContratosNegociados.ToList().ForEach(p =>
                {

                    var parcela = new Parcela { NumeroParcela = Convert.ToInt32(p.NumeroParcela) };
                    var pa = parcelas.FirstOrDefault(fd => fd.NumeroParcela == parcela.NumeroParcela);


                    var valorAcordo = Convert.ToDecimal(pa.ValorAtual, new CultureInfo("pt-BR"));
                    var valor = Convert.ToDecimal(pa.Valor, new CultureInfo("pt-BR"));

                    parcela.DataVencimento = Convert.ToDateTime(pa.DataVencimento, new CultureInfo("pt-BR"));
                    parcela.Valor = valor;
                    if (valorAcordo > valor)
                        parcela.ValorAcrescimos = valorAcordo - valor;

                    parcela.ValorCP = parcela.ValorAcrescimos;

                    if (valor > valorAcordo)
                    {
                        parcela.ValorDescontos = valor - valorAcordo;
                        parcela.ValorDescontoParcela = parcela.ValorDescontos;
                    }
                    acordo.Parcelas.Add(parcela);
                });

                switch (f.ObjAcordo.Situacao[0])
                {
                    case 'A':
                        break;

                    case 'L':
                        acordo.Liquidado = true;
                        break;

                    case 'C':
                        acordo.DataCancelamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));
                        break;
                }

                acordos.Add(acordo);
            });
            return acordos;
        }

    
        #endregion

        public void Dispose()
        {
            var _wsGvdisposable = _wsGv as IDisposable;
            if (_wsGvdisposable != null) _wsGvdisposable.Dispose();

            var WsCDCSoapdisposable = _wsCDC as IDisposable;
            if (WsCDCSoapdisposable != null) WsCDCSoapdisposable.Dispose();

            var _wsAutorizadordisposable = _wsAutorizador as IDisposable;
            if (_wsAutorizadordisposable != null) _wsAutorizadordisposable.Dispose();

            var _wsAutorizadorAcordosdisposable = _wsAutorizadorAcordos as IDisposable;
            if (_wsAutorizadorAcordosdisposable != null) _wsAutorizadorAcordosdisposable.Dispose();

            GC.SuppressFinalize(this);
        }

        #region HELP_METHODS
        private wsFuncaoAutorizador.Autenticacao AutenticarAutorizador()
        {
            var token = new FI.GeraToken.Token(CodigoChaveFuncao, UsuarioFuncao, SenhaFuncao);
            token.GerarToken();

            var aut = new wsFuncaoAutorizador.Autenticacao
            {
                codigoAmbiente = 0,
                codigoChave = CodigoChaveFuncao,
                token = token.TokenBase64
            };

            return aut;
        }
        private wsFuncaoAutorizadorAcordos.Autenticacao AutenticarAutorizadorAcordos()
        {
            var token = new FI.GeraToken.Token(CodigoChaveFuncao, UsuarioFuncao, SenhaFuncao);
            token.GerarToken();

            var aut = new wsFuncaoAutorizadorAcordos.Autenticacao
            {
                codigoAmbiente = 0,
                codigoChave = CodigoChaveFuncao,
                token = token.TokenBase64
            };
            return aut;
        }
        private wsFuncaoVeiculos.Autenticacao AutenticarCDC()
        {
            var token = new FI.GeraToken.Token(CodigoChaveFuncao, UsuarioFuncao, SenhaFuncao);
            token.GerarToken();

            var aut = new wsFuncaoVeiculos.Autenticacao
            {
                codigoAmbiente = 0,
                codigoChave = CodigoChaveFuncao,
                token =  token.TokenBase64
            };

            return aut;
        }
        private wsFuncaoGV.Autenticacao AutenticarGV()
        {
            var token = new FI.GeraToken.Token(CodigoChaveFuncao, UsuarioFuncao, SenhaFuncao);
            token.GerarToken();

            var aut = new wsFuncaoGV.Autenticacao
            {
                CodigoChave = CodigoChaveFuncao,
                Token =  token.TokenBase64
            };
            return aut;
        }
        private string FormataDocumento(long Documento)
        {
            if (Documento.ToString().Length <= 11 && Common.ValidarCPF(Documento.ToString()))
                return Documento.ToString(@"000\.000\.000-00");

            return Documento.ToString(@"00\.000\.000\/0000-00");
        }
        private Cliente ConsultarClienteGV(string Contrato)
        {
            var protocolo = IniciarProtocoloAtendimento(mesa, backOffice, Contrato);
            var ret = _wsGv.ConsultarCliente(new ConsultarClienteRequest
            {
                Autenticacao = AutenticarGV(),
                pIdProtocolo = protocolo
            }).ConsultarClienteResult;
            FecharProtocoloAtendimento(protocolo);

            if (!string.IsNullOrEmpty(ret.MensagemErro)) return null;

            var cliente = new Cliente();
            var cli = ret.DadosClientes[0];

            cliente.Codigo = cli.DadosBasicos.IdCliente.ToString();
            return cliente;
        }
        private wsFuncaoAutorizadorAcordos.InDadosReferenciasPessoais PreencherDadosRerenciais(wsFuncaoGV.RetornoDadoCadastral retCli)
        {
            var refer = new wsFuncaoAutorizadorAcordos.InDadosReferenciasPessoais();
            try
            {

                if (retCli.DADOS_REFENCIAIS != null)
                {
                    refer.DADO_REF_PESSOAL = new wsFuncaoAutorizadorAcordos.InDadoReferenciaPessoal[retCli.DADOS_REFENCIAIS.DADO_REFERENCIAL.Count()];

                    for (int i = 0; i < retCli.DADOS_REFENCIAIS.DADO_REFERENCIAL.Count(); i++)
                    {
                        refer.DADO_REF_PESSOAL[i] = new wsFuncaoAutorizadorAcordos.InDadoReferenciaPessoal();
                        if (retCli.DADOS_REFENCIAIS.DADO_REFERENCIAL[i] != null)
                        {
                            refer.DADO_REF_PESSOAL[i].NOME = retCli.DADOS_REFENCIAIS.DADO_REFERENCIAL[i].NOME;
                            refer.DADO_REF_PESSOAL[i].TELEFONE = new wsFuncaoAutorizadorAcordos.InTelefone();
                            refer.DADO_REF_PESSOAL[i].TELEFONE.DDD = retCli.DADOS_REFENCIAIS.DADO_REFERENCIAL[i].DDD;
                            refer.DADO_REF_PESSOAL[i].TELEFONE.NUMERO = retCli.DADOS_REFENCIAIS.DADO_REFERENCIAL[i].TELEFONE;
                        }
                    }
                }
            }
            catch
            {
            }

            return refer;
        }
        private wsFuncaoAutorizadorAcordos.InDadosExperienciaFinanceira PreecherDadosFinanceiros(wsFuncaoGV.RetornoDadoCadastral retCli)
        {
            if (retCli.EXPERIENCIA_FINANCEIRAS == null)
                return null;

            var fin = new wsFuncaoAutorizadorAcordos.InDadosExperienciaFinanceira();
            fin.DADO_EXPERIENCIA_FINANCEIRA = new wsFuncaoAutorizadorAcordos.InDadoExperienciaFinanceira[retCli.EXPERIENCIA_FINANCEIRAS.EXPERIENCIA_FINANCEIRA.Count()];

            try
            {
                if (retCli.EXPERIENCIA_FINANCEIRAS != null)
                {
                    for (int i = 0; i < retCli.EXPERIENCIA_FINANCEIRAS.EXPERIENCIA_FINANCEIRA.Count(); i++)
                    {
                        var ex = retCli.EXPERIENCIA_FINANCEIRAS.EXPERIENCIA_FINANCEIRA[i];

                        if (!string.IsNullOrEmpty(ex.ANO_MODELO.Trim()))
                        {
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i] = new wsFuncaoAutorizadorAcordos.InDadoExperienciaFinanceira();
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].ANO_MODELO = Convert.ToInt32(ex.ANO_MODELO);
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].BANCO_FINANCEIRA = ex.BANCO_FINANCEIRA;
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].DESCRICAO_BEM = ex.DESCRICAO_BEM;
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].NUMERO_PARCELAS_PAGAS = Convert.ToInt32(ex.NUMERO_PARCELAS_PAGAS);
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].PRAZO = Convert.ToInt32(ex.PRAZO);
                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].QUITACAO_MES_ANO = ex.QUITACAO_MES_ANO;

                            fin.DADO_EXPERIENCIA_FINANCEIRA[i].SITUACAO = (wsFuncaoAutorizadorAcordos.SituacaoExperienciaFinanceira)
                                Enum.Parse(typeof(wsFuncaoAutorizadorAcordos.SituacaoExperienciaFinanceira), ex.SITUACAO.ToString().ToUpper());
                        }

                    }
                }
            }
            catch
            {
            }

            return fin;
        }
        private wsFuncaoAutorizadorAcordos.InDadosBancarios PreencherDadosBancarios(wsFuncaoGV.RetornoDadoCadastral retCli)
        {
            var dBancarios = new wsFuncaoAutorizadorAcordos.InDadosBancarios();
            try
            {

                dBancarios.DADO_BANCARIO = new wsFuncaoAutorizadorAcordos.InDadoBancario[retCli.DADOS_BANCARIOS.DADO_BANCARIO.Count()];
                if (retCli.DADOS_BANCARIOS != null)
                {
                    for (int i = 0; i < retCli.DADOS_BANCARIOS.DADO_BANCARIO.Count(); i++)
                    {
                        if (retCli.DADOS_BANCARIOS.DADO_BANCARIO[i] != null)
                        {
                            dBancarios.DADO_BANCARIO[i] = new wsFuncaoAutorizadorAcordos.InDadoBancario();
                            dBancarios.DADO_BANCARIO[i].AGENCIA = retCli.DADOS_BANCARIOS.DADO_BANCARIO[i].AGENCIA.NUMERO;
                            dBancarios.DADO_BANCARIO[i].AGENCIA_DIGITO = retCli.DADOS_BANCARIOS.DADO_BANCARIO[i].AGENCIA.DIGITO;
                            dBancarios.DADO_BANCARIO[i].CONTA = retCli.DADOS_BANCARIOS.DADO_BANCARIO[i].CONTA.NUMERO;
                            dBancarios.DADO_BANCARIO[i].CONTA_DIGITO = retCli.DADOS_BANCARIOS.DADO_BANCARIO[i].CONTA.DIGITO;
                            dBancarios.DADO_BANCARIO[i].BANCO = retCli.DADOS_BANCARIOS.DADO_BANCARIO[i].BANCO.NUMERO;
                            dBancarios.DADO_BANCARIO[i].CONTA_TIPO = (wsFuncaoAutorizadorAcordos.TipoContaBancaria)Enum.Parse(typeof(wsFuncaoAutorizadorAcordos.TipoContaBancaria),
                                retCli.DADOS_BANCARIOS.DADO_BANCARIO[i].CONTA.TIPO.ToString());
                        }
                    }
                }
            }
            catch
            {

            }

            return dBancarios;
        }
        private wsFuncaoAutorizadorAcordos.InDadoProfissional PreencherDadosProfissionais(wsFuncaoGV.RetornoDadoCadastral retCli)
        {
            if (retCli.DADO_REFERENCIAL == null)
                return null;

            var prof = new wsFuncaoAutorizadorAcordos.InDadoProfissional();

            try
            {
                prof.CARGO = retCli.DADO_REFERENCIAL.CARGO;
                prof.DATA_ADMISSAO = retCli.DADO_REFERENCIAL.DATA_ADMISSAO;
                prof.EMPRESA_TRABALHO_CNPJ = retCli.DADO_REFERENCIAL.EMPRESA_TRABALHO_CNPJ;
                prof.EMPRESA_TRABALHO_NOME = retCli.DADO_REFERENCIAL.EMPRESA_TRABALHO_NOME;

                var porte = (wsFuncaoAutorizadorAcordos.TipoPorteEmpresa)Enum.Parse(typeof(wsFuncaoAutorizadorAcordos.TipoPorteEmpresa),
                    retCli.DADO_REFERENCIAL.PORTE_EMPRESA.ToString());

                if (porte == wsFuncaoAutorizadorAcordos.TipoPorteEmpresa.NAO_DEFINIDO)
                    prof.EMPRESA_TRABALHO_PORTE = wsFuncaoAutorizadorAcordos.TipoPorteEmpresa.NAO_DEFINIDO;
                else
                    prof.EMPRESA_TRABALHO_PORTE = porte;

                prof.EMPRESA_ANTERIOR_CARGO = retCli.DADO_REFERENCIAL.EMPRESA_ANTERIOR_CARGO;
            }
            catch { }

            return prof;
        }
        private wsFuncaoAutorizadorAcordos.InConjuge PreencherConjuge(wsFuncaoGV.RetornoDadoCadastral retCli)
        {
            var conjuge = new wsFuncaoAutorizadorAcordos.InConjuge();

            if (retCli.CONJUGE != null)
            {
                conjuge.NOME = retCli.CONJUGE.NOME;
                conjuge.CPF = retCli.CONJUGE.CPF;
                conjuge.VALOR_RENDA = retCli.CONJUGE.RENDA;
                conjuge.DATA_NASCIMENTO = retCli.CONJUGE.DATA_NASCIMENTO;
                conjuge.DADO_PROFISSIONAL = new wsFuncaoAutorizadorAcordos.InDadoProfissional();
                conjuge.DADO_PROFISSIONAL.CARGO = retCli.CONJUGE.CARGO;
                conjuge.DADO_PROFISSIONAL.PROFISSAO = retCli.CONJUGE.PROFISSAO;

                if (retCli.CONJUGE.DADOS_ENDERECOS != null)
                {
                    conjuge.ENDERECO = new wsFuncaoAutorizadorAcordos.InDadoEndereco();
                    conjuge.ENDERECO.LOGRADOURO = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].LOGRADOURO;
                    conjuge.ENDERECO.NUMERO = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].NUMERO;
                    conjuge.ENDERECO.COMPLEMENTO = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].COMPLEMENTO;
                    conjuge.ENDERECO.BAIRRO = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].BAIRRO;
                    conjuge.ENDERECO.CIDADE = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].CIDADE;
                    conjuge.ENDERECO.CEP = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].CEP;
                    conjuge.ENDERECO.UF = retCli.CONJUGE.DADOS_ENDERECOS.DADO_ENDERECO[0].UF;
                }
                if (retCli.CONJUGE.TELEFONES != null)
                {
                    conjuge.TELEFONES = new wsFuncaoAutorizadorAcordos.InTelefonesTipo();
                    conjuge.TELEFONES.TELEFONE[0].DDD = retCli.CONJUGE.TELEFONES.TELEFONE[0].DDD;
                    conjuge.TELEFONES.TELEFONE[0].NUMERO = retCli.CONJUGE.TELEFONES.TELEFONE[0].NUMERO;
                }

            }
            return conjuge;
        }
        private Cobradora ObterCobradoraCyber(Int64 Documento, String Contrato)
        {
            var ambiente = Environment.GetEnvironmentVariable("CYBER");
            if (ambiente != "ON") return null;
            if (Documento <= 0 || string.IsNullOrWhiteSpace(Contrato)) return null;

            try
            {
                var objDados = new CyberAdapter();
                var cobradora = objDados.Assessoria_Obter(Documento, Contrato, "1");
                return cobradora;
            }
            catch (Exception ex)
            {
                throw new Exception("ERRO AO OBTER COBRADORA NO CYBER", ex);
            }
           
        }
        private List<Ocorrencia> ConsultarBloqueioConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
        {
            var ret = operacao.DadosConsultarBloqueioOperacao;

            if (!ret.Any()) return null;

            var Ocorrencias = new List<Ocorrencia>();

            ret.ToList().ForEach(o =>
            {
                var Ocorrencia = new Ocorrencia
                {
                    Codigo = Convert.ToInt64(o.CodMotivoBloqueio),
                    DataInclusao = o.DataInicioBloqueio,
                    DataValidade = o.DataFimBloqueio,
                    Ativo = o.StatusBloqueio == "A",
                    Nome = o.DescMotivoBloqueio
                };
                Ocorrencias.Add(Ocorrencia);
            });
            return Ocorrencias.GroupBy(o => new { o.Codigo, o.DataInclusao, o.DataValidade }).Select(grp => grp.First()).ToList();
        }
        private Loja ObterLojaConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
        {
            var ret = operacao.DadosOrigem4;

            if (!string.IsNullOrEmpty(ret.MensagemErro)) return null;

            var loja = new Loja
            {
                Nome = ret.DADOS_ORIGEM4.Nome,
                RazaoSocial = ret.DADOS_ORIGEM4.Nome,
                CNPJ = Common.ObterNumeros(ret.DADOS_ORIGEM4.CadastroGeral.CpfCnpj.Numero),
                Codigo = ret.DADOS_ORIGEM4.Codigo.ToString(),
                Endereco =
                {
                    Logradouro = ret.DADOS_ORIGEM4.CadastroGeral.Endereco.Logradouro,
                    Numero = ret.DADOS_ORIGEM4.CadastroGeral.Endereco.Numero,
                    Bairro = ret.DADOS_ORIGEM4.CadastroGeral.Endereco.Bairro,
                    CEP = ret.DADOS_ORIGEM4.CadastroGeral.Endereco.Cep,
                    Cidade = ret.DADOS_ORIGEM4.CadastroGeral.Endereco.Cidade,
                    UF = ret.DADOS_ORIGEM4.CadastroGeral.Endereco.Uf
                },
                Telefone = ret.DADOS_ORIGEM4.CadastroGeral.Telefone.DDD + ret.DADOS_ORIGEM4.CadastroGeral.Telefone.Numero
            };
            return loja;
        }
        private Cliente ObterClienteConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
        {
            var dadoCadastral = operacao.DadosCadastral;
            var cliente = new Cliente();

            if (dadoCadastral == null) return cliente;

            cliente.Codigo = dadoCadastral.CODIGO_CLIENTE;
            cliente.PessoaTipo = dadoCadastral.TIPO_PESSOA == wsFuncaoGV.TipoPessoa1.FISICA ? "F" : "J";
            cliente.TipoSistema = TipoSistema.Funcao;
            cliente.Documento = Common.ObterNumeros(dadoCadastral.CPF_CNPJ);
            cliente.Nome = dadoCadastral.NOME;
            cliente.Nacionalidade = (TipoNacionalidade)dadoCadastral.CODIGO_NACIONALIDADE;
            cliente.NaturalidadeUF = dadoCadastral.NATURALIDADE_UF;
            cliente.Nascimento = dadoCadastral.DATA_NASCIMENTO_OU_FUNDACAO;
            cliente.Naturalidade = dadoCadastral.NATURALIDADE;
            cliente.RG = dadoCadastral.RG_OU_IE;
            cliente.RGEmissor = dadoCadastral.RG_ORGAO_EMISSOR;
            if (DateTime.MinValue != dadoCadastral.RG_OU_IE_DATA_EMISSAO)
                cliente.RGData = dadoCadastral.RG_OU_IE_DATA_EMISSAO;
            cliente.RGUF = dadoCadastral.RG_OU_IE_UF;
            cliente.Sexo = (TipoSexo)dadoCadastral.SEXO;
            cliente.EstadoCivil = (TipoEstadoCivil)dadoCadastral.ESTADO_CIVIL;
            cliente.NomeMae = dadoCadastral.NOME_MAE;
            cliente.NomePai = dadoCadastral.NOME_PAI;

            cliente.Dependentes = (short)dadoCadastral.QTD_DEPENDENTES_OU_QTD_SOCIOS;
            cliente.TipoResidencia = (TipoResidencia)dadoCadastral.TIPO_IMOVEL;

            cliente.Email = dadoCadastral.EMAIL;
            cliente.NomeRecado = dadoCadastral.NOME_RECADO;
            cliente.Renda = (decimal)dadoCadastral.VALOR_RENDA;
            cliente.Comercial = new Comercial
            {
                RendaMensal = (decimal)dadoCadastral.VALOR_RENDA,
                Profissao = dadoCadastral.DADO_REFERENCIAL.PROFISSAO,
                EmpresaNome = dadoCadastral.DADO_REFERENCIAL.EMPRESA_TRABALHO_NOME,
                EmpresaCnpj = dadoCadastral.DADO_REFERENCIAL.EMPRESA_TRABALHO_CNPJ,
                NaturezaOcupacao = dadoCadastral.DADO_REFERENCIAL.CODIGO_NATUREZA_OCUPACAO
            };

            var dataAdmissao = Common.DataReferencia.AddDays(-400);

            if (dataAdmissao > DateTime.MinValue)
            {
                var tempoEmprego = Common.DataReferencia.Subtract(dataAdmissao);
                cliente.Comercial.TempoAtividadeAno = Convert.ToSByte(tempoEmprego.Days / 365);
                cliente.Comercial.TempoAtividadeMeses = Convert.ToSByte((tempoEmprego.Days / 30) - (12 * cliente.Comercial.TempoAtividadeAno));
            }

            var end = dadoCadastral.DADOS_ENDERECOS.DADO_ENDERECO.FirstOrDefault(f => f.TIPO == wsFuncaoGV.EnumTipoEndereco.RESIDENCIAL);

            cliente.Endereco = new Endereco
            {
                CEP = end.CEP,
                Logradouro = end.LOGRADOURO,
                Numero = end.NUMERO,
                Complemento = end.COMPLEMENTO,
                Bairro = end.BAIRRO,
                Cidade = end.CIDADE,
                UF = end.UF
            };

            var endCom = dadoCadastral.DADOS_ENDERECOS.DADO_ENDERECO.FirstOrDefault(f => f.TIPO == wsFuncaoGV.EnumTipoEndereco.COMERCIAL);

            if (endCom != null && !string.IsNullOrEmpty(endCom.CEP))
            {
                cliente.Comercial.Endereco = new Endereco
                {
                    CEP = endCom.CEP,
                    Logradouro = endCom.LOGRADOURO,
                    Numero = endCom.NUMERO,
                    Complemento = endCom.COMPLEMENTO,
                    Bairro = endCom.BAIRRO,
                    Cidade = endCom.CIDADE,
                    UF = endCom.UF
                };

            }

            var endCor = dadoCadastral.DADOS_ENDERECOS.DADO_ENDERECO.FirstOrDefault(f => f.TIPO == wsFuncaoGV.EnumTipoEndereco.CORRESPONDENCIA);

            if (endCor != null && !string.IsNullOrEmpty(endCor.CEP))
            {
                cliente.Correspondencia = new Endereco
                {
                    CEP = endCor.CEP,
                    Logradouro = endCor.LOGRADOURO,
                    Numero = endCor.NUMERO,
                    Complemento = endCor.COMPLEMENTO,
                    Bairro = endCor.BAIRRO,
                    Cidade = endCor.CIDADE,
                    UF = endCor.UF
                };

            }

            cliente.Telefones = new List<Telefone>();

            var tel = dadoCadastral.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoGV.EnumTipoTelefone.FONE_RESIDENCIAL);

            if (tel != null && !string.IsNullOrEmpty(tel.NUMERO))
            {
                cliente.Telefones.Add(new Telefone
                {
                    DDD = tel.DDD,
                    Numero = (int)Common.ObterNumeros(tel.NUMERO),
                    Tipo = TipoTelefone.Telefone
                });
            }

            var cel = dadoCadastral.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoGV.EnumTipoTelefone.CELULAR);
            if (cel != null && !string.IsNullOrEmpty(cel.NUMERO))
            {
                cliente.Telefones.Add(new Telefone
                {
                    DDD = cel.DDD,
                    Numero = (int)Common.ObterNumeros(cel.NUMERO),
                    Tipo = TipoTelefone.Celular
                });
            }

            var com = dadoCadastral.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoGV.EnumTipoTelefone.FONE_COMERCIAL1);
            if (com != null && !string.IsNullOrEmpty(com.NUMERO))
            {
                cliente.Telefones.Add(new Telefone
                {
                    DDD = com.DDD,
                    Numero = (int)Common.ObterNumeros(com.NUMERO),
                    Tipo = TipoTelefone.Comercial
                });
            }

            var rec = dadoCadastral.TELEFONES.TELEFONE.FirstOrDefault(t => t.TIPO == wsFuncaoGV.EnumTipoTelefone.FONE_RECADO);
            if (rec != null && rec.NUMERO != null)
            {
                cliente.Telefones.Add(new Telefone
                {
                    DDD = rec.DDD,
                    Numero = (int)Common.ObterNumeros(rec.NUMERO),
                    Tipo = TipoTelefone.Recado
                });
            }
            return cliente;

        }
        private List<Ocorrencia> ObterOcorrenciasConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
        {
            var ret = operacao.DadosConsultarOcorrencias;

            if (!string.IsNullOrEmpty(ret.MensagemErro)) return null;

            var Ocorrencias = new List<Ocorrencia>();

            ret.DadosOcorrencias.ToList().ForEach(o =>
            {
                var Ocorrencia = new Ocorrencia
                {
                    Codigo = Convert.ToInt64(o.CodigoOcorrencia),
                    DataInclusao = o.DataOcorrencia,
                    Nome = o.DescricaoCodigo
                };
                Ocorrencias.Add(Ocorrencia);
            });

            return Ocorrencias;
        }
        private List<Garantia> ObterGarantiasConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao, bool bemApreendido = false)
        {
            var ret = operacao.DadosGarantiaOrigemOperacao;

            if (ret.DadosGarantias == null || !ret.DadosGarantias.Any()) throw new FuncaoServiceException(string.Format("ERRO AO OBTER GARANTIAS [{0}]", ret.MensagemErro));

            var garantias = new List<Garantia>();
            var grts = ret.DadosGarantias.ToList();

            foreach (var g in grts)
            {
                var garantia = new Garantia
                {
                    Veiculo =
                    {
                        Marca = g.MARCA,
                        Modelo = g.MODELO_VEICULO,
                        FabricacaoAno = Convert.ToInt16(g.ANO_FABRICACAO),
                        Chassi = g.CHASSI,
                        Cor = g.COR,
                        Placa_Codigo = g.PLACA,
                        Renavam =
                            g.RENAVAM != ""
                                ? Convert.ToInt64(g.RENAVAM.Replace(".", string.Empty).Replace("-", string.Empty))
                                : 0,
                        Alienacao = g.ALIENACAO != "N"
                    }
                };
                garantia.Veiculo.FabricacaoAno = Convert.ToInt16(g.ANO_FABRICACAO);
                garantia.Veiculo.Cor = g.COR;
                garantia.Veiculo.Apreensao = bemApreendido;
              
                garantia.Veiculo.Gravame = new Gravame
                {
                    CodigoGravame = g.CÓDIGO_GRAVAME == 30 ? 0 : g.CÓDIGO_GRAVAME,
                    CriticaCetip = g.CÓDIGO_GRAVAME == 30 ? null : g.CRITICA_CETIP,
                    StatusRegistroCetip = g.STATUS_REGISTRO_CETIP == SituacaoBemGravames.Registrado ? 1 : 2,
                    DataRegistro = Convert.ToDateTime(g.DATA_REGISTRO)
                };
                garantias.Add(garantia);
            }
            return garantias;
        }
        private List<Acordo> ObterAcordosConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
        {
            var ret = operacao.DadosAcordos;

            if (!string.IsNullOrEmpty(ret[0].MensagemErro)) throw new FuncaoServiceException(string.Format("ERRO AO OBTER ACORDOS [{0}]", ret[0].MensagemErro));

            var acordos = new List<Acordo>();
            ret.ToList().ForEach(f =>
            {
                if (f.ObjAcordo.NumeroAcordo == null) return;

                var acordo = new Acordo
                {
                    ContratoInterno = f.ObjAcordo.NumeroAcordo,
                    DataInclusao = Convert.ToDateTime(f.ObjAcordo.DataBase, new CultureInfo("pt-BR"))
                };

                acordo.DataPagamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR")) == new DateTime(2079, 2, 2).Date ? DateTime.MinValue : Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));

                acordo.FlagPagamento = "2";
                acordo.DataVencimento = Convert.ToDateTime(f.ObjAcordo.objParcelasAcordo[0].DtVencimento, new CultureInfo("pt-BR"));
               
                if (f.ObjAcordo.PDFBoleto != null) acordo.PDF = Convert.ToBase64String(f.ObjAcordo.PDFBoleto);

                
                var parcelas = ObterParcelasConsolidado(operacao);
                if (parcelas == null) throw new FuncaoServiceException(string.Format("ERRO AO OBTER PARCELAS DO ACORDO [{0}]", ret[0].MensagemErro));

                f.ObjAcordo.objParcelasAcordo.ToList().ForEach(r =>
                {
                    if (r.LinhaDigitavel != null)
                        acordo.LinhaDigitavel = r.LinhaDigitavel;
                });

                f.ObjAcordo.objContratosNegociados.ToList().ForEach(p =>
                {
                    var parcela = new Parcela { NumeroParcela = Convert.ToInt32(p.NumeroParcela) };

                    var pa = parcelas.FirstOrDefault(fd => Convert.ToInt32(fd.NumeroParcela) == parcela.NumeroParcela);
                    if (pa != null)
                    {
                        var valorAcordo = Convert.ToDecimal(pa.ValorAtual, new CultureInfo("pt-BR"));
                        var valor = Convert.ToDecimal(pa.Valor, new CultureInfo("pt-BR"));

                        parcela.DataVencimento = Convert.ToDateTime(pa.DataVencimento, new CultureInfo("pt-BR"));
                        parcela.Valor = valor;
                        if (valorAcordo > valor)
                            parcela.ValorAcrescimos = valorAcordo - valor;

                        parcela.ValorCP = parcela.ValorAcrescimos;

                        if (valor > valorAcordo)
                        {
                            parcela.ValorDescontos = valor - valorAcordo;
                            parcela.ValorDescontoParcela = parcela.ValorDescontos;
                        }
                    }
                    acordo.Parcelas.Add(parcela);
                });

                switch (f.ObjAcordo.Situacao[0])
                {
                    case 'A':
                        break;

                    case 'L':
                        acordo.Liquidado = true;
                        break;

                    case 'C':
                        acordo.DataCancelamento = Convert.ToDateTime(f.ObjAcordo.DataLiquidacao, new CultureInfo("pt-BR"));
                        acordo.Cancelado = true;
                        acordo.DataPagamento = DateTime.MinValue;
                        acordo.Liquidado = false;
                        break;
                }
                acordos.Add(acordo);
            });
           

            return acordos.Where(t => t.Cancelado == false  && t.Liquidado == false).ToList();
        }
        private List<Parcela> ObterParcelasConsolidado(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
        {
            var ret = operacao.DadosConsultaContratoParcelas;

            if (!string.IsNullOrEmpty(ret.MensagemErro))  throw new FuncaoServiceException(string.Format("ERRO AO OBTER PARCELAS [{0}]", ret.MensagemErro));
            
            var all = ret.PARCELAS.ToList();
            System.IO.File.WriteAllText(@"C:\Temp\parcelas", JsonConvert.SerializeObject(all, Formatting.Indented));
          
            var parcelas = new List<Parcela>();

            var parcelasFunc = operacao.DadosConsultaContratoParcelas.PARCELAS.ToList();
         
            for (var i = 1; i <= parcelasFunc.Count; i++)
            {
                var movimentos = parcelasFunc.Where(t => Convert.ToInt32(t.NumeroParcela) == i).ToList();
                if (movimentos.Any())
                {
                    var movimento = movimentos.FirstOrDefault(a => a.Controle == movimentos.Max(t => t.Controle));

                    if (movimento == null) continue;
                    var parcela = new Parcela();
                    parcela.DataPagamento = movimento.DataMovimento;
                    parcela.Estorno = movimento.TipoMovimento == TipoMovimento.Estorno;
                    parcela.Liquidado = (movimento.SituacaoParcela == "L" && parcela.Estorno == false);
                    parcela.DataVencimento = movimento.Vencimento;
                    parcela.NumeroParcela = Convert.ToInt32(movimento.NumeroParcela);
                    parcela.Controle = Convert.ToInt32(movimento.Controle);
                    parcela.TipoMovimentacao = movimento.TipoMovimento.ToString();

                    if (movimento.ValodCurva > movimento.ValorPMT)
                        parcela.ValorAcrescimos = (decimal)(movimento.ValodCurva - movimento.ValorPMT);
                    else if (movimento.ValorPago > movimento.ValorPMT)
                        parcela.ValorAcrescimos = (decimal)(movimento.ValorPago - movimento.ValorPMT);

                    if (!parcela.Liquidado && movimento.ValorPMT > movimento.ValodCurva)
                        parcela.ValorDescontos = (decimal)(movimento.ValorPMT - movimento.ValodCurva);
                    else if (parcela.Liquidado && movimento.ValorPMT > movimento.ValorPago)
                        parcela.ValorDescontos = (decimal)(movimento.ValorPMT - movimento.ValorPago);

                    parcela.Valor = (decimal)movimento.ValorPMT;
                    parcela.LinhaDigitavel = movimento.LinhaDigitavel;
                    parcelas.Add(parcela);
                }
            }
            return parcelas;
        }
        private ClienteExtrato ObterOperacoes(Int64 Documento)
        {
            var operacoes = ObterContratos(Documento);

            if (operacoes == null || operacoes.Count == 0) return null;

            var cliente = new ClienteExtrato
            {
                Operacoes = new List<Operacao>(),
                Nome = operacoes[0].ClienteNome,
                Documento = Documento,
                Tipo_Pessoa = Documento.ToString().Length <= 11 ? 'F' : 'J'
            };

            operacoes.ForEach(o =>
            {
                var operacao = new Operacao
                {
                    Contrato = o.NumeroContrato,
                    Quitado = o.Liquidada == 'L',
                    Data_Contrato = o.InicioAtendimento,
                    CNPJ = 59285411000113,
                    CodigoProduto = o.ProdutoCodigo
                };
                cliente.Operacoes.Add(operacao);
            });

            return cliente;
        }
        private OperacaoCredito MontaOperacao(wsFuncaoGV.RetornoConsultarDadosConsolidadosContrato operacao)
         {
            var operacaoServico = new OperacaoCredito();
            if (operacao == null) return null;


            if (operacao.DadosCadastral.MensagemErro != null && operacao.DadosCadastral.MensagemErro.ToUpper().Contains("CLIENTE NÃO ENCONTRADO"))
                throw new Exception("Cliente não localizado no serviço na base");

            operacaoServico.Cliente = ObterClienteConsolidado(operacao);

            var retOp = operacao.DadosDaOperacao;

            if (retOp == null) return null;

            operacaoServico.Origem = Origens.Funcao;
            operacaoServico.Contrato = retOp.NUMERO_OPERACAO;
            operacaoServico.CodigoProduto = retOp.DADOS_OPERACAO.CODIGO_PRODUTO;
            operacaoServico.QuantidadeParcelas = retOp.DADOS_OPERACAO.PLANO;
            operacaoServico.StatusContrato = operacao.DadosConsultaContratoParcelas.CONTRATO.Situacao;

            if (retOp.DADOS_OPERACAO.FORMA_PGTO == "B")
                operacaoServico.FormaLiquidacao = OperacaoLiquidacaoTipos.Boleto;



            var parcelasCtt = ObterParcelasConsolidado(operacao);
            if (parcelasCtt != null)
            {
                parcelasCtt.ToList().ForEach(r => r.Plano = operacaoServico.QuantidadeParcelas);
                operacaoServico.Parcelas = parcelasCtt;
            }

            if (operacao.DadosConsultaContratoParcelas.BEM != null)
            {
                var buscaApreensao = operacao.DadosConsultaContratoParcelas.BEM.FirstOrDefault();
                if (buscaApreensao != null)
                    operacaoServico.IsBNDU = !string.IsNullOrEmpty(buscaApreensao.SituacaoBem);

                    operacaoServico.BuscaApreensao = buscaApreensao.FlagApreencao == "S";
            }

            if (operacao.DadosConsultarBloqueioOperacao.Any(t => t.CodMotivoBloqueio == 674 && t.StatusBloqueio == "A"))
            {
                operacaoServico.BuscaApreensao = true;
            }

            operacaoServico.Garantias = ObterGarantiasConsolidado(operacao, operacaoServico.BuscaApreensao);

            operacaoServico.Loja = ObterLojaConsolidado(operacao);
            if (operacaoServico.Loja != null)
            {
                operacaoServico.Loja.Regional = new Regional() { Nome = retOp.DADOS_OPERACAO.PROMOTORA.Remove(0, retOp.DADOS_OPERACAO.PROMOTORA.IndexOf(':') + 2) };
            }

            operacaoServico.ValorQuitacao =
                operacaoServico.Parcelas.Where(p => !p.Liquidado && !p.PagamentoParcial)
                    .Sum(p => p.ValorPrincipal + p.ValorAcrescimos - p.ValorDescontos);
            operacaoServico.Acordos =  ObterAcordosConsolidado(operacao);
            operacaoServico.Fluxo = ObterFluxo(operacaoServico.Parcelas);
            operacaoServico.Ocorrencias = ObterOcorrenciasConsolidado(operacao);
            var bloqueios = ConsultarBloqueioConsolidado(operacao);

            if (bloqueios != null)
            {
                operacaoServico.Ocorrencias.AddRange(bloqueios);
            }
            operacaoServico.Operacao = "VEICULO";

            //var Cobradora =  ObterCobradoraCyber(Convert.ToInt64(operacaoServico.Cliente.Documento), operacaoServico.Contrato);
            //if (Cobradora != null)
            //{
            //    operacaoServico.Cobradora = Cobradora;
            //}
            operacaoServico.Empresa = new Empresa { Codigo = "001" };
            operacaoServico.Empresa.Atributos.Add("Código na origem", "001");
            return operacaoServico;
        }
        private List<FluxoItem> ObterFluxo(List<Parcela> Parcelas)
        {
            var fluxo = new List<FluxoItem>();
            foreach (var parcela in Parcelas)
            {


                if (parcela.Controle == 1 && parcela.TipoMovimentacao != "SemMovimento")
                {
                    fluxo.Add(new FluxoItem()
                    {
                        DataAmortizacao = parcela.DataVencimento,
                        DataValor = parcela.DataPagamento,
                        TipoLiquidacao = "Boleto",
                        CodigoEvento = 1,
                        Descricao = ((parcela.PagamentoParcial && parcela.Controle == 1) ? "Baixa Parcial" : "Recebimento de Parcela"),
                        Valor = (parcela.PagamentoParcial && parcela.Controle == 1) ? parcela.ValorPagamentoParcial : parcela.Valor
                    });
                }
                if (parcela.Controle > 1 && parcela.TipoMovimentacao != "SemMovimento")
                {
                    var todos = fluxo.ToList().FindAll(s => s.Descricao != null);
                    var flx = todos.FirstOrDefault(t => t.Descricao.Contains("Parcial"));

                    if (flx != null)
                    {
                        fluxo.Add(new FluxoItem()
                        {

                            DataAmortizacao = parcela.DataVencimento,
                            DataValor = parcela.DataPagamento,
                            TipoLiquidacao = "Saldo",
                            CodigoEvento = 1,
                            Valor = (!flx.Descricao.Contains("Parcial") ? parcela.Valor : (parcela.Valor) + (flx.Valor * (-1))),
                        });
                    }
                }


                if (parcela.Controle == 1 && parcela.TipoMovimentacao != "SemMovimento")
                {
                    fluxo.Add(new FluxoItem()
                    {
                        DataAmortizacao = parcela.DataVencimento,
                        DataValor = parcela.DataPagamento,
                        TipoLiquidacao = "Boleto",
                        CodigoEvento = 5,
                        Valor = parcela.ValorAcrescimos - parcela.ValorDescontos
                    });
                }
            }

            return fluxo;
        }

        #region OCORRENCIAS
        private long FecharProtocoloAtendimento(int protocolo)
        {
            var ret = _wsGv.FinalizaProtocolo(new FinalizaProtocoloRequest
            {
                Autenticacao = AutenticarGV(),
                pIdProtocolo = protocolo
            }).FinalizaProtocoloResult;
            return 0;
        }
        private int IniciarProtocoloAtendimento(string mesa, string backOffice, string contrato)
        {
            var ret = _wsGv.IniciarProtocoloAtendimentoPorOperacao(new IniciarProtocoloAtendimentoPorOperacaoRequest
            {
                Autenticacao = AutenticarGV(),
                pCodigoBackoffice = backOffice,
                pCodigoMesa = mesa,
                pNumeroContrato = contrato
            }).IniciarProtocoloAtendimentoPorOperacaoResult;
            if (ret.IdProtocolo == 0)
                throw new ArgumentException("Retorno do webservice wsGV - Falha na geração do protocolo: " + ret.CodErro + " - " + ret.MensagemErro);
            return (int)ret.IdProtocolo;
        }
        #endregion

        #region OCORRENCIAS
        private List<Ocorrencia> ConsultarOcorrencias(string contrato)
        {
            var protocolo = IniciarProtocoloAtendimento(mesa, backOffice, contrato);
            var funcao = new wsFuncaoGV.WsGVSoapClient();

            var aut = AutenticarGV();

            var ret = funcao.ConsultarOcorrencias(aut, protocolo);
            FecharProtocoloAtendimento(protocolo);

            if (!string.IsNullOrEmpty(ret.MensagemErro))
                return null;

            var Ocorrencias = new List<Ocorrencia>();

            ret.DadosOcorrencias.ToList().ForEach(o =>
            {
                var Ocorrencia = new Ocorrencia
                {
                    Codigo = Convert.ToInt64(o.CodigoOcorrencia),
                    DataInclusao = o.DataOcorrencia,
                    Nome = o.DescricaoCodigo
                };
                Ocorrencias.Add(Ocorrencia);
            });

            return Ocorrencias;
        }
        private List<Ocorrencia> ConsultarOcorrencias(string contrato, int protocoloAtendimento)
        {
            var funcao = new wsFuncaoGV.WsGVSoapClient();

            var aut = AutenticarGV();

            var ret = funcao.ConsultarOcorrencias(aut, protocoloAtendimento);

            if (!string.IsNullOrEmpty(ret.MensagemErro))
                return null;

            var Ocorrencias = new List<Ocorrencia>();

            ret.DadosOcorrencias.ToList().ForEach(o =>
            {
                var Ocorrencia = new Ocorrencia
                {
                    Codigo = Convert.ToInt64(o.CodigoOcorrencia),
                    DataInclusao = o.DataOcorrencia,
                    Nome = o.DescricaoCodigo
                };
                Ocorrencias.Add(Ocorrencia);
            });

            return Ocorrencias;
        }
        private List<Ocorrencia> ConsultarBloqueio(string contrato)
        {
            var protocolo = IniciarProtocoloAtendimento(mesa, backOffice, contrato);
            if (protocolo == 0) return null;

            var funcao = new wsFuncaoGV.WsGVSoapClient();

            var aut = AutenticarGV();

            var ret = funcao.ConsultarBloqueio(aut, protocolo, "S", Common.DataReferencia);
            FecharProtocoloAtendimento(protocolo);

            var Ocorrencias = new List<Ocorrencia>();

            ret.ToList().ForEach(o =>
            {
                var Ocorrencia = new Ocorrencia
                {
                    Codigo = Convert.ToInt64(o.CodMotivoBloqueio),
                    DataInclusao = o.DataInicioBloqueio,
                    DataValidade = o.DataFimBloqueio,
                    Ativo = o.StatusBloqueio == "A",
                    Nome = o.DescMotivoBloqueio
                };


                Ocorrencias.Add(Ocorrencia);
            });
            return Ocorrencias.GroupBy(o => new { o.Codigo, o.DataInclusao, o.DataValidade }).Select(grp => grp.First()).ToList();
        }
        private List<Ocorrencia> ConsultarBloqueio(string contrato, int protocoloAtendimento)
        {
            var ret = _wsGv.ConsultarBloqueio(new ConsultarBloqueioRequest
            {
                Autenticacao = AutenticarGV(),
                pIdProtocolo = protocoloAtendimento,
                pExibeHistorico = "S",
                pDataReferencia = Common.DataReferencia

            }).ConsultarBloqueioResult;
            var Ocorrencias = new List<Ocorrencia>();

            ret.ToList().ForEach(o =>
            {
                var Ocorrencia = new Ocorrencia
                {
                    Codigo = Convert.ToInt64(o.CodMotivoBloqueio),
                    DataInclusao = o.DataInicioBloqueio,
                    DataValidade = o.DataFimBloqueio,
                    Ativo = o.StatusBloqueio == "A",
                    Nome = o.DescMotivoBloqueio
                };
                Ocorrencias.Add(Ocorrencia);
            });

            return
                Ocorrencias.GroupBy(o => new { o.Codigo, o.DataInclusao, o.DataValidade })
                    .Select(grp => grp.First())
                    .ToList();
        }
        #endregion


        #endregion

    }
}