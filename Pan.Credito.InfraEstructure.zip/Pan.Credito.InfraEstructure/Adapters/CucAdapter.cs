﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using Pan.Credito.CrossCutting;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Credito;
using Pan.Credito.Domain.Entidades.Types;
using Pan.Credito.Infrastructure.wsCUC;

namespace Pan.Credito.Infrastructure.Adapters
{

    public class CucAdapter : ICucAdapter
    {

        private readonly ServiceSoap _cucService;

        public CucAdapter()
        {
            _cucService = new wsCUC.ServiceSoapClient(); ;
        }

        public Cliente ObterCliente(Int64 Documento)
        {
            var xml = "<CUC>" +
                "<CONSULTA>" +
                "<CPF_CNPJ>" + Documento.ToString() + "</CPF_CNPJ>" +
                "<CD_SISTEMA>14</CD_SISTEMA>" +
                "<SENHA>D6BF5627FA2B059A460CB34EEE6D608582DD4907</SENHA>" +
                "</CONSULTA>" +
                "</CUC>";

            var ret = _cucService.CONSULTA_CLIENTE(xml, 1);
            var document = XDocument.Parse(ret);
            var pf = document.Descendants("DADOS_PESSOAIS_PESSOA_FISICA").FirstOrDefault();
            var retorno = Convert.ToInt32(document.Descendants("CUC").FirstOrDefault().Element("RETORNO").Value);

            if (retorno > 0)
                return null;

            var cli = new Cliente();
            cli.Atualizacao = Convert.ToDateTime(document.Descendants("CUC").FirstOrDefault().Element("DH_ULTIMA_ATUALIZACAO").Value, new CultureInfo("pt-BR"));
            cli.TipoSistema = TipoSistema.CUC;

            cli.Documento = Convert.ToInt64(pf.Element("CPF").Value);
            cli.Nome = pf.Element("NOME").Value;
            cli.NaturalidadeUF = pf.Element("UF_NATURALIDADE").Value;
            cli.Nascimento = Convert.ToDateTime(pf.Element("DT_NASCIMENTO").Value, new CultureInfo("pt-BR"));
            cli.Naturalidade = pf.Element("NATURALIDADE").Value;
            cli.RG = pf.Element("RG").Value;
            cli.RGEmissor = pf.Element("ORGAO_EMISSAO_RG").Value;
            cli.RGData = Convert.ToDateTime(pf.Element("DT_EMISSAO_RG").Value, new CultureInfo("pt-BR"));
            cli.RGUF = pf.Element("UF_EMISSAO_RG").Value;
            cli.Sexo = (TipoSexo)(pf.Element("SEXO").Value == "M" ? 1 : 2);
            cli.EstadoCivil = (TipoEstadoCivil)Convert.ToInt32(pf.Element("ESTADO_CIVIL").Value);
            cli.NomeMae = pf.Element("NOME_MAE").Value;
            cli.NomePai = pf.Element("NOME_PAI").Value;
            cli.PessoaTipo = "F";
            cli.Email = pf.Element("EMAIL").Value;
            var end = document.Descendants("ENDERECO_RESIDENCIAL_PESSOA_FISICA").FirstOrDefault();
            if (end != null)
            {
                cli.Endereco = new Endereco();
                cli.Endereco.CEP = end.Element("CEP").Value;
                cli.Endereco.Logradouro = end.Element("LOGRADOURO").Value;
                cli.Endereco.Numero = end.Element("NUMERO").Value;
                cli.Endereco.Complemento = end.Element("COMPLEMENTO").Value;
                cli.Endereco.Bairro = end.Element("BAIRRO").Value;
                cli.Endereco.Cidade = end.Element("CIDADE").Value;
                cli.Endereco.UF = end.Element("UF").Value;

                cli.Telefones = new List<Telefone>();
            }

            if (!string.IsNullOrEmpty(end.Element("TELEFONE").Value))
            {
                cli.Telefones.Add(new Telefone
                {
                    DDD = end.Element("DDD").Value,
                    Numero = (int)Common.ObterNumeros(end.Element("TELEFONE").Value),
                    Tipo = TipoTelefone.Telefone
                });
            }
            if (!string.IsNullOrEmpty(pf.Element("CELULAR").Value))
            {

                cli.Telefones.Add(new Telefone
                {
                    DDD = pf.Element("DDD_CELULAR").Value,
                    Numero = (int)Common.ObterNumeros(pf.Element("CELULAR").Value),
                    Tipo = TipoTelefone.Celular
                });
            }

            return cli;
        }
        public string GravarClienteCUC(XmlDocument objXmlDocument, string mensagem)
        {
            #region Grava_Cliente

            var strXML_Result = _cucService.GRAVA_CLIENTE(Common.RemoveAcentos(objXmlDocument.InnerXml), 1);
            var XmlResult = new XmlDocument();

            XmlResult.LoadXml(strXML_Result);
            var XmlRoot = XmlResult.DocumentElement;
            var CodeRetorno = "0";

            foreach (XmlNode node in XmlRoot.ChildNodes)
            {
                if (node.Name == "RETORNO")
                {
                    CodeRetorno = node.InnerText;
                }
                else if (node.Name == "DESCRICAO_ERRO")
                {
                    if ((CodeRetorno != "0") && (CodeRetorno.Substring(0, 1) != "5"))
                        throw new Exception(mensagem + " - Código de Retorno: " + CodeRetorno + " (" + node.InnerText.Replace("\\", "").Replace("\'", "").Replace("\"", "") + ")");
                    else if (CodeRetorno.Substring(0, 1) == "5")
                        throw new Exception(mensagem + " - Código de Retorno: " + CodeRetorno + " Descrição: " + node.InnerText);
                    else
                        return mensagem + " - Salvo com sucesso - CUC!!!";
                }

            }
            #endregion Grava_Cliente

            return string.Empty;
        }

        public void Dispose()
        {
            var disposable = _cucService as IDisposable;
            if (disposable != null) disposable.Dispose();
            GC.SuppressFinalize(this);
        }

    }
}