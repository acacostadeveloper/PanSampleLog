﻿using System;
using System.Collections.Generic;
using System.Configuration;
using Newtonsoft.Json;
using Pan.Credito.Domain.Adapters;
using Pan.Credito.Domain.Entidades.Cobranca;
using RestSharp;

namespace Pan.Credito.Infrastructure.Adapters
{
    public class CobrancaAdapter : ICobrancaAdapter
    {
        public List<RegrasCobranca> ObterRegras(string codigoProduto,int qtdeParcelas, int DiasAtraso, bool ContratoAntesSet2017)
        {
            var client = new RestClient(ConfigurationManager.AppSettings["WSCOBRANCA"]);
            var request = new RestRequest("WEB.API.Cobranca/BuscarRegra", Method.POST);
            request.AddHeader("Content-Type", "application/json");
           
            request.AddJsonBody(new
             {
                 TipoProduto = 0,
                 CodigoProdutoLegado = codigoProduto,
                 QtdDiasAtraso = DiasAtraso,
                 QtdParcelasQuitacao = qtdeParcelas,
                 ContratoAnteriorSetembro2017 = ContratoAntesSet2017
             });
            var response = client.Execute(request);
            if (response.StatusCode != System.Net.HttpStatusCode.OK) throw new Exception(string.Format("ERRO WSCOBRANCA MESSAGE {0}", response.Content));
            return JsonConvert.DeserializeObject<List<RegrasCobranca>>(response.Content);
        }
    }

    
}