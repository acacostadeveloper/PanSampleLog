﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Security.Interface
{
    public interface IAutorization
    {
        bool ValidateToken(string token);
        string GetToken(string userName, string password);
    }
}
