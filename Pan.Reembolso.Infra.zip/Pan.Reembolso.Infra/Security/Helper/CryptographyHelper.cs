﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Configuration;

namespace Pan.Reembolso.Infra.Security.Helper
{
    public static class CryptographyHelper
    {
        private static string publicKey = ConfigurationManager.AppSettings["PublicKey"];
        private static string privateKey = ConfigurationManager.AppSettings["PrivateKey"];

        public enum KeyType 
        { 
            PublicKey = 0,
            PrivateKey = 1
        }

        public static string EncryptString(string message, KeyType keyType)
        {
            string key = (keyType == KeyType.PublicKey) ? publicKey : privateKey;
            return EncryptString(message, key);
        }

        public static string DecryptString(string message, KeyType keyType)
        {
            string key = (keyType == KeyType.PublicKey) ? publicKey : privateKey;
            return DecryptString(message, key);
        }

        private static string EncryptString(string message, string key)
        {

            byte[] results; System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();

            MD5CryptoServiceProvider hashProvider = new MD5CryptoServiceProvider();
            byte[] tDESKey = hashProvider.ComputeHash(UTF8.GetBytes(key));

            TripleDESCryptoServiceProvider tDESAlgorithm = new TripleDESCryptoServiceProvider();

            tDESAlgorithm.Key = tDESKey;
            tDESAlgorithm.Mode = CipherMode.ECB;
            tDESAlgorithm.Padding = PaddingMode.PKCS7;

            byte[] dataToEncrypt = UTF8.GetBytes(message);

            try
            {
                ICryptoTransform encryptor = tDESAlgorithm.CreateEncryptor();
                results = encryptor.TransformFinalBlock(dataToEncrypt, 0, dataToEncrypt.Length);
            }
            finally
            {
                tDESAlgorithm.Clear();
                hashProvider.Clear();
            }

            return Convert.ToBase64String(results);
        }

        private static string DecryptString(string message, string key)
        {
            byte[] results;
            System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();

            MD5CryptoServiceProvider hashProvider = new MD5CryptoServiceProvider();
            byte[] tDESKey = hashProvider.ComputeHash(UTF8.GetBytes(key));

            TripleDESCryptoServiceProvider tDESAlgorithm = new TripleDESCryptoServiceProvider();

            tDESAlgorithm.Key = tDESKey;
            tDESAlgorithm.Mode = CipherMode.ECB;
            tDESAlgorithm.Padding = PaddingMode.PKCS7;

            try
            {
                string converted = message.Replace('-', '+');
                converted = converted.Replace('_', '/');

                byte[] dataToDecrypt = Convert.FromBase64String(converted);

                ICryptoTransform Decryptor = tDESAlgorithm.CreateDecryptor();
                results = Decryptor.TransformFinalBlock(dataToDecrypt, 0, dataToDecrypt.Length);
            }
            catch(Exception ex)
            {
                // Log Ex para analise
                var erro = ex.Message;
                throw ex;
            }
            finally
            {
                tDESAlgorithm.Clear();
                hashProvider.Clear();
            }

            return UTF8.GetString(results);
        }
    }
}
