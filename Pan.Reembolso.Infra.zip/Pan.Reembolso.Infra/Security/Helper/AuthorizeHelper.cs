﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Web.Configuration;
using Newtonsoft.Json.Linq;

namespace Pan.Reembolso.Infra.Security.Helper
{

    public class AuthorizeHelper
    {
        public void Authorize(string token)
        {
            try
            {
                string key = WebConfigurationManager.AppSettings["PrivateKey"];
                
                var data = JsonWebToken.Decode(token, key);

                dynamic stuff = JObject.Parse(data);

                string aud = stuff.aud;
                string usr = CryptographyHelper.DecryptString((string)stuff.usr, CryptographyHelper.KeyType.PrivateKey);
                string pwd = CryptographyHelper.DecryptString((string)stuff.pwd, CryptographyHelper.KeyType.PrivateKey);
                string iat = stuff.iat;
                string exp = stuff.exp;

                DateTime iatToUtcDate = UnixDateTimeHelper.UnixTimeStampToDateTime(Convert.ToInt64(iat));
                DateTime expToUtcDate = UnixDateTimeHelper.UnixTimeStampToDateTime(Convert.ToInt64(exp)); 

                this.ValidateTokenData(aud, iatToUtcDate, expToUtcDate);
                this.ValidateUserCredentials(usr, pwd);
                this.AuthorizeUser(usr);
            }
            catch (Exception ex) 
            {
                throw new FaultException("Error authorizing user. " + ex.Message);
            }
        }

        private void ValidateTokenData(string aud, DateTime iat, DateTime exp)
        {
            if (aud != WebConfigurationManager.AppSettings["Audience"])
                throw new FaultException("invalid audience.");

            if (DateTime.Now > exp || DateTime.Now < iat)
                throw new FaultException("Token expired.");
        }

        private void AuthorizeUser(string userName)
        {

            bool inRole = false;
            string path = WebConfigurationManager.AppSettings["ActiveDirectoryPath"];
            string[] roles = WebConfigurationManager.AppSettings["ActiveDirectoryGroups"].Split(";".ToCharArray());

            List<String> authorizedRoles = new List<string>();

            foreach (string role in roles)
            {
                authorizedRoles.Add(role);
            }

            using (DirectoryEntry de = new DirectoryEntry(path))
            {
                using (DirectorySearcher adSearch = new DirectorySearcher(de))
                {
                    adSearch.Filter = "(sAMAccountName=" + userName + ")";
                    SearchResult adSearchResult = adSearch.FindOne();

                    int propertyCount = adSearchResult.Properties["memberOf"].Count;
                    String dn;
                    int equalsIndex, commaIndex;

                    for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                    {
                        dn = (String)adSearchResult.Properties["memberOf"][propertyCounter];

                        equalsIndex = dn.IndexOf("=", 1);
                        commaIndex = dn.IndexOf(",", 1);
                        if (-1 == equalsIndex)
                        {
                            break;
                        }

                        string role = dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1);

                        inRole = authorizedRoles.Contains(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));

                        if (inRole)
                            break;
                    }

                    if (!inRole)
                        throw new FaultException("Access is denied.");
                }
            }
        }

        private void ValidateUserCredentials(string userName, string password)
        {
            string domain = WebConfigurationManager.AppSettings["ActiveDirectoryDomain"];

            try
            {
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, domain))
                {
                    bool isValid = pc.ValidateCredentials(userName, password);
                    if (!isValid)
                    {
                        throw new FaultException("Incorrect user name or password.");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new FaultException("Error validating user. " + ex.Message);
            }
        }
    }
}
