﻿using Pan.Reembolso.Infra.Security.Helper;
using Pan.Reembolso.Infra.Security.Interface;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.Web.Configuration;

namespace Pan.Reembolso.Infra.Security.Implementation
{
    public class Autorization : IAutorization
    {
        public void Authorize(string token)
        {
            token = token.Replace(' ', '+');
            //string auth = token; // = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

            var auth = CryptographyHelper.DecryptString(token, CryptographyHelper.KeyType.PrivateKey);

            AuthorizeHelper aut = new AuthorizeHelper();

            aut.Authorize(auth);
        }

        public string GetToken(string userName, string password)
        {
            try
            {
                string usr = CryptographyHelper.EncryptString(CryptographyHelper.DecryptString(userName, CryptographyHelper.KeyType.PublicKey), CryptographyHelper.KeyType.PrivateKey);
                string pwd = CryptographyHelper.EncryptString(CryptographyHelper.DecryptString(password, CryptographyHelper.KeyType.PublicKey), CryptographyHelper.KeyType.PrivateKey);

                string issued = UnixDateTimeHelper.GetIntDate(DateTime.Now).ToString();
                string expire = UnixDateTimeHelper.GetIntDate(DateTime.Now.AddMinutes(120)).ToString();

                var payload = new Dictionary<string, object>()
                {
                    {"aud", WebConfigurationManager.AppSettings["Audience"]},
                    {"usr", usr},
                    {"pwd", pwd},
                    {"iat", issued},
                    {"exp", expire}
                };

                string token = JsonWebToken.Encode(payload, WebConfigurationManager.AppSettings["PrivateKey"], JwtHashAlgorithm.RS256);

                token = CryptographyHelper.EncryptString(token, CryptographyHelper.KeyType.PrivateKey);

                //TODO - remover apenas para teste
                Authorize(token);

                return token;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
