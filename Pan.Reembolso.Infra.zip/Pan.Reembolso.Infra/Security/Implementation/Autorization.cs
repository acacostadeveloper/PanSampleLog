﻿using Pan.Reembolso.Infra.Security.Helper;
using Pan.Reembolso.Infra.Security.Interface;
using System.ServiceModel;
using System.Web.Configuration;

namespace Pan.Reembolso.Infra.Security.Implementation
{
    public class Autorization : IAutorization
    {
        public void Verify()
        {
            string auth = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("Authorization", WebConfigurationManager.AppSettings["Audience"]);

            auth = CryptographyHelper.DecryptString(auth, CryptographyHelper.KeyType.PrivateKey);

            AuthorizeHelper aut = new AuthorizeHelper();
            aut.Authorize(auth);
        }
    }
}
