﻿using System.Collections.Generic;
using Pan.Reembolso.Infra.Autentication.Entidades;

namespace Pan.Reembolso.Infra.Autentication.Interface
{
    public interface IAutenticationUserRepository
    {
        UserAuthorization AutenticationUser(string nome, List<string> roles);

        List<RoleUser> GetRoles();
    }
}