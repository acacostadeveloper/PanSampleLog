﻿using Pan.Reembolso.Infra.Autentication.DataBase;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace Pan.Reembolso.Infra.Autentication.Mapper
{
    internal class ActionMap : EntityTypeConfiguration<AuthActionDatabase>
    {

        public ActionMap()
        {
            this.HasKey(t => t.idAction);
            this.Property(t => t.idAction).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[AUTH_ACTION]");

            this.Property(t => t.idAction).HasColumnName("ID_ACTION");
            this.Property(t => t.actionName).HasColumnName("DS_ACTION");
            this.Property(t => t.idService).HasColumnName("ID_SERVICE");
            this.Property(t => t.ativo).HasColumnName("IC_ATIVO");
        }
    }
}