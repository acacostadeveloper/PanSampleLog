﻿using Pan.Reembolso.Infra.Autentication.DataBase;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace Pan.Reembolso.Infra.Autentication.Mapper
{
    internal class ServiceMap : EntityTypeConfiguration<AuthServiceDatabase>
    {
        public ServiceMap()
        {

            this.HasKey(t => t.idService);
            this.Property(t => t.idService).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[AUTH_SERVICE]");

            this.Property(t => t.idService).HasColumnName("ID_SERVICE");
            this.Property(t => t.serviceName).HasColumnName("DS_SERVICE");
        }
    }
}