﻿using Pan.Reembolso.Infra.Autentication.DataBase;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace Pan.Reembolso.Infra.Autentication.Mapper
{
    internal class RoleMap : EntityTypeConfiguration<AuthRoleDatabase>
    {
        public RoleMap()
        {
            this.HasKey(t => t.idRole);
            this.Property(t => t.idRole).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[AUTH_ROLE]");

            this.Property(t => t.idRole).HasColumnName("ID_ROLE");
            this.Property(t => t.roleName).HasColumnName("ROLE_NAME");
        }
    }
}