﻿using Pan.Reembolso.Infra.Autentication.DataBase;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace Pan.Reembolso.Infra.Autentication.Mapper
{
    internal class RoleServiceMap : EntityTypeConfiguration<AuthRoleServiceDatabase>
    {
        public RoleServiceMap()
        {
            this.HasKey(t => new { t.idRole, t.idService });

            this.ToTable("[gestao_reembolso].[AUTH_ROLE_SERVICE]");

            this.Property(t => t.idRole).HasColumnName("ID_ROLE");
            this.Property(t => t.idService).HasColumnName("ID_SERVICE");
        }
    }
}