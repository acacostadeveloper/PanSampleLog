﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.DataBase
{
    [Table("[gestao_reembolso].[AUTH_SERVICE]")]
    [Serializable]
    public class AuthServiceDatabase
    {
        [Key]
        public int idService { get; set; }
        public string serviceName { get; set; }
    }
}
