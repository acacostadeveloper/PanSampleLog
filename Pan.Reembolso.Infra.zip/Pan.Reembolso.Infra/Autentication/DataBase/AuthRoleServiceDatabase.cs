﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.DataBase
{

    [Table("[gestao_reembolso].[AUTH_ROLE_SERVICE]")]
    [Serializable]
    public class AuthRoleServiceDatabase
    {
        [System.ComponentModel.DataAnnotations.Key]
        public int idRole { get; set; }
        public int idService { get; set; }
    }
}
