﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.DataBase
{
    [Table("[gestao_reembolso].[AUTH_ROLE]")]
    [Serializable]
    public class AuthRoleDatabase
    {
        [System.ComponentModel.DataAnnotations.Key]
        public int idRole { get; set; }
        public string roleName { get; set; }
    }
}
