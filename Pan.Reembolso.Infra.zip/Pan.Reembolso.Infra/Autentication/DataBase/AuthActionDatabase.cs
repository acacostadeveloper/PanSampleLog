﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.DataBase
{
    [Table("[gestao_reembolso].[AUTH_ACTION]")]
    [Serializable]
    public class AuthActionDatabase
    {
        public int idAction { get; set; }
        public string actionName { get; set; }
        public int idService { get; set; }
        public bool ativo { get; set; }
    }
}
