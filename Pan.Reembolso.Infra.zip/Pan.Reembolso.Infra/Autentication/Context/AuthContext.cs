﻿using System.Data.Entity;
using Pan.Reembolso.Infra.Autentication.DataBase;
using Pan.Reembolso.Infra.Autentication.Mapper;
using Pan.Reembolso.Infra.Log.Mapper;

namespace Pan.Reembolso.Infra.Autentication.Context
{
    public class AuthContext : DbContext 
    {
        public AuthContext() : base("name=PanReembolsoContext")
        {
            Database.SetInitializer<AuthContext>(null);
        }

        public virtual DbSet<AuthRoleDatabase> RoleRepository { get; set; }
        public virtual DbSet<AuthRoleServiceDatabase> RoleServicerepository { get; set; }
        public virtual DbSet<AuthServiceDatabase> ServiceRepository { get; set; }
        public virtual DbSet<AuthActionDatabase> ActionRepository { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new RoleMap());
            modelBuilder.Configurations.Add(new RoleServiceMap());
            modelBuilder.Configurations.Add(new ServiceMap());
            modelBuilder.Configurations.Add(new ActionMap());
        }
    }
}
