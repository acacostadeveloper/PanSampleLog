﻿using Pan.Reembolso.Infra.Autentication.Entidades;
using Pan.Reembolso.Infra.Autentication.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using Pan.Reembolso.Infra.Autentication.Interface;

namespace Pan.Reembolso.Infra.Autentication.Implementation
{

    public class AutenticationUserRepository : IAutenticationUserRepository
    {
        private AuthContext _contexto;

        public AutenticationUserRepository()
        {
            _contexto = new AuthContext();
        }

        public UserAuthorization AutenticationUser(string nome, List<string> roles)
        {
            var user = new UserAuthorization
            {
                nome = nome,
                roles = GetRoles(),
                timestamp = DateTime.Now
            };

            return user;
        }

        public List<RoleUser> GetRoles()
        {
            try
            {
                var resultItem = (from _roleservice in _contexto.RoleServicerepository
                                  join _role in _contexto.RoleRepository on _roleservice.idRole equals _role.idRole
                                  join _service in _contexto.ServiceRepository on _roleservice.idService equals _service.idService
                                  join _action in _contexto.ActionRepository on _service.idService equals _action.idService
                                  select new
                                  {
                                      role = _role,
                                      service = _service,
                                      action = _action
                                  })
                                  .GroupBy(s => new { s.role.idRole, s.service.idService })
                                  .Select(t => new
                                  {
                                      idRole = t.Key.idRole,

                                      idService = t.Key.idService,

                                      role = t.Select(v => v.role),

                                      service = t.Select(v => v.service),

                                      actions = t.Select(u => new ActionService
                                      {
                                          actionName = u.action.actionName,
                                          active = u.action.ativo
                                      }).ToList()

                                  })
                                  .GroupBy(v => new { v.idRole })

                                  .Select(x => new RoleUser
                                  {
                                      roleId = x.FirstOrDefault().role.FirstOrDefault().roleName,
                                      services = x.Select(v => new ServiceName
                                      {
                                          serviceName = v.service.FirstOrDefault().serviceName,
                                          actions = v.actions
                                      }).ToList()
                                  }).ToList();

                return resultItem;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }

}