﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.Entidades
{
    public class ActionService
    {
        public string actionName { get; set; }
        public bool active { get; set; }
    }
}
