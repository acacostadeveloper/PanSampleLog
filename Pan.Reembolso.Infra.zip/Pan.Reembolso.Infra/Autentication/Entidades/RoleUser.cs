﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.Entidades
{
    public class RoleUser
    {
        public RoleUser()
        {
            this.services = new List<ServiceName>();
        }

        public string roleId { get; set; }
        public IList<ServiceName> services { get; set; }
    }
}
