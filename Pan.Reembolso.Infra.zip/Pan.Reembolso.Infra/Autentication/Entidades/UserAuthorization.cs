﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.Entidades
{
    public class UserAuthorization
    {
        public UserAuthorization()
        {
            this.roles = new List<RoleUser>();
        }
        public string userId { get; set; }
        public string nome { get; set; }
        public IList<RoleUser> roles { get; set; }
        public DateTime? timestamp { get; set; }
    }
}
