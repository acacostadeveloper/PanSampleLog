﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Autentication.Entidades
{
    public class ServiceName
    {
        public ServiceName()
        {
            this.actions = new List<ActionService>();
        }
        public string serviceName { get; set; }
        public IList<ActionService> actions { get; set; }
    }
}
