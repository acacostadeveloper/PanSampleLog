﻿using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Interface
{
    public interface ILogRepository
    {
        void PersistirLog(Entidades.Log log);
        void PersistirLog(Entidades.LogConsoleApp log);
    }
}
