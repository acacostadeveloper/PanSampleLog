﻿using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Interface
{
    public interface ILogRepository
    {
        void PersistirLog(Pan.Reembolso.Entidades.Log log);
    }
}
