﻿using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Interface
{
    public interface ILogRepository
    {
        Task PersistirLog(Entidades.Log log);
        Task PersistirLog(Entidades.LogConsoleApp log);
    }
}
