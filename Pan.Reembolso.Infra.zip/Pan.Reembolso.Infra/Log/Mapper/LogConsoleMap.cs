﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Mapper
{
    public class LogConsoleMap: EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.LogConsoleDatabase>
    {
        public LogConsoleMap()
        {
            this.HasKey(t => t.LogId);
            this.Property(t => t.LogId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[dbo].[LogsReembolsoConsoleApp]");
            this.Property(t => t.LogId).HasColumnName("LogId");
            this.Property(t => t.BatchTask).HasColumnName("BatchTask");
            this.Property(t => t.Application).HasColumnName("Application");
            this.Property(t => t.Machine).HasColumnName("Machine");
            this.Property(t => t.IpAddress).HasColumnName("IpAddress");
            this.Property(t => t.Timestamp).HasColumnName("Timestamp");
            this.Property(t => t.TextLog).HasColumnName("TextLog");
            this.Property(t => t.MessageError).HasColumnName("MessageError");
        }
}
}
