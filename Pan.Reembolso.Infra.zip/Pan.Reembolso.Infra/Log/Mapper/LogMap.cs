﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Mapper
{
    public class LogMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.LogDatabase>
    {
        public LogMap()
        {
            this.HasKey(t => t.LogId);
            this.Property(t => t.LogId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[dbo].[LogsReembolsoWebAPI]");
            this.Property(t => t.LogId).HasColumnName("LogId");
            this.Property(t => t.Application).HasColumnName("Application");
            this.Property(t => t.CorrelationId).HasColumnName("CorrelationId");
            this.Property(t => t.Machine).HasColumnName("Machine");
            this.Property(t => t.IpAddress).HasColumnName("IpAddress");
            this.Property(t => t.RequestUri).HasColumnName("RequestUri");
            this.Property(t => t.StatusCode).HasColumnName("StatusCode");
            this.Property(t => t.RequestTimestamp).HasColumnName("RequestTimestamp");
            this.Property(t => t.ResponseTimestamp).HasColumnName("ResponseTimestamp");
            this.Property(t => t.TotalTime).HasColumnName("TotalTime");
            this.Property(t => t.JsonLog).HasColumnName("JsonLog");
            this.Property(t => t.MessageError).HasColumnName("MessageError");
        }
    }
}
