﻿using Newtonsoft.Json;
using Pan.Reembolso.Infra.Log.Context;
using Pan.Reembolso.Infra.Log.Interface;
using System.Data.Entity;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Implementation
{
    public class LogRepository : ILogRepository
    {
        private readonly LogContext _contexto;

        public LogRepository()
        {
            _contexto = new LogContext();
        }

        public async Task PersistirLog(Entidades.Log log)
        {
            log.JsonLog = JsonConvert.SerializeObject(log.JsonLog);

            Entidades.DatabaseEntities.LogDatabase itemLog = new Entidades.DatabaseEntities.LogDatabase
            {
                LogId = log.LogId,
                Application = log.Application,
                CorrelationId = log.CorrelationId,
                Machine = log.Machine,
                IpAddress = log.IpAddress,
                RequestUri = log.RequestUri,
                StatusCode = log.StatusCode,
                RequestTimestamp = log.RequestTimestamp,
                ResponseTimestamp = log.ResponseTimestamp,
                TotalTime = log.TotalTime,
                JsonLog = log.JsonLog,
                MessageError = log.MessageError
            };

            _contexto.LogRepository.Add(itemLog);

            _contexto.SaveChanges();
        }

        public async Task PersistirLog(Entidades.LogConsoleApp log)
        {
            Entidades.DatabaseEntities.LogConsoleDatabase itemLog = new Entidades.DatabaseEntities.LogConsoleDatabase
            {
                LogId = log.LogId,
                Application = log.Application,
                Machine = log.Machine,
                IpAddress = log.IpAddress,
                MessageError = log.MessageError,
                BatchTask = log.BatchTask,
                Timestamp = log.Timestamp,
                TextLog = log.TextLog 
            };

            _contexto.LogConsoleRepository.Add(itemLog);

            _contexto.SaveChanges();
        }

    }
}
