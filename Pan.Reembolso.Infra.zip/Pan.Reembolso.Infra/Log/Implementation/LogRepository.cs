﻿using Pan.Reembolso.Infra.Log.Context;
using Pan.Reembolso.Infra.Log.Interface;

namespace Pan.Reembolso.Infra.Log.Implementation
{
    public class LogRepository : ILogRepository
    {
        private readonly LogContext _contexto;

        public LogRepository()
        {
            _contexto = new LogContext();
        }

        public void PersistirLog(Entidades.Log log)
        {
            _contexto.Set<Entidades.Log>().Add(log);
            _contexto.SaveChanges();
        }
    }
}
