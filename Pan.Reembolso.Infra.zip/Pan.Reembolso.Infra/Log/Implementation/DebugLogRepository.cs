﻿using Newtonsoft.Json;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Infra.Log.Interface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Infra.Log.Implementation
{
    public class DebugLogRepository : ILogRepository
    {
        public async Task PersistirLog(Entidades.Log log)
        {
            Debug.Write(JsonConvert.SerializeObject(log, Formatting.Indented));
        }

        public async Task PersistirLog(Entidades.LogConsoleApp log)
        {
            // not implemented; 
        }

    }
}
