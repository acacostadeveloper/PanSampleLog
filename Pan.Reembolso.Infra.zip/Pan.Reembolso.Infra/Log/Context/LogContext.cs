﻿using System.Data.Entity;
using Pan.Reembolso.Infra.Log.Mapper;

namespace Pan.Reembolso.Infra.Log.Context
{
    public class LogContext : DbContext 
    {
        public LogContext() : base("name=LogContext")
        {
            Database.SetInitializer<LogContext>(null);
        }

        public virtual DbSet<Entidades.DatabaseEntities.LogDatabase> LogRepository { get; set; }
        public virtual DbSet<Entidades.DatabaseEntities.LogConsoleDatabase> LogConsoleRepository { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new LogMap());
            modelBuilder.Configurations.Add(new LogConsoleMap());
        }
    }
}
