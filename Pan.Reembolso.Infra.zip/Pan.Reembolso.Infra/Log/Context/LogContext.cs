﻿using Pan.Reembolso.Infra.Log.Mapper;
using System.Data.Entity;

namespace Pan.Reembolso.Infra.Log.Context
{
    public class LogContext : DbContext 
    {
        public LogContext() : base("name=LogContext") {}

        public DbSet<Entidades.DatabaseEntities.LogDatabase> LogRepository { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Pan.Reembolso.Entidades.Log>()
                .ToTable("ReebolsoApiLog");
        }
    }
}
