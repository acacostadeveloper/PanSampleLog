const proxy = [
    {
      context: '/api'
      ,target: 'http://localhost:22665'
      ,pathRewrite: {'^/api' : ''}
    }
  ];
  module.exports = proxy;