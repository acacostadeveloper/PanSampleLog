﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Agente.Interface
{
    public interface IGraficaLobApp
    {
        IDictionary<string, string> RequisitarTransferenciaEletronica(GraficaEnvio graficaEnvio);
    }
}
