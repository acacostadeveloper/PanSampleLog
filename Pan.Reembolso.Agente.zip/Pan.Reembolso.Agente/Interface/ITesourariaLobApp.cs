﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Agente.Interface
{
    public interface ITesourariaLobApp
    {
        IDictionary<string, string> RequisitarTransferenciaEletronica(MensagemTransferencia mensagemTransferencia);
        IDictionary<string, string> ConsultarTransferenciaEletronica(MensagemTransferencia mensagemTransferencia);
        IList<DevolucaoSPB> ObterDevolucaoSPB(string sistemaOrigem, int quantidadeDias);
    }
}
