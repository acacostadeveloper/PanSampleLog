﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Interface
{
    public interface IConsorcioLobApp
    {
        void ObterContrato(Pan.Reembolso.Entidades.Contrato contrato);
    }
}
