﻿using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Interface
{
    public interface ISmsLobApp
    {
        Task<Entidades.SMSRespostaEnvio> SendSMS(string cpfCnpj, string tipoPessoa, string numeroTelefone, string nomeDestinatario);
        Task<Entidades.RespostaSMS> SMSResposta(string protocolo);
    }
}