﻿using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Agente.Interface;

namespace Pan.Reembolso.Agente.Implementation
{
    public class ContabilLobApp : IContabilLobApp
    {
        public string ObterHistoricoModelo(string modelo)
        {
            string historico = string.Empty;

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABContabilidade"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(ContabilidadeSql.historicoContabil, modelo.PadLeft(5,'0'));
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {
                        historico = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                    }
                }
            }

            return historico;
        }

        public IDictionary<string, string> IntegrarMovimentoContabil(MovimentoContabil movimento)
        {
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABContabilidade"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "SP_IWF_999AUTBANK";

                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@PROCESSO_ENT", movimento.movimentoPadrao.codigoProcesso);
                cmd.Parameters.AddWithValue("@REGISTRO_ENT", movimento.numeroRegistro);
                cmd.Parameters.AddWithValue("@LAYOUT_ENT", movimento.movimentoPadrao.codigoLayout);
                cmd.Parameters.AddWithValue("@CODCOLIGADA_ENT", movimento.movimentoPadrao.codigoColigada);
                cmd.Parameters.AddWithValue("@DTASISTEMA_ENT", movimento.dataSistema);
                cmd.Parameters.AddWithValue("@CODSISTEMA_ENT", movimento.movimentoPadrao.codigoSistema);
                cmd.Parameters.AddWithValue("@REMESSA_ENT", movimento.numeroRemessa);
                cmd.Parameters.AddWithValue("@NSUORIGEM_ENT", movimento.numeroOrigem);
                cmd.Parameters.AddWithValue("@SEQCIAORIGEM_ENT", movimento.movimentoPadrao.numeroSequenciaOrigem);
                cmd.Parameters.AddWithValue("@EMPORIGEM_ENT", movimento.movimentoPadrao.codigoEmpresaOrigem);
                cmd.Parameters.AddWithValue("@CODAGENCIA_ENT", movimento.movimentoPadrao.codigoAgencia);
                cmd.Parameters.AddWithValue("@UNIDADE_ENT", movimento.movimentoPadrao.codigoUnidade);
                cmd.Parameters.AddWithValue("@NIVEL1_ENT", movimento.movimentoPadrao.codigoNivel1);
                cmd.Parameters.AddWithValue("@NIVEL2_ENT", movimento.movimentoPadrao.codigoNivel2);
                cmd.Parameters.AddWithValue("@NIVEL3_ENT", movimento.movimentoPadrao.codigoNivel3);
                cmd.Parameters.AddWithValue("@NIVEL4_ENT", movimento.movimentoPadrao.codigoNivel4);
                cmd.Parameters.AddWithValue("@DTALANCTO_ENT", movimento.dataLancamento);
                cmd.Parameters.AddWithValue("@DEBITACREDITA_ENT", movimento.movimentoPadrao.codigoCreditaDebita);
                cmd.Parameters.AddWithValue("@VALOR_ENT", movimento.valorEntrada); 
                cmd.Parameters.AddWithValue("@AGEDESTINO_ENT", movimento.movimentoPadrao.codigoAgenciaDestino);
                cmd.Parameters.AddWithValue("@NIVEL1DESTINO_ENT", movimento.movimentoPadrao.codigoNivel1Destino);
                cmd.Parameters.AddWithValue("@NIVEL2DESTINO_ENT", movimento.movimentoPadrao.codigoNivel2Destino);
                cmd.Parameters.AddWithValue("@NIVEL3DESTINO_ENT", movimento.movimentoPadrao.codigoNivel3Destino);
                cmd.Parameters.AddWithValue("@NIVEL4DESTINO_ENT", movimento.movimentoPadrao.codigoNivel4Destino);
                cmd.Parameters.AddWithValue("@UNIDADEDESTINO_ENT", movimento.movimentoPadrao.codigoUnidadeDestino);
                cmd.Parameters.AddWithValue("@HISTORICO_ENT", movimento.descricaoHistorico);
                cmd.Parameters.AddWithValue("@COMPLEMENTO1_ENT", movimento.descricaoComplemento1);
                cmd.Parameters.AddWithValue("@COMPLEMENTO2_ENT", movimento.movimentoPadrao.descricaoComplemento2);
                cmd.Parameters.AddWithValue("@COMPLEMENTO3_ENT", movimento.movimentoPadrao.descricaoComplemento3);
                cmd.Parameters.AddWithValue("@COMPLEMENTO4_ENT", movimento.movimentoPadrao.descricaoComplemento4);
                cmd.Parameters.AddWithValue("@COMPLEMENTO5_ENT", movimento.movimentoPadrao.descricaoComplemento5);
                cmd.Parameters.AddWithValue("@FORMALANCTO_ENT", movimento.movimentoPadrao.codigoFormaLancamento);
                cmd.Parameters.AddWithValue("@TPOLANCTO_ENT", movimento.movimentoPadrao.codigoTipoLancamento);
                cmd.Parameters.AddWithValue("@EVENTO_ENT", movimento.movimentoPadrao.codigoEvento);
                cmd.Parameters.AddWithValue("@MODELO_ENT", movimento.numeroModelo);
                cmd.Parameters.AddWithValue("@SEQCIAITEM_ENT", movimento.movimentoPadrao.numeroSequenciaItem);
                cmd.Parameters.AddWithValue("@TABELA_DB_ENT", movimento.movimentoPadrao.nomeTabelaDebito);
                cmd.Parameters.AddWithValue("@CODCCUSTO_DB_ENT", movimento.numeroCentroCustoDebito);
                cmd.Parameters.AddWithValue("@CODPRODUTO_DB_ENT", movimento.movimentoPadrao.codigoProdutoDebito);
                cmd.Parameters.AddWithValue("@TIPOCREDITO_DB_ENT", movimento.movimentoPadrao.codigoTipoCreditoDebito);
                cmd.Parameters.AddWithValue("@CODATIVIDADE_DB_ENT", movimento.movimentoPadrao.codigoAtividadeDebito);
                cmd.Parameters.AddWithValue("@TPOCONTA_DB_ENT", movimento.movimentoPadrao.codigoTipoContaDebito);
                cmd.Parameters.AddWithValue("@CONTA_DB_ENT", movimento.movimentoPadrao.codigoTipoContaDebito);
                cmd.Parameters.AddWithValue("@REDUZIDO_DB_ENT", movimento.movimentoPadrao.codigoReduzidoDebito);
                cmd.Parameters.AddWithValue("@CTAAUXILIAR_DB_ENT", movimento.movimentoPadrao.numeroContaAuxiliarDebito);
                cmd.Parameters.AddWithValue("@CTACORRENTE_DB_ENT", movimento.movimentoPadrao.numeroContaCorrenteDebito);
                cmd.Parameters.AddWithValue("@TABELA_CR_ENT", movimento.movimentoPadrao.nomeTabelaCredito);
                cmd.Parameters.AddWithValue("@CODCCUSTO_CR_ENT", movimento.numeroCentroCustoCredito);
                cmd.Parameters.AddWithValue("@CODPRODUTO_CR_ENT", movimento.movimentoPadrao.codigoProdutoCredito);
                cmd.Parameters.AddWithValue("@TIPOCREDITO_CR_ENT", movimento.movimentoPadrao.codigoTipoCreditoCredito);
                cmd.Parameters.AddWithValue("@CODATIVIDADE_CR_ENT", movimento.movimentoPadrao.codigoAtividadeCredito);
                cmd.Parameters.AddWithValue("@TPOCONTA_CR_ENT", movimento.movimentoPadrao.codigoTipoContaCredito);
                cmd.Parameters.AddWithValue("@CONTA_CR_ENT", movimento.movimentoPadrao.numeroContaCredito);
                cmd.Parameters.AddWithValue("@REDUZIDO_CR_ENT", movimento.movimentoPadrao.codigoReduzidoCredito);
                cmd.Parameters.AddWithValue("@CTAAUXILIAR_CR_ENT", movimento.movimentoPadrao.numeroContaAuxiliarCredito);
                cmd.Parameters.AddWithValue("@CTACORRENTE_CR_ENT", movimento.movimentoPadrao.numeroContaCorrenteCredito);
                cmd.Parameters.AddWithValue("@TPOMOEDA_ENT", movimento.movimentoPadrao.codigoTipoMoeda);
                cmd.Parameters.AddWithValue("@QTDDEMOEDA_ENT", Decimal.Parse(movimento.movimentoPadrao.quantidadeMoeda)); 
                cmd.Parameters.AddWithValue("@VALORMOEDA_ENT", Decimal.Parse(movimento.movimentoPadrao.valorMoeda)); 
                cmd.Parameters.AddWithValue("@INDREPROCESSAMENTO_ENT", movimento.movimentoPadrao.indicadorReprocessamento);
                cmd.Parameters.AddWithValue("@CODGERENTE_ENT", movimento.movimentoPadrao.codigoGerente);
                cmd.Parameters.AddWithValue("@NUMERODOCTO_ENT", movimento.movimentoPadrao.numeroDocumento);
                cmd.Parameters.AddWithValue("@DTADOCTO_ENT", movimento.dataDocumento);
                cmd.Parameters.AddWithValue("@INDATUALIZADO_ENT", movimento.movimentoPadrao.indicadorAtualizado);
                cmd.Parameters.AddWithValue("@INDCANCELADO_ENT", movimento.movimentoPadrao.indicadorCancelado);
                cmd.Parameters.AddWithValue("@INDESTORNADO_ENT", movimento.movimentoPadrao.indicadorEstornado);
                cmd.Parameters.AddWithValue("@DTAULTATUALIZACAO_ENT", movimento.dataUltimaAtualizacao);
                cmd.Parameters.AddWithValue("@LOGINUSUARIO_ENT", movimento.codigoUsuario);
                cmd.Parameters.AddWithValue("@ARQUIVO_INTEGRADO_ENT", movimento.nomeArquivoIntegrado);

                cmd.Parameters.Add(new SqlParameter { ParameterName = "@ERRO_SUCESSO", Direction = ParameterDirection.Output, Size = 8 });
                cmd.Parameters.Add(new SqlParameter { ParameterName = "@MENSAGEM", Direction = ParameterDirection.Output, Size = 100 });

                cmd.ExecuteNonQuery();

                var erroSucesso = cmd.Parameters["@ERRO_SUCESSO"].Value;
                var mensagem = cmd.Parameters["@MENSAGEM"].Value;

                IDictionary<string, string> retProc = new Dictionary<string, string>();

                retProc.Add("erroSucesso",erroSucesso.ToString());
                retProc.Add("mensagem", mensagem.ToString());

                return retProc;
            }
        }
    }
}
