﻿using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Agente.Interface;
using System.Xml;

namespace Pan.Reembolso.Agente.Implementation
{
    public class GraficaLobApp : IGraficaLobApp
    {
        //public static void ObterDadosBancarios(List<ContaCredito> contas, string cpfCnpj)
        //{
        //    using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
        //    {
        //        con.Open();
        //        SqlCommand cmd = con.CreateCommand();
        //        cmd.CommandText = String.Format(TesourariaSql.clienteDadosBancarios, cpfCnpj);
        //        using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
        //        {
        //            if (rdr.Read())
        //            {
        //                contas.Add(ObterContaCredito(rdr));
        //            }
        //        }
        //    }
        //}

        public IDictionary<string, string> RequisitarTransferenciaEletronica(GraficaEnvio graficaEnvio)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(docNode);

                XmlNode rootNode = doc.CreateElement("root");

                XmlNode entryNode = doc.CreateElement("carta");

                WriteXmlNode(doc, entryNode, "identificador", graficaEnvio.identificador?? "");
                WriteXmlNode(doc, entryNode, "nome", graficaEnvio.nome ?? "");
                WriteXmlNode(doc, entryNode, "logradouro", graficaEnvio.logradouro ?? "");
                WriteXmlNode(doc, entryNode, "numero", graficaEnvio.numero ?? "");
                WriteXmlNode(doc, entryNode, "complemento", graficaEnvio.complemento ?? "");
                WriteXmlNode(doc, entryNode, "bairro", graficaEnvio.bairro ?? "");
                WriteXmlNode(doc, entryNode, "cep", graficaEnvio.cep ?? "");
                WriteXmlNode(doc, entryNode, "cidade", graficaEnvio.cidade ?? "");
                WriteXmlNode(doc, entryNode, "estado", graficaEnvio.estado ?? "");
                
                rootNode.AppendChild(entryNode);
                doc.AppendChild(rootNode);

                var request = new WSTesouraria.gerarRequisicaoRequestBody(doc.InnerXml);
                var result = new WSTesouraria.gerarRequisicaoRequest(request);

                IDictionary<string, string> returnData = new Dictionary<string, string>();

                XmlDocument xmlResult = new XmlDocument();
                xmlResult.LoadXml(result.Body.xml);

                if (doc.GetElementsByTagName("NroRequisicao").Count > 0)
                {
                    returnData.Add("numeroRequisicao", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("erroSucesso", "SUCESSO");
                    returnData.Add("mensagem", "Requisição enviada com sucesso.");
                }

                if (doc.GetElementsByTagName("Erro").Count > 0)
                {
                    returnData.Add("numeroRequisicao", "");
                    returnData.Add("erroSucesso", "ERRO");
                    returnData.Add("mensagem", doc.GetElementsByTagName("Erro").Item(0).InnerText);
                }

                return returnData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void WriteXmlNode(XmlDocument doc, XmlNode entryNode, string name, string value)
        {
            XmlNode createdNode = doc.CreateElement(name);

            if(value != String.Empty)
                createdNode.AppendChild(doc.CreateTextNode(value));

            entryNode.AppendChild(createdNode);
        }

        private static ContaCredito ObterContaCredito(SqlDataReader rdr)
        {
            var contaCredito = new Entidades.ContaCredito();
            contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
            contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
            contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
            contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
            contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
            contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
            return contaCredito;
        }
    }
}
