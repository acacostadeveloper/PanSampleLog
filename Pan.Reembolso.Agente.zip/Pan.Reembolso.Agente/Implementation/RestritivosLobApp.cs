﻿using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation
{
    public class RestritivosLobApp
    {

        public static List<ContaCredito> CheckBlackList(ContaCredito contaCredito)
        {
            var blackListAccounts = new List<Entidades.ContaCredito>();

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["PanRestritivos"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(RestritivosSql.blackList, contaCredito.numeroBanco, contaCredito.numeroAgencia, contaCredito.numeroConta);

                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {

                        contaCredito.Erro = (rdr.IsDBNull(7) ? "" : rdr.GetString(7).Trim());
                        contaCredito.valida = false;

                        blackListAccounts.Add(contaCredito);
                    }
                }
            }

            return blackListAccounts;
        }

        private static ContaCredito ObterContaCredito(SqlDataReader rdr)
        {
            var contaCredito = new Entidades.ContaCredito();
            contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
            contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
            contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
            contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
            contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
            contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
            return contaCredito;
        }


    }
}
