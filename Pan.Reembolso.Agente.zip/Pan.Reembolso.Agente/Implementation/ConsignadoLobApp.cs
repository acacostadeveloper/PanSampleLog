﻿using System;
using Pan.Reembolso.Agente.Interface;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System.Collections.Generic;
using System.Linq;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Agente.Implementation
{
    public class ConsignadoLobApp : IConsignadoLobApp
    {
        private void ObterDadosContrato(Contrato contrato,bool buscarConvenio)
        {
            string nrcontrato = string.Empty;
            DateTime? dataStatus;
            string contratoEstornado = string.Empty;
            string historicoLiquidacao = string.Empty;
            string historicoFinanceiro = string.Empty;
            string codigoHistoricofinanceiro  = string.Empty;

            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.dadosContrato, contrato.numeroContrato);
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            nrcontrato = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                            dataStatus = !rdr.IsDBNull(1) ? ((Nullable<DateTime>)rdr.GetDateTime(1)) : null;
                            contratoEstornado = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
                            historicoLiquidacao = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
                            if (buscarConvenio)
                            {
                                contrato.convenio = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
                            }
                            
                            contrato.dataStatus = dataStatus;
                            contrato.statusContrato = VerificaStatusContrato(contratoEstornado, contrato.dataStatus);
                        }
                        else
                        {
                            contrato.statusContrato = StatusContratoType.ContratoNaoEncontrado.ToString();
                        }
                    }
                }

                if (contrato.dataStatus != null)
                {
                    using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                    {
                        con.Open();
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandText = String.Format(FuncaoConsignadoSql.contratoHistoricoFinanceiro, contrato.numeroContrato);
                        using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                        {
                            if (rdr.Read())
                            {
                                nrcontrato = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                                historicoFinanceiro = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
                                codigoHistoricofinanceiro = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
                            }

                            contrato.historicoFinanceiro = new HistoricoFinanceiro
                            {
                                codigoHistoricoFinanceiro = Convert.ToInt16(codigoHistoricofinanceiro),
                                motivo = historicoFinanceiro,
                                origemInformacao = ReembolsoConstantes.ORIGEM_PANCRED
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ObterCliente(Entidades.Contrato contrato) 
        {
            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.clienteEndereco, contrato.numeroContrato);
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            contrato.cliente.nomeCliente             = (rdr.IsDBNull(0)  ? "" : rdr.GetString(0).Trim());
                            contrato.cliente.numeroCpfCnpj           = (rdr.IsDBNull(1)  ? "" : rdr.GetString(1).Trim());
                            contrato.cliente.tipoPessoa              = (rdr.IsDBNull(2)  ? "" : rdr.GetString(2).Trim());
                            contrato.cliente.numeroDDDFixo           = (rdr.IsDBNull(3)  ? "" : rdr.GetString(3).Trim());
                            contrato.cliente.numeroFixo              = (rdr.IsDBNull(4)  ? "" : rdr.GetString(4)).Trim();
                            contrato.cliente.numeroDDDCelular        = (rdr.IsDBNull(5)  ? "" : rdr.GetString(5).Trim());
                            contrato.cliente.numeroCelular           = (rdr.IsDBNull(6)  ? "" : rdr.GetString(6).Trim());
                            contrato.cliente.endereco.nomeLogradouro = (rdr.IsDBNull(7)  ? "" : rdr.GetString(7).Trim());
                            contrato.cliente.endereco.numero         = (rdr.IsDBNull(8)  ? "" : rdr.GetString(8).Trim());
                            contrato.cliente.endereco.complemento    = (rdr.IsDBNull(9)  ? "" : rdr.GetString(9).Trim());
                            contrato.cliente.endereco.bairro         = (rdr.IsDBNull(10) ? "" : rdr.GetString(10).Trim());
                            contrato.cliente.endereco.cidade         = (rdr.IsDBNull(11) ? "" : rdr.GetString(11).Trim());
                            contrato.cliente.endereco.estado         = (rdr.IsDBNull(12) ? "" : rdr.GetString(12).Trim());
                            contrato.cliente.endereco.cep            = (rdr.IsDBNull(13) ? "" : rdr.GetString(13).Trim());
                        }
                        else
                        {
                            contrato.statusContrato = StatusContratoType.ClienteNaoEncontrado.ToString();
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        private void ObterClienteNaoIntegrado(Entidades.Contrato contrato)
        {
            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.clienteEnderecoNaoIntegrado, contrato.numeroContrato);
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            contrato.cliente.nomeCliente = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                            contrato.cliente.numeroCpfCnpj = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
                            contrato.cliente.tipoPessoa = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
                            contrato.cliente.numeroDDDFixo = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
                            contrato.cliente.numeroFixo = (rdr.IsDBNull(4) ? "" : rdr.GetString(4)).Trim();
                            contrato.cliente.numeroDDDCelular = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
                            contrato.cliente.numeroCelular = (rdr.IsDBNull(6) ? "" : rdr.GetString(6).Trim());
                            contrato.cliente.endereco.nomeLogradouro = (rdr.IsDBNull(7) ? "" : rdr.GetString(7).Trim());
                            contrato.cliente.endereco.numero = (rdr.IsDBNull(8) ? "" : rdr.GetString(8).Trim());
                            contrato.cliente.endereco.complemento = (rdr.IsDBNull(9) ? "" : rdr.GetString(9).Trim());
                            contrato.cliente.endereco.bairro = (rdr.IsDBNull(10) ? "" : rdr.GetString(10).Trim());
                            contrato.cliente.endereco.cidade = (rdr.IsDBNull(11) ? "" : rdr.GetString(11).Trim());
                            contrato.cliente.endereco.estado = (rdr.IsDBNull(12) ? "" : rdr.GetString(12).Trim());
                            contrato.cliente.endereco.cep = (rdr.IsDBNull(13) ? "" : rdr.GetString(13).Trim());
                        }
                        else
                        {
                            contrato.statusContrato = StatusContratoType.ClienteNaoEncontrado.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ObterDadosBancarios(Entidades.Contrato contrato) 
        {
            var contas = new List<Entidades.ContaCredito>();

            try 
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.clienteDadosBancarios, contrato.numeroContrato, contrato.cliente.numeroCpfCnpj) ;
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            contas.Add(ObterContaCredito(rdr));
                        }
                    }
                }

                if (!contas.Any())
                {
                    TesourariaLobApp.ObterDadosBancarios(contas, contrato.cliente.numeroCpfCnpj);
                }

                if (contas.Any())
                {
                    contrato.cliente.contaCredito = VerificarContaFraudada(contas);
                }
            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        private static ContaCredito ObterContaCredito(SqlDataReader rdr)
        {
            var contaCredito = new Entidades.ContaCredito();
            contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
            contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
            contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
            contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
            contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
            contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
            return contaCredito;
        }

        private void ObterRegistroObito(Entidades.Contrato contrato)
        {
            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["Pangestor"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.clienteRegistroObito, contrato.numeroContrato);
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            contrato.cliente.registroObito = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                            contrato.cliente.obito = !string.IsNullOrEmpty(contrato.cliente.registroObito);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.ContaCredito VerificarContaFraudada(List<Entidades.ContaCredito> contas)
        {
            var result = contas.FirstOrDefault();

            if (contas.Any())
            {
            }

            return result;
        }

        private string VerificaStatusContrato(string estornada, DateTime? dataStatus)
        {
            StatusContratoType result;

            result = dataStatus == null ? StatusContratoType.Aberto :
                     estornada == "SIM" ? StatusContratoType.Estornado : StatusContratoType.Liquidado;

            return result.ToString();
        }

        public void ObterContrato(Entidades.Contrato contrato,bool buscarConvenio)
        {
            if (contrato.statusContrato != Entidades.ImplementationTypes.ReembolsoTypes.StatusContratoType.NaoIntegrado.ToString())
            {
                this.ObterDadosContrato(contrato,buscarConvenio);

                this.ObterRegistroObito(contrato);

                this.ObterCliente(contrato);
            }
            else
            {
                this.ObterClienteNaoIntegrado(contrato);
            }

            this.ObterDadosBancarios(contrato);
        }

    }
}
