﻿using System;
using Pan.Reembolso.Agente.Interface;
using System.Data;
using System.Data.SqlClient;
using System.Configuration; 
using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;

namespace Pan.Reembolso.Agente.Implementation
{
    public class ConsignadoLobApp : IConsignadoLobApp
    {
        private void ObterCliente(Entidades.Contrato contrato) 
        {
            try
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.clienteEndereco, contrato.numeroContrato);
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            contrato.cliente.nomeCliente = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                            contrato.cliente.numeroCpfCnpj = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
                            contrato.cliente.tipoPessoa = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
                            contrato.cliente.numeroDDDFixo = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
                            contrato.cliente.numeroFixo = (rdr.IsDBNull(4) ? "" : rdr.GetString(4)).Trim();
                            contrato.cliente.numeroDDDCelular = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
                            contrato.cliente.numeroCelular = (rdr.IsDBNull(6) ? "" : rdr.GetString(6).Trim());
                            contrato.cliente.endereco.nomeLogradouro = (rdr.IsDBNull(7) ? "" : rdr.GetString(7).Trim());
                            contrato.cliente.endereco.numero = (rdr.IsDBNull(8) ? "" : rdr.GetString(8).Trim());
                            contrato.cliente.endereco.complemento = (rdr.IsDBNull(9) ? "" : rdr.GetString(9).Trim());
                            contrato.cliente.endereco.bairro = (rdr.IsDBNull(10) ? "" : rdr.GetString(10).Trim());
                            contrato.cliente.endereco.cidade = (rdr.IsDBNull(11) ? "" : rdr.GetString(11).Trim());
                            contrato.cliente.endereco.estado = (rdr.IsDBNull(12) ? "" : rdr.GetString(12).Trim());
                            contrato.cliente.endereco.cep = (rdr.IsDBNull(13) ? "" : rdr.GetString(13).Trim());
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        private void ObterDadosBancarios(Entidades.Contrato contrato) 
        {
            try 
            {
                using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["FuncaoConsignado"].ConnectionString))
                {
                    con.Open();
                    SqlCommand cmd = con.CreateCommand();
                    cmd.CommandText = String.Format(FuncaoConsignadoSql.clienteDadosBancarios, contrato.numeroContrato, contrato.cliente.numeroCpfCnpj) ;
                    using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                    {
                        if (rdr.Read())
                        {
                            contrato.cliente.contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                            contrato.cliente.contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
                            contrato.cliente.contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
                            contrato.cliente.contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
                            contrato.cliente.contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
                            contrato.cliente.contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
                        }
                    }
                }

                if (contrato.cliente.contaCredito == null) 
                { 
                    using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
                    {
                        con.Open();
                        SqlCommand cmd = con.CreateCommand();
                        cmd.CommandText = String.Format(TesourariaSql.clienteDadosBancarios, contrato.cliente.numeroCpfCnpj);
                        using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                        {
                            if (rdr.Read())
                            {
                                contrato.cliente.contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
                                contrato.cliente.contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
                                contrato.cliente.contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
                                contrato.cliente.contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
                                contrato.cliente.contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
                                contrato.cliente.contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
                            }
                        }
                    }
                }
            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        public void ObterContrato(Entidades.Contrato contrato)
        {
            this.ObterCliente(contrato);
            this.ObterDadosBancarios(contrato);
        }
    }
}
