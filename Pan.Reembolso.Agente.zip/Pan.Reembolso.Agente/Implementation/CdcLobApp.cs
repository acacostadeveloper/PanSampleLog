﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Agente.Interface;
using System.Data;
using System.Data.SqlClient;
using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using RestSharp;

namespace Pan.Reembolso.Agente.Implementation
{

    public class CdcLobApp : ICdcLobApp
    {
        private void ObterCliente(Pan.Reembolso.Entidades.Contrato contrato)
        {
            var client = new RestClient("http://veiculoshml-api.bancopan.com.br");
            var request = new RestRequest("/clientes/obterCliente/{documento}", Method.GET);
            request.AddHeader("Content-Type", "application/json");
            request.AddHeader("Authorization", "214C67783BE14D819A32F18F2C93EA0A");
            request.AddUrlSegment("documento", contrato.cliente.numeroCpfCnpj);
            var cliente = client.Execute<Pan.Reembolso.Entidades.CdcEntities.Cliente>(request);

            if (cliente.StatusCode == System.Net.HttpStatusCode.OK)
            {
                contrato.cliente.nomeCliente = cliente.Data.nome;
                contrato.cliente.tipoPessoa = cliente.Data.pessoaTipo;
                contrato.cliente.numeroDDDFixo = cliente.Data.telefones.Where(x => x.tipo == "Telefone").FirstOrDefault().ddd;
                contrato.cliente.numeroFixo = cliente.Data.telefones.Where(x => x.tipo == "Telefone").FirstOrDefault().numero.ToString();
                contrato.cliente.numeroDDDCelular = cliente.Data.telefones.Where(x => x.tipo == "Celular").FirstOrDefault().ddd;
                contrato.cliente.numeroCelular = cliente.Data.telefones.Where(x => x.tipo == "Celular").FirstOrDefault().numero.ToString();
                contrato.cliente.endereco.nomeLogradouro = cliente.Data.endereco.logradouro;
                contrato.cliente.endereco.numero = cliente.Data.endereco.numero;
                contrato.cliente.endereco.complemento = cliente.Data.endereco.complemento;
                contrato.cliente.endereco.bairro = cliente.Data.endereco.bairro;
                contrato.cliente.endereco.cidade = cliente.Data.endereco.cidade;
                contrato.cliente.endereco.estado = cliente.Data.endereco.uf;
                contrato.cliente.endereco.cep = cliente.Data.endereco.cep;
                this.ObterDadosBancarios(contrato, cliente.Data);
            }
        }

        private void ObterDadosBancarios(Pan.Reembolso.Entidades.Contrato contrato, Pan.Reembolso.Entidades.CdcEntities.Cliente cliente)
        {
            // verificar se existem dados no NPV


            // se não houver tenta o Gestão tesouraria



            // senão inicia o fluxo de comunicação com o cliente 

            contrato.cliente.contaCredito.numeroBanco = "";
            contrato.cliente.contaCredito.numeroAgencia = "";
            contrato.cliente.contaCredito.digitoAgencia = "";
            contrato.cliente.contaCredito.numeroConta = "";
            contrato.cliente.contaCredito.digitoConta = "";

        }

        public void ObterContrato(Pan.Reembolso.Entidades.Contrato contrato)
        {
            // Todo: dados relevantes do contrato 
            this.ObterCliente(contrato);
        }

    }
}
