﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries
{
    public static class TesourariaSql
    {
        internal readonly static string clienteDadosBancarios = "SELECT TOP 1 CODBANCOFAV AS BANCO, CODAGENCIAFAV AS AGENCIA, NULL AS DIGITO_AGENCIA, CODCONTAFAV AS CONTA, NULL AS DIGITO_CONTA, R.TIPOCONTAFAV AS TIPO_CONTA FROM REQUISICOES R WITH(NOLOCK) WHERE CGCFAV IN('{0}') AND STATUS = 'E' ORDER BY DATALIQUIDACAO DESC";
    }
}
