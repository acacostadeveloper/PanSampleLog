﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries
{
    internal static class FuncaoConsignadoSql
    {
        internal readonly static string clienteEndereco = "SELECT CLNOMECLI AS NOME_CLIENTE, REPLACE(REPLACE(REPLACE(CLCGC,'.',''),'-',''),'/','') AS CPF_CNPJ, CLTPFJ AS TIPO_PESSOA, CLDDDFIS AS DDD_FIXO, CLFONEFIS AS NUMERO_FIXO, CLDDDCEL AS DDD_CEL, CLCELULAR AS NUMERO_CEL, CLENDFIS AS NOME_LOGRADOURO, CLNRENDFIS AS NUMERO_ENDERECO, CLCMPTFIS AS COMPLEMENTO_ENDERECO, CLBAIFIS AS BAIRRO, CLCIDFIS AS CIDADE, CLUFFIS AS ESTADO, CLCEPFIS AS CEP FROM SYSFUNC.CCLIE A WITH(NOLOCK) INNER JOIN SYSFUNC.COPER B  WITH(NOLOCK) ON A.CLCODCLI = B.OPCODCLI WHERE B.OPNROPER = '{0}'";
        internal readonly static string clienteEnderecoNaoIntegrado = "SELECT TOP 1 CLNOMECLI AS NOME_CLIENTE, REPLACE(REPLACE(REPLACE(CLCGC,'.',''),'-',''),'/','') AS CPF_CNPJ, CLTPFJ AS TIPO_PESSOA, CLDDDFIS AS DDD_FIXO, CLFONEFIS AS NUMERO_FIXO, CLDDDCEL AS DDD_CEL, CLCELULAR AS NUMERO_CEL, CLENDFIS AS NOME_LOGRADOURO, CLNRENDFIS AS NUMERO_ENDERECO, CLCMPTFIS AS COMPLEMENTO_ENDERECO, CLBAIFIS AS BAIRRO, CLCIDFIS AS CIDADE, CLUFFIS AS ESTADO, CLCEPFIS AS CEP FROM SYSFUNC.CCLIE A WITH(NOLOCK) INNER JOIN SYSFUNC.COPER B  WITH(NOLOCK) ON A.CLCODCLI = B.OPCODCLI WHERE REPLACE(REPLACE(REPLACE(CLCGC,'.',''),'-',''),'/','') = '{0}'";
        internal readonly static string clienteDadosBancarios = "SELECT D.DCDSTBCO AS BANCO,CASE WHEN CHARINDEX('-',D.DCDSTAGE,0) = 0 THEN D.DCDSTAGE ELSE LEFT(D.DCDSTAGE,CHARINDEX('-',D.DCDSTAGE,0) - 1) END AS AGENCIA, CASE WHEN CHARINDEX('-',D.DCDSTAGE,0) = 0 THEN NULL ELSE RIGHT(D.DCDSTAGE,LEN(D.DCDSTAGE) - CHARINDEX('-',D.DCDSTAGE,0)) END AS DIGITO_AGENCIA, CASE WHEN CHARINDEX('-',D.DCDSTCC,0) = 0 THEN D.DCDSTCC ELSE LEFT(D.DCDSTCC,CHARINDEX('-',D.DCDSTCC,0) - 1) END AS CONTA, CASE WHEN CHARINDEX('-',D.DCDSTCC,0) = 0 THEN NULL ELSE RIGHT(D.DCDSTCC,LEN(D.DCDSTCC) - CHARINDEX('-',D.DCDSTCC,0)) END AS DIGITO_CONTA, CASE WHEN D.DCTPCCCP = '00' OR D.DCTPCCCP = '01' OR D.DCTPCCCP = '11' THEN 'CC' WHEN D.DCTPCCCP = '02' OR D.DCTPCCCP = '12' THEN 'PP' WHEN D.DCTPCCCP = '03' THEN 'PG' WHEN D.DCTPCCCP = '13' THEN 'CI' ELSE 'CC' END AS TIPO_CONTA FROM CDCPAN.SYSFUNC.CDOCS D WITH(NOLOCK) WHERE D.DCDSTBCO IS NOT NULL AND D.DCDSTBCO <> '' AND D.DCDSTBCO <> '000' AND D.DCDSTAGE IS NOT NULL AND D.DCDSTAGE <> '' AND D.DCDSTAGE <> '0000' AND D.DCDSTCC IS NOT NULL AND D.DCDSTCC <> '' AND D.DCDSTCC <> '0' AND D.DCNROPER IS NOT NULL AND D.DCNROPER <> '' AND D.DCNROPER = '{0}' AND REPLACE(REPLACE(D.DCFAVCGC,'.',''),'-','') = '{1}' AND (D.DCDOCUM = 'R' OR D.DCDOCUM = 'O') ORDER BY D.DCDSTBCO";
        internal readonly static string clienteRegistroObito = "SELECT ECSITCOB FROM SYSFUNC.ESCOB WHERE ECDTMOV IS NULL AND ECSITCOB in ('00002','00012','00038','00049','00052','00059') 	AND ECNROPER='{0}'";

        internal readonly static string dadosContrato = " SELECT        											" +
                                                        "		OPNROPER,                                           " +
                                                        "		OPDTLIQ,                                            " +
                                                        "		CASE                                                " +
                                                        "			WHEN ISNULL(OPESTORNO,'N')='S' THEN 'SIM'       " +
                                                        "			ELSE 'NÃO'                                      " +
                                                        "		END ESTONADA,                                       " +
                                                        "		(                                                   " +
                                                        "			SELECT TOP 1                                    " +
                                                        "			CONVERT(VARCHAR, HFCODMOV) + ' - ' + HFDESCR    " +
                                                        "			FROM CDCPAN.SYSFUNC.EFINA(NOLOCK)               " +
                                                        "			INNER JOIN CDCPAN.SYSFUNC.THFIN(NOLOCK)         " +
                                                        "				ON HFCODMOV = EFCODMOV                      " +
                                                        "			WHERE	EFNROPER = OPNROPER                     " +
                                                        "			AND		EFDTMOV = OPDTLIQ                       " +
                                                        "			ORDER BY EFNRPARC DESC                          " +
                                                        "		) HIST_LIQ,                                         " +
                                                        "		C.O4NOME NM_CONVENIO                                " +
                                                        " FROM CDCPAN.SYSFUNC.COPER B(NOLOCK)                       " +
                                                        " INNER JOIN CDCPAN.SYSFUNC.TORG4 C(NOLOCK)                 " +
                                                        "	ON B.OPCODORG4 = C.O4CODORG	                            " +
                                                        " WHERE OPNROPER = '{0}'                                    ";


        internal readonly static string contratoHistoricoFinanceiro = "SELECT EFNROPER, HFDESCR, EFCODMOV FROM CDCPAN.SYSFUNC.EFINA INNER JOIN CDCPAN.SYSFUNC.THFIN ON EFCODMOV = HFCODMOV WHERE EFNROPER = '{0}' ORDER BY EFDTMOV DESC";




    }
}
