﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries
{
    public static class RestritivosSql
    {
        internal readonly static string blackList = "SELECT BlackList.idBlackList, BlackList.nrBanco, BlackList.nrAgencia, BlackList.nrConta, BlackList.dtInclusao, BlackList.dtAlteracao, BlackList.IdUsuarioInclusao, BlackList.dsMotivo FROM tbBlackListContaBancaria BlackList WHERE  BlackList.nrBanco = '{0}' and BlackList.nrAgencia = '{1}' and BlackList.nrConta = '{2}'";
    }
}
