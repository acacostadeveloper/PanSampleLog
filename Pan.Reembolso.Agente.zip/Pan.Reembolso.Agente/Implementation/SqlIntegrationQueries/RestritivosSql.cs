﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries
{
    public static class RestritivosSql
    {
        internal readonly static string blackList = "SELECT BlackList.idBlackList, BlackList.NumeroBanco, BlackList.NumeroAgencia, BlackList.NumeroConta, BlackList.DataInclusao, BlackList.DataAlteracao, BlackList.IdUsuarioInclusao, BlackList.StatusBlackList FROM tbBlackListContaBancaria BlackList WHERE  BlackList.NumeroBanco = '{0}' and BlackList.NumeroAgencia = '{1}' and BlackList.NumeroConta = '{2}'";
    }
}
