﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries
{
    internal static class ContabilidadeSql
    {
        internal readonly static string historicoContabil = "SELECT TOP 1 HISTORICO FROM ITENSDEMODELOS WHERE TPOEMPRESA = 'U' AND MODELO = {0}";
    }
}
