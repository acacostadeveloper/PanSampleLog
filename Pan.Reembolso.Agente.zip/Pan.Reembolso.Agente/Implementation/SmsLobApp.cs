﻿using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.IO;
using System.Xml;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Pan.Reembolso.Agente.Interface;
using System.Configuration;
using System.Net;

namespace Pan.Reembolso.Agente.Implementation
{
    public class SmsLobApp : ISmsLobApp
    {
        private string _token;
        private bool _isValid;

        private readonly string _smsURI;
        private readonly string _getTokenSmsApi;
        private readonly string _sendSmsApi;
        private readonly string _getSmsApi;

        private readonly string _parceiroEnvioCodigo;
        private readonly string _centroDeCustoCodigo;
        private readonly string _templateTipoMensagem;
        private readonly string _produtoSms;


        public SmsLobApp()
        {
            _smsURI = (string)ConfigurationManager.AppSettings["SmsURI"];
            _getTokenSmsApi = (string)ConfigurationManager.AppSettings["SmsGettokenApi"];
            _sendSmsApi = (string)ConfigurationManager.AppSettings["SmsSendApi"];
            _getSmsApi = (string)ConfigurationManager.AppSettings["SmsGetApi"];
            _parceiroEnvioCodigo  = (string)ConfigurationManager.AppSettings["ParceiroEnvioCodigo"];
            _centroDeCustoCodigo = (string)ConfigurationManager.AppSettings["CentroDeCustoCodigo"];
            _templateTipoMensagem = (string)ConfigurationManager.AppSettings["TemplateTipoMensagem"];
            _produtoSms = (string)ConfigurationManager.AppSettings["ProdutoSms"];
        }


        public async Task SendSMS_old()
        {
            try
            {
                if (!this._isValid)
                {
                    await GettokenAsync();
                }

                var message = new Dictionary<string, string>
                {
                   { "ParceiroEnvioCodigo", "SSA" },
                   { "CentroDeCustoCodigo", "2402" },
                   { "TipoClienteCodigo", "F" },
                   { "TemplateTipoMensagem", "520" },
                   { "Produto", "0001" },
                   { "CpfCnpj", "31442252820" },
                   { "NumeroTelefone", "5513981256262" },
                   { "Email", "vanderlei.galdeano@grupopan.com" },
                   { "CampoAlfanumerico1", "Vanderlei" }
                };

                var client = WebRequest.Create(_smsURI + _sendSmsApi);
                client.ContentType = "application/json";
                client.Method = "POST";
                client.Headers.Add("Authorization", _token);

                var response = client.GetResponse();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<Entidades.RespostaSMS> SMSResposta(string protocolo)
        {
            try
            {
                if (!this._isValid)
                {
                    await GettokenAsync();
                }
                //var message = new
                //{
                //    idMensagemEntrada = protocolo
                //};

                var client = new RestClient(_smsURI + _getSmsApi + protocolo);
                var request = new RestRequest(Method.GET);
                request.AddHeader("Authorization", this._token);
                //request.AddJsonBody(message);

                var response = client.Execute<Entidades.RespostaSMS>(request);

                var result = JsonConvert.DeserializeObject<Entidades.RespostaSMS>(response.Content);
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<Entidades.SMSRespostaEnvio> SendSMS(string cpfCnpj, string tipoPessoa, string numeroTelefone, string nomeDestinatario)
        {
            try
            {
                numeroTelefone = "11996865226";

                if (!this._isValid)
                {
                    await GettokenAsync();

                }

                var message = new
                {
                    ParceiroEnvioCodigo = _parceiroEnvioCodigo,
                    CentroDeCustoCodigo = _centroDeCustoCodigo,
                    TemplateTipoMensagem = _templateTipoMensagem,
                    Produto = _produtoSms,
                    TipoClienteCodigo = tipoPessoa,
                    CpfCnpj = cpfCnpj,
                    NumeroTelefone = "55" + numeroTelefone,
                    Email = "",
                    CampoAlfanumerico1 = nomeDestinatario.Split(' ').First()
                };

                var client = new RestClient(_smsURI + _sendSmsApi);
                var request = new RestRequest(Method.POST);
                request.AddHeader("Authorization", this._token);
                request.AddJsonBody(message);

                var response = client.Execute<Entidades.SMSRespostaEnvio>(request);

                var result = JsonConvert.DeserializeObject<Entidades.SMSRespostaEnvio>(response.Content);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private async Task GettokenAsync()
        {
            var body = new
            {
                userName = ConfigurationManager.AppSettings["userName"],
                password = ConfigurationManager.AppSettings["password"]
            };

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_smsURI);

                StringContent content = new StringContent(JsonConvert.SerializeObject(body));

                content.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                HttpResponseMessage response = await client.PostAsync(_getTokenSmsApi, content);

                if (response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string data = await response.Content.ReadAsStringAsync();

                        var tokenResult = JsonConvert.DeserializeObject<GetTokenApiResult>(data);

                        if (tokenResult.Success == false)
                        {
                            throw new Exception(tokenResult.Result);
                        }
                        this._isValid = tokenResult.Success;

                        this._token = (tokenResult.Success) ? tokenResult.Result : "";
                    }
                }
            }
        }
    }

    public class GetTokenApiResult
    {
        public bool Success { get; set; }
        public List<string> Erros { get; set; }
        public string Result { get; set; }
    }



}
