﻿using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Agente.Implementation
{
    public class TesourariaLobApp
    {

        public static void ObterDadosBancarios(List<Entidades.ContaCredito> contas, string cpfCnpj)
        {
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(TesourariaSql.clienteDadosBancarios, cpfCnpj);
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {
                        contas.Add(ObterContaCredito(rdr));
                    }
                }
            }
        }

        private static ContaCredito ObterContaCredito(SqlDataReader rdr)
        {
            var contaCredito = new Entidades.ContaCredito();
            contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
            contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
            contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
            contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
            contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
            contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
            return contaCredito;
        }
    }
}
