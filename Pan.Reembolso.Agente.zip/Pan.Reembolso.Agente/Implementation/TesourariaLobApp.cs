﻿using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Agente.Interface;
using System.Xml;

namespace Pan.Reembolso.Agente.Implementation
{
    public class TesourariaLobApp : ITesourariaLobApp
    {
        public static void ObterDadosBancarios(List<ContaCredito> contas, string cpfCnpj)
        {
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(TesourariaSql.clienteDadosBancarios, cpfCnpj);
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {
                        contas.Add(ObterContaCredito(rdr));
                    }
                }
            }
        }

        public IDictionary<string, string> ConsultarTransferenciaEletronica(MensagemTransferencia mensagemTransferencia)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(docNode);

                XmlNode rootNode = doc.CreateElement("RAIZ");
                XmlNode entryNode = doc.CreateElement("ENTRADA");

                WriteXmlNode(doc, entryNode, "CodSisOri", mensagemTransferencia.produto.sistemaProduto.codigoSistema ?? "");
                WriteXmlNode(doc, entryNode, "NroOrigem", mensagemTransferencia.numeroOrigem ?? "");

                rootNode.AppendChild(entryNode);
                doc.AppendChild(rootNode);

                var request = new WSTesouraria.consultarRequisicaoRequestBody(doc.InnerXml);
                var result = new WSTesouraria.consultarRequisicaoRequest(request);

                IDictionary<string, string> returnData = new Dictionary<string, string>();

                XmlDocument xmlResult = new XmlDocument();
                xmlResult.LoadXml(result.Body.xml);

                if (doc.GetElementsByTagName("NroRequisicao").Count > 0)
                {
                    returnData.Add("Status", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("Mensagem", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("NroRequisicao", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("StatusRequisicao", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("TipoLiquidacao", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("NroDocumento", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("CodErro", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("TipoErro", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("erroSucesso", "SUCESSO");
                }

                if (doc.GetElementsByTagName("Erro").Count > 0)
                {
                    returnData.Add("erroSucesso", "ERRO");
                    returnData.Add("mensagem", doc.GetElementsByTagName("Erro").Item(0).InnerText);
                }

                return returnData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IDictionary<string, string> RequisitarTransferenciaEletronica(MensagemTransferencia mensagemTransferencia)
        {
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                doc.AppendChild(docNode);

                XmlNode rootNode = doc.CreateElement("RAIZ");
                XmlNode entryNode = doc.CreateElement("ENTRADA");

                WriteXmlNode(doc, entryNode, "CodDeptoCad", mensagemTransferencia.departamento.codigoDepartamento ?? "");
                WriteXmlNode(doc, entryNode, "CodSisOri", mensagemTransferencia.produto.sistemaProduto.codigoSistema ?? "");
                WriteXmlNode(doc, entryNode, "NroOrigem", mensagemTransferencia.numeroOrigem ?? "");
                WriteXmlNode(doc, entryNode, "CodColigadaCad", mensagemTransferencia.coligada.codigoColigada ?? "");
                WriteXmlNode(doc, entryNode, "CodAgenciaCad", mensagemTransferencia.coligada.codigoAgencia ?? "");
                WriteXmlNode(doc, entryNode, "CodUsuarioCad", mensagemTransferencia.codigoUsuarioCadastro ?? "");
                WriteXmlNode(doc, entryNode, "CodColigadaOpe", mensagemTransferencia.coligada.codigoColigada ?? "");
                WriteXmlNode(doc, entryNode, "CodAgenciaOpe", mensagemTransferencia.coligada.codigoAgencia ?? "");
                WriteXmlNode(doc, entryNode, "CodColigadaDes", mensagemTransferencia.coligada.codigoColigada ?? "");
                WriteXmlNode(doc, entryNode, "CnpjCpfFav", mensagemTransferencia.favorecido.numeroCpfCnpj ?? "");
                WriteXmlNode(doc, entryNode, "SequenciaFav", mensagemTransferencia.favorecido.sequenciaCpfCnpj.ToString() ?? "0");
                WriteXmlNode(doc, entryNode, "TipPesFav", mensagemTransferencia.favorecido.tipoPesssoa ?? "");
                WriteXmlNode(doc, entryNode, "NomeFav", mensagemTransferencia.favorecido.nome ?? "");
                WriteXmlNode(doc, entryNode, "CnpjCpfFav2", String.Empty);
                WriteXmlNode(doc, entryNode, "SequenciaFav2", String.Empty);
                WriteXmlNode(doc, entryNode, "TipPesFav2", String.Empty);
                WriteXmlNode(doc, entryNode, "NomeFav2", String.Empty);
                WriteXmlNode(doc, entryNode, "IndCreditaCC", mensagemTransferencia.indicadorCreditaContaCorrente ?? "");
                WriteXmlNode(doc, entryNode, "TipoContaFav", mensagemTransferencia.favorecido.contaCredito.tipoConta ?? "");
                WriteXmlNode(doc, entryNode, "CodBancoFav", mensagemTransferencia.favorecido.contaCredito.numeroBanco ?? "");
                WriteXmlNode(doc, entryNode, "CodAgenciaFav", mensagemTransferencia.favorecido.contaCredito.numeroAgencia ?? "");
                WriteXmlNode(doc, entryNode, "DVAgenciaFav", mensagemTransferencia.favorecido.contaCredito.digitoAgencia ?? "");
                WriteXmlNode(doc, entryNode, "NroContaFav", mensagemTransferencia.favorecido.contaCredito.numeroConta ?? "" + mensagemTransferencia.favorecido.contaCredito.digitoConta ?? "");
                WriteXmlNode(doc, entryNode, "CnpjCpfSac", mensagemTransferencia.contaReserva.cnpjSacado ?? "");
                WriteXmlNode(doc, entryNode, "SequenciaSac", "0");
                WriteXmlNode(doc, entryNode, "TipPesSac", mensagemTransferencia.contaReserva.tipoPessoaSacado ?? "");
                WriteXmlNode(doc, entryNode, "NomeSac", mensagemTransferencia.contaReserva.nomeSacado ?? "");
                WriteXmlNode(doc, entryNode, "CnpjCpfSac2", String.Empty);
                WriteXmlNode(doc, entryNode, "SequenciaSac2", String.Empty);
                WriteXmlNode(doc, entryNode, "TipPesSac2", String.Empty);
                WriteXmlNode(doc, entryNode, "NomeSac2", String.Empty);
                WriteXmlNode(doc, entryNode, "IndDebitaCC", mensagemTransferencia.indicadorDebitaContaCorrente ?? "");
                WriteXmlNode(doc, entryNode, "TipoContaSac", mensagemTransferencia.contaReserva.tipoConta ?? "");
                WriteXmlNode(doc, entryNode, "CodBancoSac", mensagemTransferencia.contaReserva.numeroBanco ?? "");
                WriteXmlNode(doc, entryNode, "CodAgenciaSac", mensagemTransferencia.contaReserva.numeroAgencia ?? "");
                WriteXmlNode(doc, entryNode, "DVAgenciaSac", mensagemTransferencia.contaReserva.digitoAgencia ?? "");
                WriteXmlNode(doc, entryNode, "NroContaSac", mensagemTransferencia.contaReserva.numeroConta ?? "" + mensagemTransferencia.contaReserva.digitoConta ?? "");
                WriteXmlNode(doc, entryNode, "IndTransitaCC", mensagemTransferencia.indicadorTransitaContaCorrente ?? "");
                WriteXmlNode(doc, entryNode, "NroBoleto", String.Empty);
                WriteXmlNode(doc, entryNode, "NroDocto", String.Empty);
                WriteXmlNode(doc, entryNode, "CodCarteira", mensagemTransferencia.produto.codigoCarteira ?? "");
                WriteXmlNode(doc, entryNode, "CodEvento", mensagemTransferencia.codigoEvento ?? "");
                WriteXmlNode(doc, entryNode, "Complemento", String.Empty);
                WriteXmlNode(doc, entryNode, "DatCadastro", String.Format("{0:MM/dd/yyyy}", mensagemTransferencia.dataRegistro));
                WriteXmlNode(doc, entryNode, "DatRequisicao", String.Format("{0:MM/dd/yyyy}", mensagemTransferencia.dataRegistro));
                WriteXmlNode(doc, entryNode, "DatLiquidacao", String.Format("{0:MM/dd/yyyy}", mensagemTransferencia.dataRegistro));
                WriteXmlNode(doc, entryNode, "DatHoraLiquidacao", String.Format("{0:MM/dd/yyyy}", mensagemTransferencia.dataRegistro));
                WriteXmlNode(doc, entryNode, "NroBordero", mensagemTransferencia.numeroBordero ?? "");
                WriteXmlNode(doc, entryNode, "TipLiquidacao", mensagemTransferencia.tipoLiquidacao ?? "");
                WriteXmlNode(doc, entryNode, "IndEmiteRecebe", mensagemTransferencia.indicadorEmiteRecebe ?? "");
                WriteXmlNode(doc, entryNode, "IndMesmaTitularidade", mensagemTransferencia.indicadorMesmaTitularidade ?? "");
                WriteXmlNode(doc, entryNode, "VlrBruto", mensagemTransferencia.valorTransferencia.ToString() ?? "");
                WriteXmlNode(doc, entryNode, "VlrCPMFDespesa", "0");
                WriteXmlNode(doc, entryNode, "VlrRequisicao", mensagemTransferencia.valorTransferencia.ToString() ?? "");
                WriteXmlNode(doc, entryNode, "CodFinalidade", mensagemTransferencia.codigoFinalidade ?? "");
                WriteXmlNode(doc, entryNode, "CodFinalidadeSPB", mensagemTransferencia.codigoFinalidadeSPB ?? "");
                WriteXmlNode(doc, entryNode, "CodBarras", String.Empty);
                WriteXmlNode(doc, entryNode, "IndPrevisao", mensagemTransferencia.indicadorPrevisao ?? "");
                WriteXmlNode(doc, entryNode, "CodAgenciaDes", mensagemTransferencia.coligada.codigoAgencia ?? "");
                WriteXmlNode(doc, entryNode, "CodIspbFav", String.Empty);

                rootNode.AppendChild(entryNode);
                doc.AppendChild(rootNode);

                var request = new WSTesouraria.gerarRequisicaoRequestBody(doc.InnerXml);
                var result = new WSTesouraria.gerarRequisicaoRequest(request);

                IDictionary<string, string> returnData = new Dictionary<string, string>();

                XmlDocument xmlResult = new XmlDocument();
                xmlResult.LoadXml(result.Body.xml);

                if (doc.GetElementsByTagName("NroRequisicao").Count > 0)
                {
                    returnData.Add("numeroRequisicao", doc.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("erroSucesso", "SUCESSO");
                    returnData.Add("mensagem", "Requisição enviada com sucesso.");
                }

                if (doc.GetElementsByTagName("Erro").Count > 0)
                {
                    returnData.Add("numeroRequisicao", "");
                    returnData.Add("erroSucesso", "ERRO");
                    returnData.Add("mensagem", doc.GetElementsByTagName("Erro").Item(0).InnerText);
                }

                return returnData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static void WriteXmlNode(XmlDocument doc, XmlNode entryNode, string name, string value)
        {
            XmlNode createdNode = doc.CreateElement(name);

            if(value != String.Empty)
                createdNode.AppendChild(doc.CreateTextNode(value));

            entryNode.AppendChild(createdNode);
        }

        private static ContaCredito ObterContaCredito(SqlDataReader rdr)
        {
            var contaCredito = new Entidades.ContaCredito();
            contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
            contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
            contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
            contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
            contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
            contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
            return contaCredito;
        }


        public static List<ContaCredito> ObterBlackList()
        {

            // TODO - Obter Consulta BlackList
            return new List<ContaCredito>();

            var blackListAccounts = new List<Entidades.ContaCredito>();

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(TesourariaSql.clienteDadosBancarios);
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {
                        blackListAccounts.Add(ObterContaCredito(rdr));
                    }
                }
            }

            return blackListAccounts;
        }

    }
}
