﻿using Pan.Reembolso.Agente.Implementation.SqlIntegrationQueries;
using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Agente.Interface;
using System.Xml;
using Pan.Reembolso.Agente.WSTesouraria;
using RestSharp;
using System.Xml.Serialization;
using System.IO;

namespace Pan.Reembolso.Agente.Implementation
{
    public class TesourariaLobApp : ITesourariaLobApp
    {

        public static void ObterDadosBancarios(List<ContaCredito> contas, string cpfCnpj)
        {
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(TesourariaSql.clienteDadosBancarios, cpfCnpj);
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {
                        contas.Add(ObterContaCredito(rdr));
                    }
                }
            }
        }

        public IDictionary<string, string> ConsultarTransferenciaEletronica(MensagemTransferencia mensagemTransferencia)
        {
            try
            {
                
                var doc = GeraMensagemConsultaRequisicao(mensagemTransferencia);

                var proxy = new EBIntegracaoTesServiceClient();

                var response = proxy.consultarRequisicao(doc.InnerXml);

                XmlDocument xmlResult = new XmlDocument();

                xmlResult.LoadXml(response);

                //var request = new WSTesouraria.consultarRequisicaoRequestBody(doc.InnerXml);
                //var result = new WSTesouraria.consultarRequisicaoRequest(request);

                var returnData = new Dictionary<string, string>();

                if (xmlResult.GetElementsByTagName("NroRequisicao").Count > 0)
                {
                    returnData.Add("Status", xmlResult.GetElementsByTagName("Status").Item(0).InnerText);
                    returnData.Add("Mensagem", xmlResult.GetElementsByTagName("Mensagem").Item(0).InnerText);
                    returnData.Add("NroRequisicao", xmlResult.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                    returnData.Add("StatusRequisicao", xmlResult.GetElementsByTagName("StatusRequisicao").Item(0).InnerText);
                    returnData.Add("TipoLiquidacao", xmlResult.GetElementsByTagName("TipoLiquidacao").Item(0).InnerText);
                    returnData.Add("NroDocumento", xmlResult.GetElementsByTagName("NroDocumento").Item(0).InnerText);
                    returnData.Add("CodErro", xmlResult.GetElementsByTagName("CodErro").Item(0).InnerText);
                    returnData.Add("TipoErro", xmlResult.GetElementsByTagName("TipoErro").Item(0).InnerText);
                    returnData.Add("erroSucesso", "SUCESSO");
                }

                if (xmlResult.GetElementsByTagName("Erro").Count > 0)
                {
                    returnData.Add("erroSucesso", "ERRO");
                    returnData.Add("mensagem", xmlResult.GetElementsByTagName("Erro").Item(0).InnerText);
                }

                return returnData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private XmlDocument GeraMensagemConsultaRequisicao(MensagemTransferencia mensagemTransferencia)
        {
            XmlDocument doc = new XmlDocument();
            
            XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(docNode);

            XmlNode rootNode = doc.CreateElement("RAIZ");
            XmlNode entryNode = doc.CreateElement("ENTRADA");

            WriteXmlNode(doc, entryNode, "CodSisOrigem", mensagemTransferencia.produto.sistemaProduto.codigoSistema ?? "");
            WriteXmlNode(doc, entryNode, "NroOrigem", mensagemTransferencia.numeroOrigem ?? "");

            rootNode.AppendChild(entryNode);
            doc.AppendChild(rootNode);

            return doc;
        }

        public IDictionary<string, string> RequisitarTransferenciaEletronica(MensagemTransferencia mensagemTransferencia)
        {
            try
            {
                XmlDocument doc = GeraMensagemTesouraria(mensagemTransferencia);

                var proxy = new EBIntegracaoTesServiceClient();

                var response = proxy.gerarRequisicao(doc.InnerXml);

                XmlDocument xmlResult = new XmlDocument();

                xmlResult.LoadXml(response);

                var returnData = TrataretornoTesouraria(xmlResult);

                return returnData;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static IDictionary<string, string> TrataretornoTesouraria(XmlDocument xmlResult)
        {
            IDictionary<string, string> returnData = new Dictionary<string, string>();

            if (xmlResult.GetElementsByTagName("NroRequisicao").Count > 0)
            {
                returnData.Add("numeroRequisicao", xmlResult.GetElementsByTagName("NroRequisicao").Item(0).InnerText);
                returnData.Add("erroSucesso", "SUCESSO");
                returnData.Add("mensagem", "Requisição enviada com sucesso.");
            }

            if (xmlResult.GetElementsByTagName("Erro").Count > 0)
            {
                returnData.Add("numeroRequisicao", "");
                returnData.Add("erroSucesso", "ERRO");
                returnData.Add("mensagem", xmlResult.GetElementsByTagName("Erro").Item(0).InnerText);
            }

            return returnData;
        }

        private XmlDocument GeraMensagemTesouraria(MensagemTransferencia mensagemTransferencia)
        {
            XmlDocument doc = new XmlDocument();
            XmlNode docNode = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
            doc.AppendChild(docNode);

            XmlNode rootNode = doc.CreateElement("RAIZ");
            XmlNode entryNode = doc.CreateElement("ENTRADA");

            WriteXmlNode(doc, entryNode, "CodDeptoCad", mensagemTransferencia.departamento.codigoDepartamento ?? "");
            WriteXmlNode(doc, entryNode, "CodSisOri", mensagemTransferencia.produto.sistemaProduto.codigoSistema ?? "");
            WriteXmlNode(doc, entryNode, "NroOrigem", mensagemTransferencia.numeroOrigem ?? "");
            WriteXmlNode(doc, entryNode, "CodColigadaCad", mensagemTransferencia.coligada.codigoColigada ?? "");
            WriteXmlNode(doc, entryNode, "CodAgenciaCad", mensagemTransferencia.coligada.codigoAgencia ?? "");
            WriteXmlNode(doc, entryNode, "CodUsuarioCad", mensagemTransferencia.codigoUsuarioCadastro ?? "");
            WriteXmlNode(doc, entryNode, "CodColigadaOpe", mensagemTransferencia.coligada.codigoColigada ?? "");
            WriteXmlNode(doc, entryNode, "CodAgenciaOpe", mensagemTransferencia.coligada.codigoAgencia ?? "");
            WriteXmlNode(doc, entryNode, "CodColigadaDes", mensagemTransferencia.coligada.codigoColigada ?? "");
            WriteXmlNode(doc, entryNode, "CnpjCpfFav", mensagemTransferencia.numeroCpfCnpjFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "SequenciaFav", mensagemTransferencia.numeroSequenciaFavorecido.ToString() ?? "0");
            WriteXmlNode(doc, entryNode, "TipPesFav", mensagemTransferencia.tipoPessoaFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "NomeFav", mensagemTransferencia.nomeFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "CnpjCpfFav2", String.Empty);
            WriteXmlNode(doc, entryNode, "SequenciaFav2", String.Empty);
            WriteXmlNode(doc, entryNode, "TipPesFav2", String.Empty);
            WriteXmlNode(doc, entryNode, "NomeFav2", String.Empty);
            WriteXmlNode(doc, entryNode, "IndCreditaCC", mensagemTransferencia.indicadorCreditaContaCorrente ?? "");
            WriteXmlNode(doc, entryNode, "TipoContaFav", mensagemTransferencia.tipoContaFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "CodBancoFav", mensagemTransferencia.numeroBancoFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "CodAgenciaFav", mensagemTransferencia.numeroAgenciaFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "DVAgenciaFav", mensagemTransferencia.digitoAgenciaFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "NroContaFav", mensagemTransferencia.numeroContaFavorecido ?? "" + mensagemTransferencia.digitoContaFavorecido ?? "");
            WriteXmlNode(doc, entryNode, "CnpjCpfSac", mensagemTransferencia.contaReserva.cnpjSacado ?? "");
            WriteXmlNode(doc, entryNode, "SequenciaSac", "0");
            WriteXmlNode(doc, entryNode, "TipPesSac", mensagemTransferencia.contaReserva.tipoPessoaSacado ?? "");
            WriteXmlNode(doc, entryNode, "NomeSac", mensagemTransferencia.contaReserva.nomeSacado ?? "");
            WriteXmlNode(doc, entryNode, "CnpjCpfSac2", String.Empty);
            WriteXmlNode(doc, entryNode, "SequenciaSac2", String.Empty);
            WriteXmlNode(doc, entryNode, "TipPesSac2", String.Empty);
            WriteXmlNode(doc, entryNode, "NomeSac2", String.Empty);
            WriteXmlNode(doc, entryNode, "IndDebitaCC", mensagemTransferencia.indicadorDebitaContaCorrente ?? "");
            WriteXmlNode(doc, entryNode, "TipoContaSac", mensagemTransferencia.contaReserva.tipoConta ?? "");
            WriteXmlNode(doc, entryNode, "CodBancoSac", mensagemTransferencia.contaReserva.numeroBanco ?? "");
            WriteXmlNode(doc, entryNode, "CodAgenciaSac", mensagemTransferencia.contaReserva.numeroAgencia ?? "");
            WriteXmlNode(doc, entryNode, "DVAgenciaSac", mensagemTransferencia.contaReserva.digitoAgencia ?? "");
            WriteXmlNode(doc, entryNode, "NroContaSac", mensagemTransferencia.contaReserva.numeroConta ?? "" + mensagemTransferencia.contaReserva.digitoConta ?? "");
            WriteXmlNode(doc, entryNode, "IndTransitaCC", mensagemTransferencia.indicadorTransitaContaCorrente ?? "");
            WriteXmlNode(doc, entryNode, "NroBoleto", String.Empty);
            WriteXmlNode(doc, entryNode, "NroDocto", String.Empty);
            WriteXmlNode(doc, entryNode, "CodCarteira", mensagemTransferencia.produto.codigoCarteira ?? "");
            WriteXmlNode(doc, entryNode, "CodEvento", mensagemTransferencia.codigoEvento ?? "");
            WriteXmlNode(doc, entryNode, "Complemento", String.Empty);
            WriteXmlNode(doc, entryNode, "DatCadastro", String.Format("{0:MM/dd/yyyy}", mensagemTransferencia.dataRegistro));
            WriteXmlNode(doc, entryNode, "DatRequisicao", String.Format("{0:dd/MM/yyyy}", mensagemTransferencia.dataRegistro));
            WriteXmlNode(doc, entryNode, "DatLiquidacao", String.Format("{0:dd/MM/yyyy}", mensagemTransferencia.dataRegistro));
            WriteXmlNode(doc, entryNode, "DatHoraLiquidacao", String.Format("{0:dd/MM/yyyy}", mensagemTransferencia.dataRegistro));
            WriteXmlNode(doc, entryNode, "NroBordero", mensagemTransferencia.numeroBordero ?? "");
            WriteXmlNode(doc, entryNode, "TipLiquidacao", mensagemTransferencia.tipoLiquidacao ?? "");
            WriteXmlNode(doc, entryNode, "IndEmiteRecebe", mensagemTransferencia.indicadorEmiteRecebe ?? "");
            WriteXmlNode(doc, entryNode, "IndMesmaTitularidade", mensagemTransferencia.indicadorMesmaTitularidade ?? "");
            WriteXmlNode(doc, entryNode, "VlrBruto", mensagemTransferencia.valorTransferencia.ToString() ?? "");
            WriteXmlNode(doc, entryNode, "VlrCPMFDespesa", "0");
            WriteXmlNode(doc, entryNode, "VlrRequisicao", mensagemTransferencia.valorTransferencia.ToString() ?? "");
            WriteXmlNode(doc, entryNode, "CodFinalidade", mensagemTransferencia.codigoFinalidade ?? "");
            WriteXmlNode(doc, entryNode, "CodFinalidadeSPB", mensagemTransferencia.codigoFinalidadeSPB ?? "");
            WriteXmlNode(doc, entryNode, "CodBarras", String.Empty);
            WriteXmlNode(doc, entryNode, "IndPrevisao", mensagemTransferencia.indicadorPrevisao ?? "");
            WriteXmlNode(doc, entryNode, "CodAgenciaDes", mensagemTransferencia.coligada.codigoAgencia ?? "");
            WriteXmlNode(doc, entryNode, "CodIspbFav", String.Empty);

            rootNode.AppendChild(entryNode);
            doc.AppendChild(rootNode);
            return doc;
        }

        private static void WriteXmlNode(XmlDocument doc, XmlNode entryNode, string name, string value)
        {
            XmlNode createdNode = doc.CreateElement(name);

            if(value != String.Empty)
                createdNode.AppendChild(doc.CreateTextNode(value));

            entryNode.AppendChild(createdNode);
        }

        private static ContaCredito ObterContaCredito(SqlDataReader rdr)
        {
            var contaCredito = new Entidades.ContaCredito();
            contaCredito.numeroBanco = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim());
            contaCredito.numeroAgencia = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim());
            contaCredito.digitoAgencia = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim());
            contaCredito.numeroConta = (rdr.IsDBNull(3) ? "" : rdr.GetString(3).Trim());
            contaCredito.digitoConta = (rdr.IsDBNull(4) ? "" : rdr.GetString(4).Trim());
            contaCredito.tipoConta = (rdr.IsDBNull(5) ? "" : rdr.GetString(5).Trim());
            return contaCredito;
        }

        public IList<DevolucaoSPB> ObterDevolucaoSPB(string sistemaOrigem, int quantidadeDias)
        {
            IList<DevolucaoSPB> result = new List<DevolucaoSPB>();

            DateTime dataFim = DateTime.Now;
            DateTime dataInicio = (dataFim.AddDays(quantidadeDias * -1));

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ABTesouraria"].ConnectionString))
            {
                con.Open();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = String.Format(TesourariaSql.devolucaoTeds, sistemaOrigem, String.Format("{0:yyyy-MM-dd}", dataInicio), String.Format("{0:yyyy-MM-dd}", dataFim));
                using (SqlDataReader rdr = cmd.ExecuteReader(CommandBehavior.SequentialAccess | CommandBehavior.CloseConnection))
                {
                    if (rdr.Read())
                    {
                        result.Add(new DevolucaoSPB() {
                            numeroRequisicao = (rdr.IsDBNull(0) ? "" : rdr.GetString(0).Trim()),
                            numeroOrigem = (rdr.IsDBNull(1) ? "" : rdr.GetString(1).Trim()),
                            statusRequisicao = (rdr.IsDBNull(2) ? "" : rdr.GetString(2).Trim())
                        });
                    }
                }
            }

            return result;
        }

    }
}
