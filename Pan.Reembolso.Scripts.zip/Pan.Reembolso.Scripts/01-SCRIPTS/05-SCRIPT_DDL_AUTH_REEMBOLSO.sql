USE [SSA]
GO


CREATE TABLE [gestao_reembolso].AUTH_ROLE 
(
    [ID_ROLE] [int] IDENTITY(1,1) NOT NULL,
    [ROLE_NAME] [varchar](50) NULL,

	CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED
    (
      [ID_ROLE] asc
    )
)
GO


CREATE TABLE [gestao_reembolso].AUTH_SERVICE 
(
    [ID_SERVICE] [int] IDENTITY(1,1) NOT NULL,
    [DS_SERVICE] [varchar](50) NULL,

	CONSTRAINT [PK_Service] PRIMARY KEY CLUSTERED
    (
      [ID_SERVICE] asc
    )
)
GO

CREATE TABLE [gestao_reembolso].AUTH_ROLE_SERVICE
(
	[ID_ROLE] [int] REFERENCES [gestao_reembolso].AUTH_ROLE (ID_ROLE),
    [ID_SERVICE] [int] REFERENCES [gestao_reembolso].AUTH_SERVICE (ID_SERVICE)
)
GO

CREATE TABLE [gestao_reembolso].AUTH_ACTION 
(
    [ID_ACTION] [int] IDENTITY(1,1) NOT NULL,
    [DS_ACTION] [varchar](50) NULL,
	[ID_SERVICE] INT NULL REFERENCES [gestao_reembolso].AUTH_SERVICE (ID_SERVICE),
    [IC_ATIVO] bit NOT NULL
	CONSTRAINT [PK_ACTION] PRIMARY KEY CLUSTERED  ( [ID_ACTION] asc )
)
GO
