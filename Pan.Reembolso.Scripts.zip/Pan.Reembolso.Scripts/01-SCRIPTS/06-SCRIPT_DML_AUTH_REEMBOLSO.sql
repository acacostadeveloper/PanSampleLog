USE SSA
GO

INSERT INTO [gestao_reembolso].[AUTH_ROLE] ([ROLE_NAME]) VALUES ('AnalistaBaixa') -- 1 
INSERT INTO [gestao_reembolso].[AUTH_ROLE] ([ROLE_NAME]) VALUES ('Aprovador') -- 2
INSERT INTO [gestao_reembolso].[AUTH_ROLE] ([ROLE_NAME]) VALUES ('OperadorCentral') -- 3
GO

INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('consultar-reembolso') -- 1
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('estornar-reembolso') -- 2
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('incluir-reembolso') -- 3
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('retirada-uso-interno') -- 4
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('consultar-retirada') -- 5
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('aprovar-reembolso') -- 6
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('consultar-dadosBancarios') -- 7
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('consultar-integracao') -- 8
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('consultar-clientes') -- 9
INSERT INTO [gestao_reembolso].[AUTH_SERVICE]  ([DS_SERVICE]) VALUES ('consultar-transferencia') -- 10
GO




INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 7 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnVisualizar', 7 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnAlterarDadosBancarios', 7 ,1)
GO

INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 6 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnAprovar', 6 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnRejeitar', 6 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnAprovarTodos', 6 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnRejeitarTodos', 6 ,1)
GO

INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 1 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnDetalhe', 1 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnEstornar', 1 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnEstornarTodos', 1 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('aprovar-reembolso', 1 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('chkSelecionar', 1 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('chkSelecionarTodos', 1 ,1)
GO

INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 2 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnEstornar', 2 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnEstornarTodos', 2 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('chkSelecionar', 2 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('chkSelecionarTodos', 2 ,1)
GO

INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 4 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnEfetivar', 4 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('divUpload', 4 ,1)
GO

INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 5 ,1)
GO

INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('divUpload', 7 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnInserir', 7 ,1)
GO


INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 8 ,1)
GO



INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnConsultar', 9 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('alterar-endereco', 9 ,1)
INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnNovo', 9 ,1)
GO


INSERT INTO [gestao_reembolso].[AUTH_ACTION] ([DS_ACTION], [ID_SERVICE], [IC_ATIVO])  VALUES  ('btnNovo', 10 ,1)
GO


INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,1)  -- AnalistaBaixa ; consultar-reembolso
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,2)  -- AnalistaBaixa ; estornar-reembolso
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,3)  -- AnalistaBaixa ; incluir-reembolso
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,4)  -- AnalistaBaixa ; retirada-uso-interno
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,5)  -- AnalistaBaixa ; consultar-retirada
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (2,6)  -- Aprovador ; aprovar-reembolso
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (3,7)  -- OperadorCentral ; consultar-reembolso
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,8)  -- AnalistaBaixa ; consultar-integracao
INSERT INTO [gestao_reembolso].[AUTH_ROLE_SERVICE] ([ID_ROLE],[ID_SERVICE]) VALUES  (1,9)  -- AnalistaBaixa ; consultar-clientes
GO
