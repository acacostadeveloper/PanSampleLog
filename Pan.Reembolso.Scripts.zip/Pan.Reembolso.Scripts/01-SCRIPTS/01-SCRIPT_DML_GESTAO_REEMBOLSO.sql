USE [SSA]

GO


INSERT INTO [gestao_reembolso].[DEPARTAMENTO](
	CD_DEPARTAMENTO, 
	DS_DEPARTAMENTO
) VALUES (
	'0000020',
	''
)

GO

INSERT INTO [gestao_reembolso].[SISTEMA](
	DS_SISTEMA
) VALUES (
	'SSAFUNCAO'
)

GO


INSERT INTO [gestao_reembolso].[PRODUTO](
	CD_PRODUTO,
	NM_PRODUTO,
	CD_CARTEIRA,
	ID_SISTEMA
) VALUES (
	'0001',
	'CONSIGNADO',
	'032',
	(SELECT ID_SISTEMA FROM [gestao_reembolso].[SISTEMA] WHERE DS_SISTEMA = 'SSAFUNCAO')
)

GO


INSERT INTO [gestao_reembolso].[CONTA](
	CD_TIPO_CONTA, 
	NO_BANCO, 
	NO_AGENCIA,
	NO_DIGITO_AGENCIA, 
	NO_CONTA
) VALUES (
	'CC',
	'0623',
	'0001',
	'9',
	'0000011019'
)

GO

INSERT INTO [gestao_reembolso].[CONTA_RESERVA](
	ID_CONTA, 
	NO_CNPJ_SACADO,
	NO_SEQUENCIA_SACADO,
	NM_SACADO, 
	CD_TIPO_PESSOA_SACADO
) VALUES (
	@@IDENTITY, 
	'59285411000113',
	'0',
	'BANCO PAN SA',
	'J'
)

GO

INSERT INTO [gestao_reembolso].[COLIGADA](
	CD_COLIGADA, 
	NM_COLIGADA,
	CNPJ_COLIGADA
) VALUES (
	'001',
	'BANCO PAN SA',
	'59285411000113'
)

GO

INSERT INTO [gestao_reembolso].[MENSAGEM_PADRAO](
	ID_PRODUTO, 
	CD_FINALIDADE_SPB,
	IC_CREDITA_CONTA_CORRENTE,
	IC_DEBITA_CONTA_CORRENTE,
	IC_EMITE_RECEBE,
	IC_MESMA_TITULARIDADE, 
	IC_PREVISAO,
	IC_TRANSITA_CONTA_CORRENTE,
	NO_BORDERO, 
	CD_TIPO_LIQUIDACAO
) VALUES (
	(SELECT ID_PRODUTO FROM [gestao_reembolso].[PRODUTO] WHERE CD_PRODUTO = '0001'),
	'00040',
	'N',
	'N',
	'E',
	'N',
	'N',
	'N',
	'0000000',
	'PAG0143'
)

GO

INSERT INTO [gestao_reembolso].[MENSAGEM_COMUNICACAO](
	DS_MENSAGEM_COMUNICACAO,
	CD_TIPO_COMUNICACAO
) VALUES (
	'Aviso Banco Pan: Existe um valor disponivel para reembolso em seu favor. Favor entrar em contato com nossa central de atendimento.',
	'SMS' 
)

GO

INSERT INTO [gestao_reembolso].[MENSAGEM_COMUNICACAO](
	DS_MENSAGEM_COMUNICACAO,
	CD_TIPO_COMUNICACAO
) VALUES (
	'Aviso Banco Pan: Existe um valor disponivel para reembolso em seu favor. Favor entrar em contato com nossa central de atendimento.',
	'CARTA_AR' 
)

GO


---------------------------------------------------------------------------------------------------------


-- SELECT * FROM [gestao_reembolso].[DEPARTAMENTO]
-- SELECT * FROM [gestao_reembolso].[SISTEMA]
-- SELECT * FROM [gestao_reembolso].[PRODUTO]
-- SELECT * FROM [gestao_reembolso].[CONTA]
-- SELECT * FROM [gestao_reembolso].[CONTA_RESERVA]
-- SELECT * FROM [gestao_reembolso].[COLIGADA]
-- SELECT * FROM [gestao_reembolso].[MENSAGEM_PADRAO]
-- SELECT * FROM [gestao_reembolso].[MENSAGEM_COMUNICACAO]

