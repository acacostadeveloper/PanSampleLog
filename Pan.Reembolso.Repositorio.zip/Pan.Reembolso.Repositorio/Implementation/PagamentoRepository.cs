﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Data.Entity;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using System.Data;
using System.Data.SqlTypes;
using System.Web.Configuration;
using System.Data.SqlClient;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class PagamentoRepository : IPagamentoRepository
    {
        private PanReembolsoContext _contexto;

        public PagamentoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Pagamento ObterPagamentoPorMensagemTransferencia(Entidades.MensagemTransferencia mensagem)
        {
            try
            {
                var sql = (from _pagam in _contexto.PagamentoRepository
                           join _pgmsg in _contexto.MensagemPagamentoRepository on _pagam.idPagamento equals _pgmsg.idPagamento
                           join _msgtr in _contexto.MensagemTransferenciaRepository on _pgmsg.idMensagem equals _msgtr.idMensagem
                           where _msgtr.numeroRequisicao == mensagem.numeroRequisicao
                           select new Entidades.Pagamento
                           {
                               numeroPagamento = _pagam.idPagamento,
                               dataPagamento = _pagam.dataPagamento,
                               dataRegistroPagamento = _pagam.dataRegistro,
                               tipoPagamento = _pagam.tipoPagamento,
                               valorPagamento = _pagam.valorPagamento,
                               statusPagamento = _pagam.statusPagamento
                           }
                );

                var resultItem = sql.FirstOrDefault();

                resultItem.listaReembolsos = new ReembolsoRepository().ObterReembolsosPorIdPagamento(resultItem).ToList();
                resultItem.favorecido = new FavorecidoRepository().ObterFavorecidoPorIdPagamento(resultItem);

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.Pagamento ObterPagamentosPorId(long idPagamento)
        {
            try
            {
                var result = new Entidades.Pagamento();

                var resultItem = (from _pagam in _contexto.PagamentoRepository
                                  where _pagam.dataPagamento == null
                                  && _pagam.idPagamento == idPagamento
                                  select _pagam).FirstOrDefault();

                if (resultItem != null)
                {
                    result = MapPagamento(resultItem);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private Entidades.Pagamento MapPagamento(PagamentoDatabase resultItem)
        {
            var result = new Entidades.Pagamento
            {
                numeroPagamento = resultItem.idPagamento,
                dataPagamento = resultItem.dataPagamento,
                dataRegistroPagamento = resultItem.dataRegistro,
                tipoPagamento = resultItem.tipoPagamento,
                valorPagamento = resultItem.valorPagamento,
                statusPagamento = resultItem.statusPagamento
            };

            if (resultItem != null)
            {
                result.listaReembolsos = new ReembolsoRepository().ObterReembolsosPorIdPagamento(result).ToList();
                result.favorecido = new FavorecidoRepository().ObterFavorecidoPorIdPagamento(result);
            }

            return result;
        }

        public IList<Entidades.Pagamento> ObterPagamentosPorStatus(StatusPagamentoType status)
        {
            try
            {
                var resultItem = (from _pagam in _contexto.PagamentoRepository
                                  where _pagam.dataPagamento == null
                                  && _pagam.statusPagamento == status.ToString()

                                  select new Entidades.Pagamento
                                  {
                                      numeroPagamento = _pagam.idPagamento,
                                      dataPagamento = _pagam.dataPagamento,
                                      dataRegistroPagamento = _pagam.dataRegistro,
                                      tipoPagamento = _pagam.tipoPagamento,
                                      valorPagamento = _pagam.valorPagamento,
                                      statusPagamento = _pagam.statusPagamento,
                                  }).ToList();

                foreach (var item in resultItem)
                {
                    item.listaReembolsos = new ReembolsoRepository().ObterReembolsosPorIdPagamento(item).ToList();
                    item.favorecido = new FavorecidoRepository().ObterFavorecidoPorIdPagamento(item);
                }
                return resultItem.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Pagamento> ObterPagamentoPorCPFCliente(string cpfOuCnpj)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                  join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  where _clie.cpfCnpj == cpfOuCnpj
                                  select _pagam
                ).ToList();

                var result = new List<Pagamento>();

                foreach (var item in resultItem)
                {
                    result.Add(MapPagamento(item));
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void PersistirPagamento(Entidades.Pagamento pagamento)
        {
            int idFavorecido;

            pagamento.statusPagamento = ReembolsoTypes.StatusPagamentoType.Aprovado.ToString();

            var statusAceitaveis = new List<string>()
            {
                ReembolsoTypes.StatusPagamentoType.Aprovado.ToString(),
                ReembolsoTypes.StatusPagamentoType.Recusado.ToString()
            };

            var pagamentoExistente = ObterPagamentoPorCPFCliente(pagamento.favorecido.numeroCpfCnpj)
                .Where(x => statusAceitaveis.Contains(x.statusPagamento))
                .OrderBy(y => y.statusPagamento)
                .FirstOrDefault();

            if (pagamentoExistente != null)
            {
                pagamento.numeroPagamento = pagamentoExistente.numeroPagamento;

                var listaIds = pagamento.listaReembolsos.Select(x => x.idReembolso).Except(pagamentoExistente.listaReembolsos.Select(y => y.idReembolso)).ToList();

                List<Entidades.Reembolso> listaFinal = new List<Entidades.Reembolso>();
                foreach (var id in listaIds)
                {
                    listaFinal.Add(new ReembolsoRepository().ObterReembolso(id));
                }

                pagamento.listaReembolsos = listaFinal;


                if (pagamento.listaReembolsos.Any())
                {
                    pagamento.valorPagamento = (pagamentoExistente.valorPagamento + pagamento.listaReembolsos.Sum(t => t.valorReembolso));

                    AgregarReembolso(pagamento);
                }

                AtualizarPagamento(pagamento);
            }
            else
            {
                idFavorecido = new FavorecidoRepository().PersistirFavorecido(pagamento.favorecido);

                IncluirPagamento(pagamento);
            }
        }

        private void AgregarReembolso(Entidades.Pagamento pagamento)
        {
            try
            {
                var idsReembolsos = pagamento.listaReembolsos.Select(s => s.idReembolso).ToList();

                IncluirPagamentoReembolsosDB(pagamento.numeroPagamento, idsReembolsos);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AtualizarPagamento(Entidades.Pagamento pagamento)
        {
            try
            {
                var db = (from _pgt in _contexto.PagamentoRepository
                          where _pgt.idPagamento == pagamento.numeroPagamento
                          select _pgt).FirstOrDefault();


                db.statusPagamento = pagamento.statusPagamento;
                db.tipoPagamento = pagamento.tipoPagamento;
                db.valorPagamento = pagamento.valorPagamento;
                db.dataPagamento = pagamento.dataPagamento ?? null;
                db.tipoPagamento = pagamento.tipoPagamento;

                _contexto.Entry(db).State = EntityState.Modified;

                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void IncluirPagamento(Entidades.Pagamento pagamento)
        {
            try
            {

                FavorecidoDatabase favorecido = null;
                if (pagamento.favorecido != null)
                {
                    favorecido = _contexto.FavorecidoRepository.Select(x => x)
                                                           .Where(x => x.numeroCpfCnpj == pagamento.favorecido.numeroCpfCnpj
                                                           && x.sequenciaCpfCnpj == pagamento.favorecido.sequenciaCpfCnpj)
                                                           .FirstOrDefault();
                }




                string codigoColigada = pagamento.listaReembolsos[0].contrato.coligada.codigoColigada;

                PagamentoDatabase item = new PagamentoDatabase()
                {
                    idColigada = _contexto.ColigadaRepository.Select(x => x)
                                                                .Where(x => x.codigoColigada == codigoColigada)
                                                                .FirstOrDefault()
                                                                .idColigada,

                    idFavorecido = (favorecido != null) ? favorecido.idFavorecido : (int?)null,

                    dataPagamento = null,
                    dataRegistro = DateTime.Now,
                    tipoPagamento = pagamento.tipoPagamento ?? ReembolsoTypes.PagamentoType.TED.ToString(),
                    valorPagamento = pagamento.valorPagamento,
                    statusPagamento = pagamento.statusPagamento
                };

                _contexto.Set<PagamentoDatabase>().Add(item);

                _contexto.SaveChanges();

                pagamento.numeroPagamento = item.idPagamento;

                IncluirPagamentoReembolsosDB(item.idPagamento, pagamento.listaReembolsos.Select(x => x.idReembolso).ToList());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void IncluirPagamentoReembolsosDB(long idPagamento, List<long> idsReembolsos)
        {
            try
            {
                foreach (var idReembolso in idsReembolsos)
                {
                    ReembolsoPagamentoDatabase pagamento = new ReembolsoPagamentoDatabase()
                    {
                        idPagamento = idPagamento,
                        idReembolso = idReembolso
                    };

                    _contexto.Set<ReembolsoPagamentoDatabase>().Add(pagamento);
                }
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<object>> ConsultarRetiradaInternaPorContrato(string cpfCnpj = "", string codProduto = "")
        {
            try
            {
                var siglas = new List<string>
                {
                    "DCONB",
                    "DEV TEF"
                };

                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _sigla in _contexto.SiglaRepository on _reemb.idSigla equals _sigla.idSigla
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                              join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                              where
                              (_reemb.statusReembolso == StatusReembolsoType.Registrado.ToString() ||
                               _reemb.statusReembolso == StatusReembolsoType.Bloqueado.ToString())
                              && (!siglas.Contains(_sigla.codigoSigla)
                                  && (_clie.cpfCnpj == cpfCnpj || cpfCnpj == "")
                                  && (_prod.codigoProduto == codProduto || codProduto == ""))

                              select new
                              {
                                  _reemb.idReembolso,
                                  dtReembolso = _reemb.dtInclusao,
                                  _contr.codigoContrato,
                                  valor = _reemb.valorReembolso,
                                  _clie.nomeCliente,
                                  cpf = _clie.cpfCnpj,
                                  produto = new Produto() { codigoProduto = _prod.codigoProduto, nomeProduto = _prod.nomeProduto }
                              }).OrderByDescending(x => x.dtReembolso);

                var pagamentos = result
                .GroupBy(s => new { s.cpf, s.nomeCliente, s.codigoContrato, s.produto })
                .Select(t => new
                {
                    cpfcnpj = t.Key.cpf,
                    t.Key.nomeCliente,
                    t.Key.produto,
                    retirada = new
                    {
                        t.Key.codigoContrato,
                        valorDisponivel = t.Sum(u => u.valor),
                        ids = t.Select(d => d.idReembolso).ToList()
                    }
                }).OrderByDescending(n => n.retirada.valorDisponivel)
                .GroupBy(v => new { v.cpfcnpj, v.nomeCliente, v.produto })
                .Select(y => new
                {
                    y.Key.cpfcnpj,
                    y.Key.nomeCliente,
                    y.Key.produto,
                    items = y.Select(z => z.retirada).ToList()
                });

                return pagamentos.ToList<object>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<RetiradaUsoInterno>> ConsultarRetiradaInterna(string cpfCnpj = "", string codProduto = "")
        {
            try
            {
                var siglas = new List<string>
                {
                    "DCONB",
                    "DEV TEF"
                };

                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _sigla in _contexto.SiglaRepository on _reemb.idSigla equals _sigla.idSigla
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                              join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                              where
                              (_reemb.statusReembolso == StatusReembolsoType.Registrado.ToString() ||
                               _reemb.statusReembolso == StatusReembolsoType.Bloqueado.ToString())
                              && (!siglas.Contains(_sigla.codigoSigla)
                                  && (_clie.cpfCnpj == cpfCnpj || cpfCnpj == "")
                                  && (_prod.codigoProduto == codProduto || codProduto == ""))

                              select new
                              {
                                  idReembolso = _reemb.idReembolso,
                                  dtReembolso = _reemb.dtInclusao,
                                  valor = _reemb.valorReembolso,
                                  nomeCliente = _clie.nomeCliente,
                                  cpf = _clie.cpfCnpj,
                                  produto = new Produto() { codigoProduto = _prod.codigoProduto, nomeProduto = _prod.nomeProduto }
                              }).OrderByDescending(x => x.dtReembolso);

                var pagamentos = result.GroupBy(s => new { s.cpf, s.nomeCliente, s.produto }).Select(t => new RetiradaUsoInterno
                {
                    cpfcnpj = t.Key.cpf,
                    nomeCliente = t.Key.nomeCliente,
                    valor = t.Sum(u => u.valor),
                    ids = t.Select(d => d.idReembolso).ToList(),
                    produto = t.Key.produto

                }).OrderByDescending(n => n.valor);




                return pagamentos.ToList<RetiradaUsoInterno>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task PersistirIntegracaoBulk(DataTable retiradasTable)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings[ReembolsoConstantes.BANCO_BULK_INSERT].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = ReembolsoConstantes.TABELA_INTEGRACAO_RETIRADA;

                    try
                    {
                        await bulkCopy.WriteToServerAsync(retiradasTable);

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }

        public List<IntegracaoRetiradaUsoInterno> ConsultarRetiradasPendentesLote()
        {
            try
            {
                var resultList = (from _retLot in _contexto.IntegracaoRetiradaUsoInternoRepository
                                  where _retLot.codigoStatusIntegracao == StatusIntegracaoType.Pendente.ToString()
                                  select new Entidades.IntegracaoRetiradaUsoInterno()
                                  {
                                      codigoLoteIntegracao = _retLot.codigoLoteIntegracao,
                                      codigoProduto = _retLot.codigoProduto,
                                      codigoStatusIntegracao = _retLot.codigoStatusIntegracao,
                                      idIntegracao = _retLot.idIntegracao,
                                      valorRetirada = _retLot.valorRetirada,
                                      numeroCpfCnpj = _retLot.numeroCpfCnpj,
                                      dataInclusao = _retLot.dataInclusao,
                                      mensagemErro = _retLot.mensagemErro,
                                      usuarioInclusao = _retLot.usuarioInclusao,
                                      codigoProcessoRegistro = _retLot.codigoProcessoRegistro
                                  });
                return resultList.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AtualizarIntegracaoRetiradaUsoInternoLote(IntegracaoRetiradaUsoInterno integracaoRetiradaUsoInterno)
        {
            try
            {
                var db = (from _intRetIntern in _contexto.IntegracaoRetiradaUsoInternoRepository
                          where _intRetIntern.idIntegracao == integracaoRetiradaUsoInterno.idIntegracao
                          select _intRetIntern).FirstOrDefault();

                if (db != null)
                {
                    if (integracaoRetiradaUsoInterno.Pagamento != null)
                    {
                        db.idPagamento = integracaoRetiradaUsoInterno.Pagamento.numeroPagamento;
                    }
                    db.codigoStatusIntegracao = integracaoRetiradaUsoInterno.codigoStatusIntegracao;
                    db.dataInclusao = integracaoRetiradaUsoInterno.dataInclusao;
                    db.usuarioInclusao = integracaoRetiradaUsoInterno.usuarioInclusao;
                    db.mensagemErro = integracaoRetiradaUsoInterno.mensagemErro;

                    _contexto.Entry(db).State = EntityState.Modified;

                    _contexto.SaveChanges();
                }
                else
                {
                    throw new Exception("Retirada uso interno lote não encontrado " + integracaoRetiradaUsoInterno.idIntegracao.ToString());
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        public DataTable ObterIntegracaoRetiradaDataTable()
        {
            DataTable TabelaIntegracao = new DataTable(ReembolsoConstantes.TABELA_INTEGRACAO_RETIRADA);

            TabelaIntegracao.Columns.Add(new DataColumn("ID_INTEGRACAO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CPF_CNPJ", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PRODUTO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("VL_RETIRADA", typeof(SqlDecimal)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_PAGAMENTO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_LOTE_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_STATUS_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DS_MENSAGEM_ERRO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_USUARIO_INCLUSAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INCLUSAO", typeof(DateTime)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PROCESSO_REGISTRO", typeof(Int32)));

            return TabelaIntegracao;
        }

        public async Task<List<object>> ConsultarLoteRetiradaInterna(int idLote, DateTime? dataIni, DateTime? dataFim, StatusIntegracaoType status)
        {
            try
            {

                var resultado = new List<object>();

                var RetiradaManual =
                (from _pag in _contexto.PagamentoRepository
                 join _rePag in _contexto.ReembolsoPagamentoRepository on _pag.idPagamento equals _rePag.idPagamento
                 join _reemb in _contexto.ReembolsoRepository on _rePag.idReembolso equals _reemb.idReembolso
                 join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                 join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                 join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                 join _retLot in _contexto.IntegracaoRetiradaUsoInternoRepository on _pag.idPagamento equals _retLot.idPagamento into manual
                 from _manu in manual.DefaultIfEmpty()
                 where _manu == null &&
                      (_pag.tipoPagamento == PagamentoType.UsoInterno.ToString() || _pag.idFavorecido == null) &&
                      (_pag.dataPagamento >= dataIni || dataIni == null) &&
                      (_pag.dataPagamento <= dataFim || dataFim == null)
                 select new
                 {
                     integracao = new IntegracaoRetiradaUsoInterno()
                     {
                         codigoLoteIntegracao = 0,
                         codigoProduto = _prod.codigoProduto,
                         codigoStatusIntegracao = "Retirada Manual",
                         idIntegracao = 0,
                         valorRetirada = _pag.valorPagamento,
                         numeroCpfCnpj = _clie.cpfCnpj,
                         dataInclusao = _pag.dataRegistro,
                         mensagemErro = "",
                         usuarioInclusao = _reemb.codigoUsuarioAprovacao,
                         codigoProcessoRegistro = _reemb.idProcessoRegistro
                     },
                     _pag.idPagamento,
                     _reemb.idReembolso
                 }
                 ).GroupBy(x => x.idPagamento).Select(y => new
                 {
                     integracao = y.FirstOrDefault().integracao,
                     idPagamento = y.Key,
                     listaReembolsos = y.Select(z => z.idReembolso).ToList()
                 }).ToList();

                foreach (var item in RetiradaManual)
                {
                    var lista = new List<Entidades.Reembolso>();
                    foreach (var reemb in item.listaReembolsos)
                    {
                        lista.Add(new ReembolsoRepository().ObterReembolso(reemb));
                    }

                    resultado.Add(new
                    {
                        item.integracao,
                        item.idPagamento,
                        listaReembolsos = lista

                    });
                }

                var RetiradaIntegrada =
                (from _retLot in _contexto.IntegracaoRetiradaUsoInternoRepository
                 join _rePag in _contexto.ReembolsoPagamentoRepository on _retLot.idPagamento equals _rePag.idPagamento
                 join _reemb in _contexto.ReembolsoRepository on _rePag.idReembolso equals _reemb.idReembolso
                 where
                    (_retLot.codigoStatusIntegracao == StatusIntegracaoType.Integrado.ToString()) &&
                    (_retLot.codigoLoteIntegracao == idLote || idLote == 0) &&
                    (_retLot.dataInclusao >= dataIni || dataIni == null) &&
                    (_retLot.dataInclusao <= dataFim || dataFim == null) &&
                    (_retLot.codigoStatusIntegracao == status.ToString() || status == StatusIntegracaoType.Undefined)
                 select new
                 {
                     integracao = new IntegracaoRetiradaUsoInterno()
                     {
                         codigoLoteIntegracao = _retLot.codigoLoteIntegracao,
                         codigoProduto = _retLot.codigoProduto,
                         codigoStatusIntegracao = _retLot.codigoStatusIntegracao,
                         idIntegracao = _retLot.idIntegracao,
                         valorRetirada = _retLot.valorRetirada,
                         numeroCpfCnpj = _retLot.numeroCpfCnpj,
                         dataInclusao = _retLot.dataInclusao,
                         mensagemErro = _retLot.mensagemErro,
                         usuarioInclusao = _retLot.usuarioInclusao,
                         codigoProcessoRegistro = _retLot.codigoProcessoRegistro
                     },
                     _rePag.idPagamento,
                     _reemb.idReembolso
                 }
                ).GroupBy(x => x.idPagamento).Select(y => new
                {
                    integracao = y.FirstOrDefault().integracao,
                    idPagamento = y.Key,
                    listaReembolsos = y.Select(z => z.idReembolso).ToList()
                }).ToList();

                foreach (var item in RetiradaIntegrada)
                {
                    var lista = new List<Entidades.Reembolso>();
                    foreach (var reemb in item.listaReembolsos)
                    {
                        lista.Add(new ReembolsoRepository().ObterReembolso(reemb));
                    }

                    resultado.Add(new
                    {
                        item.integracao,
                        item.idPagamento,
                        listaReembolsos = lista

                    });
                }

                var RetiradaNaoIntegrada =
                (from _retLot in _contexto.IntegracaoRetiradaUsoInternoRepository
                 where _retLot.codigoStatusIntegracao != ReembolsoTypes.StatusIntegracaoType.Integrado.ToString() &&
                (_retLot.codigoLoteIntegracao == idLote || idLote == 0) &&
                (_retLot.dataInclusao >= dataIni || dataIni == null) &&
                (_retLot.dataInclusao <= dataFim || dataFim == null) &&
                (_retLot.codigoStatusIntegracao == status.ToString() || status == StatusIntegracaoType.Undefined)
                 select new
                 {
                     integracao = new IntegracaoRetiradaUsoInterno()
                     {
                         codigoLoteIntegracao = _retLot.codigoLoteIntegracao,
                         codigoProduto = _retLot.codigoProduto,
                         codigoStatusIntegracao = _retLot.codigoStatusIntegracao,
                         idIntegracao = _retLot.idIntegracao,
                         valorRetirada = _retLot.valorRetirada,
                         numeroCpfCnpj = _retLot.numeroCpfCnpj,
                         dataInclusao = _retLot.dataInclusao,
                         mensagemErro = _retLot.mensagemErro,
                         usuarioInclusao = _retLot.usuarioInclusao,
                         codigoProcessoRegistro = _retLot.codigoProcessoRegistro
                     }
                 }).ToList();

                foreach (var item in RetiradaNaoIntegrada)
                {
                    var lista = new List<Entidades.Reembolso>();

                    resultado.Add(new
                    {
                        item.integracao,
                        idPagamento = 0,
                        listaReembolsos = lista

                    });
                }

                return resultado;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int GerarNovoLoteIntegracao()
        {
            var db = new Entidades.DatabaseEntities.LoteIntegracaoDatabase()
            {
                dtInclusao = DateTime.Now
            };

            _contexto.Set<Entidades.DatabaseEntities.LoteIntegracaoDatabase>().Add(db);

            _contexto.SaveChanges();

            return db.codigoLoteIntegracao;
        }

        private static IntegracaoRetiradaUsoInterno MapIntegracaoRetiradaInterna(IntegracaoRetiradaUsoInternoDatabase _retLot)
        {
            return new Entidades.IntegracaoRetiradaUsoInterno()
            {
                codigoLoteIntegracao = _retLot.codigoLoteIntegracao,
                codigoProduto = _retLot.codigoProduto,
                codigoStatusIntegracao = _retLot.codigoStatusIntegracao,
                idIntegracao = _retLot.idIntegracao,
                valorRetirada = _retLot.valorRetirada,
                numeroCpfCnpj = _retLot.numeroCpfCnpj,
                dataInclusao = _retLot.dataInclusao,
                mensagemErro = _retLot.mensagemErro,
                usuarioInclusao = _retLot.usuarioInclusao,
                codigoProcessoRegistro = _retLot.codigoProcessoRegistro
            };
        }
    }
}
