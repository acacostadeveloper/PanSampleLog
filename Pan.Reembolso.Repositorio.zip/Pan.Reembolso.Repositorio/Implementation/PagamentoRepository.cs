﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class PagamentoRepository : IPagamentoRepository
    {
        private PanReembolsoContext _contexto;

        public PagamentoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.PagamentoReembolso ObterPagamentoPorIdReembolso(long idReembolso)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository 
                                  join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                  join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                  where _reemb.idReembolso == idReembolso
                                  select new Pan.Reembolso.Entidades.PagamentoReembolso()
                                  {
                                      dataPagamento = _pagam.dataPagamento,
                                      dataRegistroPagamento = _pagam.dataRegistro,
                                      tipoPagamento = _pagam.tipoPagamento,
                                      valorPagamento = _pagam.valorPagamento
                                  }
                ).FirstOrDefault();

                if(resultItem != null)
                    resultItem.mensagem = new MensagemRepository().ObterMensagemPorIdReembolso(idReembolso);

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public Pan.Reembolso.Entidades.DatabaseEntities.PagamentoDatabase ObterPagamentoAbertoPorCPF(string cpfOuCnpj)
        {
            try
            {

            

                PagamentoDatabase resultItem = (from _reemb in _contexto.ReembolsoRepository
                                                join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                                join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                                join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                                join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                                where _clie.cpfCnpj == cpfOuCnpj
                                                select new PagamentoDatabase
                                                {
                                                    idColigada = _pagam.idColigada,
                                                    dataRegistro = _pagam.dataRegistro,
                                                    dataPagamento = _pagam.dataPagamento,
                                                    idPagamento = _pagam.idPagamento,
                                                    idProcessoOrigem = _pagam.idProcessoOrigem,
                                                    tipoPagamento = _pagam .tipoPagamento,
                                                    valorPagamento = _pagam.valorPagamento
                                                }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        

     


        public int AtualizarPagamento(PagamentoDatabase pagamentoDB,decimal valor)
        {
            try
            {
                pagamentoDB.valorPagamento += valor;
                _contexto.Set<PagamentoDatabase>().Attach(pagamentoDB);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
            

            return pagamentoDB.idPagamento;

        }

        public int IncluirPagamento(decimal valor,string contrato)
        {
            try
            {
                PagamentoDatabase item = new PagamentoDatabase()
                {
                    idColigada = _contexto.ContratoRepository.Select(x => x)
                                                                .Where(x => x.codigoContrato == contrato )
                                                                .FirstOrDefault()
                                                                .idColigada,
                    /*_contexto.ColigadaRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoColigada == ???)
                                                    .FirstOrDefault().idColigada,*/
                   /* idProcessoOrigem = /_contexto.ProcessoRegistroRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoProcessoRegistro == ???)
                                                    .FirstOrDefault().idProcessoRegistro,*/
                    dataPagamento = DateTime.MinValue,
                    dataRegistro = DateTime.Now,
                    tipoPagamento = ReembolsoTypes.PagamentoType.TED.ToString(),
                    valorPagamento = valor
                };

                _contexto.Set<PagamentoDatabase>().Add(item);
                _contexto.SaveChanges();

                return item.idPagamento;
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }


        public void IncluirPagamentoReembolsosDB( int idPagamento, long[] idsReembolsos )
        {
            try
            {
                var lista = new List<ReembolsoPagamentoDatabase>();
                foreach (var idReembolso in idsReembolsos)
                {
                    var pagamento = new ReembolsoPagamentoDatabase()
                    {
                        idPagamento = idPagamento,
                        idReembolso = idReembolso
                    };
                    lista.Add(pagamento);
                }
                _contexto.Set<ReembolsoPagamentoDatabase>().AddRange(lista);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }


        public PagamentoDatabase ObterPagamentoDatabase(int idPagamentoDatabase)
        {
            PagamentoDatabase pagamentoDb = (from _pag in _contexto.PagamentoRepository
                                             where _pag.idPagamento == idPagamentoDatabase
                                             select new PagamentoDatabase()
                                             {
                                                 idPagamento = _pag.idPagamento,
                                                 idColigada = _pag.idColigada,
                                                 idProcessoOrigem = _pag.idProcessoOrigem,
                                                 dataPagamento = _pag.dataPagamento,
                                                 dataRegistro = _pag.dataRegistro,
                                                 tipoPagamento = _pag.tipoPagamento,
                                                 valorPagamento = _pag.valorPagamento
                                             }).FirstOrDefault();
            return pagamentoDb;
        }



    }
}
