﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Data.Entity;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using System.Data;
using System.Data.SqlTypes;
using System.Web.Configuration;
using System.Data.SqlClient;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class PagamentoRepository : IPagamentoRepository
    {
        private PanReembolsoContext _contexto;

        public PagamentoRepository()
        {
            _contexto = new PanReembolsoContext();
        }


        public Entidades.Pagamento ObterPagamentosPorId(long idPagamento)
        {
            try
            {
                var resultItem = (from _pagam in _contexto.PagamentoRepository
                                  where _pagam.dataPagamento == null
                                  && _pagam.idPagamento  == idPagamento

                                  select new Entidades.Pagamento
                                  {
                                      numeroPagamento = _pagam.idPagamento,
                                      dataPagamento = _pagam.dataPagamento,
                                      dataRegistroPagamento = _pagam.dataRegistro,
                                      tipoPagamento = _pagam.tipoPagamento,
                                      valorPagamento = _pagam.valorPagamento,
                                      statusPagamento = _pagam.statusPagamento,
                                  }).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.listaReembolsos = new ReembolsoRepository().ObterReembolsosPorIdPagamento(resultItem).ToList();
                    resultItem.favorecido = new FavorecidoRepository().ObterFavorecidoPorIdPagamento(resultItem);
                }
                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Entidades.Pagamento> ObterPagamentosPorStatus(StatusPagamentoType status)
        {
            try
            {
                var resultItem = (from _pagam in _contexto.PagamentoRepository
                                  where _pagam.dataPagamento == null
                                  && _pagam.statusPagamento == status.ToString()

                                  select new Entidades.Pagamento
                                  {
                                      numeroPagamento = _pagam.idPagamento,
                                      dataPagamento = _pagam.dataPagamento,
                                      dataRegistroPagamento = _pagam.dataRegistro,
                                      tipoPagamento = _pagam.tipoPagamento,
                                      valorPagamento = _pagam.valorPagamento,
                                      statusPagamento = _pagam.statusPagamento,
                                  });

                foreach (var item in resultItem)
                {
                    item.listaReembolsos = new ReembolsoRepository().ObterReembolsosPorIdPagamento(item).ToList();
                    item.favorecido = new FavorecidoRepository().ObterFavorecidoPorIdPagamento(item);
                }
                return resultItem.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private PagamentoDatabase ObterPagamentoDBPorCPFCliente(string cpfOuCnpj)
        {
            try
            {
                PagamentoDatabase resultItem = (from _reemb in _contexto.ReembolsoRepository
                                                join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                                join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                                join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                                join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                                where _clie.cpfCnpj == cpfOuCnpj

                                                select _pagam

                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void PersistirPagamento(Entidades.Pagamento pagamento)
        {

            int idFavorecido;
            //Verifica se já existe pagamento aberto para dado cpf
            var pagamentoDB = ObterPagamentosPorId(pagamento.numeroPagamento);

            pagamento.listaReembolsos = pagamento.listaReembolsos.Except(pagamentoDB.listaReembolsos).ToList();

            if (pagamentoDB != null)
            {
                if (pagamento.listaReembolsos.Any())
                {
                    pagamento.valorPagamento = (pagamentoDB.valorPagamento + pagamento.listaReembolsos.Sum(t => t.valorReembolso));

                    AgregarReembolso(pagamento);
                }

                AtualizarPagamento(pagamento);
            }
            else
            {
                idFavorecido = new FavorecidoRepository().PersistirFavorecido(pagamento.favorecido);
                IncluirPagamento(pagamento);
            }
        }

        private void AgregarReembolso(Entidades.Pagamento pagamento)
        {
            try
            {
                var idsReembolsos = pagamento.listaReembolsos.Select(s => s.idReembolso).ToList();

                IncluirPagamentoReembolsosDB(pagamento.numeroPagamento, idsReembolsos);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private void AtualizarPagamento(Entidades.Pagamento pagamento)
        {
            try
            {
                var db = (from _pgt in _contexto.PagamentoRepository
                          where _pgt.idPagamento == pagamento.numeroPagamento
                          select _pgt).FirstOrDefault();

                db.statusPagamento = pagamento.statusPagamento;
                db.tipoPagamento = pagamento.statusPagamento;
                db.valorPagamento = pagamento.valorPagamento;

                _contexto.Entry(db).State = EntityState.Modified;

                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void IncluirPagamento(Entidades.Pagamento pagamento)
        {
            try
            {
                pagamento.statusPagamento = ReembolsoTypes.StatusPagamentoType.Aprovado.ToString();

                PagamentoDatabase item = new PagamentoDatabase()
                {
                    idColigada = _contexto.ColigadaRepository.Select(x => x)
                                                                .Where(x => x.codigoColigada == pagamento.listaReembolsos[0].contrato.coligada.codigoColigada)
                                                                .FirstOrDefault()
                                                                .idColigada,
                    idFavorecido = _contexto.FavorecidoRepository.Select(x => x)
                                                                .Where(x => x.numeroCpfCnpj == pagamento.favorecido.numeroCpfCnpj
                                                                && x.sequenciaCpfCnpj == pagamento.favorecido.sequenciaCpfCnpj)
                                                                .FirstOrDefault()
                                                                .idFavorecido,
                    dataPagamento = null,
                    dataRegistro = DateTime.Now,
                    tipoPagamento = ReembolsoTypes.PagamentoType.TED.ToString(),
                    valorPagamento = pagamento.valorPagamento,
                    statusPagamento = pagamento.statusPagamento
                };

                _contexto.Set<PagamentoDatabase>().Add(item);
                _contexto.SaveChanges();

                IncluirPagamentoReembolsosDB(item.idPagamento, pagamento.listaReembolsos.Select(x => x.idReembolso).ToList());

                //return item.idPagamento;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void IncluirPagamentoReembolsosDB(long idPagamento, List<long> idsReembolsos)
        {
            try
            {
                foreach (var idReembolso in idsReembolsos)
                {
                    ReembolsoPagamentoDatabase pagamento = new ReembolsoPagamentoDatabase()
                    {
                        idPagamento = idPagamento,

                        idReembolso = idReembolso
                    };

                    _contexto.Set<ReembolsoPagamentoDatabase>().Add(pagamento);
                }
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<List<object>> ConsultarRetiradaInterna(string cpfCnpj = "", string codProduto = "")
        {
            try
            {
                var siglas = new List<string>();
                siglas.Add("DCONB");
                siglas.Add("DEV TEF");

                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _sigla in _contexto.SiglaRepository on _reemb.idSigla equals _sigla.idSigla
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                              join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                              where
                              (_reemb.statusReembolso == StatusReembolsoType.Registrado.ToString() ||
                               _reemb.statusReembolso == StatusReembolsoType.Bloqueado.ToString())
                              && (!siglas.Contains(_sigla.codigoSigla)
                              && (_clie.cpfCnpj == cpfCnpj || cpfCnpj == "")
                              && (_prod.codigoProduto == codProduto || codProduto == ""))

                              select new
                              {
                                  idReembolso = _reemb.idReembolso,
                                  dtReembolso = _reemb.dtInclusao,
                                  valor = _reemb.valorReembolso,
                                  nomeCliente = _clie.nomeCliente,
                                  cpf = _clie.cpfCnpj,
                                  produto = new { _prod.codigoProduto, _prod.nomeProduto }
                              }).OrderByDescending(x => x.dtReembolso);

                var pagamentos = result.GroupBy(s => new { s.cpf, s.nomeCliente, s.produto }).Select(t => new
                {
                    cpf = t.Key.cpf,
                    nomeCliente = t.Key.nomeCliente,
                    valor = t.Sum(u => u.valor),
                    ids = t.Select(d => d.idReembolso),
                    produto = t.Key.produto

                }).OrderByDescending(n => n.valor);

                return pagamentos.ToList<object>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public async Task<string> PersistirIntegracaoBulk(DataTable retiradasTable)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings[ReembolsoConstantes.BANCO_BULK_INSERT].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = ReembolsoConstantes.TABELA_INTEGRACAO_RETIRADA;

                    try
                    {
                        await bulkCopy.WriteToServerAsync(retiradasTable);

                        return retiradasTable.Rows[0]["CD_LOTE_INTEGRACAO"].ToString();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }


        public DataTable ObterIntegracaoRetiradaDataTable()
        {
            DataTable TabelaIntegracao = new DataTable(ReembolsoConstantes.TABELA_INTEGRACAO_RETIRADA);

            TabelaIntegracao.Columns.Add(new DataColumn("ID_INTEGRACAO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CPF_CNPJ", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PRODUTO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("VL_RETIRADA", typeof(SqlDecimal)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_PAGAMENTO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_LOTE_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_STATUS_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DS_MENSAGEM_ERRO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_USUARIO_INCLUSAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INCLUSAO", typeof(DateTime)));

            return TabelaIntegracao;
        }
    }
}
