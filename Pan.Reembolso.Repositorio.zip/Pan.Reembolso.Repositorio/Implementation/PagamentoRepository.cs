﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class PagamentoRepository : IPagamentoRepository
    {
        private PanReembolsoContext _contexto;

        public PagamentoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.PagamentoReembolso ObterPagamentoPorIdReembolso(int idReembolso)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository 
                                  join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                  join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                  where _reemb.idReembolso == idReembolso
                                  select new Pan.Reembolso.Entidades.PagamentoReembolso()
                                  {
                                      dataPagamento = _pagam.dataPagamento,
                                      dataRegistroPagamento = _pagam.dataRegistro,
                                      tipoPagamento = _pagam.tipoPagamento,
                                      valorPagamento = _pagam.valorPagamento
                                  }
                ).FirstOrDefault();

                if(resultItem != null)
                    resultItem.mensagem = new MensagemRepository().ObterMensagemPorIdReembolso(idReembolso);

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
