﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ProcessoRegistroRepository : IProcessoRegistroRepository
    {
        private PanReembolsoContext _contexto;

        public ProcessoRegistroRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorIdReembolso(long idReembolso)
        {
            try
            {

                var processoRegistro = from _reemb in _contexto.ReembolsoRepository
                                       join _processoRegistro in _contexto.ProcessoRegistroRepository on _reemb.idProcessoRegistro equals _processoRegistro.idProcessoRegistro
                                       join _event in _contexto.EventoRepository on _processoRegistro.idEvento equals _event.idEvento
                                       where _reemb.idReembolso == idReembolso
                                       select _processoRegistro;

                var dbProcessoRegistro = processoRegistro.FirstOrDefault();
                
                if (dbProcessoRegistro != null)
                {
                    var result = MapProcessoRegistro(dbProcessoRegistro);

                    if (result != null)
                    {
                        result.evento = new EventoRepository().ObterEventoPorId(dbProcessoRegistro.idEvento);
                        result.eventoEstorno = new EventoRepository().ObterEventoPorId(dbProcessoRegistro.idEventoEstorno.Value);
                    }

                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<object> ObterProcessoRegistroList()
        {
            try
            {
                var processos = _contexto.ProcessoRegistroRepository.Where(s => s.indicadorFluxo == "ENTRADA")
                        .Select(c => new 
                        {
                            codigoProcessoRegistro = c.idProcessoRegistro,
                            processoRegistro = c.descricaoProcesso
                        });

                return processos.ToList<object>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Entidades.ProcessoRegistro> ObterProcessoRegistro(string fluxo)
        {
            try
            {
                var processoRegistro = from _processoRegistro in _contexto.ProcessoRegistroRepository 
                                       join _event in _contexto.EventoRepository on _processoRegistro.idEvento equals _event.idEvento
                                       where _processoRegistro.indicadorFluxo == fluxo || string.IsNullOrEmpty(fluxo)
                                       select _processoRegistro;

                var result = MapProcessoRegistro(processoRegistro.OrderBy(x => x.indicadorFluxo).OrderBy(x => x.descricaoProcesso));
                
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorCodigoFluxo(int? codigoProcessoRegistro, string indicadoFluxo) 
        {

            try
            {
                if (codigoProcessoRegistro == 0 || codigoProcessoRegistro == null)
                {
                    return null;
                }

                var processoRegistro = _contexto.ProcessoRegistroRepository.Where(n => n.codigoProcessoRegistro == codigoProcessoRegistro &&
                                                                                       n.indicadorFluxo == indicadoFluxo);

                var dbProcessoRegistro = processoRegistro.FirstOrDefault();

                if (dbProcessoRegistro != null)
                {
                    var result = MapProcessoRegistro(dbProcessoRegistro);

                    if (result != null)
                    {
                        result.evento = new EventoRepository().ObterEventoPorId(dbProcessoRegistro.idEvento);
                        result.eventoEstorno = (dbProcessoRegistro.idEventoEstorno != null) ? new EventoRepository().ObterEventoPorId(dbProcessoRegistro.idEventoEstorno.Value) : null;
                    }

                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private IQueryable<Entidades.ProcessoRegistro> MapProcessoRegistro(IQueryable<ProcessoRegistroDatabase> processoRegistros)
        {
            var result = processoRegistros.Select(n => new Pan.Reembolso.Entidades.ProcessoRegistro()
            {
                codigoProcessoRegistro = n.codigoProcessoRegistro,
                processoRegistro = n.descricaoProcesso,
                centroCusto = n.codigoCentroCusto,
                indicadorFluxo = n.indicadorFluxo,
                contaCredito = n.codigoContaCredito,
                contaDebito = n.codigoContaDebito,
                modeloContabil = n.modeloContabil,
                modeloContabilReversao = n.modeloContabilReversao,
                contaCreditoReversao = n.contaCreditoReversao,
                contaDebitoReversao = n.contaDebitoReversao
            });

            return result;
        }

        private Entidades.ProcessoRegistro MapProcessoRegistro(ProcessoRegistroDatabase processoRegistro)
        {
            var result = new ProcessoRegistro 
            {
                codigoProcessoRegistro = processoRegistro.codigoProcessoRegistro,
                processoRegistro = processoRegistro.descricaoProcesso,
                centroCusto = processoRegistro.codigoCentroCusto,
                indicadorFluxo = processoRegistro.indicadorFluxo,
                contaCredito = processoRegistro.codigoContaCredito,
                contaDebito = processoRegistro.codigoContaDebito,
                modeloContabil = processoRegistro.modeloContabil,
                modeloContabilReversao = processoRegistro.modeloContabilReversao,
                contaCreditoReversao = processoRegistro.contaCreditoReversao,
                contaDebitoReversao = processoRegistro.contaDebitoReversao
            };

            return result;
        }


        //public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorCodigoEntrada(int codigoProcessoRegistro)
        //{
        //    return ObterProcessoRegistroPorCodigoFluxo( codigoProcessoRegistro, "ENTRADA");
        //}
        //public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorCodigoSaida(int codigoProcessoRegistro)
        //{
        //    return ObterProcessoRegistroPorCodigoFluxo(codigoProcessoRegistro, "SAIDA");
        //}
    }
}
