﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ProcessoRegistroRepository : IProcessoRegistroRepository
    {
        private PanReembolsoContext _contexto;

        public ProcessoRegistroRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorIdReembolso(long idReembolso)
        {
            try
            {

                var processoRegistro = from _reemb in _contexto.ReembolsoRepository
                                       join _processoRegistro in _contexto.ProcessoRegistroRepository on _reemb.idProcessoRegistro equals _processoRegistro.idProcessoRegistro
                                       join _event in _contexto.EventoRepository on _processoRegistro.idEvento equals _event.idEvento
                                       where _reemb.idReembolso == idReembolso
                                       select _processoRegistro;

                var result = MapProcessoRegistro(processoRegistro).FirstOrDefault();

                if (result != null)
                {
                    result.evento = new EventoRepository().ObterEventoObterEventoPorId(processoRegistro.FirstOrDefault().idEvento);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorCodigoEntrada(int codigoProcessoRegistro)
        {
            return ObterProcessoRegistroPorCodigoFluxo( codigoProcessoRegistro, "ENTRADA");
        }
        public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorCodigoSaida(int codigoProcessoRegistro)
        {
            return ObterProcessoRegistroPorCodigoFluxo(codigoProcessoRegistro, "SAIDA");
        }
        public Pan.Reembolso.Entidades.ProcessoRegistro ObterProcessoRegistroPorCodigoFluxo(int codigoProcessoRegistro, string indicadoFluxo) 
        {
            try
            {
                var processoRegistro = _contexto.ProcessoRegistroRepository.Where(n => n.codigoProcessoRegistro == codigoProcessoRegistro &&
                                                                                    n.indicadorFluxo == indicadoFluxo);

                var result = MapProcessoRegistro(processoRegistro).FirstOrDefault();

                if (result != null)
                {
                    result.evento = new EventoRepository().ObterEventoObterEventoPorId(processoRegistro.FirstOrDefault().idEvento);
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private IQueryable<Entidades.ProcessoRegistro> MapProcessoRegistro(IQueryable<ProcessoRegistroDatabase> processoRegistros)
        {
            var result = processoRegistros.Select(n => new Pan.Reembolso.Entidades.ProcessoRegistro()
            {
                codigoProcessoRegistro = n.codigoProcessoRegistro,
                processoRegistro = n.descricaoProcesso,
                centroCusto = n.codigoCentroCusto,
                indicadorFluxo = n.indicadorFluxo,
                contaCredito = n.codigoContaCredito,
                contaDebito = n.codigoContaDebito,
                modeloContabil = n.modeloContabil,
                modeloContabilReversao = n.modeloContabilReversao,
            });

            return result;
        }
    }
}
