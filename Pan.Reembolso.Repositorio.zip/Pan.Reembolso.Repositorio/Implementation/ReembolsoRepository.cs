﻿using System;
using System.Linq;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using System.Collections.Generic;
using Pan.Reembolso.Repositorio.Filters;
using System.Data;
using Pan.Reembolso.Entidades.ImplementationTypes;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ReembolsoRepository : IReembolsoRepository
    {
        private PanReembolsoContext _contexto;

        public ReembolsoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Reembolso ObterReembolso(int id) 
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  where _reemb.idReembolso == id  
                                  select new Entidades.Reembolso()
                                  {
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso,
                                      dtInclusao = _reemb.dtInclusao.Value
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(id);
                    resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(id);
                    resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(id);
                    resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(id);
                    resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(id);
                    resultItem.processoRegistro= new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(id);
                    resultItem.lote = new LoteRepository().ObterLotePorIdReembolso(id);
                }

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
       
        public IList<Entidades.Reembolso> ObterReembolsos(ReembolsoFilter filter)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  where (_reemb.idLote == filter.idLote || filter.idLote == null)
                                  && (_contr.idProduto == filter.idProduto || filter.idProduto == null)
                                  && (_reemb.statusReembolso == filter.statusReembolso || string.IsNullOrEmpty(filter.statusReembolso))
                                  && (
                                        (
                                            _reemb.dtInclusao >= filter.dtInicial || filter.dtInicial == null
                                        )
                                        &&
                                        (
                                            _reemb.dtInclusao <= filter.dtFinal || filter.dtFinal == null
                                        )
                                     )
                                  && (_clie.cpfCnpj == filter.cpfCliente || string.IsNullOrEmpty(filter.cpfCliente))

                                  select new Entidades.Reembolso
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso,
                                  }
                ).ToList();

                foreach (var item in resultItem)
                {
                    item.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(item.idReembolso);
                    item.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(item.idReembolso);
                    item.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(item.idReembolso);
                    item.contrato = new ContratoRepository().ObterContratoPorIdReembolso(item.idReembolso);
                    item.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(item.idReembolso);
                    item.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(item.idReembolso);
                    item.lote = new LoteRepository().ObterLotePorIdReembolso(item.idReembolso);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia)
        {
            try
            {
                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              where _contr.codigoContrato == codigoContrato
                              && _reemb.valorReembolso == valorReembolso
                              && _reemb.mesCompetencia == mesCompetencia

                              select new Entidades.Reembolso()
                              {
                                  idReembolso = _reemb.idReembolso,
                                  numeroReembolso = _reemb.idReembolso,
                                  dataSolicitacao = _reemb.dataSolicitacao,
                                  statusReembolso = _reemb.statusReembolso,
                                  valorReembolso = _reemb.valorReembolso,
                                  mesCompetencia = _reemb.mesCompetencia
                              }
                );

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void PersistirReembolso(Entidades.Reembolso values, string idLote) 
        {
            try 
            {
                var contratoRep = new ContratoRepository();

                int idContrato = contratoRep.PersistirContrato(values.contrato);

                int idLoteReembolso = new LoteRepository().IncluirLote(idLote);

                Entidades.DatabaseEntities.ReembolsoDatabase item = new Entidades.DatabaseEntities.ReembolsoDatabase
                {
                    idLote = idLoteReembolso,
                    idContrato = idContrato,
                    dataSolicitacao = values.dataSolicitacao,
                    valorReembolso = values.valorReembolso,
                    statusReembolso = values.statusReembolso,
                    codigoUsuarioInclusao = values.usuario.codigoUsuario,
                    mesCompetencia = values.mesCompetencia,
                    anoCompetencia = values.anoCompetencia,

                    idDepartamento = _contexto.DepartamentoRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoDepartamento == values.departamento.codigoDepartamento)
                                                                .FirstOrDefault().idDepartamento,

                    idProcessoRegistro = _contexto.ProcessoRegistroRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoProcessoRegistro == values.processoRegistro.codigoProcessoRegistro
                                                                         && x.indicadorFluxo == ReembolsoConstantes.FLUXO_ENTRADA)
                                                                .FirstOrDefault().idProcessoRegistro,

                    idSigla = _contexto.SiglaRepository
                                                .Select(x => x)
                                                .Where(x => x.codigoSigla == values.sigla.codigoSigla)
                                                .FirstOrDefault().idSigla
                };

                _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Add(item);
                _contexto.SaveChanges();
                values.numeroReembolso = item.idReembolso;
                values.lote.idLote = item.idLote;
            }
            catch (Exception ex) 
            {
                values.mensagemErro = ex.Message;
                throw ex; 
            }
        }

        public void ExcluirReembolso(List<int> idsAEstornar) 
        {
            try
            {
                IQueryable<Entidades.DatabaseEntities.ReembolsoDatabase> listaReembolsos = ObterReembolsosDatabasePorId(idsAEstornar);

                foreach (var item in listaReembolsos)
                {
                    EstornarReembolso(item);
                }

                _contexto.SaveChanges();
            }
            catch ( Exception ex)
            {

                throw ex;
            }


        }

        public void EstornarReembolso(Entidades.DatabaseEntities.ReembolsoDatabase item)
        {
            item.statusReembolso = StatusReembolsoType.Cancelado.ToString();
            _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Attach(item);
            _contexto.Entry(item).State = System.Data.Entity.EntityState.Modified;
        }

        private IQueryable<Entidades.DatabaseEntities.ReembolsoDatabase> ObterReembolsosDatabasePorId(List<int> ids)
        {
            return _contexto.ReembolsoRepository.Where(x => ids.Contains(x.idReembolso));
        }

        public Entidades.Reembolso ObterReembolso(string codigoContrato)
        {
            throw new NotImplementedException();
        }
    }
}
