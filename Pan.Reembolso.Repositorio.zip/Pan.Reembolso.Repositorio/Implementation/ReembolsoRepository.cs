﻿using System;
using System.Linq;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using System.Collections.Generic;
using Pan.Reembolso.Repositorio.Filters;
using System.Data;
using Pan.Reembolso.Entidades.ImplementationTypes;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using System.Web;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ReembolsoRepository : IReembolsoRepository
    {
        private PanReembolsoContext _contexto;
        public ReembolsoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Reembolso ObterReembolso(long id)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  where _reemb.idReembolso == id
                                  select new Entidades.Reembolso()
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso,
                                      anoCompetencia = _reemb.anoCompetencia,
                                      mesCompetencia = _reemb.mesCompetencia,
                                      dtInclusao = _reemb.dtInclusao.Value,
                                      mensagemErro = _reemb.mensagemErro,
                                      usuarioInclusao = _reemb.codigoUsuarioInclusao,
                                      usuarioAlteracao = _reemb.codigoUsuarioAlteracao,
                                      usuarioAprovacao = _reemb.codigoUsuarioAprovacao,
                                      motivoBloqueio = new MotivoBloqueio { idMotivoBloqueio = _reemb.idMotivoBloqueio.Value },
                                      statusUsuario = _reemb.statusUsuario,
                                      tipoPagamentoLegado = _reemb.tipoPagamentoLegado,
                                      indicadorTombado = _reemb.indicadorTombado
                                  }
                ).FirstOrDefault();


                if (resultItem != null)
                {
                    if (resultItem.statusUsuario == null)
                    {
                        resultItem.statusUsuario = ReembolsoTypes.ObterStatusUsuario(resultItem.statusReembolso).ToString();
                    }
                    resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(id);
                    resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(id);
                    resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(id);
                    resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(id);
                    resultItem.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(id);
                    resultItem.lote = new LoteRepository().ObterLotePorIdReembolso(id);
                    resultItem.historicoReembolso = new HistoricoReembolsoRepository().ObterHistoricoReembolsoPorIdReembolso(id).ToList();
                    resultItem.motivoBloqueio = new MotivoBloqueioRepository().ObterMotivoBloqueio(resultItem.motivoBloqueio.idMotivoBloqueio);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Entidades.Reembolso> ObterReembolsoPorCpfCnpj(string cpfCnpj)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _cli in _contexto.ClienteRepository on _contr.idCliente equals _cli.idCliente
                                  where _cli.cpfCnpj == cpfCnpj

                                  select new Entidades.Reembolso()
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso,
                                      anoCompetencia = _reemb.anoCompetencia,
                                      mesCompetencia = _reemb.mesCompetencia,
                                      dtInclusao = _reemb.dtInclusao.Value,
                                      mensagemErro = _reemb.mensagemErro,
                                      usuarioInclusao = _reemb.codigoUsuarioInclusao,
                                      usuarioAlteracao = _reemb.codigoUsuarioAlteracao,
                                      usuarioAprovacao = _reemb.codigoUsuarioAprovacao,
                                      motivoBloqueio = new MotivoBloqueio { idMotivoBloqueio = _reemb.idMotivoBloqueio.Value }
                                  }
                ).ToList();


                if (resultItem.Any())
                {
                    foreach (var item in resultItem)
                    {
                        item.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(item.idReembolso);
                        item.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(item.idReembolso);
                        item.contrato = new ContratoRepository().ObterContratoPorIdReembolso(item.idReembolso);
                        item.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(item.idReembolso);
                        item.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(item.idReembolso);
                        item.lote = new LoteRepository().ObterLotePorIdReembolso(item.idReembolso);
                        item.historicoReembolso = new HistoricoReembolsoRepository().ObterHistoricoReembolsoPorIdReembolso(item.idReembolso).ToList();
                        item.motivoBloqueio = new MotivoBloqueioRepository().ObterMotivoBloqueio(item.motivoBloqueio.idMotivoBloqueio);
                    }
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Entidades.Reembolso> ObterReembolsoList(long id)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  where _reemb.idReembolso == id || id == 0
                                  select new Entidades.Reembolso()
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso,
                                      anoCompetencia = _reemb.anoCompetencia,
                                      mesCompetencia = _reemb.mesCompetencia,
                                      dtInclusao = _reemb.dtInclusao.Value,
                                      mensagemErro = _reemb.mensagemErro,
                                      usuarioInclusao = _reemb.codigoUsuarioInclusao,
                                      usuarioAlteracao = _reemb.codigoUsuarioAlteracao,
                                      usuarioAprovacao = _reemb.codigoUsuarioAprovacao
                                  }
                );

                var dep = new DepartamentoRepository();
                var comunic = new ComunicacaoRepository();
                var contrato = new ContratoRepository();
                var sigla = new SiglaRepository();
                var processo = new ProcessoRegistroRepository();
                var lote = new LoteRepository();
                var hist = new HistoricoReembolsoRepository();

                foreach (var item in resultItem)
                {
                    item.departamento = dep.ObterDepartamentoPorIdReembolso(id);
                    item.comunicacoes = comunic.ObterComunicacaoPorIdReembolso(id);
                    item.contrato = contrato.ObterContratoPorIdReembolso(id);
                    item.sigla = sigla.ObterSiglaPorIdReembolso(id);
                    item.processoRegistro = processo.ObterProcessoRegistroPorIdReembolso(id);
                    item.lote = lote.ObterLotePorIdReembolso(id);
                    item.historicoReembolso = hist.ObterHistoricoReembolsoPorIdReembolso(id).ToList();
                }

                return resultItem.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.Reembolso ObterReembolsoPorIdContrato(string codigoContrato)
        {
            throw new NotImplementedException();
        }

        public void AtualizarStatusReembolso(long idReembolso, StatusReembolsoType status, MotivoBloqueio motivoBloqueio, string mensagemErro = "", string userAlteracao = "usuarioReembolso", string aprovador = "")
        {
            try
            {
                var reembolsoDatabase = ObterReembolsosDatabasePorId(idReembolso);

                reembolsoDatabase.statusReembolso = status.ToString();

                reembolsoDatabase.statusUsuario = ObterStatusUsuario(status).ToString();

                reembolsoDatabase.mensagemErro = mensagemErro;

                reembolsoDatabase.codigoUsuarioAlteracao = userAlteracao;

                if (motivoBloqueio != null)
                {
                    reembolsoDatabase.idMotivoBloqueio = motivoBloqueio.idMotivoBloqueio;
                }

                reembolsoDatabase.codigoUsuarioAprovacao = aprovador;

                _contexto.Entry(reembolsoDatabase).Property(u => u.statusReembolso).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.mensagemErro).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.codigoUsuarioAlteracao).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.codigoUsuarioAprovacao).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.statusUsuario).IsModified = true;

                _contexto.SaveChanges();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia)
        {
            try
            {
                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              where _contr.codigoContrato == codigoContrato
                              && _reemb.valorReembolso == valorReembolso
                              && _reemb.mesCompetencia == mesCompetencia

                              select new Entidades.Reembolso()
                              {
                                  idReembolso = _reemb.idReembolso,
                                  numeroReembolso = _reemb.idReembolso,
                                  dtInclusao = _reemb.dataSolicitacao,
                                  statusReembolso = _reemb.statusReembolso,
                                  valorReembolso = _reemb.valorReembolso,
                                  mesCompetencia = _reemb.mesCompetencia,
                                  mensagemErro = _reemb.mensagemErro,
                                  lote = new Lote { idLote = _reemb.idLote }
                              }
                );

                var teem = result.FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  join _motBloq in _contexto.MotivoBloqueioRepository on _reemb.idMotivoBloqueio equals _motBloq.idMotivoBloqueio into motTemp
                                  //join _dePara in listaDePara on _reemb.statusReembolso equals _dePara.statusReembolso
                                  from _motTemp in motTemp.DefaultIfEmpty()
                                  where (_reemb.idLote == filter.idLote || filter.idLote == null)
                                  && (_prod.codigoProduto == filter.codigoProduto || string.IsNullOrEmpty(filter.codigoProduto))
                                  && (filter.statusReembolso.Contains(_reemb.statusReembolso) || !filter.statusReembolso.Any())
                                  && (
                                        (_reemb.dtInclusao >= filter.dtInicial || filter.dtInicial == null) &&
                                        (_reemb.dtInclusao <= filter.dtFinal || filter.dtFinal == null)
                                     )
                                  && (_clie.cpfCnpj == filter.cpfCliente || string.IsNullOrEmpty(filter.cpfCliente))
                                  && (_reemb.idReembolso == filter.idReembolso || filter.idReembolso == null)
                                  && (_motTemp.idMotivoBloqueio == filter.idMotivoBloqueio || filter.idMotivoBloqueio == null)
                                  select new
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      idLote = _reemb.idLote,
                                      nomeProduto = _prod.nomeProduto,
                                      dtInclusao = _reemb.dtInclusao,
                                      numeroCpfCnpj = _clie.cpfCnpj,
                                      numeroContrato = _contr.codigoContrato,
                                      nomeCliente = _clie.nomeCliente,
                                      valorReembolso = _reemb.valorReembolso,
                                      statusReembolso = _reemb.statusReembolso,
                                      statusUsuario = _reemb.statusUsuario,
                                      permiteEstorno =
                                      (_reemb.statusReembolso == StatusReembolsoType.Registrado.ToString()
                                      || _reemb.statusReembolso == StatusReembolsoType.Bloqueado.ToString()
                                      ),
                                      mesCompetencia = _reemb.mesCompetencia,
                                      anoCompetencia = _reemb.anoCompetencia,
                                      convenio = _contr.convenio,
                                      descricaoMotivoBloqueio = _motTemp.descricaoMotivoBloqueio,
                                      tipoPagamentoLegado = _reemb.tipoPagamentoLegado,
                                      indicadorTombado = _reemb.indicadorTombado
                                  }
                );
                var listaResposta = new List<object>();
                foreach (var item in resultItem.ToList())
                {
                    listaResposta.Add(new
                    {
                        item.idReembolso,
                        item.idLote,
                        item.nomeProduto,
                        item.dtInclusao,
                        item.numeroCpfCnpj,
                        item.numeroContrato,
                        item.nomeCliente,
                        item.valorReembolso,
                        item.statusReembolso,
                        statusUsuario = item.statusUsuario == null ? ReembolsoTypes.ObterStatusUsuario(item.statusReembolso).ToString() : item.statusUsuario,
                        item.permiteEstorno,
                        item.mesCompetencia,
                        item.anoCompetencia,
                        item.convenio,
                        item.descricaoMotivoBloqueio,
                        item.tipoPagamentoLegado,
                        item.indicadorTombado
                    });
                }

                return listaResposta;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public Entidades.Reembolso ObterDetalhes(int idReembolso)
        //{
        //    try
        //    {
        //        var resultItem = (from _reemb in _contexto.ReembolsoRepository
        //                          join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
        //                          join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
        //                          join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
        //                          where _reemb.idReembolso == idReembolso

        //                          select new Entidades.Reembolso
        //                          {
        //                              idReembolso = _reemb.idReembolso,
        //                              numeroReembolso = _reemb.idReembolso,
        //                              dtInclusao = _reemb.dataSolicitacao,
        //                              dataSolicitacao = _reemb.dataSolicitacao,
        //                              statusReembolso = _reemb.statusReembolso,
        //                              valorReembolso = _reemb.valorReembolso,
        //                              anoCompetencia = _reemb.anoCompetencia,
        //                              mesCompetencia = _reemb.mesCompetencia,
        //                              mensagemErro = _reemb.mensagemErro
        //                          }
        //        ).FirstOrDefault();

        //            resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(resultItem.idReembolso);
        //            resultItem.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(resultItem.idReembolso);
        //            resultItem.lote = new LoteRepository().ObterLotePorIdReembolso(resultItem.idReembolso);
        //            resultItem.historicoReembolso = new HistoricoReembolsoRepository().ObterHistoricoReembolsoPorIdReembolso(resultItem.idReembolso).ToList();


        //        return resultItem;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public void PersistirReembolso(Entidades.Reembolso values, string indicadorFluxo = ReembolsoConstantes.FLUXO_ENTRADA)
        {
            try
            {
                var contratoRep = new ContratoRepository();

                int idContrato = contratoRep.PersistirContrato(values.contrato);

                if (values.lote.idLote == 0)
                {
                    values.lote.idLote = new LoteRepository().IncluirLote();
                }

                int? idMotivoBloqueio = null;

                if (values.motivoBloqueio != null)
                {
                    idMotivoBloqueio = values.motivoBloqueio.idMotivoBloqueio;
                }

                Entidades.DatabaseEntities.ReembolsoDatabase item = new Entidades.DatabaseEntities.ReembolsoDatabase
                {
                    idLote = values.lote.idLote,
                    idContrato = idContrato,
                    dtInclusao = values.dtInclusao,
                    dataSolicitacao = values.dtInclusao,
                    valorReembolso = values.valorReembolso,
                    statusReembolso = values.statusReembolso,
                    statusUsuario = values.statusUsuario,
                    codigoUsuarioInclusao = values.usuarioInclusao,
                    mesCompetencia = values.mesCompetencia,
                    anoCompetencia = values.anoCompetencia,
                    mensagemErro = values.mensagemErro,
                    idDepartamento = _contexto.DepartamentoRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoDepartamento == values.departamento.codigoDepartamento)
                                                                .FirstOrDefault().idDepartamento,

                    idProcessoRegistro = _contexto.ProcessoRegistroRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoProcessoRegistro == values.processoRegistro.codigoProcessoRegistro
                                                                         && x.indicadorFluxo == indicadorFluxo)
                                                                .FirstOrDefault().idProcessoRegistro,

                    idSigla = _contexto.SiglaRepository
                                                .Select(x => x)
                                                .Where(x => x.codigoSigla == values.sigla.codigoSigla)
                                                .FirstOrDefault().idSigla,

                    idMotivoBloqueio = idMotivoBloqueio
                };

                _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Add(item);
                _contexto.SaveChanges();

                values.numeroReembolso = item.idReembolso;
                values.lote.idLote = item.idLote;
            }
            catch (Exception ex)
            {
                values.mensagemErro = ex.Message;
                throw ex;
            }
        }

        public void ExcluirReembolso(List<long> idsAEstornar)
        {
            try
            {
                IQueryable<Entidades.DatabaseEntities.ReembolsoDatabase> listaReembolsos = ObterReembolsosDatabasePorIds(idsAEstornar);

                foreach (var item in listaReembolsos)
                {
                    EstornarReembolso(item);
                }

                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EstornarReembolso(Entidades.DatabaseEntities.ReembolsoDatabase item)
        {
            item.statusReembolso = StatusReembolsoType.Cancelado.ToString();

            item.statusUsuario = ObterStatusUsuario(StatusReembolsoType.Cancelado).ToString();

            _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Attach(item);

            _contexto.Entry(item).State = System.Data.Entity.EntityState.Modified;
        }

        private IQueryable<Entidades.DatabaseEntities.ReembolsoDatabase> ObterReembolsosDatabasePorIds(List<long> ids)
        {
            return _contexto.ReembolsoRepository.Where(x => ids.Contains(x.idReembolso));
        }

        public IEnumerable<Entidades.Reembolso> ObterReembolsosPorIdPagamento(Pagamento pagamento)
        {
            try
            {
                var lista = new List<Entidades.Reembolso>();

                var result =
                (
                    from _rpgt in _contexto.ReembolsoPagamentoRepository
                    where _rpgt.idPagamento == pagamento.numeroPagamento

                    select _rpgt

                );

                foreach (var item in result)
                {
                    lista.Add(ObterReembolso(item.idReembolso));
                }
                return lista;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public Object ConsultarPagamentosARealizar(DateTime? dtInicial, DateTime? dtFinal)
        //{
        //    try
        //    {
        //        var result = (from _reemb in _contexto.ReembolsoRepository
        //                      join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
        //                      join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
        //                      where _reemb.statusReembolso == StatusReembolsoType.Registrado.ToString()
        //                      && (
        //                            (_reemb.dtInclusao >= dtInicial || dtInicial == null) &&
        //                            (_reemb.dtInclusao <= dtFinal || dtFinal == null)
        //                      )
        //                      select new
        //                      {
        //                          idReembolso = _reemb.idReembolso,
        //                          valor = _reemb.valorReembolso,
        //                          nomeCliente = _clie.nomeCliente,
        //                          cpf = _clie.cpfCnpj
        //                      });

        //        var pagamentos = result.GroupBy(s => new { s.cpf, s.nomeCliente }).Select(t => new
        //        {
        //            cpf = t.Key.cpf,
        //            nomeCliente = t.Key.nomeCliente,
        //            valor = t.Sum(u => u.valor),
        //            ids = t.Select(d => d.idReembolso).ToList()

        //        }).OrderByDescending(n => n.valor);

        //        var historicoPagamentos = AppendHistoricoPagamentos();

        //        var retorno = new
        //        {
        //            pagamentos = pagamentos,
        //            historicoPagamentos = historicoPagamentos
        //        };

        //        return retorno;

        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }

        //}

        public Aprovacao ConsultarPagamentosARealizarPorStatus(DateTime? dtInicial, DateTime? dtFinal, StatusReembolsoType statusReembolso)
        {
            try
            {
                var aprov = new Aprovacao();

                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                              where (_reemb.statusReembolso == statusReembolso.ToString() || statusReembolso == StatusReembolsoType.Undefined)
                              && (
                                    (_reemb.dtInclusao >= dtInicial || dtInicial == null) &&
                                    (_reemb.dtInclusao <= dtFinal || dtFinal == null)
                              )
                              select new
                              {
                                  idReembolso = _reemb.idReembolso,
                                  valor = _reemb.valorReembolso,
                                  nomeCliente = _clie.nomeCliente,
                                  numeroCpfCnpj = _clie.cpfCnpj,
                                  status = _reemb.statusReembolso
                              });

                aprov.pagamentos = result.GroupBy(s => new { s.numeroCpfCnpj, s.nomeCliente }).Select(t => new Aprovacao.PagamentoAAprovar
                {
                    numeroCpfCnpj = t.Key.numeroCpfCnpj,
                    nomeCliente = t.Key.nomeCliente,
                    valor = t.Sum(u => u.valor),
                    ids = t.Select(d => d.idReembolso).ToList(),
                }).OrderByDescending(x => x.valor).ToList();



                AppendHistoricoPagamentos(aprov);

                //var retorno = new
                //{
                //    pagamentos = pagamentos.ToList(),
                //    historicoPagamentos = historicoPagamentos
                //};

                return aprov;

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public void AppendHistoricoPagamentos(Aprovacao aprov, DateTime? dtReferencia = null)
        {

            try
            {
                if (dtReferencia == null)
                {
                    dtReferencia = DateTime.Now;
                }

                TimeSpan periodo60 = new TimeSpan(60, 0, 0, 0);
                var dataPassado60 = dtReferencia.Value.Subtract(periodo60);

                var historicoPagamentos = _contexto.HistoricoReembolsoRepository.Where(x => x.statusFim == "PagamentoLiberado" && x.dataEvento > dataPassado60).Select(x => x).ToList();

                var idsReembolsosHistorico60 = historicoPagamentos.Select(n => n.idReembolso).Distinct().ToList();
                var idsReembolso60 = _contexto.ReembolsoRepository.Where(x => idsReembolsosHistorico60.Contains(x.idReembolso));
                aprov.historicoPagamentos.historico60 = idsReembolso60
                    .Select(t => new
                    {
                        chave = 1,
                        valor = t.valorReembolso
                    }).GroupBy(t => t.chave).Select(t => new Aprovacao.HistoricoValor
                    {
                        total = t.Sum(u => u.valor),
                        media = t.Average(u => u.valor)
                    }).FirstOrDefault();

                TimeSpan periodo30 = new TimeSpan(30, 0, 0, 0);
                var dataPassado30 = dtReferencia.Value.Subtract(periodo30);

                var idsReembolsosHistorico30 = historicoPagamentos.Where(y => y.dataEvento > dataPassado30).Select(n => n.idReembolso).Distinct().ToList();
                var idsReembolso30 = _contexto.ReembolsoRepository.Where(x => idsReembolsosHistorico30.Contains(x.idReembolso));
                aprov.historicoPagamentos.historico30 = idsReembolso30
                    .Select(t => new
                    {
                        chave = 1,
                        valor = t.valorReembolso
                    }).GroupBy(t => t.chave).Select(t => new Aprovacao.HistoricoValor
                    {
                        total = t.Sum(u => u.valor),
                        media = t.Average(u => u.valor)
                    }).FirstOrDefault();

                TimeSpan periodo10 = new TimeSpan(10, 0, 0, 0);
                var dataPassado10 = dtReferencia.Value.Subtract(periodo10);

                var idsReembolsosHistorico10 = historicoPagamentos.Where(y => y.dataEvento > dataPassado10).Select(n => n.idReembolso).Distinct().ToList();
                var idsReembolso10 = _contexto.ReembolsoRepository.Where(x => idsReembolsosHistorico10.Contains(x.idReembolso));
                aprov.historicoPagamentos.historico10 = idsReembolso10
                    .Select(t => new
                    {
                        chave = 1,
                        valor = t.valorReembolso
                    }).GroupBy(t => t.chave).Select(t => new Aprovacao.HistoricoValor
                    {
                        total = t.Sum(u => u.valor),
                        media = t.Average(u => u.valor)
                    }).FirstOrDefault();

                var vazio = new Aprovacao.HistoricoValor
                {
                    total = 0,
                    media = 0
                };
                if (aprov.historicoPagamentos.historico10 == null)
                {
                    aprov.historicoPagamentos.historico10 = vazio;
                }
                vazio = new Aprovacao.HistoricoValor
                {
                    total = 0,
                    media = 0
                };
                if (aprov.historicoPagamentos.historico30 == null)
                {
                    aprov.historicoPagamentos.historico30 = vazio;
                }
                vazio = new Aprovacao.HistoricoValor
                {
                    total = 0,
                    media = 0
                };
                if (aprov.historicoPagamentos.historico60 == null)
                {
                    aprov.historicoPagamentos.historico60 = vazio;
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private Entidades.DatabaseEntities.ReembolsoDatabase ObterReembolsosDatabasePorId(long id)
        {
            return _contexto.ReembolsoRepository.Where(x => x.idReembolso == id).FirstOrDefault();
        }

        public decimal ObterValorTotalDeReembolsos(List<long> idsReembolsos)
        {
            decimal somatoria = 0;
            var reembolsos = _contexto.ReembolsoRepository.Where(x => idsReembolsos.Contains(x.idReembolso));
            foreach (var reembolso in reembolsos)
            {
                somatoria += reembolso.valorReembolso;
            }
            return somatoria;
        }

        public List<Entidades.Reembolso> ObterListaReembolso(List<long> idsReembolsos)
        {

            var listaReembolsos = new List<Entidades.Reembolso>();
            foreach (var item in idsReembolsos)
            {
                var reembolso = ObterReembolso(item);

                listaReembolsos.Add(reembolso);
            }

            listaReembolsos = listaReembolsos.OrderByDescending(s => s.dtInclusao).ToList();

            return listaReembolsos;
        }

        public IList<long> ObterIdsReembolsoPorFiltro(ReembolsoFilter filter)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  where (_reemb.idLote == filter.idLote || filter.idLote == null)
                                  && (_prod.codigoProduto == filter.codigoProduto || string.IsNullOrEmpty(filter.codigoProduto))
                                  && (filter.statusReembolso.Contains(_reemb.statusReembolso) || !filter.statusReembolso.Any())
                                  && (
                                        (_reemb.dtInclusao >= filter.dtInicial || filter.dtInicial == null) &&
                                        (_reemb.dtInclusao <= filter.dtFinal || filter.dtFinal == null)
                                     )
                                  && (_clie.cpfCnpj == filter.cpfCliente || string.IsNullOrEmpty(filter.cpfCliente))

                                  select new
                                  {
                                      _reemb.idReembolso
                                  }
                );

                return resultItem.Select(s => s.idReembolso).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

