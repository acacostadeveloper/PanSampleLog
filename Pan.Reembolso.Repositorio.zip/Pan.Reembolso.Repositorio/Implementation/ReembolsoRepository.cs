﻿using System;
using System.Linq;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using System.Collections.Generic;
using Pan.Reembolso.Repositorio.Filters;
using System.Data;
using Pan.Reembolso.Entidades.ImplementationTypes;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ReembolsoRepository : IReembolsoRepository
    {
        private PanReembolsoContext _contexto;
        public ReembolsoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Reembolso ObterReembolso(long id) 
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  where _reemb.idReembolso == id
                                  select new Entidades.Reembolso()
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso,
                                      anoCompetencia = _reemb.anoCompetencia,
                                      mesCompetencia = _reemb.mesCompetencia,
                                      dtInclusao = _reemb.dtInclusao.Value,
                                      mensagemErro = _reemb.mensagemErro,
                                      usuarioInclusao = _reemb.codigoUsuarioInclusao,
                                      usuarioAlteracao = _reemb.codigoUsuarioAlteracao,
                                      usuarioAprovacao = _reemb.codigoUsuarioAprovacao
                                  }
                ).FirstOrDefault();


                if (resultItem != null)
                {
                    resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(id);
                    resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(id);
                    resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(id);
                    resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(id);
                    resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(id);
                    resultItem.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(id);
                    resultItem.lote = new LoteRepository().ObterLotePorIdReembolso(id);
                    resultItem.historicoReembolso = new HistoricoReembolsoRepository().ObterHistoricoReembolsoPorIdReembolso(id).ToList();
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.Reembolso ObterReembolsoPorIdContrato(string codigoContrato)
        {
            throw new NotImplementedException();
        }

        public void AtualizarStatusReembolso(long idReembolso, StatusReembolsoType status, string mensagemErro = "", string userAlteracao = "usuarioReembolso", string aprovador = "")
        {
            try
            {
                var reembolsoDatabase = ObterReembolsosDatabasePorId(idReembolso);

                reembolsoDatabase.statusReembolso = status.ToString();

                reembolsoDatabase.mensagemErro = mensagemErro;

                reembolsoDatabase.codigoUsuarioAlteracao = userAlteracao;

                reembolsoDatabase.codigoUsuarioAprovacao = aprovador;

                _contexto.Entry(reembolsoDatabase).Property(u => u.statusReembolso).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.mensagemErro).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.codigoUsuarioAlteracao).IsModified = true;
                _contexto.Entry(reembolsoDatabase).Property(u => u.codigoUsuarioAprovacao).IsModified = true;

                _contexto.SaveChanges();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia)
        {
            try
            {
                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              where _contr.codigoContrato == codigoContrato
                              && _reemb.valorReembolso == valorReembolso
                              && _reemb.mesCompetencia == mesCompetencia

                              select new Entidades.Reembolso()
                              {
                                  idReembolso = _reemb.idReembolso,
                                  numeroReembolso = _reemb.idReembolso,
                                  dtInclusao = _reemb.dataSolicitacao,
                                  statusReembolso = _reemb.statusReembolso,
                                  valorReembolso = _reemb.valorReembolso,
                                  mesCompetencia = _reemb.mesCompetencia,
                                  mensagemErro = _reemb.mensagemErro,
                                  lote = new Lote { idLote = _reemb.idLote, lote = "" }
                              }
                );

                var teem = result.FirstOrDefault();

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  where (_reemb.idLote == filter.idLote || filter.idLote == null)
                                  && (_prod.codigoProduto == filter.codigoProduto || string.IsNullOrEmpty(filter.codigoProduto))
                                  && (filter.statusReembolso.Contains(_reemb.statusReembolso) || !filter.statusReembolso.Any())
                                  && (
                                        (_reemb.dtInclusao >= filter.dtInicial || filter.dtInicial == null) &&
                                        (_reemb.dtInclusao <= filter.dtFinal || filter.dtFinal == null)
                                     )
                                  && (_clie.cpfCnpj == filter.cpfCliente || string.IsNullOrEmpty(filter.cpfCliente))

                                  select new
                                  {
                                      idReembolso = _reemb.idReembolso,
                                      idLote = _reemb.idLote,
                                      nomeProduto = _prod.nomeProduto,
                                      dtInclusao = _reemb.dtInclusao,
                                      numeroCpfCnpj = _clie.cpfCnpj,
                                      numeroContrato = _contr.codigoContrato,
                                      nomeCliente = _clie.nomeCliente,
                                      valorReembolso = _reemb.valorReembolso,
                                      statusReembolso = _reemb.statusReembolso,
                                      permiteEstorno =
                                      (_reemb.statusReembolso == StatusReembolsoType.Registrado.ToString()
                                      || _reemb.statusReembolso == StatusReembolsoType.Bloqueado.ToString()
                                      )
                                  }
                );

                return resultItem.ToList<Object>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public Entidades.Reembolso ObterDetalhes(int idReembolso)
        //{
        //    try
        //    {
        //        var resultItem = (from _reemb in _contexto.ReembolsoRepository
        //                          join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
        //                          join _prod in _contexto.ProdutoRepository on _contr.idProduto equals _prod.idProduto
        //                          join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
        //                          where _reemb.idReembolso == idReembolso

        //                          select new Entidades.Reembolso
        //                          {
        //                              idReembolso = _reemb.idReembolso,
        //                              numeroReembolso = _reemb.idReembolso,
        //                              dtInclusao = _reemb.dataSolicitacao,
        //                              dataSolicitacao = _reemb.dataSolicitacao,
        //                              statusReembolso = _reemb.statusReembolso,
        //                              valorReembolso = _reemb.valorReembolso,
        //                              anoCompetencia = _reemb.anoCompetencia,
        //                              mesCompetencia = _reemb.mesCompetencia,
        //                              mensagemErro = _reemb.mensagemErro
        //                          }
        //        ).FirstOrDefault();

        //            resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(resultItem.idReembolso);
        //            resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(resultItem.idReembolso);
        //            resultItem.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(resultItem.idReembolso);
        //            resultItem.lote = new LoteRepository().ObterLotePorIdReembolso(resultItem.idReembolso);
        //            resultItem.historicoReembolso = new HistoricoReembolsoRepository().ObterHistoricoReembolsoPorIdReembolso(resultItem.idReembolso).ToList();


        //        return resultItem;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public void PersistirReembolso(Entidades.Reembolso values, string guidLote)
        {
            try
            {
                var contratoRep = new ContratoRepository();

                int idContrato = contratoRep.PersistirContrato(values.contrato);

                if (values.lote.idLote == 0)
                {
                    values.lote.idLote  = new LoteRepository().IncluirLote(guidLote);
                }


                Entidades.DatabaseEntities.ReembolsoDatabase item = new Entidades.DatabaseEntities.ReembolsoDatabase
                {
                    idLote = values.lote.idLote,
                    idContrato = idContrato,
                    dtInclusao = values.dtInclusao,
                    dataSolicitacao = values.dtInclusao,
                    valorReembolso = values.valorReembolso,
                    statusReembolso = values.statusReembolso,
                    codigoUsuarioInclusao = values.usuarioInclusao,
                    mesCompetencia = values.mesCompetencia,
                    anoCompetencia = values.anoCompetencia,
                    mensagemErro = values.mensagemErro,
                    idDepartamento = _contexto.DepartamentoRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoDepartamento == values.departamento.codigoDepartamento)
                                                                .FirstOrDefault().idDepartamento,

                    idProcessoRegistro = _contexto.ProcessoRegistroRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoProcessoRegistro == values.processoRegistro.codigoProcessoRegistro
                                                                         && x.indicadorFluxo == ReembolsoConstantes.FLUXO_ENTRADA)
                                                                .FirstOrDefault().idProcessoRegistro,

                    idSigla = _contexto.SiglaRepository
                                                .Select(x => x)
                                                .Where(x => x.codigoSigla == values.sigla.codigoSigla)
                                                .FirstOrDefault().idSigla
                };

                _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Add(item);
                _contexto.SaveChanges();

                values.numeroReembolso = item.idReembolso;
                values.lote.idLote = item.idLote;
            }
            catch (Exception ex)
            {
                values.mensagemErro = ex.Message;
                throw ex;
            }
        }

        public void ExcluirReembolso(List<long> idsAEstornar) 
        {
            try
            {
                IQueryable<Entidades.DatabaseEntities.ReembolsoDatabase> listaReembolsos = ObterReembolsosDatabasePorIds(idsAEstornar);

                foreach (var item in listaReembolsos)
                {
                    EstornarReembolso(item);
                }

                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void EstornarReembolso(Entidades.DatabaseEntities.ReembolsoDatabase item)
        {
            item.statusReembolso = StatusReembolsoType.Cancelado.ToString();
            _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Attach(item);
            _contexto.Entry(item).State = System.Data.Entity.EntityState.Modified;
        }

        private IQueryable<Entidades.DatabaseEntities.ReembolsoDatabase> ObterReembolsosDatabasePorIds(List<long> ids)
        {
            return _contexto.ReembolsoRepository.Where(x => ids.Contains(x.idReembolso));
        }

        public Object ConsultarPagamentosARealizar(DateTime? dtInicial, DateTime? dtFinal)
        {
            try
            {
                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                              join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                              where _reemb.statusReembolso == StatusReembolsoType.Registrado.ToString()
                              && (
                                    (_reemb.dtInclusao >= dtInicial || dtInicial == null) &&
                                    (_reemb.dtInclusao <= dtFinal || dtFinal == null)
                              )
                              select new
                              {
                                  idReembolso = _reemb.idReembolso,
                                  valor = _reemb.valorReembolso,
                                  nomeCliente = _clie.nomeCliente,
                                  cpf = _clie.cpfCnpj
                              });

                var pagamentos = result.GroupBy(s => new { s.cpf, s.nomeCliente }).Select(t => new
                {
                    cpf = t.Key.cpf,
                    nomeCliente = t.Key.nomeCliente,
                    valor = t.Sum(u => u.valor),
                    ids = t.Select(d => d.idReembolso).ToList()

                });
                
                var historicoPagamentos = ConsultarHistoricoPagamentos();

                var retorno = new
                {
                    pagamentos = pagamentos,
                    historicoPagamentos = historicoPagamentos
                };

                return retorno;

            }
            catch (Exception)
            {

                throw;
            }

        }

        public Object ConsultarHistoricoPagamentos(DateTime? dtReferencia = null)
        {

            try
            {
                if (dtReferencia == null)
                {
                    dtReferencia = DateTime.Now;
                }
                
                

                TimeSpan periodo60 = new TimeSpan(60, 0, 0, 0);
                var dataPassado60 = dtReferencia.Value.Subtract(periodo60);


                var historicoPagamentos = (from _histReemb in _contexto.HistoricoReembolsoRepository
                                           join _reemb in _contexto.ReembolsoRepository on _histReemb.idReembolso equals _reemb.idReembolso
                                           join _event in _contexto.EventoRepository on _histReemb.idEvento equals _event.idEvento
                                           where _event.codigoEvento == "INCLUSAO NAO CONTABIL"//"PAGAMENTO EFETIVADO"
                                           && (
                                                     (_reemb.dtInclusao >= dataPassado60) &&
                                                     (_reemb.dtInclusao <= dtReferencia)
                                              )
                                           select new
                                           {
                                               _reemb.dtInclusao,
                                               _event.codigoEvento,
                                               _reemb.valorReembolso
                                           }
                                );

                TimeSpan periodo30 = new TimeSpan(30, 0, 0, 0);
                var dataPassado30 = dtReferencia.Value.Subtract(periodo30);


                var historico30 = historicoPagamentos.Where(s => (s.dtInclusao >= dataPassado30) &&
                                                   (s.dtInclusao <= dtReferencia)).GroupBy(s => s.codigoEvento).Select(t => new
                                                   {
                                                       total = t.Sum(u => u.valorReembolso),
                                                       media = t.Average(u => u.valorReembolso)
                                                   }).FirstOrDefault();

                TimeSpan periodo10 = new TimeSpan(10, 0, 0, 0);
                var dataPassado10 = dtReferencia.Value.Subtract(periodo10);

                var historico10 = historicoPagamentos.Where(s => (s.dtInclusao >= dataPassado10) &&
                                                   (s.dtInclusao <= dtReferencia)).GroupBy(s => s.codigoEvento).Select(t => new
                                                   {
                                                       total = t.Sum(u => u.valorReembolso),
                                                       media = t.Average(u => u.valorReembolso)
                                                   }).FirstOrDefault();

                var historico60 = historicoPagamentos.GroupBy(s => s.codigoEvento).Select(t => new
                {
                    total = t.Sum(u => u.valorReembolso),
                    media = t.Average(u => u.valorReembolso)
                }).FirstOrDefault();

                var retorno = new
                {
                    historico10,
                    historico30,
                    historico60
                };

                return retorno;

            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        private Entidades.DatabaseEntities.ReembolsoDatabase ObterReembolsosDatabasePorId(long id)
        {
            return _contexto.ReembolsoRepository.Where(x => x.idReembolso == id).FirstOrDefault();
        }

        

    }
}
