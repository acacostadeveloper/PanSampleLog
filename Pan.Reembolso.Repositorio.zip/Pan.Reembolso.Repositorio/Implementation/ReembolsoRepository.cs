﻿using System;
using System.Linq;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using System.Collections.Generic;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ReembolsoRepository : IReembolsoRepository
    {
        private PanReembolsoContext _contexto;

        public ReembolsoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Reembolso ObterReembolso(int id) 
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  where _reemb.idReembolso == id  
                                  select new Entidades.Reembolso()
                                  {
                                      idLote = _reemb.idLote,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(id);
                    resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(id);
                    resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(id);
                    resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(id);
                    resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(id);
                    resultItem.processoRegistro= new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(id);
                }

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public IQueryable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia)
        {
            try
            {
                var result = (from _reemb in _contexto.ReembolsoRepository
                              join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  where _contr.codigoContrato  == codigoContrato
                                  
                              select new Entidades.Reembolso()
                                  {
                                      // TODO - Verificar ID
                                      //idReembolso = _reemb.idReembolso,
                                      idLote = _reemb.idLote,
                                      numeroReembolso = _reemb.idReembolso,
                                      dataSolicitacao = _reemb.dataSolicitacao,
                                      statusReembolso = _reemb.statusReembolso,
                                      valorReembolso = _reemb.valorReembolso
                                  }
                );

                if (result.Any())
                {
                    foreach (var resultItem in result)
                    {
                        // TODO Verificar ID
                        //resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorIdReembolso(resultItem.idReembolso);
                        //resultItem.pagamento = new PagamentoRepository().ObterPagamentoPorIdReembolso(resultItem.idReembolso);
                        //resultItem.comunicacoes = new ComunicacaoRepository().ObterComunicacaoPorIdReembolso(resultItem.idReembolso);
                        //resultItem.contrato = new ContratoRepository().ObterContratoPorIdReembolso(resultItem.idReembolso);
                        //resultItem.sigla = new SiglaRepository().ObterSiglaPorIdReembolso(resultItem.idReembolso);
                        //resultItem.processoRegistro = new ProcessoRegistroRepository().ObterProcessoRegistroPorIdReembolso(resultItem.idReembolso);
                    }
                }

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void PersistirReembolso(Entidades.Reembolso values, string idLote) 
        {
            try 
            {
                var contratoRep = new ContratoRepository();

                int idContrato = contratoRep.PersistirContrato(values.contrato);

                Entidades.DatabaseEntities.ReembolsoDatabase item = new Entidades.DatabaseEntities.ReembolsoDatabase
                {
                    idLote = idLote,
                    idContrato = idContrato,
                    dataSolicitacao = values.dataSolicitacao,
                    valorReembolso = values.valorReembolso,
                    statusReembolso = values.statusReembolso,
                    codigoUsuarioInclusao = values.usuario.codigoUsuario,

                    idDepartamento = _contexto.DepartamentoRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoDepartamento == values.departamento.codigoDepartamento)
                                                                .FirstOrDefault().idDepartamento,

                    idProcessoRegistro = _contexto.ProcessoRegistroRepository
                                                                .Select(x => x)
                                                                .Where(x => x.codigoProcessoRegistro == values.processoRegistro.codigoProcessoRegistro)
                                                                .FirstOrDefault().idProcessoRegistro,

                    idSigla = _contexto.SiglaRepository
                                                .Select(x => x)
                                                .Where(x => x.codigoSigla == values.sigla.codigoSigla)
                                                .FirstOrDefault().idSigla

                };

                _contexto.Set<Entidades.DatabaseEntities.ReembolsoDatabase>().Add(item);
                _contexto.SaveChanges();
                values.numeroReembolso = item.idReembolso;
            }
            catch (Exception ex) 
            {
                throw ex; 
            }
        }

        public void ExcluirReembolso(int id) 
        { 
            // todo
        }

        public Entidades.Reembolso ObterReembolso(string codigoContrato)
        {
            throw new NotImplementedException();
        }
    }
}
