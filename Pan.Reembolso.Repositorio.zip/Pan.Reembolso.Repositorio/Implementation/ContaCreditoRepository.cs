﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ContaCreditoRepository
    {
        private PanReembolsoContext _contexto;

        public ContaCreditoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.ContaCredito ObterContaCreditoPorCpfCliente(string cpfCliente)
        {
            try
            {
                var resultItem = (from _clien in _contexto.ClienteRepository
                                  join _cccli in _contexto.ContaCreditoRepository on _clien.idCliente equals _cccli.idCliente
                                  join _contC in _contexto.ContaRepository on _cccli.idConta equals _contC.idConta
                                  where _clien.cpfCnpj == cpfCliente
                                  select new Pan.Reembolso.Entidades.ContaCredito()
                                  {
                                      numeroBanco = _contC.numeroBanco,
                                      numeroAgencia = _contC.numeroAgencia,
                                      digitoAgencia = _contC.digitoAgencia,
                                      numeroConta = _contC.numeroConta,
                                      digitoConta = _contC.digitoConta,
                                      tipoConta = _contC.tipoConta
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public Pan.Reembolso.Entidades.ContaCredito ObterContaCreditoPorNumeroRequisicao(string numeroRequisicao)
        {
            try
            {
                var resultItem = (from _msgtr in _contexto.MensagemTransferenciaRepository
                                  join _cccli in _contexto.ContaReservaRepository on _msgtr.idContaCredito equals _cccli.idConta
                                  join _contC in _contexto.ContaRepository on _cccli.idConta equals _contC.idConta
                                  where _msgtr.numeroRequisicao == numeroRequisicao
                                  select new Pan.Reembolso.Entidades.ContaCredito()
                                  {
                                      numeroBanco = _contC.numeroBanco,
                                      numeroAgencia = _contC.numeroAgencia,
                                      digitoAgencia = _contC.digitoAgencia,
                                      numeroConta = _contC.numeroConta,
                                      digitoConta = _contC.digitoConta,
                                      tipoConta = _contC.tipoConta
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
