﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using System.Data.Entity;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ContaCreditoRepository : IContaCreditoRepository
    {
        private PanReembolsoContext _contexto;

        public ContaCreditoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.ContaCredito ObterContaCreditoPorCpfCliente(string cpfCliente)
        {
            try
            {
                var resultItem = (from _clien in _contexto.ClienteRepository
                                  join _cccli in _contexto.ContaCreditoRepository on _clien.idCliente equals _cccli.idCliente
                                  join _contC in _contexto.ContaRepository on _cccli.idConta equals _contC.idConta
                                  where _clien.cpfCnpj == cpfCliente
                                  select new Pan.Reembolso.Entidades.ContaCredito()
                                  {
                                      numeroBanco = _contC.numeroBanco,
                                      numeroAgencia = _contC.numeroAgencia,
                                      digitoAgencia = _contC.digitoAgencia,
                                      numeroConta = _contC.numeroConta,
                                      digitoConta = _contC.digitoConta,
                                      tipoConta = _contC.tipoConta
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.ContaCredito ObterContaCreditoPorNumeroRequisicao(string numeroRequisicao)
        {
            try
            {
                var resultItem = (from _msgtr in _contexto.MensagemTransferenciaRepository
                                  join _cccli in _contexto.ContaReservaRepository on _msgtr.idContaCredito equals _cccli.idConta
                                  join _contC in _contexto.ContaRepository on _cccli.idConta equals _contC.idConta
                                  where _msgtr.numeroRequisicao == numeroRequisicao

                                  select new Pan.Reembolso.Entidades.ContaCredito()
                                  {
                                      numeroBanco = _contC.numeroBanco,
                                      numeroAgencia = _contC.numeroAgencia,
                                      digitoAgencia = _contC.digitoAgencia,
                                      numeroConta = _contC.numeroConta,
                                      digitoConta = _contC.digitoConta,
                                      tipoConta = _contC.tipoConta,
                                      fraude = _contC.fraude
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.ContaCredito ObtertContaCreditoPorIdCliente(int idCliente)
        {
            var query = (from _ccr in _contexto.ContaCreditoRepository
                         join _cco in _contexto.ContaRepository on _ccr.idConta equals _cco.idConta
                         where _ccr.idCliente == idCliente

                         select new Pan.Reembolso.Entidades.ContaCredito()
                         {
                             numeroBanco = _cco.numeroBanco,
                             numeroAgencia = _cco.numeroAgencia,
                             digitoAgencia = _cco.digitoAgencia,
                             numeroConta = _cco.numeroConta,
                             digitoConta = _cco.digitoConta,
                             tipoConta = _cco.tipoConta,
                             fraude = _cco.fraude
                         }
            ).FirstOrDefault();

            return query;
        }

        public void IncluirContaCredito(Entidades.ContaCredito contaCredito, int idCliente)
        {
            Entidades.DatabaseEntities.ContaDatabase itemCco = new Entidades.DatabaseEntities.ContaDatabase
            {
                numeroBanco = contaCredito.numeroBanco,
                numeroAgencia = contaCredito.numeroAgencia,
                digitoAgencia = contaCredito.digitoAgencia,
                numeroConta = contaCredito.numeroConta,
                digitoConta = contaCredito.digitoConta,
                tipoConta = contaCredito.tipoConta
            };

            _contexto.Set<Entidades.DatabaseEntities.ContaDatabase>().Add(itemCco);
            _contexto.SaveChanges();

            Entidades.DatabaseEntities.ContaCreditoDatabase itemCcr = new Entidades.DatabaseEntities.ContaCreditoDatabase
            {
                idCliente = idCliente,
                idConta = itemCco.idConta,
                dataAtualizacao = DateTime.Now
            };

            _contexto.Set<Entidades.DatabaseEntities.ContaCreditoDatabase>().Add(itemCcr);
            _contexto.SaveChanges();
        }

        public void PersistirContaCredito(Entidades.ContaCredito contaCredito, int idCliente)
        {
            var conta = (from _ccr in _contexto.ContaCreditoRepository
                         join _cco in _contexto.ContaRepository on _ccr.idConta equals _cco.idConta
                         where _ccr.idCliente == idCliente
                         select new
                         {
                             _cco.idConta,
                             _cco.numeroBanco,
                             _cco.numeroAgencia,
                             _cco.digitoAgencia,
                             _cco.numeroConta,
                             _cco.digitoConta,
                             _cco.tipoConta
                         }
                          ).FirstOrDefault();

            if (conta != null)
            {
                var itemCco = new Entidades.DatabaseEntities.ContaDatabase()
                {
                    idConta = conta.idConta,
                    numeroBanco = contaCredito.numeroBanco,
                    numeroAgencia = contaCredito.numeroAgencia,
                    digitoAgencia = contaCredito.digitoAgencia,
                    numeroConta = contaCredito.numeroConta,
                    digitoConta = contaCredito.digitoConta,
                    tipoConta = contaCredito.tipoConta
                };

                _contexto.Entry(itemCco).State = EntityState.Modified;
                _contexto.SaveChanges();

                var itemCcr = new Entidades.DatabaseEntities.ContaCreditoDatabase
                {
                    idCliente = idCliente,
                    idConta = itemCco.idConta,
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Entry(itemCcr).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            else
            {
                if (!string.IsNullOrEmpty(contaCredito.numeroConta))
                {
                    IncluirContaCredito(contaCredito, idCliente);
                }
            }
        }
    }
}
