﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class HistoricoFinanceiroRepository : IHistoricoFinanceiroRepository
    {
        private PanReembolsoContext _contexto;

        public HistoricoFinanceiroRepository()
        {
            _contexto = new PanReembolsoContext();
        }
        
        public Pan.Reembolso.Entidades.HistoricoFinanceiro ObterHistoricoFinanceiroPorIdContrato(int idContrato)
        {
            try 
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  join _histFin in _contexto.HistoricoFinanceiroRepository  on _contr.idHistoricoFinanceiro equals _histFin.idHistoricoFinanceiro
                                  where _contr.idContrato == idContrato

                                  select new Pan.Reembolso.Entidades.HistoricoFinanceiro()
                                  {
                                      codigoHistoricoFinanceiro = _histFin.codigoHistoricoFinanceiro,
                                      motivo = _histFin.motivo,
                                      origemInformacao = _histFin.origemInformacao
                                  }
                ).FirstOrDefault();

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.HistoricoFinanceiro ObterHistoricoFinanceiroPorCodigoPanCred(int codigoHistoricoFinanceiro)
        {
            return ObterHistoricoFinanceiroPorCodigoOrigem(codigoHistoricoFinanceiro, "HF PANCRED");
        }

        public Pan.Reembolso.Entidades.HistoricoFinanceiro ObterHistoricoFinanceiroPorCodigoOrigem(int codigoHistoricoFinanceiro, string origemHistoricoFinanceiro)
        {
            try
            {
                var resultItem = (from _histFin in _contexto.HistoricoFinanceiroRepository
                                  where _histFin.codigoHistoricoFinanceiro == codigoHistoricoFinanceiro && _histFin.origemInformacao == origemHistoricoFinanceiro

                                  select new Pan.Reembolso.Entidades.HistoricoFinanceiro()
                                  {
                                      codigoHistoricoFinanceiro = _histFin.codigoHistoricoFinanceiro,
                                      motivo = _histFin.motivo,
                                      origemInformacao = _histFin.origemInformacao
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.HistoricoFinanceiro ObterHistoricoFinanceiroPorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  join _histFin in _contexto.HistoricoFinanceiroRepository on _contr.idHistoricoFinanceiro equals _histFin.idHistoricoFinanceiro
                                  where _contr.codigoContrato  == numeroContrato

                                  select new Pan.Reembolso.Entidades.HistoricoFinanceiro()
                                  {
                                      codigoHistoricoFinanceiro = _histFin.codigoHistoricoFinanceiro,
                                      motivo = _histFin.motivo,
                                      origemInformacao = _histFin.origemInformacao
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
