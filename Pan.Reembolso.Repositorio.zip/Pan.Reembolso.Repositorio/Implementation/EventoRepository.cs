﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class EventoRepository : IEventoRepository
    {
        private PanReembolsoContext _contexto;

        public EventoRepository()
        {
            _contexto = new PanReembolsoContext();
        }
        
        public Pan.Reembolso.Entidades.Evento ObterEventoObterEventoPorOperacao(string operacao)
        {
            try 
            {
                var resultItem = (from _event in _contexto.EventoRepository
                                  where _event.codigoEvento == operacao

                                  select new Pan.Reembolso.Entidades.Evento()
                                  {
                                      codigoEvento = _event.codigoEvento,
                                      eventoContabil = _event.eventoContabil,
                                      fluxo = _event.fluxo
                                  }

                ).FirstOrDefault();

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
