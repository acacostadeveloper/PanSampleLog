﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class EventoRepository : IEventoRepository
    {
        private PanReembolsoContext _contexto;

        public EventoRepository()
        {
            _contexto = new PanReembolsoContext();
        }
        
        public Pan.Reembolso.Entidades.Evento ObterEvento(string codigoEvento)
        {
            try 
            {
                var resultItem = (from _event in _contexto.EventoRepository
                                  where _event.codigoEvento == codigoEvento

                                  select new Pan.Reembolso.Entidades.Evento()
                                  {
                                      codigoEvento = _event.codigoEvento,
                                      eventoContabil = _event.eventoContabil,
                                      fluxo = _event.fluxo
                                  }

                ).FirstOrDefault();

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.Evento ObterEventoPorId(int idEvento)
        {
            try
            {
                var resultItem = (from _event in _contexto.EventoRepository where _event.idEvento == idEvento

                                  select new Pan.Reembolso.Entidades.Evento()
                                  {
                                      codigoEvento = _event.codigoEvento,
                                      eventoContabil = _event.eventoContabil,
                                      fluxo = _event.fluxo
                                  }

                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Evento ObterEventoPorProcessoRegistroInclusao(int codigoProcessoRegistro)
        {
            try
            {
                var resultItem = (from _event in _contexto.EventoRepository
                                  join _prc in _contexto.ProcessoRegistroRepository on _event.idEvento equals _prc.idEvento
                                  where _prc.codigoProcessoRegistro == codigoProcessoRegistro
                                  select new Evento()
                                  {
                                      codigoEvento = _event.codigoEvento,
                                      eventoContabil = _event.eventoContabil,
                                      fluxo = _event.fluxo
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Evento ObterEventoPorProcessoRegistroEstorno(int codigoProcessoRegistro)
        {
            try
            {
                var resultItem = (from _event in _contexto.EventoRepository
                                  join _prc in _contexto.ProcessoRegistroRepository on _event.idEvento equals _prc.idEventoEstorno
                                  where _prc.codigoProcessoRegistro == codigoProcessoRegistro
                                  select new Evento()
                                  {
                                      codigoEvento = _event.codigoEvento,
                                      eventoContabil = _event.eventoContabil,
                                      fluxo = _event.fluxo
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Evento ObterEventoPorProcessoRegistro(int codigoProcessoRegistro)
        {
            throw new NotImplementedException();
        }
    }
}
