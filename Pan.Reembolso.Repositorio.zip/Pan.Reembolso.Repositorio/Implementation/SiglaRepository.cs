﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;


namespace Pan.Reembolso.Repositorio.Implementation
{
    public class SiglaRepository : ISiglaRepository
    {
        private PanReembolsoContext _contexto;

        public SiglaRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Sigla ObterSiglaPorIdReembolso(int idReembolso)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _sigla in _contexto.SiglaRepository on _reemb.idSigla equals _sigla.idSigla
                                  where _reemb.idReembolso == idReembolso

                                  select new Pan.Reembolso.Entidades.Sigla()
                                  {
                                      codigoSigla = _sigla.codigoSigla,
                                      nomeSigla = _sigla.descricaoSigla
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.Sigla ObterSiglaPorCodigo(string codigoSigla)
        {
            try
            {
                var sigla = _contexto.SiglaRepository.FirstOrDefault(n => n.codigoSigla == codigoSigla);

                return new Entidades.Sigla
                {
                    codigoSigla = sigla.codigoSigla,
                    nomeSigla = sigla.descricaoSigla
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public IEnumerable<Sigla> ObterSiglas()
        {
            try
            {
                var siglas = _contexto.SiglaRepository
                        .Select(c => new Sigla
                        {
                            codigoSigla = c.codigoSigla,
                            nomeSigla = c.descricaoSigla
                        });

                return siglas;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
