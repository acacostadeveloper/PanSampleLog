﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ContabilRepository : IContabilRepository
    {
        private PanReembolsoContext _contexto;

        public ContabilRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public int GetNextRemessa()
        {
            try
            {
                var resultItem = (from _remes in _contexto.ContabilRemessaRepository
                                  orderby _remes.idRemessa descending
                                  select _remes
                ).FirstOrDefault();

                return resultItem.idRemessa + 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void SaveRemessa(int id)
        {
            Entidades.DatabaseEntities.ContabilRemessaDatabase item = new Entidades.DatabaseEntities.ContabilRemessaDatabase
            {
                idRemessa = id,
                dataRemessa = DateTime.Now
            };

            _contexto.Set<Entidades.DatabaseEntities.ContabilRemessaDatabase>().Add(item);
            _contexto.SaveChanges();
        }

        public void IncluirHistoricoContabil(Entidades.MovimentoContabil value, IDictionary<string, string> integrationReturn)
        {
            Entidades.DatabaseEntities.ContabilHistoricoDatabase item = new Entidades.DatabaseEntities.ContabilHistoricoDatabase
            {
                idContabilPadrao = value.movimentoPadrao.idContabilPadrao,
                numeroRegistro = value.numeroRegistro,
                dataSistema  = value.dataSistema,
                numeroRemessa = value.numeroRemessa,
                numeroOrigem = value.numeroOrigem,
                numeroSequenciaOrigem = value.numeroSequenciaOrigem,
                dataLancamento = value.dataLancamento,
                valorEntrada = value.valorEntrada,
                descricaoHistorico = value.descricaoHistorico,
                descricaoComplemento1 = value.descricaoComplemento1,
                numeroModelo = value.numeroModelo,
                numeroCentroCustoDebito = value.numeroCentroCustoDebito,
                numeroCentroCustoCredito = value.numeroCentroCustoCredito,
                dataDocumento = value.dataDocumento,
                dataUltimaAtualizacao = value.dataUltimaAtualizacao,
                codigoUsuario = value.codigoUsuario,
                nomeArquivoIntegrado = value.nomeArquivoIntegrado,
                dataIntegracao = value.dataIntegracao,
                idHistoricoReembolso = value.idHistoricoReembolso,
                codigoStatusContabilidade = integrationReturn["erroSucesso"].ToString(),
                descricaoMensagemContabilidade = integrationReturn["mensagem"].ToString()
            };

            _contexto.Set<Entidades.DatabaseEntities.ContabilHistoricoDatabase>().Add(item);
            _contexto.SaveChanges();
        }

        public Entidades.MovimentoContabilPadrao ObterMovimentoContabilPadrao(string codigoProduto)
        {
            try
            {
                var resultItem = (from _padr in _contexto.ContabilPadraoRepository
                                  join _prod in _contexto.ProdutoRepository on _padr.idProduto equals _prod.idProduto
                                  where _prod.codigoProduto == codigoProduto
                                  select new Entidades.MovimentoContabilPadrao()
                                  {
                                      codigoProcesso = _padr.codigoProcesso,
                                      codigoLayout = _padr.codigoLayout,
                                      codigoColigada = _padr.codigoColigada,
                                      codigoSistema = _padr.codigoSistema,
                                      numeroSequenciaOrigem = _padr.numeroSequenciaOrigem,
                                      codigoEmpresaOrigem = _padr.codigoEmpresaOrigem,
                                      codigoAgencia = _padr.codigoAgencia,
                                      codigoUnidade = _padr.codigoUnidade,
                                      codigoNivel1 = _padr.codigoNivel1,
                                      codigoNivel2 = _padr.codigoNivel2,
                                      codigoNivel3 = _padr.codigoNivel3,
                                      codigoNivel4 = _padr.codigoNivel4,
                                      codigoCreditaDebita = _padr.codigoCreditaDebita,
                                      codigoAgenciaDestino = _padr.codigoAgenciaDestino,
                                      codigoNivel1Destino = _padr.codigoNivel1Destino,
                                      codigoNivel2Destino = _padr.codigoNivel2Destino,
                                      codigoNivel3Destino = _padr.codigoNivel3Destino,
                                      codigoNivel4Destino = _padr.codigoNivel4Destino,
                                      codigoUnidadeDestino = _padr.codigoUnidadeDestino,
                                      descricaoComplemento2 = _padr.descricaoComplemento2,
                                      descricaoComplemento3 = _padr.descricaoComplemento3,
                                      descricaoComplemento4 = _padr.descricaoComplemento4,
                                      descricaoComplemento5 = _padr.descricaoComplemento5,
                                      codigoFormaLancamento = _padr.codigoFormaLancamento,
                                      codigoTipoLancamento = _padr.codigoTipoLancamento,
                                      codigoEvento = _padr.codigoEvento,
                                      numeroSequenciaItem = _padr.numeroSequenciaItem,
                                      nomeTabelaDebito = _padr.nomeTabelaDebito,
                                      codigoProdutoDebito = _padr.codigoProdutoDebito,
                                      codigoTipoCreditoDebito = _padr.codigoTipoCreditoDebito,
                                      codigoAtividadeDebito = _padr.codigoAtividadeDebito,
                                      codigoTipoContaDebito = _padr.codigoTipoContaDebito,
                                      numeroContaDebito = _padr.numeroContaDebito,
                                      codigoReduzidoDebito = _padr.codigoReduzidoDebito,
                                      numeroContaAuxiliarDebito = _padr.numeroContaAuxiliarDebito,
                                      numeroContaCorrenteDebito = _padr.numeroContaCorrenteDebito,
                                      nomeTabelaCredito = _padr.nomeTabelaCredito,
                                      codigoProdutoCredito = _padr.codigoProdutoCredito,
                                      codigoTipoCreditoCredito = _padr.codigoTipoCreditoCredito,
                                      codigoAtividadeCredito = _padr.codigoAtividadeCredito,
                                      codigoTipoContaCredito = _padr.codigoTipoContaCredito,
                                      numeroContaCredito = _padr.numeroContaCredito,
                                      codigoReduzidoCredito = _padr.codigoReduzidoCredito,
                                      numeroContaAuxiliarCredito = _padr.numeroContaAuxiliarCredito,
                                      numeroContaCorrenteCredito = _padr.numeroContaCorrenteCredito,
                                      codigoTipoMoeda = _padr.codigoTipoMoeda,
                                      quantidadeMoeda = _padr.quantidadeMoeda,
                                      valorMoeda = _padr.valorMoeda,
                                      indicadorReprocessamento = _padr.indicadorReprocessamento,
                                      codigoGerente = _padr.codigoGerente,
                                      numeroDocumento = _padr.numeroDocumento,
                                      indicadorAtualizado = _padr.indicadorAtualizado,
                                      indicadorCancelado = _padr.indicadorCancelado,
                                      indicadorEstornado = _padr.indicadorEstornado,
                                      idContabilPadrao = _padr.idContabilPadrao
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
