﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Data.Entity;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class TransferenciaDireitoRepository : ITransferenciaDireitoRepository
    {
        private PanReembolsoContext _contexto;

        public TransferenciaDireitoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public int PersistirTransferenciaDireito(int idConta, string numeroCpfCnpjCliente, Entidades.Cliente terceiro, DateTime dtInicioVigencia, DateTime? dtFimVigencia, string usuarioInclusao, string documento)
        {
            var db = ObterTransferenciaDireitoDBAtivoPorCpfCliente(numeroCpfCnpjCliente);
            var idTransferencia = -1;
            //Persiste pagamento
            if (db != null)
            {
                CancelarTransferenciaDireito(db);
                idTransferencia = IncluirTransferenciaDireito(numeroCpfCnpjCliente, terceiro, dtInicioVigencia, dtFimVigencia, idConta, usuarioInclusao, documento);
            }
            else
            {

                idTransferencia = IncluirTransferenciaDireito(numeroCpfCnpjCliente, terceiro, dtInicioVigencia, dtFimVigencia, idConta, usuarioInclusao, documento);
            }

            //Adiciona pagamento na tabela intermediaria entre pagamento e reembolso


            return idTransferencia;
        }

        public int IncluirTransferenciaDireito(
            string numeroCpfCnpjCliente,
            Entidades.Cliente terceiro,
            DateTime dtInicioVigencia,
            DateTime? dtFimVigencia,
            int idConta,
            string usuarioInclusao,
            string documento)
        {
            try
            {


                //var idConta = PersistirContaCredito(Entidades.ContaCredito contaCredito, int idCliente)(terceiro.contaCredito); //TO DO

                var item = new TransferenciaDireitoDatabase()
                {
                    idCliente = _contexto.ClienteRepository.Select(x => x)
                                                                .Where(x => x.cpfCnpj == numeroCpfCnpjCliente)
                                                                .FirstOrDefault()
                                                                .idCliente,
                    idConta = idConta,
                    indicadorAtivo = "1",
                    dtInicioVigencia = dtInicioVigencia,
                    dtFimVigencia = dtFimVigencia,
                    nomeTerceiro = terceiro.nomeCliente,
                    numeroCpfCnpj = terceiro.numeroCpfCnpj,
                    sequenciaCpfCnpj = 0,
                    tipoPesssoa = terceiro.tipoPessoa,
                    usuarioInclusao = usuarioInclusao,
                    documento = documento
                };

                _contexto.Set<TransferenciaDireitoDatabase>().Add(item);
                _contexto.SaveChanges();

                return item.idTransferenciaDireito;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public TransferenciaDireito ObterTransferenciaDireitoAtivoPorCpfCliente(string numeroCpfCnpjCliente)
        {
            try
            {
                var resultItem = 
                (
                    from _transf in _contexto.TransferenciaDireitoRepository
                    join _cli in _contexto.ClienteRepository on _transf.idCliente equals _cli.idCliente
                    where _cli.cpfCnpj == numeroCpfCnpjCliente && _transf.indicadorAtivo == "1"

                    select new Entidades.TransferenciaDireito()
                    {
                        cliente = new Cliente() { numeroCpfCnpj = _cli.cpfCnpj },
                        dtInicioVigencia = _transf.dtInicioVigencia,
                        dtFimVigencia = _transf.dtFimVigencia,
                        indicadorAtivo = _transf.indicadorAtivo,
                        nome = _transf.nomeTerceiro,
                        numeroCpfCnpj = _transf.numeroCpfCnpj,
                        sequenciaCpfCnpj = _transf.sequenciaCpfCnpj,
                        tipoPesssoa = _transf.tipoPesssoa,
                        usuarioInclusao = _transf.usuarioInclusao
                    }
                ).FirstOrDefault(); 

                if (resultItem != null)
                {
                    resultItem.cliente = new ClienteRepository().ObterCliente(resultItem.cliente.numeroCpfCnpj);
                    resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(resultItem.numeroCpfCnpj);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private TransferenciaDireitoDatabase ObterTransferenciaDireitoDBAtivoPorCpfCliente(string numeroCpfCnpjCliente)
        {
            try
            {
                var resultItem =
                (
                    from _transf in _contexto.TransferenciaDireitoRepository
                    join _cli in _contexto.ClienteRepository on _transf.idCliente equals _cli.idCliente
                    where _cli.cpfCnpj == numeroCpfCnpjCliente && _transf.indicadorAtivo == "1"

                    select  _transf

                ).FirstOrDefault();


                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public IEnumerable<TransferenciaDireito> ObterTransferenciaDireitoPorCpfCliente(string numeroCpfCnpjCliente)
        {
            try
            {
                var resultItem = QueryTransferenciaDireitoPorCpfCnpj(numeroCpfCnpjCliente).ToList();

                if (resultItem != null)
                {
                    foreach (var item in resultItem)
                    {
                        item.cliente = new ClienteRepository().ObterCliente(item.cliente.numeroCpfCnpj);
                        item.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(item.numeroCpfCnpj);
                    }
                }

                return resultItem.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private IEnumerable<TransferenciaDireito> QueryTransferenciaDireitoPorCpfCnpj(string numeroCpfCnpjCliente)
        {
            return (from _transf in _contexto.TransferenciaDireitoRepository
                    join _cli in _contexto.ClienteRepository on _transf.idCliente equals _cli.idCliente
                    where _cli.cpfCnpj == numeroCpfCnpjCliente 

                    select new Entidades.TransferenciaDireito()
                    {
                        cliente = new Cliente() { numeroCpfCnpj = _cli.cpfCnpj },
                        dtInicioVigencia = _transf.dtInicioVigencia,
                        dtFimVigencia = _transf.dtFimVigencia,
                        indicadorAtivo = _transf.indicadorAtivo,
                        nome = _transf.nomeTerceiro,
                        numeroCpfCnpj = _transf.numeroCpfCnpj,
                        sequenciaCpfCnpj = _transf.sequenciaCpfCnpj,
                        tipoPesssoa = _transf.tipoPesssoa,
                        usuarioInclusao = _transf.usuarioInclusao
                    }).ToList();

        }

        public int CancelarTransferenciaDireito(TransferenciaDireitoDatabase db)
        {
            try
            {
                db.indicadorAtivo = "0";

                _contexto.Entry(db).State = EntityState.Modified;
                _contexto.SaveChanges();

                return db.idTransferenciaDireito;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        
    }
}
