﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using System.Data.Entity;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ContaRejeicaoRepository : IContaRejeicaoRepository
    {
        private PanReembolsoContext _contexto;

        public ContaRejeicaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public List<Entidades.ContaRejeicao> ObterBlackListReembolso()
        {
            try
            {
                var resultItem = (from _blackList in _contexto.ContaRejeicaoRepository
                                  where _blackList.ativo == "1"

                                  select new Pan.Reembolso.Entidades.ContaRejeicao()
                                  {
                                      numeroBanco = _blackList.numeroBanco,
                                      numeroAgencia = _blackList.numeroAgencia,
                                      digitoAgencia = _blackList.digitoAgencia,
                                      numeroConta = _blackList.numeroConta,
                                      digitoConta = _blackList.digitoConta,
                                      tipoConta = _blackList.tipoConta,
                                      erro = _blackList.erro,
                                      ativo = _blackList.ativo,
                                      idConta = _blackList.idConta,
                                  }
                ).ToList();

                foreach (var item in resultItem.ToList())
                {
                    var conta = new ContaCreditoRepository().ObterConta(item.idConta);

                    item.numeroBanco = conta.numeroBanco;
                    item.numeroAgencia = conta.numeroAgencia;
                    item.digitoAgencia = conta.digitoAgencia;
                    item.numeroConta = conta.numeroConta;
                    item.digitoConta = conta.digitoConta;
                    item.tipoConta = conta.tipoConta;
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private void IncluirContaRejeicao(int idConta, ErroContaCreditoType erroContaCredito)
        {
            Entidades.DatabaseEntities.ContaRejeicaoDatabase itemCcr = new Entidades.DatabaseEntities.ContaRejeicaoDatabase
            {
                idConta = idConta,
                erro = erroContaCredito.ToString(),
                ativo = "1",
                dataAtualizacao = DateTime.Now
            };

            _contexto.Set<Entidades.DatabaseEntities.ContaRejeicaoDatabase>().Add(itemCcr);
            _contexto.SaveChanges();
        }

        public void PersistirContaRejeicao(Entidades.ContaCredito contaCredito, ErroContaCreditoType erroContaCredito)
        {
            var conta = (from _ccr in _contexto.ContaCreditoRepository
                         join _cco in _contexto.ContaRepository on _ccr.idConta equals _cco.idConta
                         where _cco.numeroBanco == contaCredito.numeroBanco &&
                         _cco.numeroAgencia == contaCredito.numeroAgencia &&
                         _cco.digitoAgencia == contaCredito.digitoAgencia &&
                         _cco.numeroConta == contaCredito.numeroConta &&
                         _cco.digitoConta == contaCredito.digitoConta
                         select new
                         {
                             _cco.idConta,
                             _cco.numeroBanco,
                             _cco.numeroAgencia,
                             _cco.digitoAgencia,
                             _cco.numeroConta,
                             _cco.digitoConta,
                             _cco.tipoConta
                         }).FirstOrDefault();

            if (conta != null)
            {
                if (!string.IsNullOrEmpty(contaCredito.numeroConta))
                {
                    //IncluirContaRejeicao(conta.idConta, erroContaCredito);
                }
            }
        }

        public void RemoverBlackList(Entidades.ContaCredito contaCredito)
        {
            var conta = (from _ccr in _contexto.ContaRejeicaoRepository
                         join _cco in _contexto.ContaRepository on _ccr.idConta equals _cco.idConta
                         where _ccr.idConta == _cco.idConta
                         select new 
                         {
                             _cco.idConta,
                             _cco.numeroBanco,
                             _cco.numeroAgencia,
                             _cco.digitoAgencia,
                             _cco.numeroConta,
                             _cco.digitoConta,
                             _cco.tipoConta
                         }).FirstOrDefault();

            if (conta != null)
            {

                var itemCcr = new Entidades.DatabaseEntities.ContaRejeicaoDatabase
                {
                    idConta = conta.idConta,
                    ativo = "0",
                    erro = ErroContaCreditoType.Undefined.ToString(),
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Entry(itemCcr).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
        }

    }
}
