﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ContratoRepository : IContratoRepository
    {
        private PanReembolsoContext _contexto;

        public ContratoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IEnumerable<Pan.Reembolso.Entidades.Contrato> ObterContrato() 
        {
            return null;
        }

        public Pan.Reembolso.Entidades.Contrato ObterContrato(int id) 
        {
            return null;
        }

        public Pan.Reembolso.Entidades.Contrato ObterContratoPorIdReembolso(int idReembolso)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository 
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  where _reemb.idReembolso == idReembolso 
                                  select new Pan.Reembolso.Entidades.Contrato()
                                  {
                                      numeroContrato = _contr.codigoContrato
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.produto = new ProdutoRepository().ObterProdutoPorNumeroContrato(resultItem.numeroContrato);
                    resultItem.cliente = new ClienteRepository().ObterClientePorNumeroContrato(resultItem.numeroContrato);
                    resultItem.coligada = new ColigadaRepository().ObterColigadaPorNumeroContrato(resultItem.numeroContrato);
                    resultItem.processoAjuizado = new ProcessoAjuizadoRepository().ObterProcessoPorNumeroContrato(resultItem.numeroContrato);
                    resultItem.historicoFinanceiro = new HistoricoFinanceiroRepository().ObterHistoricoFinanceiroPorNumeroContrato(resultItem.numeroContrato);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.Contrato ObterContrato(string codigoContrato) 
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  where _contr.codigoContrato == codigoContrato
                                  select new Pan.Reembolso.Entidades.Contrato()
                                  {
                                      numeroContrato = _contr.codigoContrato
                                  }

                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.produto = new ProdutoRepository().ObterProdutoPorNumeroContrato(resultItem.numeroContrato);
                    resultItem.cliente = new ClienteRepository().ObterClientePorNumeroContrato(resultItem.numeroContrato);
                    resultItem.coligada = new ColigadaRepository().ObterColigadaPorNumeroContrato(resultItem.numeroContrato);
                    resultItem.processoAjuizado = new ProcessoAjuizadoRepository().ObterProcessoPorNumeroContrato(resultItem.numeroContrato);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int PersistirContrato(Entidades.Contrato values) 
        {
            int idContrato = 0;
            
            var contrDb = _contexto.ContratoRepository.Select(x => x)
                                                      .Where(x => x.codigoContrato == values.numeroContrato)
                                                      .FirstOrDefault();

            if (contrDb == null)
                idContrato = this.IncluirContrato(values);

            if (contrDb != null)
            {
                idContrato = contrDb.idContrato;
                this.AtualizarContrato(contrDb, values);
            }

            return idContrato;
        }

        private int IncluirContrato(Entidades.Contrato contrato) 
        {
            try
            {
                var clienteRep = new ClienteRepository();

                var itemContr = new Entidades.DatabaseEntities.ContratoDatabase();
                
                itemContr.codigoContrato = contrato.numeroContrato;
                itemContr.idCliente = clienteRep.PersistirCliente(contrato.cliente);
                itemContr.idColigada = _contexto.ColigadaRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoColigada == contrato.coligada.codigoColigada)
                                                    .FirstOrDefault().idColigada;

                itemContr.idProduto = _contexto.ProdutoRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoProduto == contrato.produto.codigoProduto)
                                                    .FirstOrDefault().idProduto;

                itemContr.idHistoricoFinanceiro = _contexto.HistoricoFinanceiroRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoHistoricoFinanceiro == contrato.historicoFinanceiro.codigoHistoricoFinanceiro &&
                                                    x.origemInformacao == contrato.historicoFinanceiro.origemInformacao)
                                                    .FirstOrDefault().idHistoricoFinanceiro;

                _contexto.Set<Pan.Reembolso.Entidades.DatabaseEntities.ContratoDatabase>().Add(itemContr);
                _contexto.SaveChanges();

                return itemContr.idContrato;
            }
            catch (Exception ex) 
            {
                throw ex;
            }
        }

        private void AtualizarContrato(Entidades.DatabaseEntities.ContratoDatabase contrDB, Pan.Reembolso.Entidades.Contrato contrato)
        {
            try
            {
                var clienteRep = new ClienteRepository();

                contrDB.codigoContrato = contrato.numeroContrato;
                contrDB.idCliente = clienteRep.PersistirCliente(contrato.cliente);
                contrDB.idColigada = _contexto.ColigadaRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoColigada == contrato.coligada.codigoColigada)
                                                    .FirstOrDefault().idColigada;

                contrDB.idProduto = _contexto.ProdutoRepository
                                                    .Select(x => x)
                                                    .Where(x => x.codigoProduto == contrato.produto.codigoProduto)
                                                    .FirstOrDefault().idProduto;

                _contexto.Entry(contrDB).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public void ExcluirContrato(int id) 
        { 
            
        }
    }
}
