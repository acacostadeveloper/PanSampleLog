﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class MotivoEntradaRepository : IMotivoEntradaRepository
    {
        private PanReembolsoContext _contexto;

        public MotivoEntradaRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public List<Entidades.MotivoEntrada> ObterMotivosEntrada()
        {
            var resultItem =
            (
                from _motEnt in _contexto.MotivoEntradaRepository
                select new Entidades.MotivoEntrada()
                {
                    descricaoMotivoEntrada = _motEnt.descricaoMotivoEntrada,
                    dtAlteracao = _motEnt.dtAlteracao,
                    dtInclusao = _motEnt.dtInclusao,
                    idMotivoEntrada = _motEnt.idMotivoEntrada,
                    idSigla = _motEnt.idSigla,
                    indicadorAtivo = _motEnt.indicadorAtivo,
                    tipoMotivoEntrada = _motEnt.tipoMotivoEntrada
                }
            ).ToList();


            return resultItem;
                
        }


    }
}
