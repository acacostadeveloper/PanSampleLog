﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class MensagemRepository : IMensagemRepository
    {
        private PanReembolsoContext _contexto;

        public MensagemRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public void PersistirMensagem(Pagamento value)
        {
            try
            {
                Entidades.DatabaseEntities.MensagemTransferenciaDatabase msgDB = new Entidades.DatabaseEntities.MensagemTransferenciaDatabase
                {
                    dataLiquidacao = value.mensagem.dataLiquidacao,
                    dataRegistro = value.mensagem.dataRegistro,
                    idContaCredito = new ContaCreditoRepository().ObtertIdContaCreditoPorCofFavorecido(value.favorecido.numeroCpfCnpj),
                    idContaReserva = new ContaReservaRepository().ObterIdContaReservaPorCnpj(value.mensagem.contaReserva.cnpjSacado),
                    idMensagemPadrao = ObterIdMensagemPadraoProduto(value.mensagem.produto.codigoProduto),
                    numeroRequisicao = value.mensagem.numeroRequisicao,
                    statusMensagem = value.mensagem.statusMensagem
                };


                _contexto.Set<Entidades.DatabaseEntities.MensagemTransferenciaDatabase>().Add(msgDB);
                _contexto.SaveChanges();

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        private int ObterIdMensagemPadraoProduto(string codigoProduto)
        {
            var resultItem = (from _msgpr in _contexto.MensagemPadraoRepository
                              join _prd in _contexto.ProdutoRepository on _msgpr.idProduto equals _prd.idProduto
                              where _prd.codigoProduto == codigoProduto 
                              orderby _msgpr.dataInclusao descending
                              select _msgpr
            ).FirstOrDefault();

            return resultItem.idMensagemPadrao;
        }

        public MensagemTransferencia ObterMensagemPadrao()
        {
            try
            {
                var resultItem = (from _msgpr in _contexto.MensagemPadraoRepository
                                  orderby _msgpr.dataInclusao descending
                                  select new MensagemTransferencia()
                                  {
                                        codigoFinalidadeSPB = _msgpr.finalidadeSPB,
                                        indicadorCreditaContaCorrente = _msgpr.indicadorCreditaContaCorrente,
                                        indicadorDebitaContaCorrente = _msgpr.indicadorDebitaContaCorrente,
                                        indicadorEmiteRecebe = _msgpr.indicadorEmiteRecebe,
                                        indicadorMesmaTitularidade = _msgpr.indicadorMesmaTitularidade,
                                        indicadorPrevisao = _msgpr.indicadorPrevisao,
                                        indicadorTransitaContaCorrente = _msgpr.indicadorTransitaContaCorrente,
                                        numeroBordero = _msgpr.numeroBordero,
                                        tipoLiquidacao = _msgpr.tipoLiquidacao,
                                        codigoFinalidade = _msgpr.codigoFinalidade,
                                        codigoEventoTesouraria = _msgpr.codigoEventoTesouraria,
                                        codigoUsuarioCadastro = _msgpr.codigoUsuarioCadastro
                                  }
                ).FirstOrDefault();

                var departamento = (from _dep in _contexto.DepartamentoRepository
                                    where _dep.indicadorAtivo == "1"
                                    select new Departamento()
                                    {
                                        idDepartamento = _dep.idDepartamento,
                                        codigoDepartamento = _dep.codigoDepartamento,
                                        nomeDepartamento = _dep.descricaoDepartamento 
                                    }
                ).FirstOrDefault();

                resultItem.departamento = departamento;

                var coligada = (from _col in _contexto.ColigadaRepository
                                where _col.codigoColigada == "001"
                                select new  Coligada() {
                                    codigoColigada = _col.codigoColigada,
                                    nomeColigada = _col.nomeColigada,
                                    cnpjColigada = _col.cnpjColigada,
                                    codigoAgencia = _col.codigoAgencia
                                }
                ).FirstOrDefault();

                resultItem.coligada = coligada;

                var produto = (from _prd in _contexto.ProdutoRepository
                               where _prd.codigoProduto == "0001"
                               select new Produto()
                               {
                                   codigoProduto = _prd.codigoProduto,
                                   nomeProduto = _prd.nomeProduto,
                                   codigoCarteira = _prd.codigoCarteira
                               }
                ).FirstOrDefault();


                var sistema = (from _sis in _contexto.SistemaRepository
                               where _sis.descricaoSistema == "SSAFUNCAO"
                               select new SistemaProduto()
                               {
                                   codigoSistema = _sis.descricaoSistema,
                                   nomeSistema = _sis.descricaoSistema
                               }
                ).FirstOrDefault();

                produto.sistemaProduto = sistema;

                resultItem.produto = produto;

                var contaRes = (from _ccr in _contexto.ContaReservaRepository
                                join _cco in _contexto.ContaRepository on _ccr.idConta equals _cco.idConta
                                select new Reserva()
                                {
                                    cnpjSacado = _ccr.cnpjSacado,
                                    nomeSacado = _ccr.nomeSacado,
                                    tipoPessoaSacado = _ccr.tipoPessoaSacado,
                                    numeroBanco = _cco.numeroBanco, 
                                    numeroAgencia = _cco.numeroAgencia, 
                                    digitoAgencia = _cco.digitoAgencia, 
                                    numeroConta = _cco.numeroConta, 
                                    digitoConta = _cco.digitoConta,
                                    tipoConta = _cco.tipoConta 
                                }
                ).FirstOrDefault();

                resultItem.contaReserva = contaRes;

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public MensagemTransferencia ObterMensagemPorIdReembolso(long idReembolso)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository 
                                  join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                  join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                  join _msgpg in _contexto.MensagemPagamentoRepository on _pagam.idPagamento equals _msgpg.idPagamento
                                  join _msgtr in _contexto.MensagemTransferenciaRepository on _msgpg.idMensagem equals _msgtr.idMensagem
                                  where _reemb.idReembolso == idReembolso
                                  select new MensagemTransferencia()
                                  {
                                      numeroRequisicao = _msgtr.numeroRequisicao,
                                      dataRegistro = _msgtr.dataRegistro,
                                      dataLiquidacao = _msgtr.dataLiquidacao,
                                      statusMensagem = _msgtr.statusMensagem
                                  }
                ).FirstOrDefault();

                resultItem.contaReserva = new ContaReservaRepository().ObterContaReservaPorNumeroRequisicao(resultItem.numeroRequisicao);
                //resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorNumeroRequisicao(resultItem.numeroRequisicao);
                
                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
