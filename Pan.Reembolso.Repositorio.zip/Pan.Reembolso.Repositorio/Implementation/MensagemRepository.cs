﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Data.Entity;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class MensagemRepository : IMensagemRepository
    {
        private PanReembolsoContext _contexto;

        public MensagemRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public void AtualizarMensagem(MensagemTransferencia value)
        {
            try
            {
                var objectId = (from _msgtr in _contexto.MensagemTransferenciaRepository
                                where _msgtr.numeroRequisicao == value.numeroRequisicao
                                select _msgtr
                ).FirstOrDefault();

                if (objectId != null)
                {

                    objectId.dataLiquidacao = value.dataLiquidacao;

                    objectId.dataRegistro = value.dataRegistro;
                    objectId.idContaReserva = new ContaReservaRepository().ObterIdContaReservaPorCnpj(value.contaReserva.cnpjSacado);
                    objectId.idMensagemPadrao = ObterIdMensagemPadraoProduto(value.produto.codigoProduto);
                    objectId.numeroRequisicao = value.numeroRequisicao;
                    objectId.statusMensagem = value.statusMensagem;
                    objectId.valorTransferencia = value.valorTransferencia;
                    objectId.numeroOrigem = value.numeroOrigem;
                    objectId.codigoEventoTesouraria = value.codigoEvento;
                    objectId.nomeFavorecido = value.nomeFavorecido;
                    objectId.tipoPessoaFavorecido = value.tipoPessoaFavorecido;
                    objectId.numeroCpfCnpjFavorecido = value.numeroCpfCnpjFavorecido;
                    objectId.numeroSequenciaFavorecido = value.numeroSequenciaFavorecido;
                    objectId.tipoContaFavorecido = value.tipoContaFavorecido;
                    objectId.numeroBancoFavorecido = value.numeroBancoFavorecido;
                    objectId.numeroAgenciaFavorecido = value.numeroAgenciaFavorecido;
                    objectId.digitoAgenciaFavorecido = value.digitoAgenciaFavorecido;
                    objectId.numeroContaFavorecido = value.numeroContaFavorecido;
                    objectId.digitoContaFavorecido = value.digitoContaFavorecido;

                    _contexto.Set<Entidades.DatabaseEntities.MensagemTransferenciaDatabase>().Attach(objectId);
                    _contexto.Entry(objectId).State = EntityState.Modified;

                    _contexto.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public IList<MensagemTransferencia> ObterMensagemPorStatus(ReembolsoTypes.StatusMensagemTransferenciaType statusMensagem)
        {
            try
            {
                var resultItem = (from _msgtr in _contexto.MensagemTransferenciaRepository
                                  join _msgpd in _contexto.MensagemPadraoRepository on _msgtr.idMensagemPadrao equals _msgpd.idMensagemPadrao
                                  where _msgtr.statusMensagem == statusMensagem.ToString()

                                  select new MensagemTransferencia()
                                  {
                                      codigoFinalidadeSPB = _msgpd.finalidadeSPB,
                                      indicadorCreditaContaCorrente = _msgpd.indicadorCreditaContaCorrente,
                                      indicadorDebitaContaCorrente = _msgpd.indicadorDebitaContaCorrente,
                                      indicadorEmiteRecebe = _msgpd.indicadorEmiteRecebe,
                                      indicadorMesmaTitularidade = _msgpd.indicadorMesmaTitularidade,
                                      indicadorPrevisao = _msgpd.indicadorPrevisao,
                                      indicadorTransitaContaCorrente = _msgpd.indicadorTransitaContaCorrente,
                                      numeroBordero = _msgpd.numeroBordero,
                                      tipoLiquidacao = _msgpd.tipoLiquidacao,
                                      codigoUsuarioCadastro = _msgpd.codigoUsuarioCadastro,
                                      codigoFinalidade = _msgpd.codigoFinalidade,
                                      dataLiquidacao = _msgtr.dataLiquidacao,
                                      dataRegistro = _msgtr.dataRegistro,
                                      numeroRequisicao = _msgtr.numeroRequisicao,
                                      statusMensagem = _msgtr.statusMensagem,
                                      valorTransferencia = _msgtr.valorTransferencia,
                                      numeroOrigem = _msgtr.numeroOrigem,
                                      codigoEvento = _msgtr.codigoEventoTesouraria,
                                      codigoEventoTesouraria = _msgtr.codigoEventoTesouraria,
                                      nomeFavorecido = _msgtr.nomeFavorecido,
                                      tipoPessoaFavorecido = _msgtr.tipoPessoaFavorecido,
                                      numeroCpfCnpjFavorecido = _msgtr.numeroCpfCnpjFavorecido,
                                      numeroSequenciaFavorecido = _msgtr.numeroSequenciaFavorecido,
                                      tipoContaFavorecido = _msgtr.tipoContaFavorecido,
                                      numeroBancoFavorecido = _msgtr.numeroBancoFavorecido,
                                      numeroAgenciaFavorecido = _msgtr.numeroAgenciaFavorecido,
                                      digitoAgenciaFavorecido = _msgtr.digitoAgenciaFavorecido,
                                      numeroContaFavorecido = _msgtr.numeroContaFavorecido,
                                      digitoContaFavorecido = _msgtr.digitoContaFavorecido
                                  }
                ).ToList();

                foreach (MensagemTransferencia msg in resultItem)
                {
                    msg.contaReserva = new ContaReservaRepository().ObterContaReservaPorNumeroRequisicao(msg.numeroRequisicao);
                    msg.produto = new ProdutoRepository().ObterProdutoPorCodigo("0001");
                    msg.departamento = new DepartamentoRepository().ObterDepartamentoPorCodigo("0000020");
                    msg.coligada = new ColigadaRepository().ObterColigadaPorCodigo("001");

                    var sistema = (from _sis in _contexto.SistemaRepository
                                   where _sis.descricaoSistema == "SSAFUNCAO"
                                   select new SistemaProduto()
                                   {
                                       codigoSistema = _sis.descricaoSistema,
                                       nomeSistema = _sis.descricaoSistema
                                   }
                    ).FirstOrDefault();

                    msg.produto.sistemaProduto = sistema;
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void PersistirMensagem(MensagemTransferencia value, long idPagamento)
        {
            try
            {
                Entidades.DatabaseEntities.MensagemTransferenciaDatabase msgDB = new Entidades.DatabaseEntities.MensagemTransferenciaDatabase
                {
                    dataLiquidacao = value.dataLiquidacao,
                    dataRegistro = value.dataRegistro,
                    idContaReserva = new ContaReservaRepository().ObterIdContaReservaPorCnpj(value.contaReserva.cnpjSacado),
                    idMensagemPadrao = ObterIdMensagemPadraoProduto(value.produto.codigoProduto),
                    numeroRequisicao = value.numeroRequisicao,
                    statusMensagem = value.statusMensagem,
                    valorTransferencia = value.valorTransferencia,
                    numeroOrigem = value.numeroOrigem,
                    codigoEventoTesouraria = value.codigoEvento,
                    nomeFavorecido = value.nomeFavorecido,
                    tipoPessoaFavorecido = value.tipoPessoaFavorecido,
                    numeroCpfCnpjFavorecido = value.numeroCpfCnpjFavorecido,
                    numeroSequenciaFavorecido = value.numeroSequenciaFavorecido,
                    tipoContaFavorecido = value.tipoContaFavorecido,
                    numeroBancoFavorecido = value.numeroBancoFavorecido,
                    numeroAgenciaFavorecido = value.numeroAgenciaFavorecido,
                    digitoAgenciaFavorecido = value.digitoAgenciaFavorecido,
                    numeroContaFavorecido = value.numeroContaFavorecido,
                    digitoContaFavorecido = value.digitoContaFavorecido
                };

                _contexto.Set<Entidades.DatabaseEntities.MensagemTransferenciaDatabase>().Add(msgDB);
                _contexto.SaveChanges();

                Entidades.DatabaseEntities.MensagemPagamentoDatabase msgpagDB = new Entidades.DatabaseEntities.MensagemPagamentoDatabase
                {
                    idMensagem = msgDB.idMensagem,
                    idPagamento = idPagamento
                };

                _contexto.Set<Entidades.DatabaseEntities.MensagemPagamentoDatabase>().Add(msgpagDB);
                _contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private int ObterIdMensagemPadraoProduto(string codigoProduto)
        {
            var resultItem = (from _msgpr in _contexto.MensagemPadraoRepository
                              join _prd in _contexto.ProdutoRepository on _msgpr.idProduto equals _prd.idProduto
                              where _prd.codigoProduto == codigoProduto 
                              orderby _msgpr.dataInclusao descending
                              select _msgpr
            ).FirstOrDefault();

            return resultItem.idMensagemPadrao;
        }

        public MensagemTransferencia ObterMensagemPadrao()
        {
            try
            {
                var resultItem = (from _msgpr in _contexto.MensagemPadraoRepository
                                  orderby _msgpr.dataInclusao descending
                                  select new MensagemTransferencia()
                                  {
                                        codigoFinalidadeSPB = _msgpr.finalidadeSPB,
                                        indicadorCreditaContaCorrente = _msgpr.indicadorCreditaContaCorrente,
                                        indicadorDebitaContaCorrente = _msgpr.indicadorDebitaContaCorrente,
                                        indicadorEmiteRecebe = _msgpr.indicadorEmiteRecebe,
                                        indicadorMesmaTitularidade = _msgpr.indicadorMesmaTitularidade,
                                        indicadorPrevisao = _msgpr.indicadorPrevisao,
                                        indicadorTransitaContaCorrente = _msgpr.indicadorTransitaContaCorrente,
                                        numeroBordero = _msgpr.numeroBordero,
                                        tipoLiquidacao = _msgpr.tipoLiquidacao,
                                        codigoFinalidade = _msgpr.codigoFinalidade,
                                        codigoEvento = _msgpr.codigoEventoTesouraria,
                                        codigoEventoTesouraria = _msgpr.codigoEventoTesouraria,
                                        codigoUsuarioCadastro = _msgpr.codigoUsuarioCadastro
                                  }
                ).FirstOrDefault();

                resultItem.departamento = new DepartamentoRepository().ObterDepartamentoPorCodigo("0000020");
                resultItem.coligada = new ColigadaRepository().ObterColigadaPorCodigo("001");
                resultItem.produto = new ProdutoRepository().ObterProdutoPorCodigo("0001");
                resultItem.contaReserva = new ContaReservaRepository().ObterContaReservaPadrao();

                var sistema = (from _sis in _contexto.SistemaRepository
                               where _sis.descricaoSistema == "SSAFUNCAO"
                               select new SistemaProduto()
                               {
                                   codigoSistema = _sis.descricaoSistema,
                                   nomeSistema = _sis.descricaoSistema
                               }
                ).FirstOrDefault();

                resultItem.produto.sistemaProduto = sistema;

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<Object> ObterHistoricoPorIdReembolso(long idReembolso)
        {

            var pagamento =
            (
                from _pag in _contexto.PagamentoRepository
                join _rPag in _contexto.ReembolsoPagamentoRepository on _pag.idPagamento equals _rPag.idPagamento
                where _rPag.idReembolso == idReembolso
                select new
                {
                    tipo = _pag.tipoPagamento,
                    status = _pag.statusPagamento,
                    valor = _pag.valorPagamento,
                    dataInclusao = _pag.dataRegistro,
                    dataPagamento = _pag.dataPagamento,
                    idPagamento = _pag.idPagamento
                }
            );

            var historicoPagamentoMsg =
            (
                from _msg in _contexto.MensagemTransferenciaRepository
                join _msgPgt in _contexto.MensagemPagamentoRepository on _msg.idMensagem equals _msgPgt.idMensagem
                join _pgt in _contexto.PagamentoRepository on _msgPgt.idPagamento equals _pgt.idPagamento
                where _msgPgt.idPagamento == pagamento.FirstOrDefault().idPagamento
                select new
                {
                    tipo = _pgt.tipoPagamento,
                    status = _pgt.statusPagamento,
                    valor = _msg.valorTransferencia,
                    dataInclusao = _pgt.dataRegistro,
                    dataPagamento = _pgt.dataPagamento,
                    idPagamento = _pgt.idPagamento
                }
            );

            var historicoRetirada =
            (
                from _pgt in _contexto.PagamentoRepository
                join _rePgt in _contexto.ReembolsoPagamentoRepository on _pgt.idPagamento equals _rePgt.idPagamento
                where _pgt.idFavorecido == null && _rePgt.idReembolso == idReembolso
                select new
                {
                    tipo = _pgt.tipoPagamento,
                    status = _pgt.statusPagamento,
                    valor = _pgt.valorPagamento,
                    dataInclusao = _pgt.dataRegistro,
                    dataPagamento = _pgt.dataPagamento,
                    idPagamento = _pgt.idPagamento
                }
            );

            var historico =  historicoPagamentoMsg.Union(historicoRetirada).Union(pagamento);

            return historico.OrderByDescending(x => x.dataInclusao).ToList<Object>();
        }
    }
}
