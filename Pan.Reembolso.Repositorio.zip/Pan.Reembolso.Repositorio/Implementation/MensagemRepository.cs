﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class MensagemRepository
    {
        private PanReembolsoContext _contexto;

        public MensagemRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.MensagemTransferencia ObterMensagemPorIdReembolso(long idReembolso)
        {
            try
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository 
                                  join _repag in _contexto.ReembolsoPagamentoRepository on _reemb.idReembolso equals _repag.idReembolso
                                  join _pagam in _contexto.PagamentoRepository on _repag.idPagamento equals _pagam.idPagamento
                                  join _msgpg in _contexto.MensagemPagamentoRepository on _pagam.idPagamento equals _msgpg.idPagamento
                                  join _msgtr in _contexto.MensagemTransferenciaRepository on _msgpg.idMensagem equals _msgtr.idMensagem
                                  where _reemb.idReembolso == idReembolso
                                  select new Pan.Reembolso.Entidades.MensagemTransferencia()
                                  {
                                      numeroRequisicao = _msgtr.numeroRequisicao,
                                      dataRegistro = _msgtr.dataRegistro,
                                      dataLiquidacao = _msgtr.dataLiquidacao,
                                      statusMensagem = _msgtr.statusMensagem
                                  }
                ).FirstOrDefault();

                resultItem.contaReserva = new ContaReservaRepository().ObterContaReservaPorNumeroRequisicao(resultItem.numeroRequisicao);
                resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorNumeroRequisicao(resultItem.numeroRequisicao);
                
                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
