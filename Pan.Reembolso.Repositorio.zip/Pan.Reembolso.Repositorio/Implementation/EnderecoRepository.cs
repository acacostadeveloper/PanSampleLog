﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{

    public class EnderecoRepository
    {
        private PanReembolsoContext _contexto;

        public EnderecoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Endereco ObterEnderecoPorNumeroCpfCliente(string numeroCpfCliente)
        {
            try
            {
                var resultItem = (from _clien in _contexto.ClienteRepository 
                                  join _ender in _contexto.EnderecoRepository on _clien.idCliente equals _ender.idCliente
                                  where _clien.cpfCnpj == numeroCpfCliente
                                  select new Pan.Reembolso.Entidades.Endereco()
                                  {
                                      nomeLogradouro = _ender.nomeLogradouro,
                                      numero = _ender.numeroEndereco,
                                      complemento = _ender.complemento,
                                      cep = _ender.cep,
                                      bairro = _ender.bairro,
                                      cidade = _ender.cidade,
                                      estado = _ender.uf
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
