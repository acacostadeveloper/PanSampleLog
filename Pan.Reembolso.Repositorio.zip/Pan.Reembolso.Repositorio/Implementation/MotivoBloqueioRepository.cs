﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Repositorio.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class MotivoBloqueioRepository : IMotivoBloqueioRepository
    {
        private PanReembolsoContext _contexto;

        public MotivoBloqueioRepository()
        {
            _contexto = new PanReembolsoContext();
        }
        
        public MotivoBloqueio ObterMotivoBloqueio(MotivoBloqueioType? motivoBloqueio = MotivoBloqueioType.Undefined)
        {
            try 
            {
                var resultItem =
                (   
                    from _mot in _contexto.MotivoBloqueioRepository 
                    where _mot.idMotivoBloqueio == (int)motivoBloqueio

                    select new MotivoBloqueio()
                    {
                        idMotivoBloqueio = _mot.idMotivoBloqueio,
                        descricaoMotivoBloqueio = _mot.descricaoMotivoBloqueio
                    }

                ).FirstOrDefault();

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }


        public MotivoBloqueio ObterMotivoBloqueio(int? motivoBloqueio)
        {
            try
            {
                var resultItem =
                (
                    from _mot in _contexto.MotivoBloqueioRepository
                    where _mot.idMotivoBloqueio == motivoBloqueio

                    select new MotivoBloqueio()
                    {
                        idMotivoBloqueio = _mot.idMotivoBloqueio,
                        descricaoMotivoBloqueio = _mot.descricaoMotivoBloqueio
                    }

                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IList<MotivoBloqueio> ObterMotivoBloqueio()
        {
            try
            {
                var resultItem =
                (
                    from _mot in _contexto.MotivoBloqueioRepository

                    select new MotivoBloqueio
                    {
                        idMotivoBloqueio = _mot.idMotivoBloqueio,
                        descricaoMotivoBloqueio = _mot.descricaoMotivoBloqueio
                    }
                );

                return resultItem.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
