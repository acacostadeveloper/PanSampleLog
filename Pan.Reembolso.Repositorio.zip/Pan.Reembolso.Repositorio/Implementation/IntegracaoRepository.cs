﻿
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Repositorio.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class IntegracaoRepository : IIntegracaoRepository
    {
        private PanReembolsoContext _contexto;

        public IntegracaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IEnumerable<Entidades.Integracao> ObterIntegracaoPorStatus(StatusIntegracaoType status, string loteIntegracao)
        {
            return _contexto.IntegracaoRepository.Where(s => s.status == status.ToString() && s.cdLoteIntegracao == loteIntegracao)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    cdLoteIntegracao = t.cdLoteIntegracao,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                }).ToList();
        }

        public async Task<string> PersistirIntegracaoBulk(DataTable integracoesTable)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings[ReembolsoConstantes.BANCO_BULK_INSERT].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = ReembolsoConstantes.TABELA_INTEGRACAO;

                    try
                    {
                        await bulkCopy.WriteToServerAsync(integracoesTable);

                        return integracoesTable.Rows[0]["CD_LOTE_INTEGRACAO"].ToString();
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }

        public IQueryable<Integracao> ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, int mesCompetencia)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.cpfCnpj == cpfCnpj &&
                                                                             s.valorReembolso == valorReembolso &&
                                                                             s.mesCompetencia == mesCompetencia)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    cdLoteIntegracao = t.cdLoteIntegracao,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                });

            return resultIntegracao;

        }

        public IQueryable<Integracao> ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, int mesCompetencia)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.contrato == contrato &&
                                                                             s.valorReembolso == valorReembolso &&
                                                                             s.mesCompetencia == mesCompetencia)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    cdLoteIntegracao = t.cdLoteIntegracao,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                });

            return resultIntegracao;
        }

        public Integracao AtualizarIntegracao(Integracao integracao)
        {
            try
            {
                var integracaoDatabase = MapperIntegracao(integracao);

                _contexto.Entry(integracaoDatabase).State = System.Data.Entity.EntityState.Modified;

                //_contexto.Set<Entidades.DatabaseEntities.IntegracaoDatabase>().Attach(integracaoDatabase);

                _contexto.SaveChanges();

                integracao.idIntegracao = integracaoDatabase.idIntegracao;

                return integracao;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObterIntegracaoDataTable()
        {
            DataTable TabelaIntegracao = new DataTable(ReembolsoConstantes.TABELA_INTEGRACAO);

            TabelaIntegracao.Columns.Add(new DataColumn("ID_INTEGRACAO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_REEMBOLSO", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_LOTE", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_LOTE_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_STATUS_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DS_MENSAGEM_ERRO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INTEGRACAO", typeof(DateTime)));
            TabelaIntegracao.Columns.Add(new DataColumn("NM_CLIENTE", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CONTRATO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("VL_REEMBOLSO", typeof(decimal)));
            TabelaIntegracao.Columns.Add(new DataColumn("NM_CONVENIO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_MATRICULA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CPF_CNPJ", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_MES_COMPETENCIA", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_ANO_COMPETENCIA", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_SIGLA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PROCESSO_ENTRADA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PRODUTO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_USUARIO_INCLUSAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INCLUSAO", typeof(DateTime)));

            return TabelaIntegracao;
        }

        private IntegracaoDatabase MapperIntegracao(Integracao integracao)
        {
            return new IntegracaoDatabase
            {
                idIntegracao = integracao.idIntegracao,
                idReembolso = integracao.idReembolso.Value,
                idLote = integracao.idLote,
                cdLoteIntegracao = integracao.cdLoteIntegracao,
                cliente = integracao.cliente,
                contrato = integracao.contrato,
                valorReembolso = integracao.valorReembolso,
                convenio = integracao.convenio,
                matricula = integracao.matricula,
                cpfCnpj = integracao.cpfCnpj,
                mesCompetencia = integracao.mesCompetencia,
                anoCompetencia = integracao.anoCompetencia,
                sigla = integracao.sigla,
                processoEntrada = integracao.processoEntrada,
                produto = integracao.produto,
                status = integracao.status,
                mensagemErro = integracao.mensagemErro,
                usuarioInclusao = integracao.usuarioInclusao,
                dataInclusao = integracao.dataInclusao,
                dataIntegracao = integracao.dataIntegracao.Value
            };
        }
    }
}