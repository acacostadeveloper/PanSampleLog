﻿
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Repositorio.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Configuration;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class IntegracaoRepository : IIntegracaoRepository
    {
        private PanReembolsoContext _contexto;

        public IntegracaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IEnumerable<Entidades.Integracao> ObterIntegracaoPorStatus(StatusIntegracaoType status, int loteIntegracao)
        {
            try
            {
                return _contexto.IntegracaoRepository.Where(s => s.status == status.ToString() && s.idLoteIntegracao == loteIntegracao)
                    .Select(t => new Entidades.Integracao
                    {
                        idIntegracao = t.idIntegracao,
                        idReembolso = t.idReembolso,
                        idLoteReembolso = t.idLoteReembolso,
                        idLoteIntegracao = t.idLoteIntegracao,
                        cliente = t.cliente,
                        contrato = t.contrato,
                        valorReembolso = t.valorReembolso,
                        convenio = t.convenio,
                        matricula = t.matricula,
                        cpfCnpj = t.cpfCnpj,
                        mesCompetencia = t.mesCompetencia,
                        anoCompetencia = t.anoCompetencia,
                        sigla = t.sigla,
                        processoEntrada = t.processoEntrada,
                        produto = t.produto,
                        status = t.status,
                        usuarioInclusao = t.usuarioInclusao,
                        dataInclusao = t.dataInclusao,
                        dataIntegracao = t.dataIntegracao,
                        mensagemErro = t.mensagemErro
                    }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<int> PersistirIntegracaoBulk(DataTable integracoesTable)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings[ReembolsoConstantes.BANCO_BULK_INSERT].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = ReembolsoConstantes.TABELA_INTEGRACAO;

                    try
                    {
                        await bulkCopy.WriteToServerAsync(integracoesTable);

                        return int.Parse(integracoesTable.Rows[0]["ID_LOTE_INTEGRACAO"].ToString());
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
        }

        public IQueryable<Integracao> ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, int mesCompetencia)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.cpfCnpj == cpfCnpj &&
                                                                             s.valorReembolso == valorReembolso &&
                                                                             s.mesCompetencia == mesCompetencia)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLoteReembolso = t.idLoteReembolso,
                    idLoteIntegracao = t.idLoteIntegracao,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                });

            return resultIntegracao;

        }

        public IQueryable<Integracao> ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, int mesCompetencia)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.contrato == contrato &&
                                                                             s.valorReembolso == valorReembolso &&
                                                                             s.mesCompetencia == mesCompetencia)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLoteReembolso = t.idLoteReembolso,
                    idLoteIntegracao = t.idLoteIntegracao,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                });

            return resultIntegracao;
        }

        public Integracao AtualizarIntegracao(Integracao integracao)
        {
            try
            {
                var integracaoDatabase = MapperIntegracao(integracao);

                _contexto.Entry(integracaoDatabase).State = System.Data.Entity.EntityState.Modified;

                _contexto.SaveChanges();

                integracao.idIntegracao = integracaoDatabase.idIntegracao;

                return integracao;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataTable ObterIntegracaoDataTable()
        {
            DataTable TabelaIntegracao = new DataTable(ReembolsoConstantes.TABELA_INTEGRACAO);

            TabelaIntegracao.Columns.Add(new DataColumn("ID_INTEGRACAO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_REEMBOLSO", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_LOTE_REEMBOLSO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_LOTE_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_STATUS_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DS_MENSAGEM_ERRO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INTEGRACAO", typeof(DateTime)));
            TabelaIntegracao.Columns.Add(new DataColumn("NM_CLIENTE", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CONTRATO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("VL_REEMBOLSO", typeof(SqlDecimal)));
            TabelaIntegracao.Columns.Add(new DataColumn("NM_CONVENIO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_MATRICULA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CPF_CNPJ", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_MES_COMPETENCIA", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_ANO_COMPETENCIA", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_SIGLA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PROCESSO_ENTRADA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PRODUTO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_USUARIO_INCLUSAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INCLUSAO", typeof(DateTime)));

            return TabelaIntegracao;
        }

        private IntegracaoDatabase MapperIntegracao(Integracao integracao)
        {
            var result = new IntegracaoDatabase();

            result.idIntegracao = integracao.idIntegracao;
            result.idReembolso = integracao.idReembolso ?? null;
            result.idLoteReembolso = integracao.idLoteReembolso;
            result.idLoteIntegracao = integracao.idLoteIntegracao;
            result.cliente = integracao.cliente;
            result.contrato = integracao.contrato;
            result.valorReembolso = integracao.valorReembolso;
            result.convenio = integracao.convenio;
            result.matricula = integracao.matricula;
            result.cpfCnpj = integracao.cpfCnpj;
            result.mesCompetencia = integracao.mesCompetencia;
            result.anoCompetencia = integracao.anoCompetencia;
            result.sigla = integracao.sigla;
            result.processoEntrada = integracao.processoEntrada;
            result.produto = integracao.produto;
            result.status = integracao.status;
            result.mensagemErro = integracao.mensagemErro;
            result.usuarioInclusao = integracao.usuarioInclusao;
            result.dataInclusao = integracao.dataInclusao;
            result.dataIntegracao = integracao.dataIntegracao ?? null;

            return result;
            
        }

        public int GerarNovoLoteIntegracao()
        {
            try
            {
                var db = new Entidades.DatabaseEntities.LoteIntegracaoDatabase()
                {
                    dtInclusao = DateTime.Now
                };
                _contexto.Set<Entidades.DatabaseEntities.LoteIntegracaoDatabase>().Add(db);
                _contexto.SaveChanges();
                return db.idLoteIntegracao;
            }
            catch (Exception EX)
            {

                throw EX;
            }
            
        }

        public List<Integracao> ConsultarReembolsoIntegracaoPorLoteIntegracao(int idLoteIntegracao)
        {
            try
            {
                var resultItem =
                (
                    from _reembInt in _contexto.IntegracaoRepository
                    where _reembInt.idLoteIntegracao == idLoteIntegracao
                    select new Integracao()
                    {
                        anoCompetencia = _reembInt.anoCompetencia,
                        cliente = _reembInt.cliente,
                        contrato = _reembInt.contrato,
                        convenio = _reembInt.convenio,
                        cpfCnpj = _reembInt.cpfCnpj,
                        dataInclusao = _reembInt.dataInclusao,
                        dataIntegracao = _reembInt.dataIntegracao,
                        idIntegracao = _reembInt.idIntegracao,
                        idLoteIntegracao = _reembInt.idLoteIntegracao,
                        idLoteReembolso = _reembInt.idLoteReembolso,
                        idReembolso = _reembInt.idReembolso,
                        matricula = _reembInt.matricula,
                        mensagemErro = _reembInt.mensagemErro,
                        mesCompetencia = _reembInt.mesCompetencia,
                        processoEntrada = _reembInt.processoEntrada,
                        produto = _reembInt.produto,
                        sigla = _reembInt.sigla,
                        status = _reembInt.status,
                        usuarioInclusao = _reembInt.usuarioInclusao,
                        valorReembolso = _reembInt.valorReembolso
                    }
                );
                return resultItem.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}