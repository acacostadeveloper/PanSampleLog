﻿using Pan.Reembolso.Repositorio.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    class IntegracaoRepository // : IIntegracaoRepository
    {
        private PanReembolsoContext _contexto;

        public IntegracaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        
        public IEnumerable<Entidades.Integracao> ObterIntegracaoPorStatus(StatusIntegracao status)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.status == status.ToString())
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    idCliente = t.idCliente,
                    idContrato = t.idContrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    sigla = t.sigla,
                    idProcesso = t.idProcesso,
                    idProduto = t.idProduto,
                    status = t.status,
                    codigoUsuarioInclusao = t.codigoUsuarioInclusao,
                    dataEnvio = t.dataEnvio,
                    dataIntegracao =t.dataIntegracao
                });

            return resultIntegracao;
        }
    }
}
