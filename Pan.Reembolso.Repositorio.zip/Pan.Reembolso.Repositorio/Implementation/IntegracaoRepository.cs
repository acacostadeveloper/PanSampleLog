﻿using EntityFramework.BulkInsert.Extensions;
using FileHelpers;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Repositorio.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;
using System.Web.Configuration;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class IntegracaoRepository : IIntegracaoRepository
    {
        private const string BANCO_BULK_INSERT = "PanBulkIntegracao";
        private const string TABELA_INTEGRACAO = "[gestao_reembolso].[REEMBOLSO_INTEGRACAO]";

        private PanReembolsoContext _contexto;

        public IntegracaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }
        
        public IEnumerable<Entidades.Integracao> ObterIntegracaoPorStatus(StatusIntegracaoType status)
        {

            return _contexto.IntegracaoRepository.Where(s => s.status == status.ToString())
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                }).ToList();
        }

        public async Task<bool> PersistirIntegracaoBulk(IDataReader integracoesReader)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings[BANCO_BULK_INSERT].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = TABELA_INTEGRACAO;

                    try
                    {
                        bulkCopy.ColumnMappings.Add("ID_REEMBOLSO", "ID_REEMBOLSO");
                        bulkCopy.ColumnMappings.Add("ID_LOTE", "ID_LOTE");
                        bulkCopy.ColumnMappings.Add("CD_STATUS_INTEGRACAO", "CD_STATUS_INTEGRACAO");
                        bulkCopy.ColumnMappings.Add("DS_MENSAGEM_ERRO", "DS_MENSAGEM_ERRO");
                        bulkCopy.ColumnMappings.Add("DT_INTEGRACAO", "DT_INTEGRACAO");

                        bulkCopy.ColumnMappings.Add("NM_CLIENTE", "NM_CLIENTE");
                        bulkCopy.ColumnMappings.Add("NO_CONTRATO", "NO_CONTRATO");
                        bulkCopy.ColumnMappings.Add("VL_REEMBOLSO", "VL_REEMBOLSO");
                        bulkCopy.ColumnMappings.Add("NM_CONVENIO", "NM_CONVENIO");
                        bulkCopy.ColumnMappings.Add("CD_MATRICULA", "CD_MATRICULA");
                        bulkCopy.ColumnMappings.Add("NO_CPF_CNPJ", "NO_CPF_CNPJ");
                        bulkCopy.ColumnMappings.Add("NO_MES_COMPETENCIA", "NO_MES_COMPETENCIA");
                        bulkCopy.ColumnMappings.Add("NO_ANO_COMPETENCIA", "NO_ANO_COMPETENCIA");
                        bulkCopy.ColumnMappings.Add("CD_SIGLA", "CD_SIGLA");
                        bulkCopy.ColumnMappings.Add("CD_PROCESSO_ENTRADA", "CD_PROCESSO_ENTRADA");
                        bulkCopy.ColumnMappings.Add("CD_PRODUTO", "CD_PRODUTO");

                        bulkCopy.ColumnMappings.Add("CD_USUARIO_INCLUSAO", "CD_USUARIO_INCLUSAO");

                        await bulkCopy.WriteToServerAsync(integracoesReader);
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }

                return true;
            }
        }

        public async Task<bool> PersistirIntegracaoBulk(DataTable integracoesTable)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings[BANCO_BULK_INSERT].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                    {
                        bulkCopy.DestinationTableName = ReembolsoConstantes.TABELA_INTEGRACAO;

                        await bulkCopy.WriteToServerAsync(integracoesTable);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return true;
            }
        }

        public async Task<bool> PersistirIntegracaoBulk(StreamReader integracoesReader)
        {
            bool result;

            try
            {
                var engine = new FileHelperEngine<IntegracaoDatabase>();

                var dataBulk = engine.ReadStream(integracoesReader);

                using (TransactionScope scope = new TransactionScope())
                {
                    _contexto.BulkInsert(dataBulk);

                    _contexto.SaveChanges();

                    scope.Complete();

                    result = true;
                }

                return result;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public Entidades.Reembolso ObterReembolsoIntegracao(Entidades.Integracao integracao)
        {
            var reembolso = new Entidades.Reembolso();

            reembolso.integracao = integracao.idIntegracao;

            reembolso.usuario = new Entidades.Usuario { codigoUsuario = integracao.usuarioInclusao };

            reembolso.departamento = new Entidades.Departamento
            {
                // TODO Verificar Departamento 
            };

            reembolso.contrato = new Entidades.Contrato
            {
                produto = new Entidades.Produto { codigoProduto = integracao.produto },

                cliente = new Entidades.Cliente
                {
                    numeroCpfCnpj = integracao.cpfCnpj,

                    // TODO Verificar Tipo Pessoa
                    tipoPessoa = "F"
                },

                // TODO - Verificar Consignada
                coligada = new Entidades.Coligada { codigoColigada = "" },

                numeroContrato = integracao.contrato
            };

            return reembolso;
        }

        IQueryable<Integracao> IIntegracaoRepository.ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, int mesCompetencia)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.cpfCnpj  == cpfCnpj &&
                                                                             s.valorReembolso == valorReembolso &&
                                                                             s.mesCompetencia == mesCompetencia)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                });

            return resultIntegracao;

        }
        IQueryable<Integracao> IIntegracaoRepository.ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, int mesCompetencia)
        {
            var resultIntegracao = _contexto.IntegracaoRepository.Where(s => s.contrato == contrato &&
                                                                             s.valorReembolso == valorReembolso &&
                                                                             s.mesCompetencia == mesCompetencia)
                .Select(t => new Entidades.Integracao
                {
                    idIntegracao = t.idIntegracao,
                    idReembolso = t.idReembolso,
                    idLote = t.idLote,
                    cliente = t.cliente,
                    contrato = t.contrato,
                    valorReembolso = t.valorReembolso,
                    convenio = t.convenio,
                    matricula = t.matricula,
                    cpfCnpj = t.cpfCnpj,
                    mesCompetencia = t.mesCompetencia,
                    anoCompetencia = t.anoCompetencia,
                    sigla = t.sigla,
                    processoEntrada = t.processoEntrada,
                    produto = t.produto,
                    status = t.status,
                    usuarioInclusao = t.usuarioInclusao,
                    dataInclusao = t.dataInclusao,
                    dataIntegracao = t.dataIntegracao,
                    mensagemErro = t.mensagemErro
                });

            return resultIntegracao;
        }
        public Integracao PersistirIntegracao(Integracao integracao)
        {
            try
            {
                var integracaoDatabase = MapperIntegracao(integracao);

                if (integracaoDatabase.idIntegracao == 0)
                {
                    _contexto.Set<Entidades.DatabaseEntities.IntegracaoDatabase>().Add(integracaoDatabase);
                }
                else
                {
                    _contexto.Set<Entidades.DatabaseEntities.IntegracaoDatabase>().Attach(integracaoDatabase);
                }

                integracao.idIntegracao = integracaoDatabase.idIntegracao;

                return integracao;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public DataTable ObterIntegracaoDataTable()
        {
            DataTable TabelaIntegracao = new DataTable(ReembolsoConstantes.TABELA_INTEGRACAO);

            TabelaIntegracao.Columns.Add(new DataColumn("ID_INTEGRACAO", typeof(Int32)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_REEMBOLSO", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("ID_LOTE", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_STATUS_INTEGRACAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DS_MENSAGEM_ERRO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INTEGRACAO", typeof(DateTime)));
            TabelaIntegracao.Columns.Add(new DataColumn("NM_CLIENTE", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CONTRATO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("VL_REEMBOLSO", typeof(decimal)));
            TabelaIntegracao.Columns.Add(new DataColumn("NM_CONVENIO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_MATRICULA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_CPF_CNPJ", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_MES_COMPETENCIA", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("NO_ANO_COMPETENCIA", typeof(int)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_SIGLA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PROCESSO_ENTRADA", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_PRODUTO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("CD_USUARIO_INCLUSAO", typeof(string)));
            TabelaIntegracao.Columns.Add(new DataColumn("DT_INCLUSAO", typeof(DateTime)));

            return TabelaIntegracao;
        }
        private IntegracaoDatabase MapperIntegracao(Integracao integracao)
        {
            return new IntegracaoDatabase
            {
                idIntegracao = integracao.idIntegracao,
                idReembolso = integracao.idReembolso.Value,
                idLote = integracao.idLote,
                cliente = integracao.cliente,
                contrato = integracao.contrato,
                valorReembolso = integracao.valorReembolso,
                convenio = integracao.convenio,
                matricula = integracao.matricula,
                cpfCnpj = integracao.cpfCnpj,
                mesCompetencia = integracao.mesCompetencia,
                anoCompetencia = integracao.anoCompetencia,
                sigla = integracao.sigla,
                processoEntrada = integracao.processoEntrada,
                produto = integracao.produto,
                status = integracao.status,
                mensagemErro = integracao.mensagemErro,
                usuarioInclusao = integracao.usuarioInclusao,
                dataInclusao = integracao.dataInclusao,
                dataIntegracao = integracao.dataIntegracao.Value
            };
        }
    }
}
