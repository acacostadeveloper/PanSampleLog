﻿using Pan.Reembolso.Entidades.DatabaseEntities;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Repositorio.Interface;
using System;
using System.Data.Entity;
using System.Linq;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class FavorecidoRepository : IFavorecidoRepository
    {
        private PanReembolsoContext _contexto;

        public FavorecidoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Favorecido ObterFavorecidoPorNumeroRequsicaoMensagem(string numeroRequisicao)
        {
            try
            {
                var resultItem = (from _fav in _contexto.FavorecidoRepository
                                  join _conta in _contexto.ContaRepository on _fav.idConta equals _conta.idConta


                                  select new Entidades.Favorecido()
                                  {
                                      nome = _fav.nome,
                                      numeroCpfCnpj = _fav.numeroCpfCnpj,
                                      sequenciaCpfCnpj = _fav.sequenciaCpfCnpj,
                                      tipoPesssoa = _fav.tipoPesssoa
                                  }
                ).FirstOrDefault();




                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        public Entidades.Favorecido ObterFavorecidoPorId(int idFavorecido)
        {
            try
            {
                var resultItem = (from _fav in _contexto.FavorecidoRepository
                                  join _conta in _contexto.ContaRepository on _fav.idConta equals _conta.idConta
                                  where _fav.idFavorecido == idFavorecido

                                  select new Pan.Reembolso.Entidades.Favorecido()
                                  {
                                      nome = _fav.nome,
                                      numeroCpfCnpj = _fav.numeroCpfCnpj,
                                      sequenciaCpfCnpj = _fav.sequenciaCpfCnpj,
                                      tipoPesssoa = _fav.tipoPesssoa,
                                      contaCredito = new Entidades.ContaCredito
                                      {
                                          digitoAgencia = _conta.digitoAgencia,
                                          digitoConta = _conta.digitoConta,
                                          numeroAgencia = _conta.numeroAgencia,
                                          numeroBanco = _conta.numeroBanco,
                                          numeroConta = _conta.numeroConta,
                                          tipoConta = _conta.tipoConta
                                      }
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public Entidades.Favorecido ObterFavorecidoPorId(string cpfCnpj)
        {
            try
            {
                var resultItem = (from _fav in _contexto.FavorecidoRepository
                                  join _conta in _contexto.ContaRepository on _fav.idConta equals _conta.idConta
                                  where _fav.numeroCpfCnpj == cpfCnpj

                                  select new Pan.Reembolso.Entidades.Favorecido()
                                  {
                                      nome = _fav.nome,
                                      numeroCpfCnpj = _fav.numeroCpfCnpj,
                                      sequenciaCpfCnpj = _fav.sequenciaCpfCnpj,
                                      tipoPesssoa = _fav.tipoPesssoa,
                                      contaCredito = new Entidades.ContaCredito
                                      {
                                          digitoAgencia = _conta.digitoAgencia,
                                          digitoConta = _conta.digitoConta,
                                          numeroAgencia = _conta.numeroAgencia,
                                          numeroBanco = _conta.numeroBanco,
                                          numeroConta = _conta.numeroConta,
                                          tipoConta = _conta.tipoConta
                                      }
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private int IncluirFavorecido(Entidades.Favorecido favorecido)
        {
            var favorecidoDB = new FavorecidoDatabase();

            MapFavorecidoDB(favorecidoDB, favorecido);


            _contexto.Set<FavorecidoDatabase>().Add(favorecidoDB);
            _contexto.SaveChanges();
            return favorecidoDB.idFavorecido;
        }

        private void MapFavorecidoDB(FavorecidoDatabase favorecidoDb, Entidades.Favorecido favorecido)
        {
            favorecidoDb.nome = favorecido.nome;
            favorecidoDb.numeroCpfCnpj = favorecido.numeroCpfCnpj;
            favorecidoDb.sequenciaCpfCnpj = favorecido.sequenciaCpfCnpj;
            favorecidoDb.tipoPesssoa = favorecido.tipoPesssoa;
            favorecidoDb.idConta = favorecido.contaCredito.idConta;
        }

        public int PersistirFavorecido(Entidades.Favorecido favorecido)
        {
            try
            {
                var favorecidoDb = (from _fav in _contexto.FavorecidoRepository
                                    where
                                      _fav.numeroCpfCnpj == favorecido.numeroCpfCnpj &&
                                      _fav.sequenciaCpfCnpj == favorecido.sequenciaCpfCnpj
                                    select _fav).FirstOrDefault();
                if (favorecidoDb != null)
                {
                    MapFavorecidoDB(favorecidoDb, favorecido);

                    _contexto.Entry(favorecidoDb).State = EntityState.Modified;
                    _contexto.SaveChanges();
                    return favorecidoDb.idFavorecido;
                }
                else
                {
                   return IncluirFavorecido(favorecido);
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        //public void PersistirFavorecido(FavorecidoDatabase newFavorecidoDb)
        //{
        //    try
        //    {
        //        var favorecidoDb = (from _fav in _contexto.FavorecidoRepository
        //                            where
        //                              _fav.numeroCpfCnpj == newFavorecidoDb.numeroCpfCnpj &&
        //                              _fav.sequenciaCpfCnpj == newFavorecidoDb.sequenciaCpfCnpj
        //                            select _fav).FirstOrDefault();

        //        if (favorecidoDb != null)
        //        {
        //            MapFavorecidoDB(favorecidoDb, newFavorecidoDb);
        //            _contexto.Entry(favorecidoDb).State = EntityState.Modified;
        //            _contexto.SaveChanges();
        //        }
        //        else
        //        {
        //            IncluirFavorecido(newFavorecidoDb);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //        throw ex;
        //    }
            
        //}

        public Entidades.Favorecido ObterFavorecidoPorIdPagamento(Entidades.Pagamento pagamento)
        {
            try
            {
                var fav =
                (
                    from _fav in _contexto.FavorecidoRepository 
                    join _pag in _contexto.PagamentoRepository on _fav.idFavorecido equals _pag.idFavorecido 
                    where _pag.idPagamento == pagamento.numeroPagamento
                    select new //Entidades.Favorecido()
                    {
                        _fav.nome,
                        _fav.numeroCpfCnpj,
                        _fav.sequenciaCpfCnpj,
                        _fav.tipoPesssoa,
                        _fav.idConta
                    }
                ).FirstOrDefault();

                Entidades.Favorecido favorito = null;

                if (fav != null)
                {
                    favorito = new Entidades.Favorecido()
                    {
                        nome = fav.nome,
                        numeroCpfCnpj = fav.numeroCpfCnpj,
                        sequenciaCpfCnpj = fav.sequenciaCpfCnpj,
                        tipoPesssoa = fav.tipoPesssoa,
                        contaCredito = new ContaCreditoRepository().ObterConta(fav.idConta)
                    };
                }

                return favorito;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
