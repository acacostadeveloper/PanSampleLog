﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class HistoricoReembolsoRepository : IHistoricoReembolsoRepository
    {
        private PanReembolsoContext _contexto;

        public HistoricoReembolsoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(long idReembolso)
        {
            try 
            {
                var resultItem = (from _hist in _contexto.HistoricoReembolsoRepository
                                  join _event in _contexto.EventoRepository on _hist.idEvento equals _event.idEvento
                                  where _hist.idReembolso == idReembolso

                                  select new Pan.Reembolso.Entidades.HistoricoReembolso()
                                  {
                                      idHistoricoReembolso = _hist.idHistoricoReembolso,
                                      //usuarioAlteracao = _hist.usuario,
                                      dataEvento = _hist.dataEvento,
                                      reembolso = idReembolso,
                                      statusContabil = _hist.statusContabil,
                                      statusIni = _hist.statusIni,
                                      statusFim = _hist.statusFim,
                                      usuarioInclusao = _hist.usuario,
                                      mensagemErro= _hist.mensagemErro,
                                      evento = new Evento
                                      {
                                          codigoEvento = _event.codigoEvento,
                                          eventoContabil = _event.eventoContabil,
                                          fluxo = _event.fluxo
                                      }
                                  }
                );

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public HistoricoReembolso PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso)
        {
            try
            {
                var historicoReembolsoDb = new HistoricoReembolsoDatabase
                {
                    idReembolso = historicoReembolso.reembolso,
                    statusIni = historicoReembolso.statusIni,
                    statusFim = historicoReembolso.statusFim,
                    statusContabil = historicoReembolso.statusContabil,
                    dataEvento = historicoReembolso.dataEvento,
                    usuario = historicoReembolso.usuarioInclusao,
                    mensagemErro = historicoReembolso.mensagemErro,
                    idEvento = _contexto.EventoRepository.Select(e => e)
                                                         .Where(f => f.codigoEvento == historicoReembolso.evento.codigoEvento)
                                                         .FirstOrDefault().idEvento
                };

                _contexto.Set<HistoricoReembolsoDatabase>().Add(historicoReembolsoDb);

                _contexto.SaveChanges();

                historicoReembolso.idHistoricoReembolso = historicoReembolsoDb.idHistoricoReembolso;

                return historicoReembolso;
            }
            catch (Exception ex)
            {
                // TODO - Rever Log
                throw ex;
            }
        }


        public IList<HistoricoReembolso> ObterContabilReembolso()
        {
            try
            {
                var resultItem = (from _hist in _contexto.HistoricoReembolsoRepository
                                  join _event in _contexto.EventoRepository on _hist.idEvento equals _event.idEvento
                                  where _hist.statusContabil == "NAO INTEGRADO"
                                  && _event.eventoContabil == "1" && _event.indicadorAtivo == "1"

                                  select new HistoricoReembolso()
                                  {
                                      idHistoricoReembolso = _hist.idHistoricoReembolso,
                                      dataEvento = _hist.dataEvento,
                                      reembolso = _hist.idReembolso,
                                      statusContabil = _hist.statusContabil,
                                      statusIni = _hist.statusIni,
                                      statusFim = _hist.statusFim,
                                      usuarioInclusao = _hist.usuario,
                                      mensagemErro = _hist.mensagemErro,
                                      evento = new Evento
                                      {
                                          codigoEvento = _event.codigoEvento,
                                          eventoContabil = _event.eventoContabil,
                                          fluxo = _event.fluxo
                                      }
                                  }
                ).ToList();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void AtualizarHistoricoContabilizado(HistoricoReembolso historicoReembolso)
        {
            var historicoReembolsoDb = new HistoricoReembolsoDatabase
            {
                idHistoricoReembolso = historicoReembolso.idHistoricoReembolso,
                idReembolso = historicoReembolso.reembolso,
                statusIni = historicoReembolso.statusIni,
                statusFim = historicoReembolso.statusFim,
                statusContabil = historicoReembolso.statusContabil,
                dataEvento = historicoReembolso.dataEvento,
                usuario = historicoReembolso.usuarioInclusao,
                mensagemErro = historicoReembolso.mensagemErro,
                idEvento = _contexto.EventoRepository.Select(e => e)
                                                     .Where(f => f.codigoEvento == historicoReembolso.evento.codigoEvento)
                                                     .FirstOrDefault().idEvento
            };

            _contexto.Entry(historicoReembolsoDb).State = EntityState.Modified;
            _contexto.SaveChanges();

        }
    }
}
