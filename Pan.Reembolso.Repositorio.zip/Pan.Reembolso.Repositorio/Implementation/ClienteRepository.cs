﻿using System;
using System.Linq;
using System.Data.Entity;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ClienteRepository : IClienteRepository
    {

        private PanReembolsoContext _contexto;

        public ClienteRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public async Task<List<Entidades.Cliente>> ConsultarClientes(string numeroCpfCnpj, string nomeCliente)
        {
            try
            {
                var resultItem = (from _clie in _contexto.ClienteRepository
                                  join _end in _contexto.EnderecoRepository on _clie.idCliente equals _end.idCliente
                                  join _contCre in _contexto.ContaCreditoRepository on _clie.idCliente equals _contCre.idCliente
                                  join _cont in _contexto.ContaRepository on _contCre.idConta equals _cont.idConta

                                  where (
                                        (_clie.cpfCnpj == numeroCpfCnpj)
                                        ||
                                        (_clie.nomeCliente.Contains(nomeCliente))
                                      )

                                  select new Pan.Reembolso.Entidades.Cliente()
                                  {
                                      nomeCliente = _clie.nomeCliente,
                                      numeroCpfCnpj = _clie.cpfCnpj,
                                      numeroCelular = _clie.numeroCelular,
                                      numeroDDDFixo = _clie.dddFixo,
                                      numeroDDDCelular = _clie.dddCelular,
                                      numeroFixo = _clie.numeroFixo,
                                      obito = _clie.obito == "1",
                                      registroObito = _clie.registroObito,
                                      tipoPessoa = _clie.tipoPessoa,
                                      
                                      endereco = new Entidades.Endereco
                                      {
                                          nomeLogradouro = _end.nomeLogradouro,
                                          numero = _end.numeroEndereco,
                                          complemento = _end.complemento,
                                          bairro = _end.bairro,
                                          cidade = _end.cidade,
                                          estado = _end.uf,
                                          cep = _end.cep
                                      },
                                      contaCredito = new Entidades.ContaCredito
                                      {
                                          digitoAgencia = _cont.digitoAgencia,
                                          digitoConta = _cont.digitoConta,
                                          numeroAgencia = _cont.numeroAgencia,
                                          numeroBanco = _cont.numeroBanco,
                                          numeroConta = _cont.numeroConta,
                                          tipoConta = _cont.tipoConta
                                      }

                                  }
                ).Distinct();

                return resultItem.ToList<Entidades.Cliente>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public Entidades.Cliente ObterCliente(string cpfCnpj)
        {
            try
            {
                var resultItem = (ObterClientePorCpfCnpj(cpfCnpj)).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(resultItem.numeroCpfCnpj);
                    resultItem.endereco = new EnderecoRepository().ObterEnderecoPorNumeroCpfCliente(resultItem.numeroCpfCnpj);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private IQueryable<Entidades.Cliente> ObterClientePorCpfCnpj(string cpfCnpj)
        {
            return from _clien in _contexto.ClienteRepository
                   where _clien.cpfCnpj == cpfCnpj
                   select new Entidades.Cliente()
                   {
                       numeroDDDCelular = _clien.dddCelular,
                       numeroCelular = _clien.numeroCelular,
                       numeroDDDFixo = _clien.dddFixo,
                       numeroFixo = _clien.numeroFixo,
                       nomeCliente = _clien.nomeCliente,
                       numeroCpfCnpj = _clien.cpfCnpj,
                       tipoPessoa = _clien.tipoPessoa,
                       obito = _clien.obito == "1",
                       registroObito = _clien.registroObito
                   };
        }

        public int ObterIdCliente(string cpfCnpj)
        {
            var clDb = _contexto.ClienteRepository.Where(x => x.cpfCnpj == cpfCnpj)
                                                   .FirstOrDefault();


            return clDb.idCliente;
        }

        public Entidades.Cliente ObterClientePorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  join _clien in _contexto.ClienteRepository on _contr.idCliente equals _clien.idCliente
                                  where _contr.codigoContrato == numeroContrato
                                  select new Entidades.Cliente()
                                  {
                                      numeroDDDCelular = _clien.dddCelular,
                                      numeroCelular = _clien.numeroCelular,
                                      numeroDDDFixo = _clien.dddFixo,
                                      numeroFixo = _clien.numeroFixo,
                                      nomeCliente = _clien.nomeCliente,
                                      numeroCpfCnpj = _clien.cpfCnpj,
                                      tipoPessoa = _clien.tipoPessoa,
                                      obito = _clien.obito == "1",
                                      registroObito = _clien.registroObito
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(resultItem.numeroCpfCnpj);
                    resultItem.endereco = new EnderecoRepository().ObterEnderecoPorNumeroCpfCliente(resultItem.numeroCpfCnpj);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int PersistirCliente(Entidades.Cliente cliente)
        {
            int idCliente = 0;

            var clDb = _contexto.ClienteRepository.Select(x => x)
                                                   .Where(x => x.cpfCnpj == cliente.numeroCpfCnpj)
                                                   .FirstOrDefault();

            if (clDb == null)
                idCliente = this.IncluirCliente(cliente);

            if (clDb != null)
            {
                idCliente = clDb.idCliente;
                this.AtualizarCliente(clDb, cliente);
            }

            return idCliente;
        }

        private void AtualizarCliente(Entidades.DatabaseEntities.ClienteDatabase clienteDB, Entidades.Cliente cliente)
        {
            try
            {
                clienteDB.cpfCnpj = cliente.numeroCpfCnpj;
                clienteDB.tipoPessoa = cliente.tipoPessoa;
                clienteDB.nomeCliente = cliente.nomeCliente;
                clienteDB.dddCelular = cliente.numeroDDDCelular;
                clienteDB.numeroCelular = cliente.numeroCelular;
                clienteDB.dddFixo = cliente.numeroDDDFixo;
                clienteDB.numeroFixo = cliente.numeroFixo;

                clienteDB.obito = cliente.obito ? "1" : "0";
                clienteDB.registroObito = cliente.registroObito;

                _contexto.Entry(clienteDB).State = EntityState.Modified;
                _contexto.SaveChanges();

                // Obter item de endereco da base 

                var itemEnder = _contexto.EnderecoRepository.Select(x => x)
                                                            .Where(x => x.idCliente == clienteDB.idCliente)
                                                            .FirstOrDefault();

                itemEnder.idCliente = clienteDB.idCliente;
                itemEnder.nomeLogradouro = cliente.endereco.nomeLogradouro;
                itemEnder.numeroEndereco = cliente.endereco.numero;
                itemEnder.complemento = cliente.endereco.complemento;
                itemEnder.bairro = cliente.endereco.bairro;
                itemEnder.cep = cliente.endereco.cep;
                itemEnder.cidade = cliente.endereco.cidade;
                itemEnder.uf = cliente.endereco.estado;
                itemEnder.dataAtualizacao = DateTime.Now;

                _contexto.Entry(itemEnder).State = EntityState.Modified;
                _contexto.SaveChanges();

                new ContaCreditoRepository().PersistirContaCredito(cliente.contaCredito, clienteDB.idCliente);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private int IncluirCliente(Entidades.Cliente cliente)
        {
            try
            {
                Entidades.DatabaseEntities.ClienteDatabase itemCli = new Entidades.DatabaseEntities.ClienteDatabase
                {
                    cpfCnpj = cliente.numeroCpfCnpj,
                    tipoPessoa = cliente.tipoPessoa,
                    nomeCliente = cliente.nomeCliente,
                    dddCelular = cliente.numeroDDDCelular,
                    numeroCelular = cliente.numeroCelular,
                    dddFixo = cliente.numeroDDDFixo,
                    numeroFixo = cliente.numeroFixo
                };

                _contexto.Set<Entidades.DatabaseEntities.ClienteDatabase>().Add(itemCli);
                _contexto.SaveChanges();

                Entidades.DatabaseEntities.EnderecoDatabase itemEnd = new Entidades.DatabaseEntities.EnderecoDatabase
                {
                    idCliente = itemCli.idCliente,
                    nomeLogradouro = cliente.endereco.nomeLogradouro,
                    numeroEndereco = cliente.endereco.numero,
                    complemento = cliente.endereco.complemento,
                    bairro = cliente.endereco.bairro,
                    cep = cliente.endereco.cep,
                    cidade = cliente.endereco.cidade,
                    uf = cliente.endereco.estado,
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Set<Entidades.DatabaseEntities.EnderecoDatabase>().Add(itemEnd);
                _contexto.SaveChanges();

                return itemCli.idCliente;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Object> ConsultarClientesParaManutencaoDadosBancarios()
        {
            try
            {
                List<String> lista = new List<string> {
                    StatusReembolsoType.EmTransito.ToString()
                ,   StatusReembolsoType.Reembolsado.ToString()
                ,   StatusReembolsoType.Rejeitado.ToString()
                };

                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  join _contCre in _contexto.ContaCreditoRepository on _clie.idCliente equals _contCre.idCliente into tmpCre
                                  from _contCre in tmpCre.DefaultIfEmpty()
                                  join _cont in _contexto.ContaRepository on _contCre.idConta equals _cont.idConta into tmpCont
                                  from _cont in tmpCont.DefaultIfEmpty()
                                  where !lista.Contains(_reemb.statusReembolso)

                                  select new
                                  {
                                      idCliente = _clie.idCliente,
                                      nomeCliente = _clie.nomeCliente,
                                      numeroCpfCnpj = _clie.cpfCnpj,
                                      conta = new Entidades.ContaCredito()
                                      {
                                          digitoAgencia = _cont.digitoAgencia,
                                          digitoConta = _cont.digitoConta,
                                          numeroAgencia = _cont.numeroAgencia,
                                          numeroBanco = _cont.numeroBanco,
                                          numeroConta = _cont.numeroConta,
                                          tipoConta = _cont.tipoConta

                                      }
                                  }
                ).GroupBy(s => s.idCliente).Select(v => new
                {
                    idCliente = v.Key,
                    nomeCliente = v.FirstOrDefault().nomeCliente,
                    numeroCpfCnpj = v.FirstOrDefault().numeroCpfCnpj,
                    conta = v.Select(u => u.conta).Distinct().ToList()
                });

                return resultItem.ToList<Object>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public async Task<List<Object>> ConsultarClientesParaManutencaoDadosBancariosFlat(string numeroCpfCnpj, string nomeCliente)
        {
            try
            {
                List<String> lista = new List<string> {
                    StatusReembolsoType.EmTransito.ToString()
                ,   StatusReembolsoType.Reembolsado.ToString()
                ,   StatusReembolsoType.Rejeitado.ToString()
                };

                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  join _contCre in _contexto.ContaCreditoRepository on _clie.idCliente equals _contCre.idCliente into tmpCre
                                  from _contCre in tmpCre.DefaultIfEmpty()
                                  join _cont in _contexto.ContaRepository on _contCre.idConta equals _cont.idConta into tmpCont
                                  from _cont in tmpCont.DefaultIfEmpty()
                                  where !lista.Contains(_reemb.statusReembolso)
                                      && ((_clie.cpfCnpj == numeroCpfCnpj || string.IsNullOrEmpty(numeroCpfCnpj))
                                      || (_clie.nomeCliente.Contains(nomeCliente) || string.IsNullOrEmpty(nomeCliente)))

                                  select new
                                  {
                                      idCliente = _clie.idCliente,
                                      nomeCliente = _clie.nomeCliente,
                                      numeroCpfCnpj = _clie.cpfCnpj,
                                      digitoAgencia = _cont.digitoAgencia,
                                      digitoConta = _cont.digitoConta,
                                      fraude = _cont.fraude,
                                      numeroAgencia = _cont.numeroAgencia,
                                      numeroBanco = _cont.numeroBanco,
                                      numeroConta = _cont.numeroConta,
                                      tipoConta = _cont.tipoConta
                                  }
                ).Distinct();

                return resultItem.ToList<Object>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        public List<Entidades.Cliente> ConsultarClientesASeremComunicados()
        {
            try
            {
                var resultItems =
                (
                    from _clie in _contexto.ClienteRepository
                    join _cntr in _contexto.ContratoRepository on _clie.idCliente equals _cntr.idCliente
                    join _reemb in _contexto.ReembolsoRepository on _cntr.idContrato equals _reemb.idContrato
                    where _reemb.statusReembolso == StatusReembolsoType.Bloqueado.ToString()
                    select new
                    {
                        //idCliente = _clie.idCliente,
                        cpfCnpj = _clie.cpfCnpj,
                        idReembolso = _reemb.idReembolso
                    } into a
                    join _hist in _contexto.HistoricoReembolsoRepository on a.idReembolso equals _hist.idReembolso
                    group _hist by new { a.cpfCnpj, a.idReembolso } into b
                    select new
                    {
                        //idCliente = b.Key.idCliente,
                        cpfCnpj = b.Key.cpfCnpj,
                        idReembolso = b.Key.idReembolso,

                        eventos = b.Select(x => x.idEvento).ToList()
                    } into c
                    where c.eventos.Max() == 4
                    select new
                    {
                        c.cpfCnpj
                    }
                ).Distinct().ToList();

                var clientes = new List<Entidades.Cliente>();
                foreach (var item in resultItems)
                {
                    clientes.Add(ObterCliente(item.cpfCnpj));
                }
                //(
                //    from _d in resultItem
                //    join _client in _contexto.ClienteRepository on _d.idCliente equals _client.idCliente
                //    select new Entidades.Cliente()
                //    {
                //        nomeCliente = _client.nomeCliente,
                //        numeroCelular = _client.numeroCelular,
                //        numeroDDDCelular = _client.dddCelular,
                //        numeroFixo = _client.numeroFixo,
                //        numeroDDDFixo = _client.dddFixo,
                //        numeroCpfCnpj = _client.cpfCnpj,
                //        tipoPessoa = _client.tipoPessoa,
                //        registroObito = _client.registroObito,
                //        obito = _client.obito == "1"
                //    }
                //);
                //foreach (var item in clientes)
                //{
                //    item.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(item.numeroCpfCnpj);
                //    item.endereco = new EnderecoRepository().ObterEnderecoPorNumeroCpfCliente(item.numeroCpfCnpj);
                //}

                return clientes;
            }
            catch (Exception ex )
            {
                throw ex;
            }
        }
    }
}
