﻿using System;
using System.Linq;
using System.Data.Entity;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;


namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ClienteRepository : IClienteRepository 
    {

        private PanReembolsoContext _contexto;

        public ClienteRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Cliente ObterCliente(string cpfCnpj) 
        {
            var clDb = _contexto.ClienteRepository.Select(x => x)
                                                   .Where(x => x.cpfCnpj == cpfCnpj)
                                                   .FirstOrDefault();


            return new Entidades.Cliente();
        }

        public Entidades.Cliente ObterClientePorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  join _clien in _contexto.ClienteRepository on _contr.idCliente equals _clien.idCliente
                                  where _contr.codigoContrato == numeroContrato
                                  select new Entidades.Cliente()
                                  {
                                        numeroDDDCelular = _clien.dddCelular,
                                        numeroCelular = _clien.numeroCelular,
                                        numeroDDDFixo = _clien.dddFixo,
                                        numeroFixo = _clien.numeroFixo,
                                        nomeCliente = _clien.nomeCliente,
                                        numeroCpfCnpj = _clien.cpfCnpj,
                                        tipoPessoa = _clien.tipoPessoa
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(resultItem.numeroCpfCnpj);
                    resultItem.endereco = new EnderecoRepository().ObterEnderecoPorNumeroCpfCliente(resultItem.numeroCpfCnpj);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int PersistirCliente(Entidades.Cliente cliente) 
        {
            int idCliente = 0;
            
            var clDb = _contexto.ClienteRepository.Select(x => x)
                                                   .Where(x => x.cpfCnpj == cliente.numeroCpfCnpj)
                                                   .FirstOrDefault();

            if(clDb == null)
                idCliente = this.IncluirCliente(cliente);

            if(clDb != null)
            {
                idCliente = clDb.idCliente;
                this.AtualizarCliente(clDb, cliente);
            }

            return idCliente;
        }

        private void AtualizarCliente(Entidades.DatabaseEntities.ClienteDatabase clienteDB, Entidades.Cliente cliente)
        {
            try
            {
                clienteDB.cpfCnpj = cliente.numeroCpfCnpj;
                clienteDB.tipoPessoa = cliente.tipoPessoa;
                clienteDB.nomeCliente = cliente.nomeCliente;
                clienteDB.dddCelular = cliente.numeroDDDCelular;
                clienteDB.numeroCelular = cliente.numeroCelular;
                clienteDB.dddFixo = cliente.numeroDDDFixo;
                clienteDB.numeroFixo = cliente.numeroFixo;

                _contexto.Entry(clienteDB).State = EntityState.Modified;
                _contexto.SaveChanges();

                // Obter item de endereco da base 

                var itemEnder = _contexto.EnderecoRepository.Select(x => x)
                                                            .Where(x => x.idCliente == clienteDB.idCliente)
                                                            .FirstOrDefault();

                itemEnder.idCliente = clienteDB.idCliente;
                itemEnder.nomeLogradouro = cliente.endereco.nomeLogradouro;
                itemEnder.numeroEndereco = cliente.endereco.numero;
                itemEnder.complemento = cliente.endereco.complemento;
                itemEnder.bairro = cliente.endereco.bairro;
                itemEnder.cep = cliente.endereco.cep;
                itemEnder.cidade = cliente.endereco.cidade;
                itemEnder.uf = cliente.endereco.estado;
                itemEnder.dataAtualizacao = DateTime.Now; 

                _contexto.Entry(itemEnder).State = EntityState.Modified;
                _contexto.SaveChanges();

                var query = (from _ccr in _contexto.ContaCreditoRepository
                               join _cco in _contexto.ContaRepository on _ccr.idConta equals _cco.idConta
                               where _ccr.idCliente == clienteDB.idCliente
                               select new
                               {
                                   _cco.idConta,
                                   _cco.numeroBanco,
                                   _cco.numeroAgencia,
                                   _cco.digitoAgencia,
                                   _cco.numeroConta,
                                   _cco.digitoConta,
                                   _cco.tipoConta
                               }
                ).FirstOrDefault();

                var itemCco = new Entidades.DatabaseEntities.ContaDatabase()
                {
                    idConta = query.idConta,
                    numeroBanco = query.numeroBanco,
                    numeroAgencia = query.numeroAgencia,
                    digitoAgencia = query.digitoAgencia,
                    numeroConta = query.numeroConta,
                    digitoConta = query.digitoConta,
                    tipoConta = query.tipoConta
                };

                _contexto.Entry(itemCco).State = EntityState.Modified;
                _contexto.SaveChanges();

                var itemCcr = new Entidades.DatabaseEntities.ContaCreditoDatabase
                {
                    idCliente = clienteDB.idCliente,
                    idConta = itemCco.idConta,
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Entry(itemCcr).State = EntityState.Modified;
                _contexto.SaveChanges();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        private int IncluirCliente(Entidades.Cliente cliente)
        {
            try
            {
                Entidades.DatabaseEntities.ClienteDatabase itemCli = new Entidades.DatabaseEntities.ClienteDatabase
                {
                    cpfCnpj = cliente.numeroCpfCnpj,
                    tipoPessoa = cliente.tipoPessoa,
                    nomeCliente = cliente.nomeCliente,
                    dddCelular = cliente.numeroDDDCelular,
                    numeroCelular = cliente.numeroCelular,
                    dddFixo = cliente.numeroDDDFixo,
                    numeroFixo = cliente.numeroFixo
                };

                _contexto.Set<Entidades.DatabaseEntities.ClienteDatabase>().Add(itemCli);
                _contexto.SaveChanges();

                Entidades.DatabaseEntities.EnderecoDatabase itemEnd = new Entidades.DatabaseEntities.EnderecoDatabase
                {
                    idCliente = itemCli.idCliente,
                    nomeLogradouro = cliente.endereco.nomeLogradouro,
                    numeroEndereco = cliente.endereco.numero,
                    complemento = cliente.endereco.complemento,
                    bairro = cliente.endereco.bairro,
                    cep = cliente.endereco.cep,
                    cidade = cliente.endereco.cidade,
                    uf = cliente.endereco.estado,
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Set<Entidades.DatabaseEntities.EnderecoDatabase>().Add(itemEnd);
                _contexto.SaveChanges();

                Entidades.DatabaseEntities.ContaDatabase itemCco = new Entidades.DatabaseEntities.ContaDatabase
                {
                    numeroBanco = cliente.contaCredito.numeroBanco,
                    numeroAgencia = cliente.contaCredito.numeroAgencia,
                    digitoAgencia = cliente.contaCredito.digitoAgencia,
                    numeroConta = cliente.contaCredito.numeroConta,
                    digitoConta = cliente.contaCredito.digitoConta,
                    tipoConta = cliente.contaCredito.tipoConta
                };

                _contexto.Set<Entidades.DatabaseEntities.ContaDatabase>().Add(itemCco);
                _contexto.SaveChanges();

                Entidades.DatabaseEntities.ContaCreditoDatabase itemCcr = new Entidades.DatabaseEntities.ContaCreditoDatabase
                {
                    idCliente = itemCli.idCliente,
                    idConta = itemCco.idConta,
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Set<Entidades.DatabaseEntities.ContaCreditoDatabase>().Add(itemCcr);
                _contexto.SaveChanges();

                return itemCli.idCliente;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
