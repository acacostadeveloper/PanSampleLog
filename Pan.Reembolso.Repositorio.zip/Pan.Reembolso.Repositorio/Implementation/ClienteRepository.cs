﻿using System;
using System.Linq;
using System.Data.Entity;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;
using System.Collections.Generic;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ClienteRepository : IClienteRepository
    {

        private PanReembolsoContext _contexto;

        public ClienteRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Entidades.Cliente ObterCliente(string cpfCnpj) 
        {
            var clDb = _contexto.ClienteRepository.Select(x => x)
                                                   .Where(x => x.cpfCnpj == cpfCnpj)
                                                   .FirstOrDefault();


            return new Entidades.Cliente();
        }

        public Entidades.Cliente ObterClientePorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  join _clien in _contexto.ClienteRepository on _contr.idCliente equals _clien.idCliente
                                  where _contr.codigoContrato == numeroContrato
                                  select new Entidades.Cliente()
                                  {
                                        numeroDDDCelular = _clien.dddCelular,
                                        numeroCelular = _clien.numeroCelular,
                                        numeroDDDFixo = _clien.dddFixo,
                                        numeroFixo = _clien.numeroFixo,
                                        nomeCliente = _clien.nomeCliente,
                                        numeroCpfCnpj = _clien.cpfCnpj,
                                        tipoPessoa = _clien.tipoPessoa
                                  }
                ).FirstOrDefault();

                if (resultItem != null)
                {
                    resultItem.contaCredito = new ContaCreditoRepository().ObterContaCreditoPorCpfCliente(resultItem.numeroCpfCnpj);
                    resultItem.endereco = new EnderecoRepository().ObterEnderecoPorNumeroCpfCliente(resultItem.numeroCpfCnpj);
                }

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public int PersistirCliente(Entidades.Cliente cliente) 
        {
            int idCliente = 0;
            
            var clDb = _contexto.ClienteRepository.Select(x => x)
                                                   .Where(x => x.cpfCnpj == cliente.numeroCpfCnpj)
                                                   .FirstOrDefault();

            if(clDb == null)
                idCliente = this.IncluirCliente(cliente);

            if(clDb != null)
            {
                idCliente = clDb.idCliente;
                this.AtualizarCliente(clDb, cliente);
            }

            return idCliente;
        }

        private void AtualizarCliente(Entidades.DatabaseEntities.ClienteDatabase clienteDB, Entidades.Cliente cliente)
        {
            try
            {
                clienteDB.cpfCnpj = cliente.numeroCpfCnpj;
                clienteDB.tipoPessoa = cliente.tipoPessoa;
                clienteDB.nomeCliente = cliente.nomeCliente;
                clienteDB.dddCelular = cliente.numeroDDDCelular;
                clienteDB.numeroCelular = cliente.numeroCelular;
                clienteDB.dddFixo = cliente.numeroDDDFixo;
                clienteDB.numeroFixo = cliente.numeroFixo;

                clienteDB.obito = cliente.obito ? "1" : "0";
                clienteDB.registroObito = cliente.registroObito;

                _contexto.Entry(clienteDB).State = EntityState.Modified;
                _contexto.SaveChanges();

                // Obter item de endereco da base 

                var itemEnder = _contexto.EnderecoRepository.Select(x => x)
                                                            .Where(x => x.idCliente == clienteDB.idCliente)
                                                            .FirstOrDefault();

                itemEnder.idCliente = clienteDB.idCliente;
                itemEnder.nomeLogradouro = cliente.endereco.nomeLogradouro;
                itemEnder.numeroEndereco = cliente.endereco.numero;
                itemEnder.complemento = cliente.endereco.complemento;
                itemEnder.bairro = cliente.endereco.bairro;
                itemEnder.cep = cliente.endereco.cep;
                itemEnder.cidade = cliente.endereco.cidade;
                itemEnder.uf = cliente.endereco.estado;
                itemEnder.dataAtualizacao = DateTime.Now; 

                _contexto.Entry(itemEnder).State = EntityState.Modified;
                _contexto.SaveChanges();

                new ContaCreditoRepository().PersistirContaCredito(cliente.contaCredito, clienteDB.idCliente);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        private int IncluirCliente(Entidades.Cliente cliente)
        {
            try
            {
                Entidades.DatabaseEntities.ClienteDatabase itemCli = new Entidades.DatabaseEntities.ClienteDatabase
                {
                    cpfCnpj = cliente.numeroCpfCnpj,
                    tipoPessoa = cliente.tipoPessoa,
                    nomeCliente = cliente.nomeCliente,
                    dddCelular = cliente.numeroDDDCelular,
                    numeroCelular = cliente.numeroCelular,
                    dddFixo = cliente.numeroDDDFixo,
                    numeroFixo = cliente.numeroFixo
                };

                _contexto.Set<Entidades.DatabaseEntities.ClienteDatabase>().Add(itemCli);
                _contexto.SaveChanges();

                Entidades.DatabaseEntities.EnderecoDatabase itemEnd = new Entidades.DatabaseEntities.EnderecoDatabase
                {
                    idCliente = itemCli.idCliente,
                    nomeLogradouro = cliente.endereco.nomeLogradouro,
                    numeroEndereco = cliente.endereco.numero,
                    complemento = cliente.endereco.complemento,
                    bairro = cliente.endereco.bairro,
                    cep = cliente.endereco.cep,
                    cidade = cliente.endereco.cidade,
                    uf = cliente.endereco.estado,
                    dataAtualizacao = DateTime.Now
                };

                _contexto.Set<Entidades.DatabaseEntities.EnderecoDatabase>().Add(itemEnd);
                _contexto.SaveChanges();

                return itemCli.idCliente;
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public List<Object> ConsultarClientesParaManutencaoDadosBancarios()
        {
            try
            {
                List<String> lista = new List<string> {
                    StatusReembolsoType.EmTransito.ToString()
                ,   StatusReembolsoType.Reembolsado.ToString()
                ,   StatusReembolsoType.Rejeitado.ToString()
                };

                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _contr in _contexto.ContratoRepository on _reemb.idContrato equals _contr.idContrato
                                  join _clie in _contexto.ClienteRepository on _contr.idCliente equals _clie.idCliente
                                  join _contCre in _contexto.ContaCreditoRepository on _clie.idCliente equals _contCre.idCliente into tmpCre
                                  from _contCre in tmpCre.DefaultIfEmpty()
                                  join _cont in _contexto.ContaRepository on _contCre.idConta equals _cont.idConta into tmpCont
                                  from _cont in tmpCont.DefaultIfEmpty()
                                  where !lista.Contains(_reemb.statusReembolso)

                                  select new
                                  {
                                      idCliente = _clie.idCliente,
                                      nomeCliente = _clie.nomeCliente,
                                      numeroCpfCnpj = _clie.cpfCnpj,
                                      conta = new Entidades.ContaCredito()
                                      {
                                          digitoAgencia = _cont.digitoAgencia,
                                          digitoConta = _cont.digitoConta,
                                          fraude = _cont.fraude,
                                          numeroAgencia = _cont.numeroAgencia,
                                          numeroBanco = _cont.numeroBanco,
                                          numeroConta = _cont.numeroConta,
                                          tipoConta = _cont.tipoConta

                                      }
                                  }
                ).GroupBy(s => s.idCliente).Select(v => new
                {
                    idCliente = v.Key,
                    nomeCliente = v.FirstOrDefault().nomeCliente,
                    numeroCpfCnpj = v.FirstOrDefault().numeroCpfCnpj,
                    conta = v.Select(u => u.conta).Distinct().ToList()
                });

                return resultItem.ToList<Object>();
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
    }
}
