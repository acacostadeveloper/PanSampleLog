﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class DepartamentoRepository : IDepartamentoRepository
    {
        private PanReembolsoContext _contexto;

        public DepartamentoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Departamento ObterDepartamentoPorIdReembolso(long idReembolso)
        {
            try 
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository 
                                  join _depar in _contexto.DepartamentoRepository on _reemb.idDepartamento equals _depar.idDepartamento
                                  where _reemb.idReembolso == idReembolso
                                  select new Pan.Reembolso.Entidades.Departamento()
                                  {
                                      idDepartamento = _depar.idDepartamento,
                                      codigoDepartamento = _depar.codigoDepartamento,
                                      nomeDepartamento = _depar.descricaoDepartamento 
                                  }
                ).FirstOrDefault();

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.Departamento ObterDepartamentoPorCodigo(string codigoDepartamento) 
        {
            return null; 
        }
    }
}
