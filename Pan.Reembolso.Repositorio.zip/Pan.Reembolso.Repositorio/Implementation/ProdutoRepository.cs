﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ProdutoRepository : IProdutoRepository
    {
        private PanReembolsoContext _contexto;

        public ProdutoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Produto ObterProdutoPorNumeroContrato(string numeroContrato)
        {
            try
            {
                var resultItem = (from _contr in _contexto.ContratoRepository
                                  join _produ in _contexto.ProdutoRepository on _contr.idProduto equals _produ.idProduto
                                  join _siste in _contexto.SistemaRepository on _produ.idSistema equals _siste.idSistema
                                  where _contr.codigoContrato == numeroContrato
                                  select new Pan.Reembolso.Entidades.Produto()
                                  {
                                      codigoCarteira = _produ.codigoCarteira,
                                      codigoProduto = _produ.codigoProduto,
                                      nomeProduto = _produ.nomeProduto,
                                      sistemaProduto = new Pan.Reembolso.Entidades.SistemaProduto()
                                      {
                                          codigoSistema = "",
                                          nomeSistema = _siste.descricaoSistema
                                      }
                                  }
                ).FirstOrDefault();

                return resultItem;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Pan.Reembolso.Entidades.Produto ObterProdutoPorCodigo(string codigoProduto)
        {
            var produto = new Pan.Reembolso.Entidades.Produto();



            return produto;
        }
        public IEnumerable<Entidades.Produto> ObterProdutos()
        {
            var produtos = _contexto.ProdutoRepository
                                .Select(c => new Entidades.Produto
                                {
                                    codigoCarteira = c.codigoCarteira,
                                    codigoProduto = c.codigoProduto,
                                    nomeProduto = c.nomeProduto
                                }
                );

            return produtos;
        }
    }
}
