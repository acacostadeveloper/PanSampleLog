﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ComunicacaoRepository : IComunicacaoRepository
    {
        private PanReembolsoContext _contexto;

        public ComunicacaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IList<Pan.Reembolso.Entidades.Comunicacao> ObterComunicacaoPorIdReembolso(long idReembolso) 
        {
            try 
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _remco in _contexto.ReembolsoComunicacaoRepository on _reemb.idReembolso equals _remco.idReembolso
                                  join _comun in _contexto.ComunicacaoRepository on _remco.idComunicacao equals _comun.idComunicacao
                                  join _msgco in _contexto.MensagemComunicacaoRepository on _comun.idMensagemComunicacao equals _msgco.idMensagemComunicacao
                                  where _reemb.idReembolso == idReembolso
                                  select new Pan.Reembolso.Entidades.Comunicacao()
                                  {
                                      dataEnvioComunicacao = _comun.dataEnvio,
                                      indicadorEfetivacao = _comun.indicadorEfetivacao,
                                      protocolo = _comun.protocolo,
                                      mensagemComunicacao = new Pan.Reembolso.Entidades.MensagemComunicacao()
                                      {
                                          mensagemComunicacao = _msgco.descricaoMensagemComunicacao,
                                          numeroVersao = "",
                                          tipoComunicacao = _msgco.tipoMensagemComunicacao
                                      }
                                  }
                ).ToList();
                
                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
    }
}
