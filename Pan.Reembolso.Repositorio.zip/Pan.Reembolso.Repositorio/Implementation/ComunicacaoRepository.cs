﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class ComunicacaoRepository : IComunicacaoRepository
    {
        private PanReembolsoContext _contexto;

        public ComunicacaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IList<Pan.Reembolso.Entidades.Comunicacao> ObterComunicacaoPorIdReembolso(long idReembolso) 
        {
            try 
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _remco in _contexto.ReembolsoComunicacaoRepository on _reemb.idReembolso equals _remco.idReembolso
                                  join _comun in _contexto.ComunicacaoRepository on _remco.idComunicacao equals _comun.idComunicacao
                                  join _msgco in _contexto.MensagemComunicacaoRepository on _comun.idMensagemComunicacao equals _msgco.idMensagemComunicacao
                                  where _reemb.idReembolso == idReembolso
                                  select new Pan.Reembolso.Entidades.Comunicacao()
                                  {
                                      identificador = _comun.idComunicacao,
                                      dataEnvioComunicacao = _comun.dataEnvio,
                                      indicadorEfetivacao = _comun.indicadorEfetivacao,
                                      protocolo = _comun.protocolo,
                                      mensagemComunicacao = new Pan.Reembolso.Entidades.MensagemComunicacao()
                                      {
                                          mensagemComunicacao = _msgco.descricaoMensagemComunicacao,
                                          versao = _msgco.versao,
                                          tipoComunicacao = _msgco.tipoMensagemComunicacao
                                      }
                                  }
                ).ToList();
                
                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public Entidades.Comunicacao ObterComunicacao(int identificador)
        {
            var resultItem =
            (
                from _comun in _contexto.ComunicacaoRepository
                join _msgco in _contexto.MensagemComunicacaoRepository on _comun.idMensagemComunicacao equals _msgco.idMensagemComunicacao
                where _comun.idComunicacao == identificador
                select new Entidades.Comunicacao()
                {
                    dataEnvioComunicacao = _comun.dataEnvio,
                    identificador = _comun.idComunicacao,
                    descricaoErro = _comun.descricaoErro,
                    indicadorEfetivacao = _comun.indicadorEfetivacao,
                    mensagemComunicacao = new Entidades.MensagemComunicacao()
                    {
                        mensagemComunicacao = _msgco.descricaoMensagemComunicacao,
                        versao = _msgco.versao,
                        tipoComunicacao = _msgco.tipoMensagemComunicacao
                    }
                }
            ).FirstOrDefault();
            return resultItem;
                
        }

        public Entidades.Comunicacao ObterUltimaComunicacao (List<long> idsReembolsos)
        {
            var resultItem = (  from _reemb in _contexto.ReembolsoRepository
                                join _remco in _contexto.ReembolsoComunicacaoRepository on _reemb.idReembolso equals _remco.idReembolso
                                join _comun in _contexto.ComunicacaoRepository on _remco.idComunicacao equals _comun.idComunicacao
                                join _msgco in _contexto.MensagemComunicacaoRepository on _comun.idMensagemComunicacao equals _msgco.idMensagemComunicacao
                                where idsReembolsos.Contains( _reemb.idReembolso ) 
                                && _comun.indicadorEfetivacao != ReembolsoTypes.StatusComunicacaoType.Efetivado.ToString()
                                select new Entidades.Comunicacao()
                                {
                                    identificador = _comun.idComunicacao,
                                    dataEnvioComunicacao = _comun.dataEnvio,
                                    indicadorEfetivacao = _comun.indicadorEfetivacao,
                                    protocolo = _comun.protocolo,
                                    mensagemComunicacao = new Entidades.MensagemComunicacao()
                                    {
                                        mensagemComunicacao = _msgco.descricaoMensagemComunicacao,
                                        versao = _msgco.versao,
                                        tipoComunicacao = _msgco.tipoMensagemComunicacao
                                    }
                                }).Distinct().FirstOrDefault();
            return resultItem;
        }

        public void IncluirComunicacao(Entidades.Comunicacao comunicacao,List<Entidades.Reembolso> reembolsos)
        {
            if (comunicacao.idLoteComunicacao == -1)
            {
                comunicacao.idLoteComunicacao = GerarNovoLoteComunicacao();
            }
            var db = new Entidades.DatabaseEntities.ComunicacaoDatabase()
            {
                dataEnvio = comunicacao.dataEnvioComunicacao,
                descricaoErro = comunicacao.descricaoErro,
                indicadorEfetivacao = comunicacao.indicadorEfetivacao,
                protocolo = comunicacao.protocolo,
                idLote = comunicacao.idLoteComunicacao,
                idMensagemComunicacao = _contexto.MensagemComunicacaoRepository
                                            .Select( x => x )
                                            .Where
                                            (x => 
                                                x.tipoMensagemComunicacao == comunicacao.mensagemComunicacao.tipoComunicacao &&
                                                x.versao == comunicacao.mensagemComunicacao.versao
                                            )
                                            .FirstOrDefault().idMensagemComunicacao
            };
            _contexto.Set<Entidades.DatabaseEntities.ComunicacaoDatabase>().Add(db);
            _contexto.SaveChanges();

            IncluirAssociativaComunicacao(db.idComunicacao, reembolsos.Select(x => x.idReembolso).ToList());
        }

        private int GerarNovoLoteComunicacao ()
        {
            var db = new Entidades.DatabaseEntities.LoteComunicacaoDatabase()
            {
                dtInclusao = DateTime.Now
            };
            _contexto.Set<Entidades.DatabaseEntities.LoteComunicacaoDatabase>().Add(db);
            _contexto.SaveChanges();
            return db.idLoteComunicacao;
        }

        public void IncluirAssociativaComunicacao(int idComunicacao, List<long> idsreembolsos)
        {
            foreach (var item in idsreembolsos)
            {
                var db = new Entidades.DatabaseEntities.ReembolsoComunicacaoDatabase()
                {
                    idComunicacao = idComunicacao,
                    idReembolso = item

                };
                _contexto.Set<Entidades.DatabaseEntities.ReembolsoComunicacaoDatabase>().Add(db);
                _contexto.SaveChanges();
            }
        }

        public void AtualizarComunicacao (Entidades.Comunicacao comunicacao)
        {
            var db = _contexto.ComunicacaoRepository.Where(x => x.idComunicacao == comunicacao.identificador).FirstOrDefault();

            if (db != null)
            {
                db.indicadorEfetivacao = comunicacao.indicadorEfetivacao;
                db.protocolo = comunicacao.protocolo;
                db.descricaoErro = comunicacao.descricaoErro;
                _contexto.Entry(db).State = System.Data.Entity.EntityState.Modified;
                _contexto.SaveChanges();
            }
            else
            {
                throw new Exception("Comunicação não encontrada no banco de dados");
            }
        }

        public Entidades.MensagemComunicacao ObterMensagemComunicacao(ReembolsoTypes.ComunicacaoType type)
        {
            var resultItem =
            (
                from _msgco in _contexto.MensagemComunicacaoRepository
                where _msgco.tipoMensagemComunicacao == type.ToString()
                select new Entidades.MensagemComunicacao()
                {
                    mensagemComunicacao = _msgco.descricaoMensagemComunicacao,
                    versao = _msgco.versao,
                    tipoComunicacao = _msgco.tipoMensagemComunicacao
                }
            ).OrderByDescending(x => x.versao).FirstOrDefault();
            return resultItem;
        }

        public List<Entidades.Comunicacao> ObterSMSEnviados()
        {
            var resultItem =
            (
                from _comun in _contexto.ComunicacaoRepository
                join _msgco in _contexto.MensagemComunicacaoRepository on _comun.idMensagemComunicacao equals _msgco.idMensagemComunicacao
                where _msgco.tipoMensagemComunicacao == ReembolsoTypes.ComunicacaoType.SMS.ToString()
                && _comun.indicadorEfetivacao == ReembolsoTypes.StatusComunicacaoType.Enviado.ToString()
                select new Entidades.Comunicacao()
                {
                    identificador = _comun.idComunicacao,
                    indicadorEfetivacao = _comun.indicadorEfetivacao,
                    protocolo = _comun.protocolo,
                    dataEnvioComunicacao = _comun.dataEnvio,
                    descricaoErro = _comun.descricaoErro,
                    mensagemComunicacao = new Entidades.MensagemComunicacao()
                    {
                        mensagemComunicacao = _msgco.descricaoMensagemComunicacao,
                        versao = _msgco.versao,
                        tipoComunicacao = _msgco.tipoMensagemComunicacao
                    }
                }
            ).ToList();
            return resultItem;
        }


    }
}
