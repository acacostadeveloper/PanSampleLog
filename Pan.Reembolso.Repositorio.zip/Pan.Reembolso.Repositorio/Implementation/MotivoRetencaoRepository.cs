﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class MotivoRetencaoRepository : IMotivoRetencaoRepository
    {
        private PanReembolsoContext _contexto;

        public MotivoRetencaoRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public IEnumerable<MotivoRetencao> ObterMotivosRetencao()
        {
            try
            {
                var motivosRetencao = _contexto.MotivoRetencaoRepository
                        .Select(c => new MotivoRetencao
                        {
                            idMotivoRetencao = c.idMotivoRetencao,
                            descricaoMotivoRetencao = c.descricaoMotivoRetencao
                        });

                return motivosRetencao;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
