﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Repositorio.Interface;
using Pan.Reembolso.Repositorio.Context;
using Pan.Reembolso.Entidades.DatabaseEntities;

namespace Pan.Reembolso.Repositorio.Implementation
{
    public class LoteRepository : ILoteRepository
    {
        private PanReembolsoContext _contexto;

        public LoteRepository()
        {
            _contexto = new PanReembolsoContext();
        }

        public Pan.Reembolso.Entidades.Lote ObterLotePorIdReembolso(int idReembolso)
        {
            try 
            {
                var resultItem = (from _reemb in _contexto.ReembolsoRepository
                                  join _lote in _contexto.LoteRepository on _reemb.idLote equals _lote.idLote
                                  where _reemb.idReembolso == idReembolso

                                  select new Pan.Reembolso.Entidades.Lote()
                                  {
                                      idLote = _lote.idLote,
                                      lote = _lote.lote
                                  }
                ).FirstOrDefault();

                return resultItem; 
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public int IncluirLote(string lote)
        {
            try
            {
                var itemLote = new Entidades.DatabaseEntities.LoteDatabase();

                itemLote.lote = lote;

                _contexto.Set<Pan.Reembolso.Entidades.DatabaseEntities.LoteDatabase>().Add(itemLote);
                _contexto.SaveChanges();

                return itemLote.idLote;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
