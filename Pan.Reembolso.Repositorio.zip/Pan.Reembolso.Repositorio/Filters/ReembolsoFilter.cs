﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Filters
{
    public class ReembolsoFilter
    {
        public int? idLote { get; set; }
        public string codigoProduto { get; set; }
        public DateTime? dtInicial { get; set; }
        public DateTime? dtFinal { get; set; }
        public string cpfCliente { get; set; }
        public string[] statusReembolso { get; set; }
    }
    
}
