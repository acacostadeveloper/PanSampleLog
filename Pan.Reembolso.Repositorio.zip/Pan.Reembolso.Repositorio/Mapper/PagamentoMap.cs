﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class PagamentoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.PagamentoDatabase>
    {
        public PagamentoMap() 
        {
            this.HasKey(t   => t.idPagamento);
            this.Property(t => t.idPagamento).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[PAGAMENTO]");
            this.Property(t => t.idPagamento).HasColumnName("ID_PAGAMENTO");
            this.Property(t => t.idColigada).HasColumnName("ID_COLIGADA");
            this.Property(t => t.dataRegistro).HasColumnName("DT_REGISTRO_PAGAMENTO");
            this.Property(t => t.dataPagamento).HasColumnName("DT_PAGAMENTO");
            this.Property(t => t.tipoPagamento).HasColumnName("CD_TIPO_PAGAMENTO");
            this.Property(t => t.valorPagamento).HasColumnName("VL_PAGAMENTO");
            this.Property(t => t.idProcessoOrigem).HasColumnName("ID_PROCESSO_REGISTRO");
            this.Property(t => t.idFavorecido).HasColumnName("ID_FAVORECIDO");
            this.Property(t => t.statusPagamento).HasColumnName("CD_STATUS_PAGAMENTO");
            //this.Property(t => t.idMensagem).HasColumnName("ID_MENSAGEM");
        }
    }
}
