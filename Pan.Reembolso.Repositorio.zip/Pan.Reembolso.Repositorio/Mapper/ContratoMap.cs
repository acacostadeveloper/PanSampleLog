﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContratoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ContratoDatabase>
    {
        public ContratoMap() 
        {
            this.HasKey(t   => t.idContrato);
            this.Property(t => t.idContrato).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[CONTRATO]");
            this.Property(t => t.idContrato).HasColumnName("ID_CONTRATO");
            this.Property(t => t.codigoContrato).HasColumnName("CD_CONTRATO");
            this.Property(t => t.idProduto).HasColumnName("ID_PRODUTO");
            this.Property(t => t.idCliente).HasColumnName("ID_CLIENTE");
            this.Property(t => t.idColigada).HasColumnName("ID_COLIGADA");
            this.Property(t => t.statusContrato).HasColumnName("CD_STATUS_CONTRATO");
            this.Property(t => t.dataLiquidacao).HasColumnName("DT_LIQUIDACAO");
            this.Property(t => t.registroObito).HasColumnName("ID_REGISTRO_OBITO");
        }
    }
}
