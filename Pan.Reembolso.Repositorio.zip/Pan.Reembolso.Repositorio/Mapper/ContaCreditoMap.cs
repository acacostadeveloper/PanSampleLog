﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContaCreditoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ContaCreditoDatabase>
    {
        public ContaCreditoMap() 
        {
            this.HasKey(t => new {t.idConta, t.idCliente});
            
            this.ToTable("[gestao_reembolso].[CONTA_CREDITO]");
            this.Property(t => t.idConta).HasColumnName("ID_CONTA");
            this.Property(t => t.idCliente).HasColumnName("ID_CLIENTE");
            this.Property(t => t.dataAtualizacao).HasColumnName("DT_ATUALIZACAO");
        }
    }
}
