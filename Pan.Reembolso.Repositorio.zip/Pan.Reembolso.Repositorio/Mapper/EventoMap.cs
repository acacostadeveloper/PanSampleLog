﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class EventoMap : DominioMap<Pan.Reembolso.Entidades.DatabaseEntities.EventoDatabase>
    {
        public EventoMap() 
        {
            this.HasKey(t => t.idEvento);
            this.Property(t => t.idEvento).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[EVENTO]");

            this.Property(t => t.idEvento).HasColumnName("ID_EVENTO");
            this.Property(t => t.codigoEvento).HasColumnName("CD_EVENTO");
            this.Property(t => t.eventoContabil).HasColumnName("IC_CONTABIL");
            this.Property(t => t.fluxo).HasColumnName("CD_FLUXO");
        }
    }
}
