﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContabilRemessaMap : EntityTypeConfiguration<Entidades.DatabaseEntities.ContabilRemessaDatabase>
    {
        public ContabilRemessaMap()
        {
            this.HasKey(t => t.idRemessa);
            this.Property(t => t.idRemessa).HasDatabaseGeneratedOption(DatabaseGeneratedOption.None);

            this.ToTable("[gestao_reembolso].[CONTABIL_REMESSA]");
            this.Property(t => t.idRemessa).HasColumnName("ID_REMESSA");
            this.Property(t => t.dataRemessa).HasColumnName("DT_REMESSA");
        }
    }
}