﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ProcessoRegistroMap : DominioMap<Pan.Reembolso.Entidades.DatabaseEntities.ProcessoRegistroDatabase>
    {
        public ProcessoRegistroMap() 
        {
            this.HasKey(t   => t.idProcessoRegistro);
            this.Property(t => t.idProcessoRegistro).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[PROCESSO_REGISTRO]");

            this.Property(t => t.idProcessoRegistro).HasColumnName("ID_PROCESSO_REGISTRO");
            this.Property(t => t.codigoProcessoRegistro).HasColumnName("CD_PROCESSO_REGISTRO");
            this.Property(t => t.descricaoProcesso).HasColumnName("DS_PROCESSO_REGISTRO");
            this.Property(t => t.codigoCentroCusto).HasColumnName("CD_CENTRO_CUSTO");
            this.Property(t => t.modeloContabil).HasColumnName("CD_MODELO_CONTABIL");
            this.Property(t => t.indicadorFluxo).HasColumnName("CD_FLUXO");
            this.Property(t => t.codigoContaDebito).HasColumnName("CD_CONTA_DEBITO");
            this.Property(t => t.codigoContaCredito).HasColumnName("CD_CONTA_CREDITO");
            this.Property(t => t.modeloContabilReversao).HasColumnName("CD_MODELO_CONTABIL_REVERSAO");
            this.Property(t => t.contaDebitoReversao).HasColumnName("CD_CONTA_DEBITO_REVERSAO");
            this.Property(t => t.contaCreditoReversao).HasColumnName("CD_CONTA_CREDITO_REVERSAO");
            this.Property(t => t.idEvento).HasColumnName("ID_EVENTO");
        }
    }
}
