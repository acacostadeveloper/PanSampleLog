﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContaRejeicaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ContaRejeicaoDatabase>
    {
        public ContaRejeicaoMap() 
        {
            this.HasKey(t => t.idConta);
            
            this.ToTable("[gestao_reembolso].[CONTA_REJEICAO]");
            this.Property(t => t.idConta).HasColumnName("ID_CONTA");
            this.Property(t => t.erro).HasColumnName("DS_ERRO");
            this.Property(t => t.ativo).HasColumnName("IC_ATIVO");
            this.Property(t => t.dataAtualizacao).HasColumnName("DT_ATUALIZACAO");
        }
    }
}
