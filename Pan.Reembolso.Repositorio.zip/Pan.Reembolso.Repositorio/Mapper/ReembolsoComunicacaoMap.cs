﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ReembolsoComunicacaoMap: EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ReembolsoComunicacaoDatabase>
    {
        public ReembolsoComunicacaoMap() 
        {


            this.HasKey(t => new { t.idComunicacao, t.idReembolso });

            this.ToTable("[gestao_reembolso].[REEMBOLSO_COMUNICACAO]");
            this.Property(t => t.idComunicacao).HasColumnName("ID_COMUNICACAO");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");

        }
    }
}
