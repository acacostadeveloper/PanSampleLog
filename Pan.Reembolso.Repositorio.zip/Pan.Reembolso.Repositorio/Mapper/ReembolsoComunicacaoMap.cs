﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ReembolsoComunicacaoMap: EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ReembolsoComunicacaoDatabase>
    {
        public ReembolsoComunicacaoMap() 
        {
            this.HasKey(t => t.idReembolso);
            this.HasKey(t => t.idComunicacao);

            this.ToTable("[gestao_reembolso].[REEMBOLSO_COMUNICACAO]");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");
            this.Property(t => t.idComunicacao).HasColumnName("ID_COMUNICACAO");
        }
    }
}
