﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContabilHistoricoMap : EntityTypeConfiguration<Entidades.DatabaseEntities.ContabilHistoricoDatabase>
    {
        public ContabilHistoricoMap()
        {

            this.HasKey(t => t.idContabilHistorico);
            this.Property(t => t.idContabilHistorico).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[CONTABIL_HISTORICO]");
            this.Property(t => t.idContabilHistorico).HasColumnName("ID_CONTABIL_HISTORICO");
            this.Property(t => t.idContabilPadrao).HasColumnName("ID_CONTABIL_PADRAO");
            this.Property(t => t.numeroRegistro).HasColumnName("NO_REGISTRO");
            this.Property(t => t.dataSistema).HasColumnName("DT_SISTEMA");
            this.Property(t => t.numeroRemessa).HasColumnName("NO_REMESSA");
            this.Property(t => t.numeroOrigem).HasColumnName("NO_ORIGEM");
            this.Property(t => t.numeroSequenciaOrigem).HasColumnName("NO_SEQUENCIA_ORIGEM");
            this.Property(t => t.dataLancamento).HasColumnName("DT_LANCAMENTO");
            this.Property(t => t.valorEntrada).HasColumnName("VL_ENTRADA");
            this.Property(t => t.descricaoHistorico).HasColumnName("DS_HISTORICO");
            this.Property(t => t.descricaoComplemento1).HasColumnName("DS_COMPLEMENTO1");
            this.Property(t => t.numeroModelo).HasColumnName("NO_MODELO");
            this.Property(t => t.numeroCentroCustoDebito).HasColumnName("NO_CENTRO_CUSTO_DEBITO");
            this.Property(t => t.numeroCentroCustoCredito).HasColumnName("NO_CENTRO_CUSTO_CREDITO");
            this.Property(t => t.dataDocumento).HasColumnName("DT_DOCUMENTO");
            this.Property(t => t.dataUltimaAtualizacao).HasColumnName("DT_ULTIMA_ATUALIZACAO");
            this.Property(t => t.codigoUsuario).HasColumnName("CD_USUARIO");
            this.Property(t => t.nomeArquivoIntegrado).HasColumnName("NM_ARQUIVO_INTEGRADO");
            this.Property(t => t.dataIntegracao).HasColumnName("DT_INTEGRACAO");
            this.Property(t => t.idHistoricoReembolso).HasColumnName("ID_HISTORICO_REEMBOLSO");
            this.Property(t => t.codigoStatusContabilidade).HasColumnName("CD_STATUS_CONTABILIDADE");
            this.Property(t => t.descricaoMensagemContabilidade).HasColumnName("DS_MENSAGEM_CONTABILIDADE");
        }
}
}
