﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MensagemPadraoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.MensagemPadraoDatabase>
    {
        public MensagemPadraoMap() 
        {
            this.HasKey(t => t.idMensagemPadrao);
            this.Property(t => t.idMensagemPadrao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[MENSAGEM_PADRAO]");
            this.Property(t => t.idMensagemPadrao).HasColumnName("ID_MENSAGEM_PADRAO");
            this.Property(t => t.idProduto).HasColumnName("ID_PRODUTO");
            this.Property(t => t.finalidadeSPB).HasColumnName("CD_FINALIDADE_SPB");
            this.Property(t => t.indicadorCreditaContaCorrente).HasColumnName("IC_CREDITA_CONTA_CORRENTE");
            this.Property(t => t.indicadorDebitaContaCorrente).HasColumnName("IC_DEBITA_CONTA_CORRENTE");
            this.Property(t => t.indicadorEmiteRecebe).HasColumnName("IC_EMITE_RECEBE");
            this.Property(t => t.indicadorMesmaTitularidade).HasColumnName("IC_MESMA_TITULARIDADE");
            this.Property(t => t.indicadorPrevisao).HasColumnName("IC_PREVISAO");
            this.Property(t => t.indicadorTransitaContaCorrente).HasColumnName("IC_TRANSITA_CONTA_CORRENTE");
            this.Property(t => t.numeroBordero).HasColumnName("NO_BORDERO");
            this.Property(t => t.tipoLiquidacao).HasColumnName("CD_TIPO_LIQUIDACAO");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.codigoFinalidade).HasColumnName("CD_FINALIDADE");
            this.Property(t => t.codigoEventoTesouraria).HasColumnName("CD_EVENTO_TESOURARIA");
            this.Property(t => t.codigoUsuarioCadastro).HasColumnName("CD_USUARIO_TESOURARIA");
        }
    }
}
