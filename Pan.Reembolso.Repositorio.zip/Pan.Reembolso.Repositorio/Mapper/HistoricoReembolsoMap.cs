﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class HistoricoReembolsoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.HistoricoReembolsoDatabase>
    {
        public HistoricoReembolsoMap()
        {
            this.HasKey(t => t.idHistoricoReembolso);
            this.Property(t => t.idHistoricoReembolso).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[HISTORICO_REEMBOLSO]");

            this.Property(t => t.idHistoricoReembolso).HasColumnName("ID_HISTORICO_REEMBOLSO");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");
            this.Property(t => t.idEvento).HasColumnName("ID_EVENTO");
            this.Property(t => t.dataEvento).HasColumnName("DT_EVENTO");
            this.Property(t => t.statusIni).HasColumnName("CD_STATUS_INICIO");
            this.Property(t => t.statusFim).HasColumnName("CD_STATUS_FIM");
            this.Property(t => t.statusUsuario).HasColumnName("CD_STATUS_USUARIO");
            this.Property(t => t.usuario).HasColumnName("CD_USUARIO_INCLUSAO");
            this.Property(t => t.statusContabil).HasColumnName("CD_STASTUS_CONTABIL");
            this.Property(t => t.idMotivoBloqueio).HasColumnName("ID_MOTIVO_BLOQUEIO");
            this.Property(t => t.justificativaStatus).HasColumnName("DS_JUSTIFICATIVA_STATUS");
            this.Property(t => t.processoRegistro).HasColumnName("CD_PROCESSO_REGISTRO");

        }
    }
}
