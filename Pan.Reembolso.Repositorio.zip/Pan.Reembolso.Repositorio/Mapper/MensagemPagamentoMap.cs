﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MensagemPagamentoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.MensagemPagamentoDatabase>
    {
        public MensagemPagamentoMap() 
        {
            this.HasKey(t => t.idPagamento);
            this.HasKey(t => t.idMensagem);

            this.ToTable("[gestao_reembolso].[MENSAGEM_PAGAMENTO]");
            this.Property(t => t.idPagamento).HasColumnName("ID_PAGAMENTO");
            this.Property(t => t.idMensagem).HasColumnName("ID_MENSAGEM");
        }
    }
}
