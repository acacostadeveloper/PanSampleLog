﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MotivoEntradaMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.MotivoEntradaDatabase>
    {
        public MotivoEntradaMap()
        {
            this.HasKey(t => t.idMotivoEntrada);
            this.Property(t => t.idMotivoEntrada).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[MOTIVO_ENTRADA]");
            this.Property(t => t.idMotivoEntrada).HasColumnName("ID_MOTIVO_ENTRADA");
            this.Property(t => t.descricaoMotivoEntrada).HasColumnName("DS_MOTIVO_ENTRADA");
            this.Property(t => t.tipoMotivoEntrada).HasColumnName("CD_TIPO_MOTIVO_ENTRADA");
            this.Property(t => t.idSigla).HasColumnName("ID_SIGLA");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
            this.Property(t => t.dtInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.dtAlteracao).HasColumnName("DT_ALTERACAO");
        }
    }
}
