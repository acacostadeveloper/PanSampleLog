﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ClienteMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ClienteDatabase>
    {
        public ClienteMap() 
        {
            this.HasKey(t   => t.idCliente);
            this.Property(t => t.idCliente).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[CLIENTE]");
            this.Property(t => t.idCliente).HasColumnName("ID_CLIENTE");
            this.Property(t => t.nomeCliente).HasColumnName("NM_CLIENTE");
            this.Property(t => t.tipoPessoa).HasColumnName("CD_TIPO_PESSOA");
            this.Property(t => t.cpfCnpj).HasColumnName("NO_CPF_CNPJ");
            this.Property(t => t.dddCelular).HasColumnName("NO_DDD_CELULAR");
            this.Property(t => t.numeroCelular).HasColumnName("NO_CELULAR");
            this.Property(t => t.dddFixo).HasColumnName("NO_DDD_FIXO");
            this.Property(t => t.numeroFixo).HasColumnName("NO_FIXO");
        }
    }
}
