﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContaMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ContaDatabase>
    {
        public ContaMap() 
        {
            this.HasKey(t   => t.idConta);
            this.Property(t => t.idConta).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[CONTA]");
            this.Property(t => t.idConta).HasColumnName("ID_CONTA");
            this.Property(t => t.tipoConta).HasColumnName("CD_TIPO_CONTA");
            this.Property(t => t.numeroBanco).HasColumnName("NO_BANCO");
            this.Property(t => t.numeroAgencia).HasColumnName("NO_AGENCIA");
            this.Property(t => t.digitoAgencia).HasColumnName("NO_DIGITO_AGENCIA");
            this.Property(t => t.numeroConta).HasColumnName("NO_CONTA");
            this.Property(t => t.digitoConta).HasColumnName("NO_DIGITO_CONTA");
        }
    }
}
