﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ReembolsoPagamentoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ReembolsoPagamentoDatabase>
    {
        public ReembolsoPagamentoMap() 
        {
            this.HasKey(t => t.idPagamento);
            this.HasKey(t => t.idReembolso);

            this.ToTable("[gestao_reembolso].[REEMBOLSO_PAGAMENTO]");
            this.Property(t => t.idPagamento).HasColumnName("ID_PAGAMENTO");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");
        }
    }
}
