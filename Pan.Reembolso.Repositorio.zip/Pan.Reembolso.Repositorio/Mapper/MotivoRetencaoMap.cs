﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MotivoRetencaoMap: DominioMap<Pan.Reembolso.Entidades.DatabaseEntities.MotivoRetencaoDatabase>
    {
        public MotivoRetencaoMap()
        {
            this.HasKey(t => t.idMotivoRetencao);
            this.Property(t => t.idMotivoRetencao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[MOTIVO_RETENCAO]");

            this.Property(t => t.idMotivoRetencao).HasColumnName("ID_MOTIVO_RETENCAO");
            this.Property(t => t.descricaoMotivoRetencao).HasColumnName("DS_MOTIVO_RETENCAO");
        }
    }
}
