﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MotivoBloqueioMap : EntityTypeConfiguration<Entidades.DatabaseEntities.MotivoBloqueioDatabase>
    {
        public MotivoBloqueioMap() 
        {
            this.HasKey(t => t.idMotivoBloqueio);
            this.Property(t => t.idMotivoBloqueio).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[MOTIVO_BLOQUEIO]");

            this.Property(t => t.idMotivoBloqueio).HasColumnName("ID_MOTIVO_BLOQUEIO");
            this.Property(t => t.descricaoMotivoBloqueio).HasColumnName("DS_MOTIVO_BLOQUEIO");
            this.Property(t => t.dtInclusao).HasColumnName("DT_INCLUSAO");


        }
    }
}
