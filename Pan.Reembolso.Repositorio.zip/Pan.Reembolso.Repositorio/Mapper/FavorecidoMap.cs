﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class FavorecidoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.FavorecidoDatabase>
    {
        public FavorecidoMap() 
        {
            this.HasKey(t   => t.idFavorecido);
            this.Property(t => t.idFavorecido).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[FAVORECIDO]");

            this.Property(t => t.idFavorecido).HasColumnName("ID_FAVORECIDO");
            this.Property(t => t.numeroCpfCnpj).HasColumnName("NO_CPF_CNPJ");
            this.Property(t => t.sequenciaCpfCnpj).HasColumnName("NO_SEQUENCIA");
            this.Property(t => t.tipoPesssoa).HasColumnName("CD_TIPO_PESSOA");
            this.Property(t => t.nome).HasColumnName("NM_CLIENTE");
            this.Property(t => t.idConta).HasColumnName("ID_CONTA");
        }
    }
}
