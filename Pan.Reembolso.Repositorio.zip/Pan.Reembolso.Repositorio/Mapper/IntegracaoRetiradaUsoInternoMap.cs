﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class IntegracaoRetiradaUsoInternoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.IntegracaoRetiradaUsoInternoDatabase>
    {
        public IntegracaoRetiradaUsoInternoMap()
        {
            this.HasKey(t => t.idIntegracao);
            this.Property(t => t.idIntegracao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[INTEGRACAO_RETIRADA_USO_INTERNO]");
            this.Property(t => t.idIntegracao).HasColumnName("ID_INTEGRACAO");
            this.Property(t => t.numeroCpfCnpj).HasColumnName("NO_CPF_CNPJ");
            this.Property(t => t.codigoProduto).HasColumnName("CD_PRODUTO");
            this.Property(t => t.valorRetirada).HasColumnName("VL_RETIRADA");
            this.Property(t => t.idPagamento).HasColumnName("ID_PAGAMENTO");
            this.Property(t => t.codigoLoteIntegracao).HasColumnName("CD_LOTE_INTEGRACAO");
            this.Property(t => t.codigoStatusIntegracao).HasColumnName("CD_STATUS_INTEGRACAO");
            this.Property(t => t.mensagemErro).HasColumnName("DS_MENSAGEM_ERRO");
            this.Property(t => t.usuarioInclusao).HasColumnName("CD_USUARIO_INCLUSAO");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.codigoProcessoRegistro).HasColumnName("CD_PROCESSO_REGISTRO");
        }
    }
}
