﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ComunicacaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ComunicacaoDatabase>
    {
        public ComunicacaoMap()
        {
            this.HasKey(t => t.idComunicacao);
            this.Property(t => t.idComunicacao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[COMUNICACAO]");
            this.Property(t => t.idComunicacao).HasColumnName("ID_COMUNICACAO");
            this.Property(t => t.idMensagemComunicacao).HasColumnName("ID_MENSAGEM_COMUNICACAO");
            this.Property(t => t.dataEnvio).HasColumnName("DT_ENVIO");
            this.Property(t => t.indicadorEfetivacao).HasColumnName("IC_EFETIVACAO");
            this.Property(t => t.protocolo).HasColumnName("CD_PROTOCOLO");
        }
    }
}
