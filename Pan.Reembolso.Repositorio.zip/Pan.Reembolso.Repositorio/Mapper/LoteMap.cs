﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class LoteMap : DominioMap<Pan.Reembolso.Entidades.DatabaseEntities.LoteDatabase>
    {
        public LoteMap() 
        {
            this.HasKey(t   => t.idLote);
            this.Property(t => t.idLote).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[LOTE_REEMBOLSO]");

            this.Property(t => t.idLote).HasColumnName("ID_LOTE");
            this.Property(t => t.lote).HasColumnName("DS_LOTE");
        }
    }
}
