﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class TransferenciaDireitoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.TransferenciaDireitoDatabase>
    {
        public TransferenciaDireitoMap() 
        {


            this.HasKey(t   => t.idTransferenciaDireito);
            this.Property(t => t.idTransferenciaDireito).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[TRANSFERENCIA_DIREITO]");
            this.Property(t => t.idTransferenciaDireito).HasColumnName("ID_TRANSFERENCIA_DIREITO");
            this.Property(t => t.idCliente).HasColumnName("ID_CLIENTE");
            this.Property(t => t.idConta).HasColumnName("ID_CONTA");
            this.Property(t => t.nomeTerceiro).HasColumnName("NM_TERCEIRO");
            this.Property(t => t.tipoPesssoa).HasColumnName("CD_TIPO_PESSOA");
            this.Property(t => t.dtInicioVigencia).HasColumnName("DT_INICIO_VIGENCIA");
            this.Property(t => t.dtFimVigencia).HasColumnName("DT_FIM_VIGENCIA");
            this.Property(t => t.numeroCpfCnpj).HasColumnName("NO_CPF_CNPJ");
            this.Property(t => t.sequenciaCpfCnpj).HasColumnName("NO_SEQUENCIA");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
            this.Property(t => t.usuarioInclusao).HasColumnName("CD_USUARIO_INCLUSAO");
            this.Property(t => t.documento).HasColumnName("CD_DOCUMENTO");
        }
    }
}
