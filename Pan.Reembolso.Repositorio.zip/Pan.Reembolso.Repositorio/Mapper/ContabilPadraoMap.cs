﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ContabilPadraoMap : EntityTypeConfiguration<Entidades.DatabaseEntities.ContabilPadraoDatabase>
    {
        public ContabilPadraoMap()
        {
            this.HasKey(t => t.idContabilPadrao);
            this.Property(t => t.idContabilPadrao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[CONTABIL_PADRAO]");
            this.Property(t => t.idContabilPadrao).HasColumnName("ID_CONTABIL_PADRAO");
            this.Property(t => t.idProduto).HasColumnName("ID_PRODUTO");
            this.Property(t => t.codigoProcesso).HasColumnName("CD_PROCESSO");
            this.Property(t => t.codigoLayout).HasColumnName("CD_LAYOUT");
            this.Property(t => t.codigoColigada).HasColumnName("CD_COLIGADA");
            this.Property(t => t.codigoSistema).HasColumnName("CD_SISTEMA");
            this.Property(t => t.numeroSequenciaOrigem).HasColumnName("NO_SEQUENCIA_ORIGEM");
            this.Property(t => t.codigoEmpresaOrigem).HasColumnName("CD_EMPRESA_ORIGEM");
            this.Property(t => t.codigoAgencia).HasColumnName("CD_AGENCIA");
            this.Property(t => t.codigoUnidade).HasColumnName("CD_UNIDADE");
            this.Property(t => t.codigoNivel1).HasColumnName("CD_NIVEL1");
            this.Property(t => t.codigoNivel2).HasColumnName("CD_NIVEL2");
            this.Property(t => t.codigoNivel3).HasColumnName("CD_NIVEL3");
            this.Property(t => t.codigoNivel4).HasColumnName("CD_NIVEL4");
            this.Property(t => t.codigoCreditaDebita).HasColumnName("CD_DEBITA_CREDITA");
            this.Property(t => t.codigoAgenciaDestino).HasColumnName("CD_AGENCIA_DESTINO");
            this.Property(t => t.codigoNivel1Destino).HasColumnName("CD_NIVEL1_DESTINO");
            this.Property(t => t.codigoNivel2Destino).HasColumnName("CD_NIVEL2_DESTINO");
            this.Property(t => t.codigoNivel3Destino).HasColumnName("CD_NIVEL3_DESTINO");
            this.Property(t => t.codigoNivel4Destino).HasColumnName("CD_NIVEL4_DESTINO");
            this.Property(t => t.codigoUnidadeDestino).HasColumnName("CD_UNIDADE_DESTINO");
            this.Property(t => t.descricaoComplemento2).HasColumnName("DS_COMPLEMENTO2");
            this.Property(t => t.descricaoComplemento3).HasColumnName("DS_COMPLEMENTO3");
            this.Property(t => t.descricaoComplemento4).HasColumnName("DS_COMPLEMENTO4");
            this.Property(t => t.descricaoComplemento5).HasColumnName("DS_COMPLEMENTO5");
            this.Property(t => t.codigoFormaLancamento).HasColumnName("CD_FORMA_LANCAMENTO");
            this.Property(t => t.codigoTipoLancamento).HasColumnName("CD_TIPO_LANCAMENTO");
            this.Property(t => t.codigoEvento).HasColumnName("CD_EVENTO");
            this.Property(t => t.numeroSequenciaItem).HasColumnName("NO_SEQUENCIA_ITEM");
            this.Property(t => t.nomeTabelaDebito).HasColumnName("NM_TABELA_DEBITO");
            this.Property(t => t.codigoProdutoDebito).HasColumnName("CD_PRODUTO_DEBITO");
            this.Property(t => t.codigoTipoCreditoDebito).HasColumnName("CD_TIPO_CREDITO_DEBITO");
            this.Property(t => t.codigoAtividadeDebito).HasColumnName("CD_ATIVIDADE_DEBITO");
            this.Property(t => t.codigoTipoContaDebito).HasColumnName("CD_TIPO_CONTA_DEBITO");
            this.Property(t => t.numeroContaDebito).HasColumnName("NO_CONTA_DEBITO");
            this.Property(t => t.codigoReduzidoDebito).HasColumnName("CD_REDUZIDO_DEBITO");
            this.Property(t => t.numeroContaAuxiliarDebito).HasColumnName("NO_CONTA_AUXILIAR_DEBITO");
            this.Property(t => t.numeroContaCorrenteDebito).HasColumnName("NO_CONTA_CORRENTE_DEBITO");
            this.Property(t => t.nomeTabelaCredito).HasColumnName("NM_TABELA_CREDITO");
            this.Property(t => t.codigoProdutoCredito).HasColumnName("CD_PRODUTO_CREDITO");
            this.Property(t => t.codigoTipoCreditoCredito).HasColumnName("CD_TIPO_CREDITO_CREDITO");
            this.Property(t => t.codigoAtividadeCredito).HasColumnName("CD_ATIVIDADE_CREDITO");
            this.Property(t => t.codigoTipoContaCredito).HasColumnName("CD_TIPO_CONTA_CREDITO");
            this.Property(t => t.numeroContaCredito).HasColumnName("NO_CONTA_CREDITO");
            this.Property(t => t.codigoReduzidoCredito).HasColumnName("CD_REDUZIDO_CREDITO");
            this.Property(t => t.numeroContaAuxiliarCredito).HasColumnName("NO_CONTA_AUXILIAR_CREDITO");
            this.Property(t => t.numeroContaCorrenteCredito).HasColumnName("NO_CONTA_CORRENTE_CREDITO");
            this.Property(t => t.codigoTipoMoeda).HasColumnName("CD_TIPO_MOEDA");
            this.Property(t => t.quantidadeMoeda).HasColumnName("QT_MOEDA");
            this.Property(t => t.valorMoeda).HasColumnName("VL_MOEDA");
            this.Property(t => t.indicadorReprocessamento).HasColumnName("IC_REPROCESSAMENTO");
            this.Property(t => t.codigoGerente).HasColumnName("CD_GERENTE");
            this.Property(t => t.numeroDocumento).HasColumnName("NO_DOCUMENTO");
            this.Property(t => t.indicadorAtualizado).HasColumnName("IC_ATUALIZADO");
            this.Property(t => t.indicadorCancelado).HasColumnName("IC_CANCELADO");
            this.Property(t => t.indicadorEstornado).HasColumnName("IC_ESTORNADO");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
        }

}
}
