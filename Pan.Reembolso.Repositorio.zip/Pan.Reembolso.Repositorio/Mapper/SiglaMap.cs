﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class SiglaMap : DominioMap<Pan.Reembolso.Entidades.DatabaseEntities.SiglaDatabase>
    {
        public SiglaMap() 
        {
            this.HasKey(t   => t.idSigla);
            this.Property(t => t.idSigla).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[SIGLA]");

            this.Property(t => t.idSigla).HasColumnName("ID_SIGLA");
            this.Property(t => t.codigoSigla).HasColumnName("CD_SIGLA");
            this.Property(t => t.descricaoSigla).HasColumnName("DS_SIGLA");
        }
    }
}
