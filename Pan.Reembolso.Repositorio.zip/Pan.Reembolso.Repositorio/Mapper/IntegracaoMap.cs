﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class IntegracaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.IntegracaoDatabase>
    {
        public IntegracaoMap()
        {
            this.HasKey(t => t.idIntegracao);
            this.Property(t => t.idIntegracao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[REEMBOLSO_INTEGRACAO]");
            this.Property(t => t.idIntegracao).HasColumnName("ID_INTEGRACAO");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");
            this.Property(t => t.idLoteReembolso).HasColumnName("ID_LOTE_REEMBOLSO");
            this.Property(t => t.idLoteIntegracao).HasColumnName("ID_LOTE_INTEGRACAO");
            this.Property(t => t.status).HasColumnName("CD_STATUS_INTEGRACAO");
            this.Property(t => t.mensagemErro).HasColumnName("DS_MENSAGEM_ERRO");
            this.Property(t => t.dataIntegracao).HasColumnName("DT_INTEGRACAO");
            this.Property(t => t.cliente).HasColumnName("NM_CLIENTE");
            this.Property(t => t.contrato).HasColumnName("NO_CONTRATO");
            this.Property(t => t.valorReembolso).HasColumnName("VL_REEMBOLSO");
            this.Property(t => t.convenio).HasColumnName("NM_CONVENIO");
            this.Property(t => t.matricula).HasColumnName("CD_MATRICULA");
            this.Property(t => t.cpfCnpj).HasColumnName("NO_CPF_CNPJ");
            this.Property(t => t.mesCompetencia).HasColumnName("NO_MES_COMPETENCIA");
            this.Property(t => t.anoCompetencia).HasColumnName("NO_ANO_COMPETENCIA");
            this.Property(t => t.sigla).HasColumnName("CD_SIGLA");
            this.Property(t => t.processoEntrada).HasColumnName("CD_PROCESSO_ENTRADA");
            this.Property(t => t.produto).HasColumnName("CD_PRODUTO");
            this.Property(t => t.usuarioInclusao).HasColumnName("CD_USUARIO_INCLUSAO");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
        }
    }
}
