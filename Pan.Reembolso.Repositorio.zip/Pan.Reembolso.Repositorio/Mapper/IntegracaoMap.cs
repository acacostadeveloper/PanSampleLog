﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class IntegracaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.IntegracaoDatabase>
    {
        public IntegracaoMap() 
        {
            this.HasKey(t   => t.idIntegracao);
            this.Property(t => t.idIntegracao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[REEMBOLSO_INTEGRACAO]");
            this.Property(t => t.idIntegracao).HasColumnName("ID_INTEGRACAO");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");
            this.Property(t => t.idLote).HasColumnName("ID_LOTE");
            this.Property(t => t.idCliente).HasColumnName("ID_CLIENTE");
            this.Property(t => t.idContrato).HasColumnName("ID_CONTRATO");
            this.Property(t => t.valorReembolso).HasColumnName("VL_REEMBOLSO");
            this.Property(t => t.convenio).HasColumnName("CD_CONVENIO");
            this.Property(t => t.matricula).HasColumnName("CD_MATRICULA");
            this.Property(t => t.cpfCnpj).HasColumnName("NO_CPF_CNPJ");
            this.Property(t => t.mesCompetencia).HasColumnName("MES_COMPETENCIA");
            this.Property(t => t.sigla).HasColumnName("DS_SIGLA");
            this.Property(t => t.idProcesso).HasColumnName("CD_PROCESSO");
            this.Property(t => t.idProduto).HasColumnName("CD_PRODUTO");
            this.Property(t => t.status).HasColumnName("CD_STATUS_INTEGRACAO");
            this.Property(t => t.codigoUsuarioInclusao).HasColumnName("CD_USUARIO_INCLUSAO");
            this.Property(t => t.dataEnvio).HasColumnName("DT_ENVIO");
            this.Property(t => t.dataIntegracao).HasColumnName("DT_INTEGRACAO");
        }
    }
}
