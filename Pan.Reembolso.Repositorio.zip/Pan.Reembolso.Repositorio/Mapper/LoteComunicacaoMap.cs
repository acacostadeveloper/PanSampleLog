﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class LoteComunicacaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.LoteComunicacaoDatabase>
    {
        public LoteComunicacaoMap() 
        {
            this.HasKey(t   => t.idLoteComunicacao);
            this.Property(t => t.idLoteComunicacao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[LOTE_COMUNICACAO]");

            this.Property(t => t.idLoteComunicacao).HasColumnName("ID_LOTE");
            this.Property(t => t.dtInclusao).HasColumnName("DT_INCLUSAO");
        }
    }
}
