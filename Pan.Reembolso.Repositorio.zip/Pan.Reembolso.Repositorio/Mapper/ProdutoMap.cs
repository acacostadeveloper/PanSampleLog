﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ProdutoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ProdutoDatabase>
    {
        public ProdutoMap() 
        {
            this.HasKey(t   => t.idProduto);
            this.Property(t => t.idProduto).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[PRODUTO]");
            this.Property(t => t.idProduto).HasColumnName("ID_PRODUTO");
            this.Property(t => t.codigoProduto).HasColumnName("CD_PRODUTO");
            this.Property(t => t.nomeProduto).HasColumnName("NM_PRODUTO");
            this.Property(t => t.codigoCarteira).HasColumnName("CD_CARTEIRA");
            this.Property(t => t.idSistema).HasColumnName("ID_SISTEMA");
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.dataAlteracao).HasColumnName("DT_ALTERACAO");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
        }
    }
}
