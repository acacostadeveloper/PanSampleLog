﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class LoteIntegracaoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.LoteIntegracaoDatabase>
    {
        public LoteIntegracaoMap() 
        {
            this.HasKey(t   => t.idLoteIntegracao);
            this.Property(t => t.idLoteIntegracao).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[LOTE_INTEGRACAO]");

            this.Property(t => t.idLoteIntegracao).HasColumnName("ID_LOTE_INTEGRACAO");
            this.Property(t => t.dtInclusao).HasColumnName("DT_INCLUSAO");
        }
    }
}
