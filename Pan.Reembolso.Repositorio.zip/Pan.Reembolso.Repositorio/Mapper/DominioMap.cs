﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public abstract class DominioMap<TDominio> : EntityTypeConfiguration<TDominio> where TDominio : Pan.Reembolso.Entidades.DatabaseEntities.DominioDatabase
    {
        public DominioMap() 
        {
            this.Property(t => t.dataInclusao).HasColumnName("DT_INCLUSAO");
            this.Property(t => t.dataAlteracao).HasColumnName("DT_ALTERACAO");
            this.Property(t => t.indicadorAtivo).HasColumnName("IC_ATIVO");
        }
    }
}
