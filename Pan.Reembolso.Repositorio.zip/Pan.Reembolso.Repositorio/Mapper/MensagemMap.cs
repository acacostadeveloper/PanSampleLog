﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class MensagemMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.MensagemTransferenciaDatabase>
    {
        public MensagemMap() 
        {
            this.HasKey(t => t.idMensagem);
            this.Property(t => t.idMensagem).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[MENSAGEM]");
            this.Property(t => t.idMensagem).HasColumnName("ID_MENSAGEM");
            this.Property(t => t.idMensagemPadrao).HasColumnName("ID_MENSAGEM_PADRAO");
            this.Property(t => t.numeroRequisicao).HasColumnName("NO_REQUISICAO");
            this.Property(t => t.dataRegistro).HasColumnName("DT_REGISTRO");
            this.Property(t => t.dataLiquidacao).HasColumnName("DT_LIQUIDACAO");
            this.Property(t => t.statusMensagem).HasColumnName("CD_STATUS_MENSAGEM");
            this.Property(t => t.idContaReserva).HasColumnName("ID_CONTA_RESERVA");
            this.Property(t => t.idContaCredito).HasColumnName("ID_CONTA_CREDITO");
        }
    }
}
