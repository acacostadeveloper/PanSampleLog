﻿using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class ReembolsoMap : EntityTypeConfiguration<Pan.Reembolso.Entidades.DatabaseEntities.ReembolsoDatabase>
    {
        public ReembolsoMap() 
        {
            this.HasKey(t => t.idReembolso);
            this.Property(t => t.idReembolso).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[REEMBOLSO]");
            this.Property(t => t.idReembolso).HasColumnName("ID_REEMBOLSO");
            this.Property(t => t.idLote).HasColumnName("ID_LOTE_REEMBOLSO");
            this.Property(t => t.codigoUsuarioInclusao).HasColumnName("CD_USUARIO_INCLUSAO");
            this.Property(t => t.codigoUsuarioAlteracao).HasColumnName("CD_USUARIO_ALTERACAO");
            this.Property(t => t.codigoUsuarioAprovacao).HasColumnName("CD_USUARIO_APROVACAO");
            this.Property(t => t.idDepartamento).HasColumnName("ID_DEPARTAMENTO");
            this.Property(t => t.idContrato).HasColumnName("ID_CONTRATO");
            this.Property(t => t.codigoEvento).HasColumnName("CD_EVENTO");
            this.Property(t => t.dataSolicitacao).HasColumnName("DT_SOLICITACAO");
            this.Property(t => t.statusReembolso).HasColumnName("CD_STATUS_REEMBOLSO");
            this.Property(t => t.valorReembolso).HasColumnName("VL_REEMBOLSO");
            this.Property(t => t.idSigla).HasColumnName("ID_SIGLA");
            this.Property(t => t.idProcessoRegistro).HasColumnName("ID_PROCESSO_REGISTRO");
            //this.Property(t => t.mesCompetencia).HasColumnName("MES_COMPETENCIA");
            //this.Property(t => t.anoCompetencia).HasColumnName("ANO_COMPETENCIA");
        }
    }
}
