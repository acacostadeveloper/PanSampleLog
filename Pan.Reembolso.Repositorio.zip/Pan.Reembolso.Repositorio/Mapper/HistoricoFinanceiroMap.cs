﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Pan.Reembolso.Repositorio.Mapper
{
    public class HistoricoFinanceiroMap : DominioMap<Pan.Reembolso.Entidades.DatabaseEntities.HistoricoFinanceiroDatabase>
    {
        public HistoricoFinanceiroMap()
        {
            this.HasKey(t => t.idHistoricoFinanceiro);
            this.Property(t => t.idHistoricoFinanceiro).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);

            this.ToTable("[gestao_reembolso].[HISTORICO_FINANCEIRO]");

            this.Property(t => t.idHistoricoFinanceiro).HasColumnName("ID_HISTORICO_FINANCEIRO");
            this.Property(t => t.motivo).HasColumnName("DS_MOTIVO");
            this.Property(t => t.origemInformacao).HasColumnName("DS_ORIGEM_INFORMACAO");
            this.Property(t => t.codigoHistoricoFinanceiro).HasColumnName("CD_HISTORICO_FINANCEIRO");
        }

    }
}
