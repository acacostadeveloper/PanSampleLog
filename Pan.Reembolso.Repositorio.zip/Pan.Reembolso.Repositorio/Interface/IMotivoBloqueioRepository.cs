﻿using Pan.Reembolso.Entidades;
using System.Collections.Generic;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IMotivoBloqueioRepository
    {
        MotivoBloqueio ObterMotivoBloqueio(MotivoBloqueioType? motivoBloqueio = MotivoBloqueioType.Undefined);
        MotivoBloqueio ObterMotivoBloqueio(int? motivoBloqueio);
        IList<MotivoBloqueio> ObterMotivoBloqueio();
    }
}