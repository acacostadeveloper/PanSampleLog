﻿using Pan.Reembolso.Entidades;
using System.Collections.Generic;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface ISiglaRepository
    {
        Sigla ObterSiglaPorCodigo(string codigoSigla);
        Sigla ObterSiglaPorIdReembolso(int idReembolso);
        IEnumerable<Sigla> ObterSiglas();
    }
}
