﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface ISiglaRepository
    {
        Sigla ObterSiglaPorCodigo(string codigoSigla);
        Sigla ObterSiglaPorIdReembolso(int idReembolso);
    }
}
