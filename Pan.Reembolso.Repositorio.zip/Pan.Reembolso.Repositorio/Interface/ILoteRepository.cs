﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface ILoteRepository
    {
        Lote ObterLotePorIdReembolso(long idReembolso);
    }
}