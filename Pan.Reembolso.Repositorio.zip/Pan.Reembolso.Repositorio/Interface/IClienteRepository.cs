﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IClienteRepository
    {
        Cliente ObterCliente(string cpfCnpj);
        Cliente ObterClientePorNumeroContrato(string numeroContrato);
        int PersistirCliente(Cliente cliente);
        List<Object> ConsultarClientesParaManutencaoDadosBancarios();
    }
}
