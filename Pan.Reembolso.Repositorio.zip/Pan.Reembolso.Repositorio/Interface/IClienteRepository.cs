﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IClienteRepository
    {
        Task<List<Entidades.Cliente>> ConsultarClientesPorFiltro(Filters.ReembolsoFilter filter);
        Cliente ObterCliente(string cpfCnpj);
        int ObterIdCliente(string cpfCnpj);
        Cliente ObterClientePorNumeroContrato(string numeroContrato);
        int PersistirCliente(Cliente cliente);
        Task<List<Object>> ConsultarClientesParaManutencaoDadosBancariosPorFiltro(Filters.ReembolsoFilter filter);
        Task<List<Object>> ConsultarClientesParaManutencaoDadosBancariosFlat(string numeroCpfCnpj, string nomeCliente);
        List<ClienteReembolsos> ConsultarClientesASeremComunicados();
        List<ClienteReembolsos> ObterClientesSMSErro();
    }
}
