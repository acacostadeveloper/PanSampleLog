﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IEventoRepository
    {
        Evento ObterEvento(string codigoEvento);
        Evento ObterEventoPorId(int idEvento);
        Evento ObterEventoPorProcessoRegistro(int codigoProcessoRegistro);
        Evento ObterEventoPorProcessoRegistroInclusao(int codigoProcessoRegistro);
        Evento ObterEventoPorProcessoRegistroEstorno(int codigoProcessoRegistro);

    }
}