﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IEventoRepository
    {
        Evento ObterEventoObterEventoPorOperacao(string operacao);
    }
}