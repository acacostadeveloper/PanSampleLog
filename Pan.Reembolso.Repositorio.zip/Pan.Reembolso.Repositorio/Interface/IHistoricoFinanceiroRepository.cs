﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IHistoricoFinanceiroRepository
    {
        HistoricoFinanceiro ObterHistoricoFinanceiroPorCodigoOrigem(int codigoHistoricoFinanceiro, string origemHistoricoFinanceiro);
        HistoricoFinanceiro ObterHistoricoFinanceiroPorIdContrato(int idContrato);
    }
}
