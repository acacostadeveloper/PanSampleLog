﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IContaCreditoRepository
    {
        void IncluirContaCredito(ContaCredito contaCredito, int idCliente);
        ContaCredito ObterContaCreditoPorCpfCliente(string cpfCliente);
        ContaCredito ObterContaCreditoPorNumeroRequisicao(string numeroRequisicao);
        ContaCredito ObtertContaCreditoPorIdCliente(int idCliente);
        void PersistirContaCredito(ContaCredito contaCredito, int idCliente);
    }
}