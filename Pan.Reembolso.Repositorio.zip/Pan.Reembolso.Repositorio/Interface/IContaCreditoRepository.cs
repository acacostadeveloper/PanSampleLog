﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IContaCreditoRepository
    {
        void IncluirContaCredito(ContaCredito contaCredito, int idCliente);
        ContaCredito ObterContaCreditoPorCpfCliente(string cpfCliente);
        int ObterIdContaCreditoPorCpfCliente(string cpfCliente);
        ContaCredito ObtertContaCreditoPorIdCliente(int idCliente);
        Entidades.DatabaseEntities.ContaDatabase IncluirConta(Entidades.ContaCredito contaCredito);
        void PersistirContaCredito(ContaCredito contaCredito, int idCliente);
        ContaCredito ObterConta(int idConta);
    }
}