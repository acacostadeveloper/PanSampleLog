﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IFavorecidoRepository
    {
        Favorecido ObterFavorecidoPorId(int idFavorecido);
        Favorecido ObterFavorecidoPorIdPagamento(Pagamento pagamento);
        int PersistirFavorecido(Entidades.Favorecido favorecido);
    }
}