﻿using System;
using System.Collections.Generic;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface ITransferenciaDireitoRepository
    {
        int PersistirTransferenciaDireito(int idConta, string numeroCpfCnpjCliente, Entidades.Cliente terceiro, DateTime dtInicioVigencia, DateTime? dtFimVigencia, string usuarioInclusao, string documento);
        TransferenciaDireito ObterTransferenciaDireitoAtivoPorCpfCliente(string numeroCpfCnpjCliente);
        IEnumerable<TransferenciaDireito> ObterTransferenciaDireitoPorCpfCliente(string numeroCpfCnpjCliente);
    }
}