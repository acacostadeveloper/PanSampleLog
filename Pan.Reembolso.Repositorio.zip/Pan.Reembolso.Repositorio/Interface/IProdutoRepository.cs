﻿using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IProdutoRepository
    {
        Pan.Reembolso.Entidades.Produto ObterProdutoPorNumeroContrato(string numeroContrato);
        Pan.Reembolso.Entidades.Produto ObterProdutoPorCodigo(string codigoProduto);
        IEnumerable<Entidades.Produto> ObterProdutos();
    }
}
