﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IMensagemRepository
    {
        MensagemTransferencia ObterMensagemPadrao();
        void PersistirMensagem(Pagamento value);
    }
}
