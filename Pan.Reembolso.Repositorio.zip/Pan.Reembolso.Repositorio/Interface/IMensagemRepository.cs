﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IMensagemRepository
    {
        MensagemTransferencia ObterMensagemPadrao();
        void PersistirMensagem(MensagemTransferencia value, long idPagamento);
        IList<MensagemTransferencia> ObterMensagemPorStatus(ReembolsoTypes.StatusMensagemTransferenciaType statusMensagem);
        void AtualizarMensagem(MensagemTransferencia value);
        IList<Object> ObterHistoricoPorIdReembolso(long idReembolso);
    }
}
