﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IContabilRepository
    {
        Entidades.MovimentoContabilPadrao ObterMovimentoContabilPadrao(string codigoProduto);
        int GetNextRemessa();
        void SaveRemessa(int id);
        void IncluirHistoricoContabil(Entidades.MovimentoContabil value, IDictionary<string, string> integrationReturn);

    }
}
