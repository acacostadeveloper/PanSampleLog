﻿using System;
using System.Collections.Generic;
using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IMotivoRetencaoRepository
    {
        IEnumerable<MotivoRetencao> ObterMotivosRetencao();
    }
}
