﻿using Pan.Reembolso.Entidades;
using System.Collections.Generic;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IProcessoRegistroRepository
    {
        ProcessoRegistro ObterProcessoRegistroPorCodigoFluxo(int? codigoProcessoRegistro, string indicadorFluxo);
        ProcessoRegistro ObterProcessoRegistroPorIdReembolso(long idReembolso);
        IEnumerable<Entidades.ProcessoRegistro> ObterProcessoRegistro(string fluxo);

        //ProcessoRegistro ObterProcessoRegistroPorCodigoEntrada(int codigoProcessoRegistro);
        //ProcessoRegistro ObterProcessoRegistroPorCodigoSaida(int codigoProcessoRegistro);
    }
}
