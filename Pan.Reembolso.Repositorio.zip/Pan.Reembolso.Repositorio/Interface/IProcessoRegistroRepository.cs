﻿using Pan.Reembolso.Entidades;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IProcessoRegistroRepository
    {
        ProcessoRegistro ObterProcessoRegistroPorCodigoFluxo(int codigoProcessoRegistro, string indicadorFluxo);
        ProcessoRegistro ObterProcessoRegistroPorIdReembolso(long idReembolso);
        ProcessoRegistro ObterProcessoRegistroPorCodigoEntrada(int codigoProcessoRegistro);
        ProcessoRegistro ObterProcessoRegistroPorCodigoSaida(int codigoProcessoRegistro);
    }
}
