﻿using Pan.Reembolso.Entidades;
using System.Collections.Generic;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IHistoricoReembolsoRepository
    {
        IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(long idReembolso);

        HistoricoReembolso PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso);
        IList<HistoricoReembolso> ObterContabilReembolso();
        void AtualizarHistoricoContabilizado(HistoricoReembolso historicoReembolso);

    }
}
