﻿using Pan.Reembolso.Entidades;
using System.Collections.Generic;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IHistoricoReembolsoRepository
    {
        IEnumerable<HistoricoReembolso> ObterHistoricoReembolsoPorIdReembolso(int idReembolso);

        Pan.Reembolso.Entidades.HistoricoReembolso PersistirHistoricoReembolso(HistoricoReembolso historicoReembolso);
    }
}
