﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IIntegracaoRepository
    {
        IEnumerable<Integracao> ObterIntegracaoPorStatus(ReembolsoTypes.StatusIntegracaoType status);
        //Task<bool> PersistirIntegracaoBulk(IDataReader integracoesReader);
        DataTable ObterIntegracaoDataTable();
        Task<bool> PersistirIntegracaoBulk(StreamReader integracoesReader);
        Task<bool> PersistirIntegracaoBulk(DataTable integracoesTable);
        Integracao PersistirIntegracao(Integracao integracao);
        IQueryable<Integracao> ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, int mesCompetencia);
        IQueryable<Integracao> ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, int mesCompetencia);
    }
}
