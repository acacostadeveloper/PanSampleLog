﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IIntegracaoRepository
    {
        IEnumerable<Entidades.Integracao> ObterIntegracaoPorStatus(StatusIntegracaoType status, int loteIntegracao);
        DataTable ObterIntegracaoDataTable();
        Task<int> PersistirIntegracaoBulk(DataTable integracoesTable);
        Integracao AtualizarIntegracao(Integracao integracao);
        IQueryable<Integracao> ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, int mesCompetencia);
        IQueryable<Integracao> ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, int mesCompetencia);
        List<Integracao> ConsultarReembolsoIntegracaoPorLoteIntegracao(int idLoteIntegracao);
        int GerarNovoLoteIntegracao();
    }
}
