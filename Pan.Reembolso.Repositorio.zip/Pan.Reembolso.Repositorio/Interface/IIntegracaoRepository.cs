﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IIntegracaoRepository
    {
        IEnumerable<Integracao> ObterIntegracaoPorStatus(ReembolsoTypes.StatusIntegracaoType status, string loteIntegracao);
        DataTable ObterIntegracaoDataTable();
        Task<string> PersistirIntegracaoBulk(DataTable integracoesTable);
        Integracao AtualizarIntegracao(Integracao integracao);
        IQueryable<Integracao> ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, int mesCompetencia);
        IQueryable<Integracao> ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, int mesCompetencia);
    }
}
