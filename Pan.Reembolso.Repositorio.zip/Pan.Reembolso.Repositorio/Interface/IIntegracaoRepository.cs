﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IIntegracaoRepository
    {
        IEnumerable<Integracao> ObterIntegracaoPorStatus(ReembolsoTypes.StatusIntegracao status);
        Task<bool> PersistirIntegracaoBulk(IDataReader integracoesReader);
        Integracao PersistirIntegracao(Integracao integracao);
        IEnumerable<Integracao> ObterIntegracaoPorCpfCnPj(string cpfCnpj, decimal valorReembolso, string mesCompetencia);
        IEnumerable<Integracao> ObterIntegracaoPorContrato(string contrato, decimal valorReembolso, string mesCompetencia);
    }
}
