﻿using Pan.Reembolso.Entidades.ImplementationTypes;
using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IReembolsoRepository
    {
        Entidades.Reembolso ObterReembolso(long id);
        Entidades.Reembolso ObterReembolsoPorIdContrato(string codigoContrato);
        IEnumerable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia);
        IList<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        //Entidades.Reembolso ObterDetalhes(int idReembolso);
        void PersistirReembolso(Entidades.Reembolso values, string guidLote, string indicadorFluxo = ReembolsoConstantes.FLUXO_ENTRADA);
        void ExcluirReembolso(List<long> idsAEstornar);
        Object ConsultarPagamentosPorStatus(DateTime? dtInicial, DateTime? dtFinal, StatusReembolsoType statusReembolso);
        Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        void AtualizarStatusReembolso(long idReembolso, StatusReembolsoType status, string mensagemErro = "", string userAlteracao = "usuarioReembolso", string aprovador = "");
        decimal ObterValorTotalDeReembolsos(List<long> idsReembolsos);
        List<Entidades.Reembolso> ObterListaReembolso(List<long> idsReembolsos);
        IList<long> ObterIdsReembolsoPorFiltro(ReembolsoFilter filter);
        Object ConsultarPagamentosARealizar(DateTime? dtInicial, DateTime? dtFinal);
        IEnumerable<Entidades.Reembolso> ObterReembolsosPorIdPagamento(Entidades.Pagamento pagamento);
        List<Entidades.Reembolso> ObterReembolsoList(long id);
    }
}
