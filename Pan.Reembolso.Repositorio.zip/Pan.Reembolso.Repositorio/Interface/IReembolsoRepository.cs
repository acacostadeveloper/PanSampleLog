﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IReembolsoRepository
    {
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(int id);
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(string codigoContrato);
        void PersistirReembolso(Pan.Reembolso.Entidades.Reembolso values, string idLote);
        void ExcluirReembolso(int id);
    }
}
