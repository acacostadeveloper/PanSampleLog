﻿using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IReembolsoRepository
    {
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(long id);
        Pan.Reembolso.Entidades.Reembolso ObterReembolsoPorIdContrato(string codigoContrato);
        IEnumerable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia);
        IList<Object> ConsultarInformacoesReembolso(ReembolsoFilter filter);
        //Entidades.Reembolso ObterDetalhes(int idReembolso);
        void PersistirReembolso(Pan.Reembolso.Entidades.Reembolso values, string idLote);
        void ExcluirReembolso(List<long> idsAEstornar);
        Object ConsultarPagamentosARealizar(DateTime? dtInicial, DateTime? dtFinal);
        Object ConsultarHistoricoPagamentos(DateTime? dtInicial = null);
        void AtualizarStatusReembolso(long idReembolso, StatusReembolsoType status, string mensagemErro = "", string userAlteracao = "usuarioReembolso", string aprovador = "");
    }
}
