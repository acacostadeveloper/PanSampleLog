﻿using Pan.Reembolso.Repositorio.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IReembolsoRepository
    {
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(int id);
        Pan.Reembolso.Entidades.Reembolso ObterReembolso(string codigoContrato);
        IList<Entidades.Reembolso> ObterReembolsos(ReembolsoFilter filter);
        void PersistirReembolso(Pan.Reembolso.Entidades.Reembolso values, string idLote);
        IEnumerable<Entidades.Reembolso> ObterReembolsoPorContrato(string codigoContrato, decimal valorReembolso, int mesCompetencia);
        void ExcluirReembolso(List<int> idsAEstornar);
    }
}
