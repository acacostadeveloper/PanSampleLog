﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IComunicacaoRepository
    {
        Entidades.Comunicacao ObterUltimaComunicacao(List<long> idsReembolsos);
        void IncluirComunicacao(Entidades.Comunicacao comunicacao, List<Entidades.Reembolso> reembolsos);
        void AtualizarComunicacao(Entidades.Comunicacao comunicacao);
        Entidades.Comunicacao ObterComunicacao(int identificador);
        Entidades.MensagemComunicacao ObterMensagemComunicacao(Entidades.ImplementationTypes.ReembolsoTypes.ComunicacaoType type);
        List<Entidades.Comunicacao> ObterSMSEnviados();
    }
}
