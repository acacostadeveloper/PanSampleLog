﻿using System.Collections.Generic;
using System.Linq;
using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.ImplementationTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IContaRejeicaoRepository
    {
        List<ContaRejeicao> ObterBlackListReembolso();
        void PersistirContaRejeicao(ContaCredito contaCredito, ReembolsoTypes.ErroContaCreditoType erroContaCredito);
        void RemoverBlackList(ContaCredito contaCredito);
    }
}