﻿using Pan.Reembolso.Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IContratoRepository
    {
        void ExcluirContrato(int id);
        IEnumerable<Contrato> ObterContrato();
        Contrato ObterContrato(int id);
        Contrato ObterContrato(string codigoContrato);
        Contrato ObterContratoPorIdReembolso(long idReembolso);
        int PersistirContrato(Contrato values);
    }
}
