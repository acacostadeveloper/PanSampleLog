﻿using Pan.Reembolso.Entidades.DatabaseEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IPagamentoRepository
    {
        PagamentoDatabase ObterPagamentoAbertoPorCPF(string cpfOuCnpj);
        int AtualizarPagamento(PagamentoDatabase pagamentoDB, decimal valor);
        int IncluirPagamento(decimal valor, string contrato);
        void IncluirPagamentoReembolsosDB(int idPagamento, long[] idsReembolsos);
    }
}
