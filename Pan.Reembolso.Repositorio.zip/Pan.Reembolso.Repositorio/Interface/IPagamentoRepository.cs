﻿using Pan.Reembolso.Entidades;
using Pan.Reembolso.Entidades.DatabaseEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IPagamentoRepository
    {
        IList<Entidades.Pagamento> ObterPagamentosPorStatus(StatusPagamentoType status);
        Entidades.Pagamento ObterPagamentosPorId(long idPagamento);
        Task<List<Entidades.RetiradaUsoInterno>> ConsultarRetiradaInterna(string cpfCnpj = "", string produto = "");
        Task<List<object>> ConsultarRetiradaInternaPorContrato(string cpfCnpj = "", string codProduto = "");
        DataTable ObterIntegracaoRetiradaDataTable();
        Task PersistirIntegracaoBulk(DataTable retiradasTable);
        void PersistirPagamento(Entidades.Pagamento pagamento);
        void IncluirPagamento(Entidades.Pagamento pagamento);
        Entidades.Pagamento ObterPagamentoPorMensagemTransferencia(Entidades.MensagemTransferencia mensagem);
        void AtualizarPagamento(Entidades.Pagamento pagamento);
        List<Entidades.IntegracaoRetiradaUsoInterno> ConsultarRetiradasPendentesLote();
        void AtualizarIntegracaoRetiradaUsoInternoLote(Entidades.IntegracaoRetiradaUsoInterno integracaoRetiradaUsoInterno);
        IList<Entidades.Pagamento> ObterPagamentoPorCPFCliente(string cpfOuCnpj);
        int GerarNovoLoteIntegracao();
        Task<List<object>> ConsultarLoteRetiradaInterna(int idLote, DateTime? dataIni, DateTime? dataFim, StatusIntegracaoType status);
    }
}
