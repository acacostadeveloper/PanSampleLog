﻿using Pan.Reembolso.Entidades.DatabaseEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Pan.Reembolso.Entidades.ImplementationTypes.ReembolsoTypes;

namespace Pan.Reembolso.Repositorio.Interface
{
    public interface IPagamentoRepository
    {
        IList<Entidades.Pagamento> ObterPagamentosPorStatus(StatusPagamentoType status);
        Entidades.Pagamento ObterPagamentosPorId(long idPagamento);
        Task<List<object>> ConsultarRetiradaInterna(string cpfCnpj = "", string produto = "");
        DataTable ObterIntegracaoRetiradaDataTable();
        Task<string> PersistirIntegracaoBulk(DataTable retiradasTable);
        void PersistirPagamento(Entidades.Pagamento pagamento);

    }
}
