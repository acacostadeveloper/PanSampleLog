USE [IT_Logs]
GO

/****** Object:  Table [dbo].[LogsReembolsoWebAPI]    Script Date: 16/08/2018 14:09:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF EXISTS(SELECT 1 FROM SYSOBJECTS WHERE NAME = 'LogsReembolsoConsoleApp' AND TYPE = 'U')
BEGIN
	DROP TABLE [dbo].[LogsReembolsoConsoleApp]
END 

GO

CREATE TABLE [dbo].[LogsReembolsoConsoleApp](
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[Application] [varchar](50) NULL,
	[BatchTask] [varchar](100) NULL,
	[Machine] [varchar](50) NULL,
	[IpAddress] [varchar](50) NULL,
	[Timestamp] [datetime] NULL,
	[TextLog] [varchar](max) NULL,
	[MessageError] [nvarchar](max) NULL,
 CONSTRAINT [PK_LogsReembolsoConsoleApp] PRIMARY KEY CLUSTERED 
(
	[LogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO
